# 📬 Sistema de Notificaciones - Supramercado

## Comunicación Multi-Canal para Compradores y Beneficiarios

---

## 🎯 Descripción General

El sistema de notificaciones de Supramercado utiliza **dos canales principales**:

1. **Resend** - Para emails transaccionales a compradores (en USA)
2. **Twilio** - Para WhatsApp y SMS a beneficiarios (en República Dominicana)

### Flujo de Notificaciones

```
Payment Succeeds (Stripe Webhook)
         ↓
    ┌────┴────┐
    │         │
  Email     WhatsApp/SMS
    ↓         ↓
 Buyer    Beneficiary
(USA)      (DR)
    │         │
    ↓         ↓
Confirmation  Magic Link
   Email      Message
```

---

## 📧 Configuración de Resend (Emails)

### 1. Crear Cuenta

1. Ve a [resend.com](https://resend.com)
2. Regístrate con tu email
3. Verifica tu cuenta

### 2. Obtener API Key

```
Dashboard → API Keys → Create API Key
```

- **Name**: Supramercado Production
- **Permission**: Full Access
- Copia la API Key (solo se muestra una vez)

### 3. Verificar Dominio

**Opción A: Usar dominio personalizado** (Producción)

```
Dashboard → Domains → Add Domain
```

1. Ingresa tu dominio: `supramercado.com`
2. Agrega los registros DNS:
   ```
   Type: TXT
   Name: resend._domainkey
   Value: [provided by Resend]

   Type: MX
   Name: @
   Value: feedback-smtp.us-east-1.amazonses.com (priority: 10)
   ```
3. Espera verificación (5-30 minutos)

**Opción B: Usar dominio de desarrollo** (Testing)

Resend automáticamente provee `onboarding@resend.dev` para pruebas.

### 4. Configurar Variable de Entorno

```bash
# .env.local
RESEND_API_KEY=re_123456789abcdefghijklmnop
```

### 5. Probar Email

```bash
curl -X POST http://localhost:3000/api/test/send-email \
  -H "Content-Type: application/json" \
  -d '{"to": "tu@email.com"}'
```

---

## 📱 Configuración de Twilio (WhatsApp & SMS)

### 1. Crear Cuenta Twilio

1. Ve a [twilio.com](https://www.twilio.com)
2. Regístrate y verifica tu email/teléfono
3. Completa el formulario inicial

### 2. Obtener Credenciales

```
Console → Account Info
```

Copia:
- **Account SID**: `AC1234567890abcdef`
- **Auth Token**: `your_auth_token_here`

### 3. Configurar WhatsApp Sandbox (Desarrollo)

```
Console → Messaging → Try it out → Send a WhatsApp message
```

1. Escanea el QR code con WhatsApp
2. Envía el mensaje de join: `join [your-code]`
3. Copia el número sandbox: `whatsapp:+14155238886`

### 4. Configurar Número de SMS

```
Console → Phone Numbers → Buy a number
```

1. Selecciona país: **Dominican Republic** (+1-809, +1-829, +1-849)
2. Capabilities: ✅ SMS
3. Compra el número (~$1/mes)
4. Copia el número: `+18091234567`

### 5. Configurar WhatsApp Producción (Opcional)

Para usar WhatsApp en producción:

```
Console → Messaging → WhatsApp → Senders
```

1. Request Access to WhatsApp Business API
2. Completa formulario de aprobación de Facebook
3. Verifica negocio (1-2 semanas)
4. Configura plantillas de mensajes pre-aprobadas

### 6. Configurar Variables de Entorno

```bash
# .env.local
TWILIO_ACCOUNT_SID=AC1234567890abcdef
TWILIO_AUTH_TOKEN=your_auth_token_here

# WhatsApp (sandbox para desarrollo, número aprobado para producción)
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886

# SMS (número comprado)
TWILIO_SMS_NUMBER=+18091234567
```

### 7. Probar WhatsApp

```bash
curl -X POST http://localhost:3000/api/test/send-whatsapp \
  -H "Content-Type: application/json" \
  -d '{
    "to": "+18091234567",
    "beneficiaryName": "María García"
  }'
```

---

## 🔗 Sistema de Magic Links

### Cómo Funcionan

1. **Generación**: Al completar el pago
   ```typescript
   magicLinkCode = `ML-${Date.now()}-${random()}`
   // Ejemplo: ML-1704067200000-X7K9P
   ```

2. **URL**:
   ```
   https://supramercado.com/magic/ML-1704067200000-X7K9P
   ```

3. **Expiración**: 30 días desde la creación

4. **Contenido**:
   - ✅ Información de la orden
   - ✅ Productos incluidos
   - ✅ Código de retiro (6 dígitos)
   - ✅ Ubicación del comercio
   - ✅ Estado de la orden

### Seguridad

- No requiere autenticación (acceso anónimo)
- Código único de 40+ caracteres
- Expira automáticamente
- No se puede modificar la orden desde el magic link
- Solo lectura de información

---

## 📋 Tipos de Notificaciones

### 1. Confirmación de Orden (Email a Comprador)

**Trigger**: Payment succeeds

**Destinatario**: Comprador (en USA)

**Contenido**:
- ✅ Número de orden
- ✅ Total pagado
- ✅ Nombre del beneficiario
- ✅ Comercio
- ✅ Lista de productos
- ✅ Próximos pasos

**Plantilla**: `src/lib/notifications.ts` → `sendOrderConfirmationEmail()`

---

### 2. Magic Link (WhatsApp a Beneficiario)

**Trigger**: Payment succeeds

**Destinatario**: Beneficiario (en DR)

**Contenido**:
```
🛒 Supramercado

¡Hola María! 👋

Te han enviado una orden desde Estados Unidos.

📦 Orden: ORD-20240101-X7K9P
🏪 Comercio: Supermercado La Sirena

🔗 Abre este link para ver los detalles:
https://supramercado.com/magic/ML-1704067200000-X7K9P

Podrás ver:
✅ Productos incluidos
✅ Código de retiro
✅ Ubicación del comercio

¡Gracias por usar Supramercado! 💚
```

**Fallback**: Si WhatsApp falla, envía SMS con mensaje corto

---

### 3. Orden Lista para Recoger (WhatsApp/SMS)

**Trigger**: Merchant marca orden como `ready_for_pickup`

**Destinatario**: Beneficiario (en DR)

**Contenido**:
```
🎉 ¡Tu orden está lista!

Hola María,

Tu orden ya está lista para recoger en:
🏪 Supermercado La Sirena
📍 Av. John F. Kennedy, Santo Domingo

🔐 Código de retiro: 482759

Por favor presenta este código al llegar al comercio.

¡Gracias por usar Supramercado! 💚
```

---

## 🔄 Integración Automática

### En el Webhook de Stripe

El sistema envía notificaciones **automáticamente** cuando un pago es exitoso:

```typescript
// src/app/api/stripe/webhook/route.ts

case 'payment_intent.succeeded': {
  // 1. Actualizar orden
  await prisma.order.update({ status: 'paid' });

  // 2. Enviar email al comprador
  await sendOrderConfirmationEmail({ /* ... */ });

  // 3. Enviar magic link al beneficiario
  await sendMagicLinkWhatsApp({ /* ... */ });
}
```

**Importante**: Las notificaciones están envueltas en try-catch para que **no bloqueen el webhook** si fallan.

---

## 🧪 Testing

### Página de Prueba

```
http://localhost:3000/test-notifications
```

Interfaz para probar:
- ✅ Envío de email de confirmación
- ✅ Envío de WhatsApp con magic link
- ✅ Envío de SMS con magic link
- ✅ Visualización de magic link page

### API Endpoints de Prueba

**Enviar Magic Link**:
```bash
curl -X POST http://localhost:3000/api/notifications/send-magic-link \
  -H "Content-Type: application/json" \
  -H "Cookie: sb-access-token=..." \
  -d '{
    "orderId": "uuid-de-orden"
  }'
```

**Respuesta**:
```json
{
  "success": true,
  "method": "whatsapp",
  "magicLink": "http://localhost:3000/magic/ML-..."
}
```

### Testing con Stripe CLI

```bash
# Simular webhook de pago exitoso
stripe trigger payment_intent.succeeded

# El sistema automáticamente:
# 1. Actualiza orden a 'paid'
# 2. Envía email al comprador
# 3. Envía WhatsApp/SMS al beneficiario
```

---

## 📊 Monitoreo

### Logs de Notificaciones

Todos los intentos de envío se registran en consola:

```
✅ Email sent to buyer@email.com
✅ WhatsApp sent to +18091234567
⚠️ WhatsApp failed, trying SMS fallback
✅ SMS sent to +18091234567
❌ Notification error (non-blocking): [error details]
```

### Métricas Importantes

Monitorear:
- 📧 Tasa de entrega de emails (Resend Dashboard)
- 📱 Tasa de entrega de WhatsApp (Twilio Console)
- 🔗 Magic links abiertos (añadir analytics)
- ⏱️ Tiempo de envío promedio

### Resend Dashboard

```
Dashboard → Logs → Emails
```

Ver:
- Emails enviados
- Emails entregados
- Emails abiertos
- Bounces y quejas

### Twilio Console

```
Console → Messaging → Logs
```

Ver:
- Mensajes enviados
- Estado de entrega
- Errores
- Costos

---

## 💰 Costos

### Resend

- **Plan Gratuito**:
  - 100 emails/día
  - 1 dominio verificado
  - Perfecto para desarrollo y MVP

- **Plan Pro** ($20/mes):
  - 50,000 emails/mes
  - Dominios ilimitados
  - Soporte prioritario

### Twilio

- **WhatsApp**:
  - Conversaciones de negocio: $0.005 por mensaje
  - Conversaciones de usuario: Gratis (primeras 24h)
  - Sandbox: Gratis para desarrollo

- **SMS (República Dominicana)**:
  - Precio: ~$0.04 por mensaje
  - Número local: ~$1/mes

**Estimación para 1000 órdenes/mes**:
- 1000 emails: Gratis (plan gratuito) o incluido en Pro
- 1000 WhatsApp: $5
- 1000 SMS (fallback 20%): $8
- Número de teléfono: $1
- **Total**: ~$14/mes

---

## 🔒 Seguridad

### Variables de Entorno

**Nunca** commitear estas variables:

```bash
# Emails
RESEND_API_KEY=re_...

# SMS/WhatsApp
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_WHATSAPP_NUMBER=whatsapp:+...
TWILIO_SMS_NUMBER=+...

# App
NEXT_PUBLIC_APP_URL=https://supramercado.com
```

### Validación de Acceso

- `/api/notifications/send-magic-link` → Requiere autenticación
- Solo el comprador de la orden puede enviar el magic link
- Magic links no permiten modificar datos

### Rate Limiting

Implementar límites para prevenir abuso:
- Máximo 5 reenvíos de magic link por orden
- Cooldown de 1 minuto entre reenvíos

---

## ⚙️ Configuración en Producción

### 1. Vercel Environment Variables

```
Vercel Dashboard → Project → Settings → Environment Variables
```

Agregar todas las variables listadas arriba.

### 2. Dominio Personalizado

Asegúrate de que `NEXT_PUBLIC_APP_URL` apunte a tu dominio de producción:

```bash
NEXT_PUBLIC_APP_URL=https://supramercado.com
```

### 3. Verificar Dominio en Resend

Completa la verificación DNS antes de desplegar a producción.

### 4. Aprobar WhatsApp en Twilio

Para producción, necesitas aprobación de Facebook Business para WhatsApp.

### 5. Webhook URL

Configura el webhook de Stripe con la URL de producción:

```
https://supramercado.com/api/stripe/webhook
```

---

## 🐛 Troubleshooting

### Email no llega

**Causa**: Dominio no verificado o API key inválida

**Solución**:
1. Verificar dominio en Resend Dashboard
2. Revisar API key en `.env.local`
3. Revisar logs en Resend Dashboard
4. Verificar que el email no está en spam

---

### WhatsApp no llega

**Causa**: Número no registrado en sandbox o plantilla no aprobada

**Solución**:
1. Verificar que enviaste `join [code]` al sandbox
2. Revisar logs en Twilio Console
3. Verificar formato de número: `whatsapp:+1234567890`
4. Para producción, verificar plantillas aprobadas

---

### SMS no llega

**Causa**: Número no configurado o saldo insuficiente

**Solución**:
1. Verificar número en Twilio Console
2. Revisar saldo de cuenta
3. Verificar capabilities del número (SMS enabled)
4. Revisar restricciones de país

---

### Magic Link expirado

**Causa**: Han pasado más de 30 días desde la creación

**Solución**:
1. Re-enviar magic link desde el dashboard
2. El sistema genera nuevo código
3. Actualiza expiración a +30 días

---

### Error: "Twilio not configured"

**Causa**: Variables de entorno faltantes

**Solución**:
```bash
# Verificar que todas estas variables existen:
echo $TWILIO_ACCOUNT_SID
echo $TWILIO_AUTH_TOKEN
echo $TWILIO_WHATSAPP_NUMBER
echo $TWILIO_SMS_NUMBER
```

---

## 📚 Recursos Oficiales

### Resend
- [Documentación](https://resend.com/docs)
- [API Reference](https://resend.com/docs/api-reference)
- [Dashboard](https://resend.com/dashboard)
- [Status Page](https://status.resend.com/)

### Twilio
- [Documentación](https://www.twilio.com/docs)
- [WhatsApp API](https://www.twilio.com/docs/whatsapp)
- [SMS API](https://www.twilio.com/docs/sms)
- [Console](https://console.twilio.com/)
- [Pricing](https://www.twilio.com/pricing)

---

## ✅ Checklist de Configuración

### Desarrollo
- [ ] Cuenta de Resend creada
- [ ] API key de Resend configurada
- [ ] Cuenta de Twilio creada
- [ ] Credenciales de Twilio configuradas
- [ ] WhatsApp sandbox configurado
- [ ] Número de SMS comprado
- [ ] Variables de entorno en `.env.local`
- [ ] Test de email exitoso
- [ ] Test de WhatsApp exitoso
- [ ] Test de SMS exitoso
- [ ] Magic link page funcionando

### Producción
- [ ] Dominio verificado en Resend
- [ ] WhatsApp aprobado por Facebook (si aplica)
- [ ] Variables de entorno en Vercel
- [ ] `NEXT_PUBLIC_APP_URL` apunta a producción
- [ ] Webhook de Stripe configurado
- [ ] Test de flujo completo en producción
- [ ] Monitoreo de logs configurado
- [ ] Alertas configuradas para fallos
- [ ] Rate limiting implementado
- [ ] Documentación entregada al equipo

---

**Prompt 8 Status**: COMPLETADO ✅

**Siguiente**: Prompt 9 - Dashboard de Configuración

**Nota**: Las notificaciones son críticas para la experiencia de usuario. Asegúrate de testear exhaustivamente antes de lanzar a producción.
