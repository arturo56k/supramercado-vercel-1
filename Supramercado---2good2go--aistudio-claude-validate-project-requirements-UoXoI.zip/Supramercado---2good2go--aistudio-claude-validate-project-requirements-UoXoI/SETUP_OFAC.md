# 🛡️ OFAC Screening - Supramercado

## Compliance Automático con Regulaciones de EE.UU.

### ¿Qué es OFAC?

**OFAC** (Office of Foreign Assets Control) es una agencia del Departamento del Tesoro de EE.UU. que administra y hace cumplir las sanciones económicas y comerciales.

La **SDN List** (Specially Designated Nationals and Blocked Persons List) es una lista de individuos y entidades con los que los ciudadanos y empresas estadounidenses tienen **prohibido** hacer negocios.

---

## 🚨 Importancia Legal

### Consecuencias de No Cumplir

- 💰 Multas de hasta **$20 millones** por violación
- ⚖️ Cargos criminales potenciales
- 🚫 Prohibición de operar en EE.UU.
- 📉 Daño reputacional severo

### Requisitos

- ✅ Screening de **100%** de las transacciones
- ✅ Logs de todas las validaciones
- ✅ Actualización periódica de la lista
- ✅ Bloqueo automático de coincidencias

---

## 🔧 Implementación en Supramercado

### 1. Algoritmo de Screening

#### Normalización de Nombres
```typescript
normalizeName("José María García") → "JOSE MARIA GARCIA"
```

Proceso:
1. Remover acentos y diacríticos
2. Convertir a mayúsculas
3. Remover caracteres especiales
4. Normalizar espacios

#### Matching

**Nivel 1: Exact Match**
- Comparación directa con nombre normalizado
- Comparación con aliases normalizados
- Resultado: **BLOQUEADO** inmediatamente

**Nivel 2: Fuzzy Match (Levenshtein)**
- Algoritmo de distancia de edición
- Threshold: 85% similitud
- Resultado: **POTENTIAL_MATCH** (revisión manual)

**Nivel 3: Clear**
- No coincidencias
- Resultado: **CLEAR** (aprobado)

---

## 📊 Flujo de Screening

```
Usuario crea orden
       ↓
Ingresa nombre beneficiario
       ↓
   OFAC Screen
       ↓
  ┌────┴────┐
  │         │
BLOCKED  CLEAR
  │         │
  ↓         ↓
Error    Payment
403      Proceeds
  │         │
  ↓         ↓
 Log      Log
Screen   Screen
```

---

## 🔗 Integración Automática

### En el Checkout

El screening se ejecuta **automáticamente** antes de crear el PaymentIntent:

```typescript
// src/app/api/stripe/create-payment-intent/route.ts

const screeningResult = await screenName(beneficiaryName);

if (screeningResult.result === 'blocked') {
  return NextResponse.json({
    error: 'OFAC_BLOCKED',
    message: 'Transaction blocked due to compliance',
  }, { status: 403 });
}
```

### Logs en Base de Datos

Cada screening se guarda en `ofac_screenings`:
- Nombre validado
- Resultado (clear/potential_match/blocked)
- Detalles de coincidencias
- Timestamp
- Order ID (si aplica)

---

## 🔄 Actualización de la Lista SDN

### Automática (Producción)

**Vercel Cron Job** - Cada domingo a medianoche:

```json
// vercel.json
{
  "crons": [{
    "path": "/api/cron/update-sdn",
    "schedule": "0 0 * * 0"
  }]
}
```

### Manual (Desarrollo)

```bash
curl -X POST http://localhost:3000/api/ofac/update-sdn-list \
  -H "Authorization: Bearer $CRON_SECRET"
```

### Fuente Oficial

```
https://www.treasury.gov/ofac/downloads/sdn.xml
```

La lista completa tiene **~10,000 entradas** que se actualizan semanalmente.

---

## 🧪 Testing

### Página de Prueba

```
http://localhost:3000/test-ofac
```

Interfaz para probar el screening con:
- Nombres de prueba pre-configurados
- Test manual con cualquier nombre
- Visualización de resultados y coincidencias

### Nombres de Prueba

| Nombre | Resultado Esperado |
|--------|-------------------|
| Juan Pérez | ✅ CLEAR |
| Pablo Escobar | 🚫 BLOCKED |
| Maria Rodriguez | ✅ CLEAR |
| ESCOBAR Pablo | 🚫 BLOCKED |

### API Endpoint

```bash
# Test screening
curl -X POST http://localhost:3000/api/ofac/screen \
  -H "Content-Type: application/json" \
  -H "Cookie: sb-access-token=..." \
  -d '{"name": "Pablo Escobar"}'
```

Respuesta BLOCKED:
```json
{
  "result": "blocked",
  "matches": [{
    "entryId": "TEST-001",
    "name": "ESCOBAR, Pablo",
    "similarity": 100,
    "program": "SDNTK",
    "type": "Individual"
  }],
  "message": "Transaction blocked: Name matches OFAC SDN list"
}
```

---

## 📈 Monitoreo

### Dashboard de Screenings

Query para ver screenings recientes:

```sql
SELECT
  screened_name,
  screening_result,
  created_at,
  match_details
FROM ofac_screenings
ORDER BY created_at DESC
LIMIT 100;
```

### Métricas Importantes

- Total de screenings
- Porcentaje de blocked
- Porcentaje de potential_match
- Tiempo promedio de screening

### Alertas

Configurar alertas para:
- 🚨 Cualquier screening **BLOCKED**
- ⚠️ Aumento en **POTENTIAL_MATCH**
- 📉 Fallos en actualización de lista
- ⏱️ Screenings que tomen >2 segundos

---

## 🔒 Seguridad

### Variables de Entorno

```bash
# Cron secret para actualización automática
CRON_SECRET=tu_secret_generado_en_prompt_0
```

### Validación de Acceso

Endpoints protegidos:
- `/api/ofac/screen` → Requiere autenticación
- `/api/ofac/update-sdn-list` → Requiere CRON_SECRET
- `/api/cron/update-sdn` → Requiere CRON_SECRET

---

## ⚙️ Configuración en Producción

### 1. Vercel Deployment

El cron job se configura automáticamente con `vercel.json`.

Verifica en:
```
Vercel Dashboard > Project > Settings > Cron Jobs
```

### 2. Environment Variables

Agregar en Vercel:
```
CRON_SECRET=<tu_secret>
```

### 3. Primera Carga de Datos

Después del deploy, ejecutar manualmente:

```bash
curl -X POST https://tu-dominio.vercel.app/api/ofac/update-sdn-list \
  -H "Authorization: Bearer $CRON_SECRET"
```

### 4. Monitoreo

Revisar logs semanalmente:
```
Vercel Dashboard > Project > Logs
```

Buscar: `SDN list updated`

---

## 🐛 Troubleshooting

### Error: "No SDN entries found"

**Causa**: Lista no inicializada
**Solución**:
```bash
curl -X POST .../api/ofac/update-sdn-list \
  -H "Authorization: Bearer $CRON_SECRET"
```

### Error: "Screening timeout"

**Causa**: Demasiadas entradas en DB
**Solución**:
- Agregar índice en `name_normalized`
- Limitar fuzzy match a top 1000 entradas
- Considerar Algolia o similar para búsqueda

### Falso Positivo

**Causa**: Nombre común coincide parcialmente
**Solución**:
- Aumentar threshold de 85% a 90%
- Revisar y aprobar manualmente
- Agregar whitelist si es necesario

### Actualización falla

**Causa**: Error descargando XML de OFAC
**Solución**:
- Verificar conectividad
- Revisar logs de Vercel
- Reintentar manualmente
- Usar backup de lista si disponible

---

## 📚 Recursos Oficiales

- [OFAC Website](https://ofac.treasury.gov/)
- [SDN List (XML)](https://www.treasury.gov/ofac/downloads/sdn.xml)
- [Compliance Guidelines](https://www.treasury.gov/resource-center/sanctions/Programs/Pages/Programs.aspx)
- [FAQs](https://ofac.treasury.gov/faqs)

---

## ✅ Checklist de Compliance

- [ ] SDN List descargada e inicializada
- [ ] Screening integrado en checkout
- [ ] Logs de screening funcionando
- [ ] Cron job configurado en Vercel
- [ ] Actualización semanal verificada
- [ ] Test de nombres bloqueados exitoso
- [ ] Alertas configuradas
- [ ] Documentación de compliance archivada
- [ ] Equipo legal notificado del sistema
- [ ] Procedimiento de revisión manual establecido

---

## 📋 Política de Compliance

### Acciones ante BLOCKED

1. ❌ Transacción rechazada inmediatamente
2. 📝 Log detallado guardado
3. 🔔 Notificación a equipo de compliance
4. 📧 Email al usuario (sin detalles sensibles)
5. 🚫 Beneficiario marcado en sistema

### Acciones ante POTENTIAL_MATCH

1. ⚠️ Transacción permitida (configurable)
2. 📝 Log guardado para revisión
3. 🔔 Alerta a equipo de compliance
4. 👁️ Revisión manual en 24 horas
5. ✅ Aprobación o bloqueo manual

### Retención de Logs

- Mínimo: **5 años**
- Formato: JSON en base de datos
- Backup: Mensual
- Auditoría: Anual

---

**Prompt 7 Status**: IMPLEMENTADO ✅
**Siguiente**: Prompt 8 - Sistema de Notificaciones

**NOTA LEGAL**: Este sistema es una implementación de referencia. Consulta con tu equipo legal para asegurar compliance completo con regulaciones OFAC y requisitos específicos de tu jurisdicción.
