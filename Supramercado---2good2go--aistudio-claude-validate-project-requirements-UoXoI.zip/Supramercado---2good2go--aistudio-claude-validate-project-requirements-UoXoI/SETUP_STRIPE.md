# 💳 Configuración de Stripe Connect - Supramercado

## Sistema de Pagos con Comisión del 5%

### Arquitectura

```
Cliente (USA) → Stripe → [5% comisión plataforma] → Merchant (RD)
```

---

## 1️⃣ Configurar Stripe Account

### Paso 1: Crear cuenta en Stripe
```
https://dashboard.stripe.com/register
```

### Paso 2: Activar modo Test
- Dashboard > Developers
- Cambiar a "Test mode" (toggle arriba a la derecha)

### Paso 3: Obtener API Keys
```
Dashboard > Developers > API keys
```

Necesitas:
- **Publishable key** (comienza con `pk_test_...`)
- **Secret key** (comienza con `sk_test_...`)

Ya están en tu `.env.local`:
```bash
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51SjFSiPfTdEZFZ8r...
STRIPE_SECRET_KEY=sk_test_51SjFSiPfTdEZFZ8r...
```

---

## 2️⃣ Activar Stripe Connect

### Paso 1: Activar Connect
```
Dashboard > Connect > Get Started
```

### Paso 2: Configurar Connect
1. **Platform name**: Supramercado
2. **Connect type**: Express (más fácil para merchants)
3. **País**: Dominican Republic (DO)

### Paso 3: Branding
- Logo: Subir logo de Supramercado
- Color: #059669 (emerald-600)

---

## 3️⃣ Configurar Webhooks

### ¿Por qué webhooks?
Los webhooks permiten que Stripe notifique a tu aplicación cuando:
- Un pago es exitoso ✅
- Un pago falla ❌
- Un cargo es reembolsado 💸
- Una cuenta Connect cambia de estado 🔄

### Paso 1: Crear Webhook Endpoint

#### Desarrollo (usando Stripe CLI):
```bash
# Instalar Stripe CLI
# macOS
brew install stripe/stripe-cli/stripe

# Windows
scoop install stripe

# Linux
wget https://github.com/stripe/stripe-cli/releases/download/vX.X.X/stripe_X.X.X_linux_x86_64.tar.gz
tar -xvf stripe_X.X.X_linux_x86_64.tar.gz
sudo mv stripe /usr/local/bin

# Login
stripe login

# Forward webhooks a localhost
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Esto te dará un **webhook signing secret** (comienza con `whsec_...`).

Agrégalo a `.env.local`:
```bash
STRIPE_WEBHOOK_SECRET=whsec_...
```

#### Producción:
```
Dashboard > Developers > Webhooks > Add endpoint
```

**URL**: `https://tu-dominio.vercel.app/api/stripe/webhook`

**Eventos a escuchar**:
- `payment_intent.succeeded`
- `payment_intent.payment_failed`
- `charge.refunded`
- `account.updated`

Copia el **Signing secret** y agrégalo en Vercel Environment Variables.

---

## 4️⃣ Configurar Connected Accounts (Merchants)

### Flujo de Onboarding

1. **Merchant se registra** en Supramercado
2. **Admin asigna rol** `MERCHANT_ADMIN`
3. **Merchant inicia onboarding**:
   ```
   POST /api/stripe/create-connect-account
   ```
4. **Stripe genera link** de onboarding
5. **Merchant completa** información en Stripe
6. **Stripe verifica** y activa cuenta
7. **Merchant puede recibir** pagos

### Campos requeridos por Stripe (Express):
- Nombre del negocio
- Email
- Dirección
- Número de identificación fiscal (RNC en RD)
- Información bancaria (para recibir pagos)

---

## 5️⃣ Probar el Flujo de Pagos

### Tarjetas de Test

#### Pago exitoso:
```
Número: 4242 4242 4242 4242
Fecha: cualquier fecha futura (ej: 12/34)
CVC: cualquier 3 dígitos (ej: 123)
ZIP: cualquier código (ej: 12345)
```

#### Pago fallido:
```
Número: 4000 0000 0000 0002
```

#### Requiere autenticación 3D Secure:
```
Número: 4000 0025 0000 3155
```

### Flujo de Test

1. **Login** en la aplicación
2. **Ir a Marketplace** (próximo a implementar)
3. **Agregar productos** al carrito
4. **Seleccionar beneficiario** en RD
5. **Ir a Checkout**
6. **Usar tarjeta de test** 4242...
7. **Confirmar pago**
8. **Ver orden exitosa**

### Verificar en Stripe Dashboard

```
Dashboard > Payments > All payments
```

Deberías ver:
- ✅ Payment Intent creado
- 💰 Monto total
- 📊 Application fee (5%)
- 🏪 Transfer al merchant

---

## 6️⃣ Comisiones y Fees

### Estructura de Costos

Ejemplo: Orden de $100 USD

```
Total pagado por cliente:        $100.00
Stripe fee (2.9% + $0.30):       -$3.20
Platform fee (5% del subtotal):  -$5.00
Transfer al merchant:            $91.80
```

### Configuración Actual

En `src/lib/stripe.ts`:
```typescript
export function calculatePlatformFee(subtotalUSD: number): number {
  return Math.round(subtotalUSD * 0.05 * 100) / 100; // 5%
}
```

Para cambiar la comisión, modifica `0.05` (5%) al porcentaje deseado.

---

## 7️⃣ Endpoints Creados

| Endpoint | Método | Descripción |
|----------|--------|-------------|
| `/api/stripe/create-payment-intent` | POST | Crear pago para orden |
| `/api/stripe/webhook` | POST | Recibir eventos de Stripe |
| `/api/stripe/create-connect-account` | POST | Conectar cuenta de merchant |

### Ejemplo de uso:

```typescript
// Crear payment intent
const response = await fetch('/api/stripe/create-payment-intent', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    merchantId: 'merchant-uuid',
    items: [{ productId: 'p1', price: 10, quantity: 2 }],
    beneficiaryName: 'Juan Pérez',
    beneficiaryPhone: '+18095551234',
  }),
});

const { clientSecret, orderId } = await response.json();
```

---

## 8️⃣ Seguridad

### ✅ Implementado

- **API keys** en variables de entorno (nunca en código)
- **Webhook signature** verification
- **Server-side payment** creation (nunca en cliente)
- **User authentication** requerida
- **Order ownership** validation
- **HTTPS** enforced en producción

### 🔒 Mejores Prácticas

1. **Nunca** expongas `STRIPE_SECRET_KEY` al cliente
2. **Siempre** valida webhook signatures
3. **Verifica** ownership antes de mostrar órdenes
4. **Usa** HTTPS en producción
5. **Revisa** logs de Stripe regularmente

---

## 9️⃣ Monitoreo

### Dashboard de Stripe

```
Dashboard > Payments
```

Métricas importantes:
- 💰 **Revenue** - Ingresos totales
- 📊 **Volume** - Volumen de transacciones
- 🔄 **Refunds** - Reembolsos
- ⚠️ **Disputes** - Disputas

### Logs

```
Dashboard > Developers > Logs
```

Ver:
- API requests
- Webhook deliveries
- Errors

---

## 🔟 Troubleshooting

### Error: "No such destination"
- El merchant no ha completado onboarding
- Verificar `stripeAccountId` en DB
- Revisar estado de cuenta Connect

### Error: "Invalid client secret"
- PaymentIntent expiró (24 horas)
- Crear nuevo payment intent

### Webhook no se recibe
- Verificar URL en Dashboard
- Revisar signing secret
- Usar Stripe CLI para debugging:
  ```bash
  stripe listen --forward-to localhost:3000/api/stripe/webhook
  ```

### Pago exitoso pero orden no se actualiza
- Revisar logs de webhook
- Verificar que el evento se procesó
- Confirmar que `orderId` está en metadata

---

## 📚 Recursos

- [Stripe Connect Docs](https://stripe.com/docs/connect)
- [Payment Intents](https://stripe.com/docs/payments/payment-intents)
- [Webhooks Guide](https://stripe.com/docs/webhooks)
- [Test Cards](https://stripe.com/docs/testing)
- [Stripe CLI](https://stripe.com/docs/stripe-cli)

---

## ✅ Checklist de Configuración

- [ ] Cuenta de Stripe creada
- [ ] API keys agregadas a `.env.local`
- [ ] Stripe Connect activado
- [ ] Webhooks configurados (desarrollo con CLI)
- [ ] Test de pago con tarjeta 4242...
- [ ] Pago exitoso visible en Stripe Dashboard
- [ ] Orden actualizada en base de datos
- [ ] Webhook event recibido correctamente

---

**Prompt 6 Status**: IMPLEMENTADO ✅
**Siguiente**: Prompt 7 - OFAC Screening
