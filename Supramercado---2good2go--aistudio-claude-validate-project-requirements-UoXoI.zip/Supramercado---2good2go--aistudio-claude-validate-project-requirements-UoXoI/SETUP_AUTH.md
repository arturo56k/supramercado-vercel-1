# 🔐 Configuración de Autenticación - Supramercado

## Configuración Completa de Supabase Auth

### 1️⃣ Habilitar Google OAuth en Supabase

#### Paso 1: Ir a Supabase Dashboard
```
https://supabase.com/dashboard/project/xuxkgwfwpqcdjllrtczd/auth/providers
```

#### Paso 2: Configurar Google Provider

1. Click en **Google** en la lista de providers
2. Habilitar el toggle "Enable Sign in with Google"
3. Necesitarás configurar Google OAuth Credentials

---

### 2️⃣ Crear Google OAuth Credentials

#### Paso 1: Ir a Google Cloud Console
```
https://console.cloud.google.com/apis/credentials
```

#### Paso 2: Crear Proyecto (si no tienes uno)
1. Click en el selector de proyecto (arriba)
2. "New Project"
3. Nombre: "Supramercado"
4. Click "Create"

#### Paso 3: Configurar OAuth Consent Screen
1. Ve a "OAuth consent screen" en el menú lateral
2. Selecciona "External"
3. Click "Create"
4. Llena los campos requeridos:
   - **App name**: Supramercado
   - **User support email**: tu@email.com
   - **Developer contact**: tu@email.com
5. Click "Save and Continue"
6. En "Scopes", click "Add or Remove Scopes"
7. Selecciona:
   - `.../auth/userinfo.email`
   - `.../auth/userinfo.profile`
8. Click "Update" y luego "Save and Continue"
9. En "Test users", agrega tu email para testing
10. Click "Save and Continue"

#### Paso 4: Crear OAuth Client ID
1. Ve a "Credentials" en el menú lateral
2. Click "+ CREATE CREDENTIALS" > "OAuth client ID"
3. Application type: "Web application"
4. Name: "Supramercado Web"
5. Authorized JavaScript origins:
   ```
   http://localhost:3000
   https://yourdomain.vercel.app
   ```
6. Authorized redirect URIs:
   ```
   https://xuxkgwfwpqcdjllrtczd.supabase.co/auth/v1/callback
   http://localhost:54321/auth/v1/callback
   ```
7. Click "Create"
8. **GUARDA** el Client ID y Client Secret

---

### 3️⃣ Configurar en Supabase

#### Paso 1: Volver a Supabase Auth Providers
```
https://supabase.com/dashboard/project/xuxkgwfwpqcdjllrtczd/auth/providers
```

#### Paso 2: Configurar Google Provider
1. Pega el **Client ID** de Google
2. Pega el **Client Secret** de Google
3. Click "Save"

---

### 4️⃣ Configurar Magic Links (Email)

#### Paso 1: SMTP Settings (Opcional - Usa servicio de email)
Por defecto, Supabase usa su propio servicio de email (limitado).

Para producción, configura tu propio SMTP:
1. Ve a Project Settings > Auth > SMTP Settings
2. Configura con Resend, SendGrid, o tu proveedor preferido

#### Paso 2: Email Templates
1. Ve a Authentication > Email Templates
2. Personaliza los templates si quieres

---

### 5️⃣ Configurar URL de Redirect

#### En Supabase Dashboard:
```
Authentication > URL Configuration
```

**Site URL**:
```
http://localhost:3000  (desarrollo)
https://tu-dominio.vercel.app  (producción)
```

**Redirect URLs** (agregar ambas):
```
http://localhost:3000/auth/callback
https://tu-dominio.vercel.app/auth/callback
```

---

### 6️⃣ Variables de Entorno

Ya están configuradas en `.env.local`:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://xuxkgwfwpqcdjllrtczd.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
```

---

### 7️⃣ Probar la Autenticación

#### Opción 1: Google OAuth
1. Ir a http://localhost:3000/login
2. Click en "Continuar con Google"
3. Seleccionar cuenta de Google
4. Debería redirigir a /dashboard

#### Opción 2: Magic Link
1. Ir a http://localhost:3000/login
2. Ingresar email
3. Click "Enviar Magic Link"
4. Revisar inbox
5. Click en el link
6. Debería redirigir a /dashboard

---

## 🔒 Rutas Protegidas

Las siguientes rutas requieren autenticación:
- `/dashboard` - Panel principal
- `/marketplace` - Tienda
- `/orders` - Órdenes
- `/profile` - Perfil

Si intentas acceder sin login, te redirige automáticamente a `/login`.

---

## ✅ Checklist de Configuración

- [ ] Google OAuth Client ID creado
- [ ] Google OAuth configurado en Supabase
- [ ] Redirect URLs configuradas en Supabase
- [ ] Site URL configurada
- [ ] Test de login con Google exitoso
- [ ] Test de Magic Link exitoso
- [ ] Usuario sincronizado en tabla `users`

---

## 🐛 Troubleshooting

### Error: "Email link is invalid or has expired"
- Verifica que las redirect URLs en Supabase estén correctas
- Asegúrate de que el link se abre en el mismo navegador

### Error: "Invalid redirect URL"
- Agrega la URL en Supabase Dashboard > Authentication > URL Configuration

### Google OAuth no funciona
- Verifica que el Client ID y Secret estén correctos
- Revisa que las redirect URIs en Google Cloud Console incluyan la URL de Supabase
- Asegúrate de que el proyecto esté en modo "Testing" con tu email agregado

---

## 📚 Recursos

- [Supabase Auth Docs](https://supabase.com/docs/guides/auth)
- [Google OAuth Setup](https://supabase.com/docs/guides/auth/social-login/auth-google)
- [Next.js Auth with Supabase](https://supabase.com/docs/guides/auth/server-side/nextjs)
