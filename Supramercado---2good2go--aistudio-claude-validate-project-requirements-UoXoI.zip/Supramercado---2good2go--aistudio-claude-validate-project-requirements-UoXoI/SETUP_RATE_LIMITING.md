# 🚦 Rate Limiting - Supramercado

## Protección contra Abuso de API con Upstash Redis

---

## 🎯 Descripción General

El sistema de Rate Limiting protege los API endpoints del abuso, ataques DDoS y uso excesivo mediante **Upstash Redis** (serverless Redis) con algoritmo de **Sliding Window**.

### Características Principales

- ⚡ **Serverless Redis** - Sin gestión de infraestructura
- 🪟 **Sliding Window** - Algoritmo más preciso que fixed window
- 🎚️ **Límites por nivel** - Diferentes límites según criticidad del endpoint
- 📊 **Headers informativos** - Cliente sabe cuántas peticiones le quedan
- 🔄 **Graceful degradation** - Si Redis falla, permite peticiones
- 👤 **Por usuario e IP** - Tracking por user ID o IP address
- 📈 **Analytics integrados** - Métricas en Upstash Console

---

## 🏷️ Niveles de Rate Limiting

### Strict (Estricto)
**10 requests / minuto**

Usado en:
- ✅ `/api/stripe/create-payment-intent` - Crear pagos
- ✅ Endpoints de OFAC screening
- ✅ Operaciones financieras críticas

```typescript
// 10 peticiones por minuto por usuario
const rateLimitResult = await checkRateLimit(request, 'strict', userId);
```

---

### Moderate (Moderado)
**30 requests / minuto**

Usado en:
- ✅ `/api/notifications/send-magic-link` - Enviar notificaciones
- ✅ APIs de creación de órdenes
- ✅ Operaciones de escritura estándar

```typescript
// 30 peticiones por minuto por usuario
const rateLimitResult = await checkRateLimit(request, 'moderate', userId);
```

---

### Relaxed (Relajado)
**100 requests / minuto**

Usado en:
- ✅ APIs de lectura públicas
- ✅ Listado de productos
- ✅ Marketplace
- ✅ Operaciones de solo lectura

```typescript
// 100 peticiones por minuto por usuario/IP
const rateLimitResult = await checkRateLimit(request, 'relaxed', userId);
```

---

### Admin (Administrador)
**200 requests / minuto**

Usado en:
- ✅ `/api/admin/config` - Dashboard de configuración
- ✅ APIs administrativas
- ✅ Operaciones de SAAS_ADMIN

```typescript
// 200 peticiones por minuto por admin
const rateLimitResult = await checkRateLimit(request, 'admin', userId);
```

---

## 🛠️ Configuración Inicial

### 1. Crear Cuenta en Upstash

1. Ve a [upstash.com](https://upstash.com)
2. Regístrate con Google o GitHub
3. Verifica tu email

---

### 2. Crear Database Redis

```
Upstash Console → Redis → Create Database
```

**Configuración recomendada:**
- **Name**: `supramercado-ratelimit`
- **Type**: Regional (más barato) o Global (baja latencia mundial)
- **Region**: `us-east-1` (mismo que tu app en Vercel)
- **Eviction**: No Eviction (mantener todos los datos)

Click **Create**

---

### 3. Obtener Credenciales

Después de crear la database:

```
Database Details → REST API
```

Copiar:
- **UPSTASH_REDIS_REST_URL**: `https://us1-xxx.upstash.io`
- **UPSTASH_REDIS_REST_TOKEN**: `AXXXxxx...`

---

### 4. Configurar en .env.local

```bash
# Upstash Redis (Rate Limiting)
UPSTASH_REDIS_REST_URL=https://us1-xxxxxxxxxxxx.upstash.io
UPSTASH_REDIS_REST_TOKEN=AXXXxxx...
```

---

### 5. Configurar en Vercel (Producción)

```
Vercel Dashboard → Project → Settings → Environment Variables

Name: UPSTASH_REDIS_REST_URL
Value: https://us1-xxxxxxxxxxxx.upstash.io
Environment: Production, Preview

Name: UPSTASH_REDIS_REST_TOKEN
Value: AXXXxxx...
Environment: Production, Preview
```

---

### 6. Verificar Conexión

```bash
# Endpoint de prueba
curl http://localhost:3000/api/test/redis-ping

# Respuesta esperada:
{
  "success": true,
  "message": "Redis connection successful"
}
```

---

## 📚 Cómo Usar en tu Código

### Patrón Estándar

```typescript
import { checkRateLimit, createRateLimitResponse } from '@/lib/rate-limit';

export async function POST(request: Request) {
  // 1. Autenticación
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // 2. Rate Limiting
  const rateLimitResult = await checkRateLimit(request, 'moderate', user.id);
  if (!rateLimitResult.success) {
    return createRateLimitResponse(rateLimitResult);
  }

  // 3. Tu lógica de negocio
  const data = await processRequest();

  // 4. Respuesta con headers de rate limit
  const response = NextResponse.json({ data });
  return createRateLimitResponse(rateLimitResult, response);
}
```

---

### Rate Limit por IP (Sin Autenticación)

```typescript
import { checkRateLimit, createRateLimitResponse } from '@/lib/rate-limit';

export async function GET(request: Request) {
  // Rate limit por IP (usuario no autenticado)
  const rateLimitResult = await checkRateLimit(request, 'relaxed');
  if (!rateLimitResult.success) {
    return createRateLimitResponse(rateLimitResult);
  }

  // Tu lógica...
  const response = NextResponse.json({ products });
  return createRateLimitResponse(rateLimitResult, response);
}
```

---

### Rate Limit Personalizado

```typescript
import { customRateLimit } from '@/lib/rate-limit';

// 5 peticiones cada 30 segundos
const result = await customRateLimit(
  `custom:${userId}:action`,
  5,           // max requests
  30 * 1000    // 30 seconds in ms
);

if (!result.success) {
  return NextResponse.json(
    { error: 'Too many requests' },
    { status: 429 }
  );
}
```

---

## 📊 Response Headers

Todos los endpoints protegidos retornan headers informativos:

```http
HTTP/1.1 200 OK
X-RateLimit-Limit: 30
X-RateLimit-Remaining: 27
X-RateLimit-Reset: 1704067260000
```

### Descripción de Headers

| Header | Descripción | Ejemplo |
|--------|-------------|---------|
| `X-RateLimit-Limit` | Límite máximo de peticiones | `30` |
| `X-RateLimit-Remaining` | Peticiones restantes en la ventana actual | `27` |
| `X-RateLimit-Reset` | Unix timestamp cuando se resetea el límite | `1704067260000` |
| `Retry-After` | Segundos a esperar antes de reintentar (solo en 429) | `45` |

---

## 🚫 Error Response (429 Too Many Requests)

Cuando se excede el límite:

```http
HTTP/1.1 429 Too Many Requests
X-RateLimit-Limit: 10
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 1704067320000
Retry-After: 42
```

```json
{
  "error": "Too Many Requests",
  "message": "Rate limit exceeded. Please try again in 42 seconds.",
  "retryAfter": 42,
  "limit": 10,
  "reset": 1704067320000
}
```

---

## 🎚️ Identificadores

El sistema usa diferentes identificadores según el contexto:

### 1. Usuario Autenticado
```
Identificador: user:abc-123-def-456
```

Usado cuando el usuario ha hecho login. Más preciso y difícil de evadir.

### 2. IP Address
```
Identificador: ip:192.168.1.1
```

Usado para usuarios no autenticados. Se extrae de:
1. Header `x-forwarded-for` (Vercel, proxies)
2. Header `x-real-ip`
3. Fallback: `anonymous`

### 3. Custom
```
Identificador: custom:user-123:send-email
```

Para casos especiales (ej: limitar acción específica por usuario).

---

## 🪟 Algoritmo: Sliding Window

### ¿Por qué Sliding Window?

**Fixed Window (Problema):**
```
Minuto 1: [========] 100 requests at 0:59
Minuto 2: [========] 100 requests at 1:00
Total: 200 requests en 1 segundo! 💥
```

**Sliding Window (Solución):**
```
Ventana deslizante de 60 segundos
Cuenta peticiones en los últimos 60s desde NOW
Previene bursts al límite del período
```

### Ventajas

✅ Más preciso que fixed window
✅ Previene bursts al borde de períodos
✅ Distribución más uniforme del tráfico
✅ Mejor experiencia de usuario

---

## 💰 Costos de Upstash

### Plan Gratuito (Free Tier)

- **10,000 commands/día** (~7 commands/min)
- **256 MB de storage**
- **Perfecto para desarrollo y MVP**

### Plan Pro (Pay As You Go)

- **$0.2 por 100,000 requests**
- Sin límites
- Perfecto para producción

### Estimación para Supramercado

```
Tráfico esperado:
- 1,000 usuarios activos/día
- 50 peticiones/usuario/día
- Total: 50,000 peticiones/día

Costo mensual:
50,000 peticiones/día × 30 días = 1,500,000 peticiones/mes
1,500,000 / 100,000 × $0.2 = $3/mes
```

**Conclusión**: ~$3-5/mes para la mayoría de aplicaciones

---

## 🔧 Configuraciones Avanzadas

### Cambiar Límites

Edita `/src/lib/rate-limit.ts`:

```typescript
const RATE_LIMIT_CONFIGS = {
  strict: {
    requests: 20,      // Cambiar de 10 a 20
    window: '1 m',
  },
  moderate: {
    requests: 50,      // Cambiar de 30 a 50
    window: '1 m',
  },
  // ...
};
```

---

### Límites por Hora en lugar de Minuto

```typescript
const RATE_LIMIT_CONFIGS = {
  hourly: {
    requests: 1000,
    window: '1 h',     // 1000 peticiones por hora
  },
};
```

---

### Límites Diferentes para Usuarios Premium

```typescript
import { checkRateLimit } from '@/lib/rate-limit';

const user = await getCurrentUser();
const tier = user.isPremium ? 'relaxed' : 'moderate';

const rateLimitResult = await checkRateLimit(request, tier, user.id);
```

---

### Whitelist de IPs

```typescript
const WHITELISTED_IPS = ['1.2.3.4', '5.6.7.8'];

const ip = request.headers.get('x-forwarded-for')?.split(',')[0];

if (WHITELISTED_IPS.includes(ip)) {
  // Skip rate limiting
} else {
  const rateLimitResult = await checkRateLimit(request, 'moderate');
  // ...
}
```

---

## 📊 Monitoreo

### Upstash Console

```
Console → Database → Metrics
```

Ver:
- **Requests/second** - Tráfico en tiempo real
- **Storage used** - Uso de memoria
- **Daily commands** - Total de comandos por día
- **Top keys** - Qué identificadores usan más límites

---

### Logs de Rate Limiting

En producción, todos los rate limits se loggean:

```bash
# Vercel Logs
⚠️  Rate limit exceeded: user:abc-123 on /api/stripe/create-payment-intent
```

---

### Alertas

Configura alertas en Upstash:

```
Console → Database → Alerts

Condición: Daily commands > 90% of limit
Acción: Email a admin@supramercado.com
```

---

## 🐛 Troubleshooting

### Error: "Redis not configured"

**Síntoma**:
```
⚠️  Upstash Redis not configured. Rate limiting will be disabled.
```

**Solución**:
1. Verificar que `UPSTASH_REDIS_REST_URL` y `UPSTASH_REDIS_REST_TOKEN` estén en `.env.local`
2. Reiniciar servidor: `npm run dev`
3. Verificar sintaxis (no espacios extra, sin comillas)

---

### Error: "429 Too Many Requests" en desarrollo

**Síntoma**: Al desarrollar, llegas rápido al límite

**Soluciones**:

**Opción A**: Aumentar límites temporalmente
```typescript
// En rate-limit.ts (solo para desarrollo)
const RATE_LIMIT_CONFIGS = {
  strict: {
    requests: 9999,  // Límite muy alto para dev
    window: '1 m',
  },
};
```

**Opción B**: Deshabilitar rate limiting en desarrollo
```typescript
// En el endpoint
if (process.env.NODE_ENV === 'development') {
  // Skip rate limiting
} else {
  const rateLimitResult = await checkRateLimit(request, 'strict', user.id);
  // ...
}
```

**Opción C**: Limpiar Redis
```bash
curl -X POST http://localhost:3000/api/admin/clear-rate-limits
```

---

### Rate limit no se aplica

**Síntoma**: Puedes hacer peticiones ilimitadas

**Causas posibles**:
1. Redis no configurado (graceful degradation permite peticiones)
2. En modo desarrollo y límite muy alto
3. Error en el código (forgot to check result)

**Solución**: Verificar logs y configuración

---

### Redis connection timeout

**Síntoma**:
```
Error: Redis connection timeout
```

**Soluciones**:
1. Verificar que la region de Upstash sea cercana a Vercel
2. Revisar status de Upstash: [status.upstash.com](https://status.upstash.com)
3. Verificar credenciales correctas

---

## 🔒 Seguridad

### Prevención de Bypass

**❌ NO hacer**:
```typescript
// Usuario puede cambiar su user ID en el frontend
const { userId } = await request.json();
const result = await checkRateLimit(request, 'moderate', userId);
```

**✅ HACER**:
```typescript
// Obtener user ID del servidor (confiable)
const user = await getCurrentUser();
const result = await checkRateLimit(request, 'moderate', user.id);
```

---

### Rate Limit en Webhooks

Para webhooks de terceros (Stripe, Twilio):

```typescript
// NO aplicar rate limiting a webhooks verificados
const signature = request.headers.get('stripe-signature');
const event = stripe.webhooks.constructEvent(body, signature, secret);

// Si signature es válida, skip rate limiting
// Stripe ya tiene su propio rate limiting
```

---

### DDoS Protection

El rate limiting ayuda pero **NO es suficiente** contra DDoS severo.

Capas de protección:

1. **Vercel Edge** - Protección DDoS automática
2. **Rate Limiting** - Límites por usuario/IP
3. **Cloudflare** (Opcional) - WAF y DDoS protection
4. **Captcha** - Para endpoints públicos sensibles

---

## 🧪 Testing

### Test Manual

```bash
# 1. Hacer 15 peticiones rápidas (límite: 10/min)
for i in {1..15}; do
  curl -X POST http://localhost:3000/api/stripe/create-payment-intent \
    -H "Content-Type: application/json" \
    -H "Cookie: sb-access-token=..." \
    -d '{"merchantId":"...","items":[]}'
  echo ""
done

# Primeras 10: 200 OK
# Últimas 5: 429 Too Many Requests
```

---

### Test Automatizado

```typescript
// tests/rate-limit.test.ts
import { checkRateLimit } from '@/lib/rate-limit';

describe('Rate Limiting', () => {
  it('should block after exceeding limit', async () => {
    const request = new Request('http://localhost:3000/api/test');

    // Hacer 10 peticiones (límite strict)
    for (let i = 0; i < 10; i++) {
      const result = await checkRateLimit(request, 'strict', 'test-user');
      expect(result.success).toBe(true);
    }

    // La 11ª debe fallar
    const result = await checkRateLimit(request, 'strict', 'test-user');
    expect(result.success).toBe(false);
    expect(result.remaining).toBe(0);
  });
});
```

---

## 📋 Checklist de Configuración

### Desarrollo
- [ ] Cuenta de Upstash creada
- [ ] Database Redis creada
- [ ] Credenciales copiadas a `.env.local`
- [ ] Servidor reiniciado
- [ ] Test de conexión exitoso (`/api/test/redis-ping`)
- [ ] Rate limiting aplicado a endpoints críticos
- [ ] Headers de rate limit presentes en respuestas
- [ ] Error 429 funciona correctamente

### Producción
- [ ] Credenciales configuradas en Vercel
- [ ] Database en región cercana a Vercel
- [ ] Límites configurados apropiadamente
- [ ] Monitoring activo en Upstash Console
- [ ] Alertas configuradas
- [ ] Plan de Upstash adecuado para tráfico esperado
- [ ] Logs monitoreando rate limit violations
- [ ] Documentación entregada al equipo

---

## 📖 Recursos

### Upstash
- [Documentación](https://docs.upstash.com/redis)
- [Pricing](https://upstash.com/pricing)
- [Console](https://console.upstash.com)
- [Status Page](https://status.upstash.com)

### Rate Limiting
- [Rate Limiting Algorithms](https://konghq.com/blog/how-to-design-a-scalable-rate-limiting-algorithm)
- [Sliding Window vs Fixed Window](https://blog.cloudflare.com/counting-things-a-lot-of-different-things/)

---

## 🎓 Mejores Prácticas

### 1. Empezar Conservador

```
Empezar con límites bajos
Monitorear durante 1 semana
Ajustar basado en datos reales
```

### 2. Comunicar Límites

```
Documentar límites en tu API docs
Mostrar límites en UI cuando cerca del límite
Email a usuarios que consistentemente llegan al límite
```

### 3. Logs y Alertas

```
Log todos los 429 responses
Alert si >5% de peticiones son 429
Investigar patrones de abuso
```

### 4. Graceful Degradation

```
Si Redis falla, permitir peticiones (fail open)
Loggear errores de Redis
Tener plan de backup
```

---

**Prompt 10 Status**: COMPLETADO ✅

**Siguiente**: Prompt 11 - Security Headers (CSP, HSTS)

**Nota**: Rate limiting es una primera línea de defensa. Combinar con autenticación robusta, validación de input y monitoreo para seguridad completa.
