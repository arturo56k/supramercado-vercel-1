
import React from 'react';
import { MagicLinkView } from '../../components/MagicLinkView';
import { useOrders } from '../../components/OrderContext';

export const RedemptionContainer: React.FC = () => {
  const { orders, merchants } = useOrders();
  // En producción, esto vendría del query param ?code=xxx
  const order = orders[0] || null;
  const merchant = merchants.find(m => m.id === order?.merchantId) || merchants[0];

  if (!order) return <div className="min-h-screen flex items-center justify-center font-black text-slate-300 uppercase tracking-widest">Esperando Magic Link...</div>;

  return (
    <div className="min-h-screen bg-indigo-50/30">
      <div className="max-w-md mx-auto py-10">
        <div className="text-center mb-8">
           <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Supramercado | Redemption</p>
        </div>
        <MagicLinkView 
          order={order} 
          merchant={merchant} 
          onConfirm={() => console.log("Redimido")} 
        />
      </div>
    </div>
  );
};
