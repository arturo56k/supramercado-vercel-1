import React, { useState } from 'react';
import { Home, ShoppingBag, User, Search, ShoppingCart } from 'lucide-react';
import { Landing } from '../../components/Landing';
import { Marketplace } from '../../components/Marketplace';
import { Profile } from '../../components/Profile';
import { CartDrawer } from '../../components/CartDrawer';
import { BeneficiarySelector } from '../../components/BeneficiarySelector';
import { UserOrderTracking } from '../../components/UserOrderTracking';
import { useOrders } from '../../components/OrderContext';
import { Merchant, Product, Beneficiary, UserRole } from '../../packages/types';

export const WebContainer: React.FC = () => {
  const [view, setView] = useState<'HOME' | 'MARKET' | 'PROFILE'>('HOME');
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [selectedBeneficiaryId, setSelectedBeneficiaryId] = useState<string | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { products } = useOrders();

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="max-w-[1600px] mx-auto p-6 lg:p-12 space-y-12">
        <nav className="flex justify-between items-center bg-white p-6 rounded-[2rem] shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-700 rounded-xl flex items-center justify-center text-white font-black italic">S</div>
            <span className="font-black text-xl text-blue-700 tracking-tighter">supramercado.web</span>
          </div>
          <div className="flex gap-4">
             <button onClick={() => setView('HOME')} className={`p-4 rounded-2xl ${view === 'HOME' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}><Home /></button>
             <button onClick={() => setView('MARKET')} className={`p-4 rounded-2xl ${view === 'MARKET' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}><ShoppingBag /></button>
             <button onClick={() => setView('PROFILE')} className={`p-4 rounded-2xl ${view === 'PROFILE' ? 'bg-slate-900 text-white' : 'text-slate-400'}`}><User /></button>
          </div>
        </nav>

        {view === 'HOME' && (
          <>
            <Landing onSelectMerchant={setSelectedMerchant} onBrowseAll={() => setView('MARKET')} />
            <UserOrderTracking />
          </>
        )}
        
        {view === 'MARKET' && (
          <Marketplace selectedBeneficiary={null} onAddToCart={(p) => {}} />
        )}

        {/* Fixed: Use UserRole.CLIENT as a value instead of the 'any' type */}
        {view === 'PROFILE' && <Profile role={UserRole.CLIENT} />}
      </div>
    </div>
  );
};