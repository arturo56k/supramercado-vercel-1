
import React, { useState } from 'react';
import { MerchantHub } from '../../components/MerchantHub';
import { SaaSManagement } from '../../components/SaaSManagement';
import { LayoutDashboard, ShieldCheck, Store } from 'lucide-react';

export const PortalContainer: React.FC = () => {
  const [portalType, setPortalType] = useState<'MERCHANT' | 'SAAS'>('MERCHANT');

  return (
    <div className="min-h-screen bg-[#F1F5F9]">
      <aside className="fixed left-0 top-0 bottom-0 w-64 bg-slate-900 p-8 flex flex-col gap-8 text-white">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white text-slate-900 rounded-xl flex items-center justify-center font-black italic">S</div>
          <span className="font-black text-xl tracking-tighter">supra.portal</span>
        </div>

        <nav className="space-y-2 mt-10">
           <button 
            onClick={() => setPortalType('MERCHANT')}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${portalType === 'MERCHANT' ? 'bg-blue-600' : 'text-slate-400 hover:bg-white/5'}`}
           >
             <Store className="w-5 h-5" /> Terminal Merchant
           </button>
           <button 
            onClick={() => setPortalType('SAAS')}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl font-bold transition-all ${portalType === 'SAAS' ? 'bg-red-600' : 'text-slate-400 hover:bg-white/5'}`}
           >
             <ShieldCheck className="w-5 h-5" /> SaaS Admin
           </button>
        </nav>

        <div className="mt-auto p-6 bg-white/5 rounded-[2rem] border border-white/5">
           <p className="text-[10px] font-black text-slate-500 uppercase">Sistema Operativo</p>
           <p className="text-xs font-bold text-blue-400 mt-1">v2.4.0-stable</p>
        </div>
      </aside>

      <main className="ml-64 p-12">
        {portalType === 'MERCHANT' ? <MerchantHub /> : <SaaSManagement />}
      </main>
    </div>
  );
};
