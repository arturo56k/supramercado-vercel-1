# 🚀 SUPRAMERCADO - PLAN DE IMPLEMENTACIÓN NEXT.JS (1 SEMANA)

**Versión**: Corregida y adaptada para Next.js 15
**Timeline**: 7 días para MVP funcional
**Fecha**: 2025-12-28

---

## ⚡ SCOPE DE 1 SEMANA (MVP)

### ✅ Lo que SÍ implementaremos:
- ✅ Migración a Next.js 15 (App Router)
- ✅ Base de datos Supabase completa
- ✅ Autenticación multi-rol con Supabase Auth
- ✅ Stripe Connect (Direct Charges + Application Fee)
- ✅ OFAC Screening con SDN List
- ✅ API routes seguras (Gemini AI en backend)
- ✅ Security básica (headers, validación, rate limiting)
- ✅ Componentes UI principales migrados

### ⚠️ Lo que pospondremos (post-MVP):
- Subscripciones recurrentes
- Sistema de reviews
- Features sociales (CommunityWall, GratitudeGallery, etc.)
- Wishlist familiar
- E2E testing completo
- Monitoring avanzado (Sentry)
- PWA offline sync

---

## 📅 CRONOGRAMA (7 DÍAS)

| Día | Fase | Entregable |
|-----|------|-----------|
| **Día 1** | Migración a Next.js | Proyecto corriendo en Next.js 15 |
| **Día 2** | Schema Supabase + Auth | Base de datos + Login funcional |
| **Día 3** | Stripe Connect | Pagos reales funcionando |
| **Día 4** | OFAC + API routes | Compliance + IA en backend |
| **Día 5** | Seguridad + Testing | Headers, validación, tests básicos |
| **Día 6** | Integración + Fixes | Flujo end-to-end funcionando |
| **Día 7** | Deploy + Documentación | En producción con docs |

---

## 🏗️ FASE 0: MIGRACIÓN A NEXT.JS (DÍA 1)

### Objetivo:
Convertir el proyecto de Vite + React 19 a Next.js 15 (App Router)

### Pasos:

#### 1. Crear proyecto Next.js base

```bash
# En el directorio padre (fuera de Supramercado---2good2go--aistudio)
npx create-next-app@latest supramercado-nextjs --typescript --tailwind --app --src-dir --import-alias "@/*"

cd supramercado-nextjs
```

Configuración durante setup:
- ✅ TypeScript
- ✅ Tailwind CSS
- ✅ App Router (NO pages router)
- ✅ src/ directory
- ✅ Import alias (@/*)
- ❌ Turbopack (usar Webpack por ahora)

#### 2. Copiar archivos del proyecto actual

```bash
# Desde supramercado-nextjs/
# Copiar componentes
cp -r ../Supramercado---2good2go--aistudio/components ./src/
cp -r ../Supramercado---2good2go--aistudio/utils ./src/
cp ../Supramercado---2good2go--aistudio/types.ts ./src/
cp ../Supramercado---2good2go--aistudio/constants.tsx ./src/

# Copiar assets si existen
cp -r ../Supramercado---2good2go--aistudio/public/* ./public/
```

#### 3. Instalar dependencias adicionales

```bash
npm install @supabase/ssr @supabase/supabase-js
npm install stripe @stripe/stripe-js
npm install @google/generative-ai
npm install zod
npm install papaparse @types/papaparse
npm install lucide-react
npm install date-fns
npm install @upstash/ratelimit @upstash/redis
npm install csv-parse
```

#### 4. Configurar estructura App Router

```typescript
// src/app/layout.tsx
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { OrderProvider } from '@/components/OrderContext';
import { LanguageProvider } from '@/components/LanguageContext';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Supramercado - Envía amor a República Dominicana',
  description: 'Marketplace binacional USA → RD. Compra productos frescos y envía a tus seres queridos.',
  keywords: ['remesas', 'dominicana', 'marketplace', 'envios'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body className={inter.className}>
        <LanguageProvider>
          <OrderProvider>
            {children}
          </OrderProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
```

```typescript
// src/app/page.tsx
import { Landing } from '@/components/Landing';

export default function Home() {
  return <Landing />;
}
```

```typescript
// src/app/marketplace/page.tsx
import { Marketplace } from '@/components/Marketplace';

export default function MarketplacePage() {
  return <Marketplace />;
}
```

```typescript
// src/app/merchant/page.tsx
import { MerchantHub } from '@/components/MerchantHub';
import { ProtectedRoute } from '@/components/ProtectedRoute';

export default function MerchantPage() {
  return (
    <ProtectedRoute allowedRoles={['MERCHANT_ADMIN', 'MERCHANT_EMPLOYEE']}>
      <MerchantHub />
    </ProtectedRoute>
  );
}
```

```typescript
// src/app/redeem/[code]/page.tsx
import { RedeemView } from '@/components/RedeemView';

export default function RedeemPage({ params }: { params: { code: string } }) {
  return <RedeemView magicLinkCode={params.code} />;
}
```

#### 5. Marcar componentes como 'use client'

**IMPORTANTE**: En Next.js App Router, todos los componentes que usan hooks (useState, useEffect, etc.) deben tener `'use client'` al inicio.

Agregar a estos archivos:
- `src/components/OrderContext.tsx`
- `src/components/LanguageContext.tsx`
- `src/components/Login.tsx`
- `src/components/Marketplace.tsx`
- Todos los componentes que usen hooks

```typescript
// Ejemplo: src/components/OrderContext.tsx
'use client';

import { createContext, useState, useContext, ReactNode } from 'react';
// ... resto del código
```

#### 6. Configurar variables de entorno

```bash
# .env.local (crear archivo)
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc... # Solo backend

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_... # Solo backend
STRIPE_WEBHOOK_SECRET=whsec_... # Configurar después de crear webhook

# Google Gemini (SOLO BACKEND - no NEXT_PUBLIC_)
GEMINI_API_KEY=AIza...

# App
NEXT_PUBLIC_URL=http://localhost:3000

# Rate Limiting (Upstash - configurar en Día 5)
UPSTASH_REDIS_URL=
UPSTASH_REDIS_TOKEN=
```

#### 7. Verificar que compila

```bash
npm run dev
```

Visita http://localhost:3000 y verifica que el landing se vea correctamente.

---

## 📊 FASE 1: SUPABASE SCHEMA + AUTH (DÍA 2)

### Parte A: Schema de Base de Datos

#### 1. Crear proyecto en Supabase

1. Ir a https://supabase.com/dashboard
2. Crear nuevo proyecto: `supramercado-prod`
3. Elegir región: `East US` (más cerca de RD)
4. Copiar credenciales a `.env.local`

#### 2. Ejecutar SQL Schema (CORREGIDO)

Ir a SQL Editor en Supabase Dashboard y ejecutar:

```sql
-- ============================================
-- SUPRAMERCADO - SCHEMA COMPLETO
-- ============================================

-- Habilitar extensiones
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- Para fuzzy search (OFAC)

-- ============================================
-- ENUMS
-- ============================================

CREATE TYPE user_role AS ENUM (
  'CLIENT',
  'BENEFICIARY',
  'MERCHANT_ADMIN',
  'MERCHANT_EMPLOYEE',
  'SAAS_ADMIN',
  'SAAS_SUPPORT'
);

CREATE TYPE order_status AS ENUM (
  'pending_payment',
  'paid',
  'ready_for_pickup',
  'redeemed',
  'cancelled',
  'disputed',
  'refunded'
);

CREATE TYPE stripe_account_status AS ENUM (
  'pending',
  'active',
  'restricted',
  'disabled'
);

CREATE TYPE ofac_screening_result AS ENUM (
  'clear',
  'potential_match',
  'blocked'
);

CREATE TYPE reservation_status AS ENUM (
  'active',
  'converted',
  'expired',
  'released'
);

CREATE TYPE payout_status AS ENUM (
  'pending',
  'processing',
  'completed',
  'failed'
);

CREATE TYPE ticket_status AS ENUM (
  'open',
  'in_progress',
  'resolved',
  'closed'
);

CREATE TYPE subscription_status AS ENUM (
  'active',
  'paused',
  'cancelled'
);

-- ============================================
-- TABLAS PRINCIPALES
-- ============================================

-- 1. USERS
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  phone TEXT,
  role user_role NOT NULL DEFAULT 'CLIENT',
  stripe_customer_id TEXT, -- Para buyers
  merchant_id UUID, -- FK agregado después
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. MERCHANTS
CREATE TABLE merchants (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  logo_url TEXT,
  cover_image_url TEXT,
  stripe_account_id TEXT UNIQUE, -- Stripe Connected Account ID
  stripe_account_status stripe_account_status DEFAULT 'pending',
  country TEXT DEFAULT 'DO',
  address JSONB, -- {street, city, province, coordinates: {lat, lng}}
  phone TEXT,
  email TEXT,
  business_hours JSONB, -- {monday: {open: "08:00", close: "18:00"}, ...}
  commission_rate DECIMAL(5, 4) DEFAULT 0.05, -- 5% = 0.0500
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Agregar FK de users a merchants
ALTER TABLE users
  ADD CONSTRAINT fk_merchant FOREIGN KEY (merchant_id) REFERENCES merchants(id);

-- 3. PRODUCTS
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  price_usd DECIMAL(10, 2) NOT NULL,
  category TEXT,
  image_url TEXT,
  is_available BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. INVENTORY
CREATE TABLE inventory (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID UNIQUE NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  quantity_available INTEGER DEFAULT 0 CHECK (quantity_available >= 0),
  quantity_reserved INTEGER DEFAULT 0 CHECK (quantity_reserved >= 0),
  low_stock_threshold INTEGER DEFAULT 5,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. BENEFICIARIES (FALTABA EN DOCUMENTO ORIGINAL)
CREATE TABLE beneficiaries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  relationship TEXT,
  location JSONB, -- {latitude, longitude, address}
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. ORDERS
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number TEXT UNIQUE NOT NULL,
  buyer_id UUID NOT NULL REFERENCES users(id),
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  beneficiary_id UUID REFERENCES beneficiaries(id),
  beneficiary_name TEXT NOT NULL, -- Snapshot para OFAC
  beneficiary_phone TEXT NOT NULL,
  items JSONB NOT NULL, -- [{product_id, name, quantity, unit_price, subtotal}, ...]
  subtotal_usd DECIMAL(10, 2) NOT NULL,
  platform_fee_usd DECIMAL(10, 2) NOT NULL,
  total_usd DECIMAL(10, 2) NOT NULL,
  stripe_payment_intent_id TEXT,
  stripe_charge_id TEXT,
  status order_status DEFAULT 'pending_payment',
  pickup_code TEXT UNIQUE,
  magic_link_code TEXT UNIQUE,
  magic_link_expires_at TIMESTAMPTZ,
  paid_at TIMESTAMPTZ,
  redeemed_at TIMESTAMPTZ,
  redeemed_by UUID REFERENCES users(id), -- Empleado que entregó
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 7. INVENTORY RESERVATIONS
CREATE TABLE inventory_reservations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES products(id),
  order_id UUID REFERENCES orders(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  expires_at TIMESTAMPTZ NOT NULL,
  status reservation_status DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. OFAC SCREENINGS
CREATE TABLE ofac_screenings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id),
  screened_name TEXT NOT NULL,
  screening_result ofac_screening_result NOT NULL,
  screening_provider TEXT DEFAULT 'internal_sdn_list',
  match_details JSONB, -- {sdn_entry_id, match_score, match_type}
  screened_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. SDN ENTRIES (para OFAC)
CREATE TABLE sdn_entries (
  id SERIAL PRIMARY KEY,
  entry_id TEXT UNIQUE NOT NULL, -- ID de OFAC
  name TEXT NOT NULL,
  name_normalized TEXT NOT NULL, -- lowercase, sin acentos
  sdn_type TEXT, -- 'Individual', 'Entity', etc.
  program TEXT, -- Programa de sanciones
  countries TEXT[],
  aliases TEXT[],
  aliases_normalized TEXT[],
  raw_data JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. AUDIT LOGS
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  action TEXT NOT NULL, -- 'order.created', 'order.redeemed', etc.
  entity_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  old_values JSONB,
  new_values JSONB,
  ip_address TEXT,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 11. SUPPORT TICKETS (FALTABA)
CREATE TABLE support_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  merchant_id UUID REFERENCES merchants(id),
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  status ticket_status DEFAULT 'open',
  priority TEXT CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

-- 12. SUBSCRIPTIONS (FALTABA)
CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id),
  beneficiary_id UUID NOT NULL REFERENCES beneficiaries(id),
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  products JSONB NOT NULL, -- [{product_id, quantity}, ...]
  frequency TEXT CHECK (frequency IN ('weekly', 'biweekly', 'monthly')),
  next_billing_date DATE NOT NULL,
  status subscription_status DEFAULT 'active',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 13. WISHLISTS (FALTABA)
CREATE TABLE wishlists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id),
  beneficiary_id UUID NOT NULL REFERENCES beneficiaries(id),
  product_id UUID NOT NULL REFERENCES products(id),
  urgency TEXT CHECK (urgency IN ('low', 'medium', 'high')),
  notes TEXT,
  status TEXT CHECK (status IN ('pending', 'fulfilled', 'cancelled')) DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 14. ORDER REVIEWS (FALTABA)
CREATE TABLE order_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id),
  user_id UUID NOT NULL REFERENCES users(id),
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  photo_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 15. PAYOUTS (FALTABA)
CREATE TABLE payouts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  amount_usd DECIMAL(10, 2) NOT NULL,
  stripe_transfer_id TEXT,
  bank_name TEXT,
  account_last4 TEXT,
  status payout_status DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

-- 16. EMPLOYEE INVITATIONS (FALTABA)
CREATE TABLE employee_invitations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL,
  merchant_id UUID NOT NULL REFERENCES merchants(id),
  invited_by UUID NOT NULL REFERENCES users(id),
  token TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  accepted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- ÍNDICES
-- ============================================

CREATE INDEX idx_orders_merchant_status ON orders(merchant_id, status);
CREATE INDEX idx_orders_buyer ON orders(buyer_id);
CREATE INDEX idx_orders_pickup_code ON orders(pickup_code);
CREATE INDEX idx_orders_magic_link ON orders(magic_link_code) WHERE magic_link_code IS NOT NULL;
CREATE INDEX idx_orders_status_created ON orders(status, created_at DESC);

CREATE INDEX idx_products_merchant ON products(merchant_id, is_available);

CREATE INDEX idx_reservations_expires ON inventory_reservations(expires_at) WHERE status = 'active';

CREATE INDEX idx_sdn_name_normalized ON sdn_entries USING gin(name_normalized gin_trgm_ops);
CREATE INDEX idx_sdn_aliases ON sdn_entries USING gin(aliases_normalized);

CREATE INDEX idx_audit_logs_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at DESC);

-- ============================================
-- FUNCIONES SQL
-- ============================================

-- 1. Generar número de orden
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TEXT AS $$
DECLARE
  new_number TEXT;
  exists_check INTEGER;
BEGIN
  LOOP
    new_number := 'SUPRA-' || LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');
    SELECT COUNT(*) INTO exists_check FROM orders WHERE order_number = new_number;
    EXIT WHEN exists_check = 0;
  END LOOP;
  RETURN new_number;
END;
$$ LANGUAGE plpgsql;

-- 2. Generar código de pickup seguro
CREATE OR REPLACE FUNCTION generate_pickup_code()
RETURNS TEXT AS $$
DECLARE
  chars TEXT := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; -- Sin O, 0, I, 1 para evitar confusión
  result TEXT := '';
  i INTEGER;
BEGIN
  FOR i IN 1..8 LOOP
    result := result || substr(chars, 1 + floor(random() * length(chars))::int, 1);
  END LOOP;
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- 3. Calcular platform fee
CREATE OR REPLACE FUNCTION calculate_platform_fee(
  subtotal DECIMAL,
  commission_rate DECIMAL
)
RETURNS DECIMAL AS $$
BEGIN
  RETURN ROUND(subtotal * commission_rate, 2);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- 4. Búsqueda fuzzy para OFAC
CREATE OR REPLACE FUNCTION search_sdn_fuzzy(
  search_name TEXT,
  similarity_threshold FLOAT DEFAULT 0.8
)
RETURNS TABLE (
  entry_id TEXT,
  name TEXT,
  similarity FLOAT
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    sdn_entries.entry_id,
    sdn_entries.name,
    similarity(sdn_entries.name_normalized, search_name) as sim
  FROM sdn_entries
  WHERE similarity(sdn_entries.name_normalized, search_name) >= similarity_threshold
  ORDER BY sim DESC
  LIMIT 10;
END;
$$ LANGUAGE plpgsql STABLE;

-- 5. Liberar reservas expiradas
CREATE OR REPLACE FUNCTION release_expired_reservations()
RETURNS INTEGER AS $$
DECLARE
  released_count INTEGER;
BEGIN
  UPDATE inventory_reservations
  SET status = 'expired'
  WHERE status = 'active'
    AND expires_at < NOW();

  GET DIAGNOSTICS released_count = ROW_COUNT;

  RETURN released_count;
END;
$$ LANGUAGE plpgsql;

-- 6. Convertir reserva a orden
CREATE OR REPLACE FUNCTION convert_reservations_for_order(
  order_id_param UUID
)
RETURNS VOID AS $$
BEGIN
  UPDATE inventory_reservations
  SET
    status = 'converted',
    order_id = order_id_param
  WHERE order_id IS NULL
    AND status = 'active'
    AND EXISTS (
      SELECT 1 FROM orders
      WHERE id = order_id_param
    );

  -- Actualizar inventory
  UPDATE inventory i
  SET
    quantity_available = quantity_available - COALESCE(
      (SELECT SUM(ir.quantity)
       FROM inventory_reservations ir
       WHERE ir.product_id = i.product_id
         AND ir.order_id = order_id_param
         AND ir.status = 'converted'
      ), 0
    ),
    quantity_reserved = quantity_reserved - COALESCE(
      (SELECT SUM(ir.quantity)
       FROM inventory_reservations ir
       WHERE ir.product_id = i.product_id
         AND ir.order_id = order_id_param
         AND ir.status = 'converted'
      ), 0
    ),
    updated_at = NOW()
  WHERE EXISTS (
    SELECT 1 FROM inventory_reservations ir
    WHERE ir.product_id = i.product_id
      AND ir.order_id = order_id_param
      AND ir.status = 'converted'
  );
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- TRIGGERS
-- ============================================

-- Trigger para updated_at automático
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_merchants_updated_at BEFORE UPDATE ON merchants
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger para audit log en cambios de orden
CREATE OR REPLACE FUNCTION log_order_changes()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'UPDATE' AND OLD.status IS DISTINCT FROM NEW.status THEN
    INSERT INTO audit_logs (
      action,
      entity_type,
      entity_id,
      old_values,
      new_values
    ) VALUES (
      'order.status_changed',
      'order',
      NEW.id,
      jsonb_build_object('status', OLD.status),
      jsonb_build_object('status', NEW.status)
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER log_order_status_changes AFTER UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION log_order_changes();

-- Trigger para crear perfil de usuario al registrarse
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO users (id, email, full_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name'),
    'CLIENT'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- ============================================

-- Habilitar RLS en todas las tablas
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE merchants ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE beneficiaries ENABLE ROW LEVEL SECURITY;

-- Políticas para USERS
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  USING (auth.uid() = id);

-- Políticas para MERCHANTS
CREATE POLICY "Anyone can view active merchants"
  ON merchants FOR SELECT
  USING (is_active = true);

CREATE POLICY "Merchant admins can update own merchant"
  ON merchants FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.merchant_id = merchants.id
        AND users.role = 'MERCHANT_ADMIN'
    )
  );

-- Políticas para PRODUCTS
CREATE POLICY "Anyone can view available products"
  ON products FOR SELECT
  USING (
    is_available = true
    AND EXISTS (
      SELECT 1 FROM merchants
      WHERE merchants.id = products.merchant_id
        AND merchants.is_active = true
    )
  );

CREATE POLICY "Merchant staff can manage products"
  ON products FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.merchant_id = products.merchant_id
        AND users.role IN ('MERCHANT_ADMIN', 'MERCHANT_EMPLOYEE')
    )
  );

-- Políticas para ORDERS
CREATE POLICY "Clients can view own orders"
  ON orders FOR SELECT
  USING (
    buyer_id = auth.uid()
    OR EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.merchant_id = orders.merchant_id
        AND users.role IN ('MERCHANT_ADMIN', 'MERCHANT_EMPLOYEE')
    )
  );

CREATE POLICY "Clients can create orders"
  ON orders FOR INSERT
  WITH CHECK (
    buyer_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM users
      WHERE users.id = auth.uid()
        AND users.role = 'CLIENT'
    )
  );

-- Políticas para INVENTORY
CREATE POLICY "Anyone can view inventory"
  ON inventory FOR SELECT
  USING (true);

CREATE POLICY "Merchant staff can manage inventory"
  ON inventory FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM users u
      JOIN products p ON p.id = inventory.product_id
      WHERE u.id = auth.uid()
        AND u.merchant_id = p.merchant_id
        AND u.role IN ('MERCHANT_ADMIN', 'MERCHANT_EMPLOYEE')
    )
  );

-- Políticas para BENEFICIARIES
CREATE POLICY "Users can manage own beneficiaries"
  ON beneficiaries FOR ALL
  USING (user_id = auth.uid());

-- ============================================
-- DATOS DE PRUEBA
-- ============================================

-- Merchant de prueba
INSERT INTO merchants (
  name,
  slug,
  description,
  logo_url,
  country,
  address,
  phone,
  email,
  business_hours,
  is_active
) VALUES (
  'Colmado El Buen Gusto',
  'colmado-el-buen-gusto',
  'Colmado tradicional dominicano con productos frescos y de calidad',
  'https://images.unsplash.com/photo-1604719312566-8912e9227c6a',
  'DO',
  '{"street": "Calle Duarte #123", "city": "Santiago", "province": "Santiago", "coordinates": {"lat": 19.4517, "lng": -70.6970}}',
  '+1-809-555-0100',
  'info@colmadobuengusto.do',
  '{"monday": {"open": "07:00", "close": "20:00"}, "tuesday": {"open": "07:00", "close": "20:00"}, "wednesday": {"open": "07:00", "close": "20:00"}, "thursday": {"open": "07:00", "close": "20:00"}, "friday": {"open": "07:00", "close": "20:00"}, "saturday": {"open": "07:00", "close": "21:00"}, "sunday": {"open": "08:00", "close": "18:00"}}',
  true
);

-- Obtener el merchant_id
DO $$
DECLARE
  merchant_uuid UUID;
BEGIN
  SELECT id INTO merchant_uuid FROM merchants WHERE slug = 'colmado-el-buen-gusto';

  -- Productos de prueba
  INSERT INTO products (merchant_id, name, description, price_usd, category, image_url, is_available) VALUES
  (merchant_uuid, 'Plátanos Maduros', 'Plátanos maduros frescos del Cibao', 2.50, 'Frutas y Vegetales', 'https://images.unsplash.com/photo-1603833665858-e61d17a86224', true),
  (merchant_uuid, 'Aguacate Dominicano', 'Aguacates criollos de primera calidad', 3.00, 'Frutas y Vegetales', 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578', true),
  (merchant_uuid, 'Mangú Mix', 'Plátanos verdes listos para hacer mangú', 4.50, 'Productos Preparados', 'https://images.unsplash.com/photo-1587334206515-e1b9e75b5e91', true),
  (merchant_uuid, 'Salami Dominicano', 'Salami Induveca 500g', 8.00, 'Carnes y Embutidos', 'https://images.unsplash.com/photo-1607623814075-e51df1bdc82f', true),
  (merchant_uuid, 'Queso de Hoja', 'Queso criollo artesanal de Moca', 12.00, 'Lácteos', 'https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d', true);

  -- Crear inventario para cada producto
  INSERT INTO inventory (product_id, quantity_available, quantity_reserved, low_stock_threshold)
  SELECT id, 100, 0, 10
  FROM products
  WHERE merchant_id = merchant_uuid;
END $$;

-- Mensaje de éxito
SELECT 'Schema creado exitosamente. Merchant y productos de prueba insertados.' AS status;
```

### Parte B: Configuración de Autenticación

#### 1. Habilitar proveedores en Supabase Dashboard

1. Ir a **Authentication > Providers**
2. Habilitar **Email** (con Magic Links)
3. Habilitar **Google OAuth**:
   - Client ID: (obtener de Google Cloud Console)
   - Client Secret: (obtener de Google Cloud Console)
   - Redirect URL: `https://[TU-PROYECTO].supabase.co/auth/v1/callback`
4. Configurar **Site URL**: `http://localhost:3000` (dev) / `https://supramercado.com` (prod)
5. Agregar **Redirect URLs**:
   - `http://localhost:3000/auth/callback`
   - `https://supramercado.com/auth/callback`

#### 2. Crear cliente de Supabase

```typescript
// src/lib/supabase/client.ts
import { createBrowserClient } from '@supabase/ssr';

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
```

```typescript
// src/lib/supabase/server.ts
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';

export function createServerSupabaseClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch (error) {
            // Server Component에서 set 불가능 (middleware에서만)
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: '', ...options });
          } catch (error) {
            // Server Component에서 remove 불가능
          }
        },
      },
    }
  );
}
```

#### 3. Crear middleware para auth

```typescript
// src/middleware.ts
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  let response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value,
            ...options,
          });
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.set({
            name,
            value,
            ...options,
          });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({
            name,
            value: '',
            ...options,
          });
          response = NextResponse.next({
            request: {
              headers: request.headers,
            },
          });
          response.cookies.set({
            name,
            value: '',
            ...options,
          });
        },
      },
    }
  );

  await supabase.auth.getSession();

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
```

#### 4. Implementar hook useAuth

```typescript
// src/hooks/useAuth.ts
'use client';

import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { User } from '@supabase/supabase-js';

export type UserRole =
  | 'CLIENT'
  | 'BENEFICIARY'
  | 'MERCHANT_ADMIN'
  | 'MERCHANT_EMPLOYEE'
  | 'SAAS_ADMIN'
  | 'SAAS_SUPPORT';

export interface AuthUser {
  id: string;
  email: string;
  role: UserRole;
  merchantId?: string;
  fullName?: string;
  avatarUrl?: string;
}

export function useAuth() {
  const supabase = createClient();
  const router = useRouter();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();

      if (session?.user) {
        await loadUserProfile(session.user);
      }

      setLoading(false);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          await loadUserProfile(session.user);
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadUserProfile = async (authUser: User) => {
    const { data: profile } = await supabase
      .from('users')
      .select('*')
      .eq('id', authUser.id)
      .single();

    if (profile) {
      setUser({
        id: authUser.id,
        email: authUser.email!,
        role: profile.role,
        merchantId: profile.merchant_id,
        fullName: profile.full_name,
        avatarUrl: profile.avatar_url,
      });
    }
  };

  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
  };

  const signInWithEmail = async (email: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  return {
    user,
    loading,
    isAuthenticated: !!user,
    signInWithGoogle,
    signInWithEmail,
    signOut,
  };
}
```

#### 5. Crear página de callback

```typescript
// src/app/auth/callback/route.ts
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const next = searchParams.get('next') ?? '/marketplace';

  if (code) {
    const supabase = createServerSupabaseClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  return NextResponse.redirect(`${origin}/auth/error`);
}
```

---

## 💳 FASE 2: STRIPE CONNECT (DÍA 3)

### Configuración Inicial

#### 1. Instalar Stripe CLI

```bash
# macOS
brew install stripe/stripe-cli/stripe

# Login
stripe login
```

#### 2. Configurar webhooks locales

```bash
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Copiar el webhook signing secret a `.env.local`:
```
STRIPE_WEBHOOK_SECRET=whsec_...
```

### Implementación

#### 1. Onboarding de Merchants

```typescript
// src/app/api/stripe/connect/onboard/route.ts
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

export async function POST(req: Request) {
  try {
    const { merchantId, email, businessName } = await req.json();

    // Crear Connected Account
    const account = await stripe.accounts.create({
      type: 'express',
      country: 'US', // Pagan en USD, convierten localmente
      email,
      business_type: 'company',
      company: { name: businessName },
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
      metadata: { merchantId },
    });

    // Guardar en Supabase
    const supabase = createServerSupabaseClient();
    await supabase
      .from('merchants')
      .update({
        stripe_account_id: account.id,
        stripe_account_status: 'pending',
      })
      .eq('id', merchantId);

    // Generar Account Link
    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: `${process.env.NEXT_PUBLIC_URL}/merchant/onboarding/refresh`,
      return_url: `${process.env.NEXT_PUBLIC_URL}/merchant/onboarding/complete`,
      type: 'account_onboarding',
    });

    return NextResponse.json({ url: accountLink.url });
  } catch (error: any) {
    console.error('[Stripe Onboarding Error]', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

#### 2. Checkout con Direct Charge

```typescript
// src/app/api/stripe/checkout/route.ts
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

export async function POST(req: Request) {
  try {
    const { orderId } = await req.json();

    const supabase = createServerSupabaseClient();

    // Obtener orden
    const { data: order, error } = await supabase
      .from('orders')
      .select(`
        *,
        merchant:merchants(stripe_account_id, commission_rate)
      `)
      .eq('id', orderId)
      .single();

    if (error || !order) {
      return NextResponse.json(
        { error: 'Order not found' },
        { status: 404 }
      );
    }

    if (order.status !== 'pending_payment') {
      return NextResponse.json(
        { error: 'Order already processed' },
        { status: 400 }
      );
    }

    // Crear PaymentIntent con Direct Charge
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(order.total_usd * 100), // centavos
      currency: 'usd',
      application_fee_amount: Math.round(order.platform_fee_usd * 100),
      transfer_data: {
        destination: order.merchant.stripe_account_id,
      },
      metadata: {
        orderId: order.id,
        merchantId: order.merchant_id,
        orderNumber: order.order_number,
      },
      automatic_payment_methods: { enabled: true },
    });

    // Actualizar orden
    await supabase
      .from('orders')
      .update({ stripe_payment_intent_id: paymentIntent.id })
      .eq('id', orderId);

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      publishableKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
    });
  } catch (error: any) {
    console.error('[Stripe Checkout Error]', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

#### 3. Webhook Handler

```typescript
// src/app/api/stripe/webhook/route.ts
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { headers } from 'next/headers';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2024-12-18.acacia',
});

export async function POST(req: Request) {
  const body = await req.text();
  const signature = headers().get('stripe-signature')!;

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    console.error('[Webhook Error]', err.message);
    return NextResponse.json(
      { error: 'Invalid signature' },
      { status: 400 }
    );
  }

  const supabase = createServerSupabaseClient();

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const orderId = paymentIntent.metadata.orderId;

      // Actualizar orden
      const { data: order } = await supabase
        .from('orders')
        .update({
          status: 'paid',
          paid_at: new Date().toISOString(),
          stripe_charge_id: paymentIntent.latest_charge as string,
          pickup_code: generatePickupCode(),
          magic_link_code: crypto.randomUUID(),
          magic_link_expires_at: new Date(
            Date.now() + 7 * 24 * 60 * 60 * 1000
          ).toISOString(),
        })
        .eq('id', orderId)
        .select()
        .single();

      // Convertir reservas
      await supabase.rpc('convert_reservations_for_order', {
        order_id_param: orderId,
      });

      // TODO: Enviar magic link (Fase posterior)
      console.log('[Order Paid]', order?.order_number);

      break;
    }

    case 'payment_intent.payment_failed': {
      const paymentIntent = event.data.object as Stripe.PaymentIntent;
      const orderId = paymentIntent.metadata.orderId;

      await supabase
        .from('orders')
        .update({ status: 'cancelled' })
        .eq('id', orderId);

      console.log('[Payment Failed]', orderId);
      break;
    }

    case 'account.updated': {
      const account = event.data.object as Stripe.Account;
      const merchantId = account.metadata.merchantId;

      const status = account.charges_enabled ? 'active' : 'pending';

      await supabase
        .from('merchants')
        .update({ stripe_account_status: status })
        .eq('id', merchantId);

      console.log('[Account Updated]', merchantId, status);
      break;
    }
  }

  return NextResponse.json({ received: true });
}

function generatePickupCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = '';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
```

---

## 🔒 FASE 3: OFAC SCREENING (DÍA 4)

### Script de Actualización SDN List

```typescript
// src/lib/ofac/update-sdn-list.ts
import { createClient } from '@supabase/supabase-js';
import { parse } from 'csv-parse/sync';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY! // Service role para bypass RLS
);

const SDN_CSV_URL = 'https://www.treasury.gov/ofac/downloads/sdn.csv';

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // acentos
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\b(jr|sr|ii|iii|iv|de|del|la|los|las|von|van)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function updateSdnList() {
  console.log('📥 Downloading SDN list...');

  const response = await fetch(SDN_CSV_URL);
  const csvText = await response.text();

  const records = parse(csvText, {
    skip_empty_lines: true,
  });

  console.log(`📊 Found ${records.length} SDN entries`);

  // Limpiar tabla existente
  await supabase.from('sdn_entries').delete().neq('id', 0);

  const entries = records.map((row: string[]) => ({
    entry_id: row[0],
    name: row[1],
    name_normalized: normalizeText(row[1]),
    sdn_type: row[2],
    program: row[3],
    countries: row[4] ? [row[4]] : [],
    aliases: [],
    aliases_normalized: [],
    raw_data: { originalRow: row },
  }));

  // Insertar en batches
  for (let i = 0; i < entries.length; i += 1000) {
    const batch = entries.slice(i, i + 1000);
    await supabase.from('sdn_entries').insert(batch);
    console.log(`✅ Inserted batch ${i / 1000 + 1}`);
  }

  console.log('✅ SDN list updated successfully');
  return entries.length;
}
```

### Servicio de Screening

```typescript
// src/lib/ofac/screening.ts
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

interface ScreeningResult {
  isClean: boolean;
  matches: Array<{
    sdnEntryId: string;
    name: string;
    matchScore: number;
    matchType: 'exact' | 'fuzzy';
  }>;
  screenedAt: Date;
}

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\b(jr|sr|ii|iii|iv|de|del|la|los|las|von|van)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function screenBeneficiary(
  beneficiaryName: string
): Promise<ScreeningResult> {
  const normalized = normalizeText(beneficiaryName);

  // 1. Búsqueda exacta
  const { data: exactMatches } = await supabase
    .from('sdn_entries')
    .select('entry_id, name')
    .eq('name_normalized', normalized);

  if (exactMatches && exactMatches.length > 0) {
    return {
      isClean: false,
      matches: exactMatches.map((m) => ({
        sdnEntryId: m.entry_id,
        name: m.name,
        matchScore: 100,
        matchType: 'exact' as const,
      })),
      screenedAt: new Date(),
    };
  }

  // 2. Búsqueda fuzzy
  const { data: fuzzyMatches } = await supabase.rpc('search_sdn_fuzzy', {
    search_name: normalized,
    similarity_threshold: 0.8,
  });

  if (fuzzyMatches && fuzzyMatches.length > 0) {
    return {
      isClean: false,
      matches: fuzzyMatches.map((m: any) => ({
        sdnEntryId: m.entry_id,
        name: m.name,
        matchScore: Math.round(m.similarity * 100),
        matchType: 'fuzzy' as const,
      })),
      screenedAt: new Date(),
    };
  }

  return {
    isClean: true,
    matches: [],
    screenedAt: new Date(),
  };
}
```

### API Route para Screening

```typescript
// src/app/api/ofac/screen/route.ts
import { screenBeneficiary } from '@/lib/ofac/screening';
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { beneficiaryName, orderId } = await req.json();

    // Realizar screening
    const result = await screenBeneficiary(beneficiaryName);

    // Guardar resultado
    const supabase = createServerSupabaseClient();
    await supabase.from('ofac_screenings').insert({
      order_id: orderId || null,
      screened_name: beneficiaryName,
      screening_result: result.isClean ? 'clear' : 'potential_match',
      screening_provider: 'internal_sdn_list',
      match_details: result.matches.length > 0 ? result.matches : null,
      screened_at: result.screenedAt.toISOString(),
    });

    if (!result.isClean) {
      // TODO: Notificar compliance team
      console.error('[OFAC MATCH]', beneficiaryName, result.matches);
    }

    return NextResponse.json(result);
  } catch (error: any) {
    console.error('[OFAC Screening Error]', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

---

## 🛡️ FASE 4: SEGURIDAD (DÍA 5)

### 1. Mover Gemini AI a Backend

```typescript
// src/app/api/ai/generate/route.ts
import { GoogleGenerativeAI } from '@google/generative-ai';
import { NextResponse } from 'next/server';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function POST(req: Request) {
  try {
    const { prompt, model = 'gemini-3-flash-preview' } = await req.json();

    const aiModel = genAI.getGenerativeModel({ model });
    const result = await aiModel.generateContent(prompt);

    return NextResponse.json({
      text: result.response.text(),
    });
  } catch (error: any) {
    console.error('[AI Generation Error]', error);
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    );
  }
}
```

Refactorizar componentes para usar este endpoint en vez de API key directa.

### 2. Security Headers

```typescript
// next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on',
          },
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload',
          },
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-eval' 'unsafe-inline' https://js.stripe.com",
              "style-src 'self' 'unsafe-inline'",
              "img-src 'self' blob: data: https://images.unsplash.com https://*.supabase.co",
              "font-src 'self'",
              "connect-src 'self' https://*.supabase.co https://api.stripe.com wss://*.supabase.co",
              "frame-src https://js.stripe.com https://hooks.stripe.com",
            ].join('; '),
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
```

### 3. Rate Limiting con Upstash

```bash
# Crear cuenta gratis en upstash.com
# Copiar credenciales a .env.local
```

```typescript
// src/lib/rate-limit.ts
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const redis = new Redis({
  url: process.env.UPSTASH_REDIS_URL!,
  token: process.env.UPSTASH_REDIS_TOKEN!,
});

export const rateLimiters = {
  api: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(20, '1 m'),
    prefix: 'rl:api',
  }),

  auth: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(5, '1 m'),
    prefix: 'rl:auth',
  }),

  checkout: new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(10, '5 m'),
    prefix: 'rl:checkout',
  }),
};
```

```typescript
// Agregar a src/middleware.ts
import { rateLimiters } from '@/lib/rate-limit';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export async function middleware(request: NextRequest) {
  const ip = request.ip ?? '127.0.0.1';
  const path = request.nextUrl.pathname;

  // Rate limiting para API routes
  if (path.startsWith('/api/')) {
    let limiter;

    if (path.startsWith('/api/auth')) {
      limiter = rateLimiters.auth;
    } else if (path.startsWith('/api/stripe/checkout')) {
      limiter = rateLimiters.checkout;
    } else if (path.startsWith('/api/')) {
      limiter = rateLimiters.api;
    }

    if (limiter) {
      const { success, limit, reset, remaining } = await limiter.limit(ip);

      if (!success) {
        return new NextResponse('Too Many Requests', {
          status: 429,
          headers: {
            'X-RateLimit-Limit': limit.toString(),
            'X-RateLimit-Remaining': remaining.toString(),
            'X-RateLimit-Reset': reset.toString(),
          },
        });
      }
    }
  }

  // Supabase auth (código existente)
  // ...

  return NextResponse.next();
}
```

### 4. Validación con Zod

```typescript
// src/lib/validations.ts
import { z } from 'zod';

export const createOrderSchema = z.object({
  merchantId: z.string().uuid(),
  beneficiaryName: z
    .string()
    .min(2, 'Nombre muy corto')
    .max(100, 'Nombre muy largo')
    .regex(/^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s'-]+$/, 'Nombre inválido'),
  beneficiaryPhone: z
    .string()
    .regex(/^\+?[1-9]\d{9,14}$/, 'Teléfono inválido'),
  items: z
    .array(
      z.object({
        productId: z.string().uuid(),
        quantity: z.number().int().min(1).max(100),
      })
    )
    .min(1, 'Debe tener al menos un producto'),
});

// Uso en API route
import { createOrderSchema } from '@/lib/validations';

export async function POST(req: Request) {
  const body = await req.json();

  const result = createOrderSchema.safeParse(body);

  if (!result.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: result.error.flatten() },
      { status: 400 }
    );
  }

  // Continuar con datos validados
  const validatedData = result.data;
  // ...
}
```

---

## 🚀 FASE 5: DEPLOY (DÍA 7)

### 1. Configurar Vercel

```bash
npm install -g vercel
vercel login
vercel
```

Seguir el wizard:
- Link to existing project: No
- Project name: supramercado
- Directory: ./
- Override build command: No
- Override output directory: No

### 2. Agregar variables de entorno en Vercel Dashboard

Ir a Project Settings > Environment Variables y agregar todas las de `.env.local`.

### 3. Deploy

```bash
vercel --prod
```

### 4. Configurar dominio custom (opcional)

En Vercel Dashboard:
- Settings > Domains
- Agregar `supramercado.com`
- Configurar DNS (seguir instrucciones de Vercel)

### 5. Configurar webhooks de Stripe en producción

```bash
stripe listen --forward-to https://supramercado.com/api/stripe/webhook --live
```

O crear webhook en Stripe Dashboard con URL: `https://supramercado.com/api/stripe/webhook`

---

## ✅ CHECKLIST FINAL

- [ ] Proyecto corriendo en Next.js 15
- [ ] Supabase schema ejecutado correctamente
- [ ] Autenticación funcionando (Google + Email)
- [ ] Stripe Connect onboarding funcional
- [ ] Pagos procesándose en modo test
- [ ] OFAC screening bloqueando matches
- [ ] API keys NO expuestas en frontend
- [ ] Security headers aplicados
- [ ] Rate limiting funcionando
- [ ] Deployed en Vercel
- [ ] Webhooks de Stripe configurados
- [ ] DNS configurado (si aplica)

---

## 📝 NOTAS IMPORTANTES

1. **Timeline de 1 semana es ajustado**: Prioriza MVP, features secundarias quedan para iteraciones futuras.

2. **Testing**: Por tiempo, testing E2E se pospone. Hacer testing manual exhaustivo del flujo completo.

3. **Monitoring**: Sentry y analytics se agregan post-MVP.

4. **Features pospuestas**:
   - Subscripciones recurrentes
   - Sistema de reviews
   - Features sociales
   - PWA offline completo
   - N8N/WhatsApp integration

5. **Seguridad**: Lo implementado es suficiente para MVP, pero para escalar considera:
   - Web Application Firewall (Cloudflare)
   - Penetration testing
   - Compliance audit

---

## 🎯 SIGUIENTE PASO

**Ejecutar Fase 0 (Migración a Next.js)** mañana mismo. Una vez tengas el proyecto corriendo en Next.js, las demás fases fluirán naturalmente.

¿Listo para empezar? 🚀
