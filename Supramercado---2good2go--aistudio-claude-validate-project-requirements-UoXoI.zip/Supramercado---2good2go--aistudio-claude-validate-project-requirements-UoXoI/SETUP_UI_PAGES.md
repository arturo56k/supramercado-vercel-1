# 🎨 Páginas Principales - Supramercado

## Implementación completa del diseño con Brand Book v1.0

---

## 📋 Descripción General

Implementación de todas las páginas principales de Supramercado siguiendo fielmente el **Brand Book v1.0**, con:

✅ **Mobile-first design** - Optimizado para móvil primero
✅ **Colores de marca** - Blue #0E5FB2 y Orange #F68606
✅ **Tipografía** - Poppins (headings) + Inter (body)
✅ **Checkout en 4 pasos** - Producto → Beneficiario → Resumen → Pago
✅ **Grid de 8pt** - Espaciado consistente
✅ **Componentes reutilizables** - Botones, cards, inputs
✅ **Sticky CTA** - Botón fijo en mobile para checkout

---

## 🎨 Sistema de Diseño

### Colores Configurados

```typescript
// tailwind.config.ts
colors: {
  primary: "#0E5FB2",        // Azul - Confianza, seguridad
  accent: "#F68606",         // Naranja - Progreso, highlights
  neutral: {
    background: "#F4F6F8",   // Fondo principal
    text: "#4A4A4A",         // Texto secundario
    border: "#E5E7EB",       // Bordes/divisores
  },
  error: "#D92D20",          // Errores críticos
}
```

### Tipografía

```css
/* Headings, Botones */
font-family: "Poppins", system-ui, -apple-system, ...;
font-weight: 400 | 500 | 600 | 700;

/* Body, Párrafos, Formularios */
font-family: "Inter", system-ui, -apple-system, ...;
font-weight: 400 | 500;
```

### Border Radius

```typescript
borderRadius: {
  card: "12px",      // Cards
  button: "14px",    // Botones
  modal: "20px",     // Modales
}
```

### Componentes Globales

```css
/* Botón principal */
.btn-primary {
  background: #0E5FB2;
  color: white;
  border-radius: 14px;
  padding: 12px 24px;
}

/* Botón de acento */
.btn-accent {
  background: #F68606;
  color: white;
}

/* Botón secundario */
.btn-secondary {
  background: white;
  color: #0E5FB2;
  border: 2px solid #0E5FB2;
}

/* Card */
.card {
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.12);
}

/* Input */
.input {
  width: 100%;
  padding: 12px 16px;
  border-radius: 14px;
  border: 1px solid #E5E7EB;
  font-family: "Inter";
}

/* Sticky CTA (móvil) */
.sticky-cta {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: white;
  padding: 16px;
  border-top: 1px solid #E5E7EB;
  z-index: 50;
}
```

---

## 📄 Páginas Implementadas

### 1. Landing Page (`/`)

**Archivo**: `src/app/page.tsx`

**Secciones**:
- **Header** - Logo + Iniciar sesión
- **Hero** - Headline principal con CTAs
- **Features** - 3 beneficios clave
- **How It Works** - 4 pasos explicados
- **Trust Section** - "Yo me encargo"
- **Footer** - Links legales

**Copy Principal**:
```
Headline: "Compra desde EE.UU. y entrégalo hoy en República Dominicana"
Subheadline: "Sin remesas. Sin llamadas. Tú pagas. Nosotros lo resolvemos."
CTA: "Comprar ahora"
```

**Features**:
1. 🛒 Compra en 2 minutos
2. 🚀 Entrega el mismo día
3. ✨ Confirmación inmediata

**Mobile-first**: Hero se adapta a pantallas pequeñas, CTAs en columna.

---

### 2. Marketplace (`/marketplace`)

**Archivo**: `src/app/marketplace/page.tsx`

**Funcionalidad**:
- Lista todos los productos disponibles (`isAvailable: true`)
- Grid responsive (1 col móvil, 2 cols tablet, 3 cols desktop)
- Cada producto muestra:
  - Imagen (o emoji 🛒 si no hay)
  - Nombre y descripción
  - Logo del merchant
  - Precio en USD
  - Botón "Comprar"
- Hover effects en cards

**Query a Base de Datos**:
```typescript
const products = await prisma.product.findMany({
  where: { isAvailable: true },
  include: { merchant: true },
  orderBy: { createdAt: "desc" }
});
```

**Diseño**:
- Header sticky con navegación
- Hero azul con título
- Grid de productos
- Trust banner en footer

---

### 3. Órdenes (`/orders`)

**Archivo**: `src/app/orders/page.tsx`

**Funcionalidad**:
- Historial de órdenes del usuario autenticado
- **Requiere autenticación** (redirect a `/login` si no autenticado)
- Muestra:
  - Número de orden
  - Fecha de creación
  - Estado (con badge de color)
  - Merchant
  - Beneficiario (nombre + teléfono)
  - Total en USD
  - Cantidad de productos
- Botones: "Ver detalles" + "Enlace mágico"

**Estados de Orden**:
```typescript
pending_payment   → Amarillo
paid              → Azul
ready_for_pickup  → Naranja
redeemed          → Verde
cancelled         → Gris
disputed          → Rojo
refunded          → Morado
```

**Query a Base de Datos**:
```typescript
const orders = await prisma.order.findMany({
  where: { buyerId: userId },
  include: { merchant: true },
  orderBy: { createdAt: "desc" }
});
```

---

### 4. Dashboard (`/dashboard`)

**Archivo**: `src/app/dashboard/page.tsx`

**Funcionalidad**:
- Panel principal del usuario autenticado
- **Requiere autenticación**
- Muestra:
  - Welcome message personalizado
  - 3 stats cards:
    - 📦 Órdenes enviadas
    - 💵 Total enviado (USD)
    - 👨‍👩‍👧‍👦 Beneficiarios
  - Acciones rápidas (3 cards con links)
  - Información de cuenta

**Stats Query**:
```typescript
const ordersCount = await prisma.order.count({
  where: { buyerId: userId }
});

const totalSpent = await prisma.order.aggregate({
  where: {
    buyerId: userId,
    status: { in: ["paid", "ready_for_pickup", "redeemed"] }
  },
  _sum: { totalUsd: true }
});

const beneficiariesCount = await prisma.beneficiary.count({
  where: { userId }
});
```

**Diseño**:
- Stats con iconos grandes
- Cards interactivos con hover
- Información legible

---

### 5. Perfil (`/profile`)

**Archivo**: `src/app/profile/page.tsx`

**Secciones**:
1. **Información Personal**:
   - Nombre completo
   - Email
   - Teléfono
   - Tipo de cuenta
   - Botones: Guardar cambios, Cambiar contraseña (disabled)

2. **Mis Beneficiarios**:
   - Lista de beneficiarios guardados
   - Nombre, teléfono, relación
   - Botones: Editar, Eliminar (disabled)
   - Nota: "Se gestiona durante checkout"

3. **Métodos de Pago**:
   - Información de Stripe
   - Nunca almacenamos tarjetas

4. **Zona Peligrosa**:
   - Eliminar cuenta (disabled)
   - Border rojo

**Query de Beneficiarios**:
```typescript
const beneficiaries = await prisma.beneficiary.findMany({
  where: { userId },
  orderBy: { createdAt: "desc" }
});
```

---

### 6. Checkout (`/checkout`)

**Archivo**: `src/app/checkout/page.tsx`

**⭐ Implementación de 4 Pasos Según Brand Book**:

#### Step 1: Producto
- Muestra producto seleccionado
- Imagen, nombre, descripción, precio
- Botón: "Continuar"

#### Step 2: Beneficiario
- Formulario con 2 campos:
  - Nombre completo
  - Teléfono (WhatsApp)
- Copy: "Nombre y teléfono de tu familiar en RD. Ellos no hacen nada."
- Botones: "Atrás" | "Continuar"

#### Step 3: Resumen
- Productos con cantidades
- Beneficiario (card destacado)
- Subtotal
- Comisión 5%
- Total
- Botones: "Atrás" | "Confirmar compra y entregar en RD"

#### Step 4: Pago
- **Stripe Elements** integrado
- Tarjeta de débito/crédito
- Microcopy: "El cargo aparecerá como Supramercado en tu estado de cuenta"

**Características Clave**:
- ✅ Header sin menú (regla del brand book)
- ✅ Indicador de progreso visual
- ✅ Sticky CTA en móvil
- ✅ Auto-avance entre campos (atributos HTML)
- ✅ Validación en cada paso
- ✅ Colores de marca en Stripe Elements

**Stripe Elements Theme**:
```typescript
appearance: {
  theme: "stripe",
  variables: {
    colorPrimary: "#0E5FB2",
    colorBackground: "#ffffff",
    colorText: "#1A1A1A",
    colorDanger: "#D92D20",
    fontFamily: "Inter, system-ui, sans-serif",
    borderRadius: "14px",
  }
}
```

**Flujo de Datos**:
```
1. User clicks producto → /checkout?productId=xxx
2. Fetch product from /api/products/[id]
3. Step 1: Display product
4. Step 2: Collect beneficiary data
5. Step 3: Show summary
6. Step 4: POST /api/stripe/create-payment-intent
7. Stripe Elements renders
8. User pays → Webhook → Success page
```

---

## 🔗 Navegación Entre Páginas

```
┌─────────────┐
│   Landing   │ ──Comprar ahora──> Marketplace
│      /      │
└─────────────┘
       │
   Iniciar sesión
       ↓
┌─────────────┐
│  Dashboard  │ ←─────────────────┐
│ /dashboard  │                   │
└─────────────┘                   │
       │                          │
    3 acciones:                   │
    ├─> Marketplace               │
    ├─> Órdenes                   │
    └─> Perfil ───────────────────┘

Marketplace
    │
    └─> Checkout (4 steps)
            │
            └─> Success (/order/success?orderId=xxx)
```

---

## 📱 Mobile-First Features

### Sticky CTA
```html
<!-- Desktop: normal button -->
<div class="sm:relative sm:bottom-auto sm:border-0 sm:p-0">
  <button class="btn-primary w-full">Continuar</button>
</div>

<!-- Mobile: sticky bottom -->
<div class="sticky-cta">
  <button class="btn-primary w-full">Continuar</button>
</div>
```

### Responsive Grid
```html
<!-- 1 col móvil, 2 tablet, 3 desktop -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
```

### Mostrar Total en CTA (móvil)
Según brand book: el sticky CTA debe mostrar el total.

**TODO**: Actualizar sticky CTA para incluir precio:
```html
<div class="sticky-cta flex items-center justify-between">
  <div>
    <p class="text-xs text-neutral-text">Total</p>
    <p class="text-xl font-bold text-primary">$45.00 USD</p>
  </div>
  <button class="btn-primary">Continuar</button>
</div>
```

---

## 🎯 Detalles de UX del Brand Book

### 1. Sin Menú en Checkout
```typescript
// Header en checkout NO tiene links externos
<header>
  <div className="flex items-center justify-center">
    <Logo /> {/* Solo logo centrado, sin navegación */}
  </div>
</header>
```

### 2. Formularios Optimizados
```html
<!-- Email field -->
<input type="email" inputMode="email" />

<!-- Phone field -->
<input type="tel" inputMode="tel" />

<!-- Auto-focus first field -->
<input autoFocus />
```

### 3. Orden de Campos de Pago
Según brand book:
1. Email
2. Nombre
3. Tarjeta

**Nota**: Stripe Elements ya maneja esto correctamente.

### 4. No Pedir Dirección del Pagador
✅ Implementado: Solo pedimos email en Stripe Elements, no dirección.

### 5. Microcopy Obligatorio
✅ Implementado en Step 4:
```
"El cargo aparecerá como Supramercado en tu estado de cuenta"
```

Esto reduce chargebacks y confusión post-pago.

---

## 🧪 Testing de UI

### Checklist de Páginas

#### Landing (/)
- [ ] Hero con headline correcto
- [ ] 3 features cards
- [ ] 4 steps de "Cómo funciona"
- [ ] Links funcionan (Marketplace, Login)
- [ ] Responsive en móvil

#### Marketplace (/marketplace)
- [ ] Productos se cargan de DB
- [ ] Grid responsive (1/2/3 cols)
- [ ] Hover effects en cards
- [ ] Click en producto → /checkout?productId=xxx

#### Órdenes (/orders)
- [ ] Requiere autenticación
- [ ] Lista órdenes del usuario
- [ ] Estados con colores correctos
- [ ] Links a "Ver detalles" y "Enlace mágico"

#### Dashboard (/dashboard)
- [ ] Requiere autenticación
- [ ] Stats se calculan correctamente
- [ ] 3 acciones rápidas con links
- [ ] Botón "Cerrar sesión" funciona

#### Perfil (/profile)
- [ ] Requiere autenticación
- [ ] Muestra datos del usuario
- [ ] Lista beneficiarios
- [ ] Inputs disabled correctamente

#### Checkout (/checkout)
- [ ] 4 steps se muestran en orden
- [ ] Indicador de progreso visual
- [ ] Validación en Step 2 (nombre + teléfono)
- [ ] Summary correcto en Step 3
- [ ] Stripe Elements se renderiza en Step 4
- [ ] Sticky CTA en móvil
- [ ] Header sin navegación

---

## 🎨 Archivo de Componentes

### Ubicación
```
nextjs-app/
├── tailwind.config.ts        # Tema con colores de marca
├── src/
│   ├── app/
│   │   ├── globals.css        # Componentes globales (btn-primary, card, etc.)
│   │   ├── page.tsx           # Landing
│   │   ├── marketplace/page.tsx
│   │   ├── orders/page.tsx
│   │   ├── dashboard/page.tsx
│   │   ├── profile/page.tsx
│   │   └── checkout/page.tsx  # 4-step checkout
│   └── api/
│       └── products/
│           └── [id]/route.ts  # Endpoint para fetch producto
```

---

## 🚀 Próximos Pasos

### Mejoras de UX
1. **Añadir total en Sticky CTA** (móvil)
2. **Skeleton loaders** en vez de spinners
3. **Animaciones** en transiciones de step
4. **Toast notifications** para feedback
5. **Validación en tiempo real** en formularios

### Funcionalidad Pendiente
1. **Editar perfil** (actualmente disabled)
2. **Gestionar beneficiarios** (CRUD completo)
3. **Buscar/filtrar productos** en marketplace
4. **Categorías** de productos
5. **Página de detalle** de orden (/order/[id])
6. **Success page** mejorada (/order/success)

### SEO y Performance
1. **Metadata** en cada página
2. **Open Graph tags**
3. **Lazy loading** de imágenes
4. **Image optimization** con next/image
5. **Sitemap.xml**

---

## 📚 Recursos del Brand Book

### Copy Library Usado

✅ **Headline**: *Compra desde EE.UU. y entrégalo hoy en República Dominicana.*
✅ **Subheadline**: *Sin remesas. Sin llamadas. Tú pagas. Nosotros lo resolvemos.*
✅ **CTA**: *Comprar ahora* / *Confirmar compra y entregar en RD*
✅ **Confianza**: *Confirmación inmediata*
✅ **Pago**: *El cargo aparecerá como Supramercado*
✅ **Post-pago**: *Tu compra ya está en proceso. Tu familia la recibirá pronto.*

### Reglas Visuales Aplicadas

✅ Mobile-first design
✅ Grid de 8pt
✅ Bordes redondeados (cards 12px, buttons 14px, modals 20px)
✅ Sombras suaves (2 niveles)
✅ Iconografía con emojis (alineado con tono humano y cercano)
✅ Titulares en azul, highlights en naranja

---

## ✅ Checklist Final

- [x] Tema de Tailwind con colores y tipografía del brand book
- [x] Landing page con hero y features
- [x] Marketplace con grid de productos
- [x] Historial de órdenes con estados
- [x] Dashboard con stats
- [x] Perfil con beneficiarios
- [x] Checkout en 4 pasos (Producto → Beneficiario → Resumen → Pago)
- [x] Sticky CTA en móvil
- [x] Header sin navegación en checkout
- [x] Componentes reutilizables (btn-primary, card, input, etc.)
- [x] Mobile-first responsive design
- [x] Stripe Elements con tema de marca
- [x] Copy del brand book aplicado

---

**Prompt 13 Status**: COMPLETADO ✅

**Siguiente**: Prompt 14 - Deploy a Vercel

**Nota**: Todas las páginas siguen el Brand Book v1.0 fielmente. El diseño comunica "Yo me encargo" — cálido, confiable, rápido. Supramercado es un puente emocional, no una remesa.
