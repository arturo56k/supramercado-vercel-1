# 🤖 PROMPTS SECUENCIALES PARA AGENTE - SUPRAMERCADO

**Versión**: Production-Ready con Dashboard de Configuración
**Timeline**: 7 días
**Objetivo**: Proyecto escalable, listo para producción, sin hardcodear credenciales

---

## 🎯 ARQUITECTURA SELECCIONADA (Decisiones Tomadas)

### Stack Tecnológico Optimizado:

**Frontend + Backend:**
- ✅ Next.js 15 (App Router) - SSR + ISR para SEO y performance
- ✅ React Server Components - Reduce bundle size, mejor performance
- ✅ TypeScript - Type safety
- ✅ Tailwind CSS - Ya implementado, mantener

**Base de Datos + Auth:**
- ✅ Supabase PostgreSQL - Gratis hasta 500MB, escalable
- ✅ Supabase Auth - Integrado, multi-provider
- ✅ Prisma ORM - Type-safe queries, mejor DX
- ✅ Row Level Security (RLS) - Seguridad a nivel de DB

**Pagos:**
- ✅ Stripe Connect (Direct Charges + Application Fee)
- ✅ Webhooks centralizados

**Emails/Notificaciones:**
- ✅ Resend - 100 emails/día gratis, mejor para Next.js
- ✅ Twilio WhatsApp - Para magic links a beneficiarios
- ✅ Twilio SMS - Backup si WhatsApp falla

**Cache + Rate Limiting:**
- ✅ Upstash Redis - Serverless, pay-per-use
- ✅ SWR - Client-side caching automático

**Deployment:**
- ✅ Vercel - Auto-scaling, Edge Functions, CDN global
- ✅ Vercel Cron - Background jobs (actualizar SDN list)
- ✅ Vercel Analytics - Gratis, privacy-first

**Monitoring + Logs:**
- ✅ Axiom - Logs estructurados, gratis hasta 100GB/mes
- ✅ Sentry - Error tracking, gratis hasta 5K errors/mes
- ✅ Vercel Speed Insights - Performance monitoring

**Compliance:**
- ✅ OFAC SDN List - Descarga semanal automática
- ✅ Audit logs - Todo evento guardado en DB

### Costos Mensuales Estimados (MVP):
| Servicio | Tier Gratis | Costo Estimado (primeros 6 meses) |
|----------|-------------|-----------------------------------|
| Vercel | Hobby (gratis) | $0 |
| Supabase | Free tier | $0 |
| Upstash Redis | Free tier (10K req/día) | $0 |
| Resend | 100 emails/día | $0 - $20/mes |
| Twilio | Pay-as-you-go | ~$50/mes (500 mensajes) |
| Stripe | Sin costo fijo | 2.9% + $0.30 por transacción |
| Axiom | 100GB gratis | $0 |
| Sentry | 5K errors/mes | $0 |
| **TOTAL** | | **~$50-70/mes** |

---

## 📋 LISTA DE CREDENCIALES NECESARIAS

### ⚠️ Credenciales que DEBES proporcionar:

Crea un archivo `CREDENCIALES_PENDIENTES.md` con esta estructura y llénalo cuando tengas las credenciales:

```markdown
# CREDENCIALES PENDIENTES

## 1. Supabase (Gratis - https://supabase.com)
- [ ] NEXT_PUBLIC_SUPABASE_URL=
- [ ] NEXT_PUBLIC_SUPABASE_ANON_KEY=
- [ ] SUPABASE_SERVICE_ROLE_KEY=

## 2. Stripe (Gratis - https://stripe.com)
- [ ] NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
- [ ] STRIPE_SECRET_KEY=
- [ ] STRIPE_WEBHOOK_SECRET= (se genera después de deploy)

## 3. Google Gemini (Gratis con límites - https://aistudio.google.com/apikey)
- [ ] GEMINI_API_KEY=

## 4. Resend (Gratis 100/día - https://resend.com)
- [ ] RESEND_API_KEY=

## 5. Twilio (Pay-as-you-go - https://twilio.com)
- [ ] TWILIO_ACCOUNT_SID=
- [ ] TWILIO_AUTH_TOKEN=
- [ ] TWILIO_WHATSAPP_NUMBER= (ej: whatsapp:+14155238886)
- [ ] TWILIO_SMS_NUMBER= (ej: +15017122661)

## 6. Upstash Redis (Gratis - https://upstash.com)
- [ ] UPSTASH_REDIS_URL=
- [ ] UPSTASH_REDIS_TOKEN=

## 7. Axiom (Gratis 100GB - https://axiom.co)
- [ ] AXIOM_TOKEN=
- [ ] AXIOM_DATASET=supramercado-logs

## 8. Sentry (Gratis 5K errors - https://sentry.io)
- [ ] NEXT_PUBLIC_SENTRY_DSN=
- [ ] SENTRY_AUTH_TOKEN=

## 9. Google OAuth (Gratis - https://console.cloud.google.com)
- [ ] GOOGLE_CLIENT_ID=
- [ ] GOOGLE_CLIENT_SECRET=

## 10. Vercel (Gratis - se configura automáticamente)
- Se configura con `vercel login`
```

### 🔐 Sistema de Configuración Seguro

**IMPORTANTE**: Las credenciales se guardarán en:
1. **Desarrollo**: Archivo `.env.local` (git-ignored)
2. **Producción**: Vercel Environment Variables (encriptadas)
3. **Dashboard Admin**: Base de datos (encriptadas con AES-256)

El dashboard permitirá actualizar credenciales sin redeploy.

---

## 🚀 PROMPTS SECUENCIALES

### PROMPT 0: Preparación del Entorno

**Objetivo**: Crear proyecto Next.js base y configurar git

**Comando para ejecutar**:
```bash
# En el directorio padre (fuera del proyecto Vite actual)
npx create-next-app@latest supramercado-nextjs \
  --typescript \
  --tailwind \
  --app \
  --src-dir \
  --import-alias "@/*" \
  --no-turbopack

cd supramercado-nextjs

# Inicializar git
git init
git add .
git commit -m "chore: initial Next.js 15 setup"

# Crear branch de desarrollo
git checkout -b development
```

**Verificación**:
```bash
npm run dev
# Debe abrir en http://localhost:3000
```

**Checklist**:
- [ ] Proyecto Next.js 15 creado
- [ ] TypeScript configurado
- [ ] Tailwind CSS funcionando
- [ ] App Router habilitado
- [ ] Git inicializado

---

### PROMPT 1: Instalar Dependencias y Configurar Prisma

**Objetivo**: Instalar todas las dependencias necesarias y configurar Prisma como ORM

**Comando para ejecutar**:
```bash
# Dependencias de producción
npm install \
  @supabase/ssr \
  @supabase/supabase-js \
  @prisma/client \
  stripe \
  @stripe/stripe-js \
  @google/generative-ai \
  zod \
  papaparse \
  lucide-react \
  date-fns \
  @upstash/ratelimit \
  @upstash/redis \
  csv-parse \
  resend \
  twilio \
  swr \
  crypto-js \
  nanoid

# Dependencias de desarrollo
npm install -D \
  @types/papaparse \
  @types/crypto-js \
  prisma \
  tsx

# Inicializar Prisma
npx prisma init
```

**Crear schema de Prisma**:

Crea archivo `prisma/schema.prisma`:

```prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")
  directUrl = env("DIRECT_URL")
}

// Enums
enum UserRole {
  CLIENT
  BENEFICIARY
  MERCHANT_ADMIN
  MERCHANT_EMPLOYEE
  SAAS_ADMIN
  SAAS_SUPPORT
}

enum OrderStatus {
  pending_payment
  paid
  ready_for_pickup
  redeemed
  cancelled
  disputed
  refunded
}

enum StripeAccountStatus {
  pending
  active
  restricted
  disabled
}

// Models
model User {
  id               String    @id @db.Uuid
  email            String    @unique
  fullName         String?   @map("full_name")
  phone            String?
  role             UserRole  @default(CLIENT)
  stripeCustomerId String?   @map("stripe_customer_id")
  merchantId       String?   @map("merchant_id") @db.Uuid
  avatarUrl        String?   @map("avatar_url")
  createdAt        DateTime  @default(now()) @map("created_at")
  updatedAt        DateTime  @updatedAt @map("updated_at")

  merchant      Merchant?       @relation(fields: [merchantId], references: [id])
  orders        Order[]
  beneficiaries Beneficiary[]
  auditLogs     AuditLog[]

  @@map("users")
}

model Merchant {
  id                   String               @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  name                 String
  slug                 String               @unique
  description          String?
  logoUrl              String?              @map("logo_url")
  coverImageUrl        String?              @map("cover_image_url")
  stripeAccountId      String?              @unique @map("stripe_account_id")
  stripeAccountStatus  StripeAccountStatus? @default(pending) @map("stripe_account_status")
  country              String               @default("DO")
  address              Json?
  phone                String?
  email                String?
  businessHours        Json?                @map("business_hours")
  commissionRate       Decimal              @default(0.05) @db.Decimal(5, 4)
  isActive             Boolean              @default(true) @map("is_active")
  createdAt            DateTime             @default(now()) @map("created_at")
  updatedAt            DateTime             @updatedAt @map("updated_at")

  staff    User[]
  products Product[]
  orders   Order[]

  @@map("merchants")
}

model Product {
  id          String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  merchantId  String   @map("merchant_id") @db.Uuid
  name        String
  description String?
  priceUsd    Decimal  @map("price_usd") @db.Decimal(10, 2)
  category    String?
  imageUrl    String?  @map("image_url")
  isAvailable Boolean  @default(true) @map("is_available")
  createdAt   DateTime @default(now()) @map("created_at")
  updatedAt   DateTime @updatedAt @map("updated_at")

  merchant  Merchant   @relation(fields: [merchantId], references: [id], onDelete: Cascade)
  inventory Inventory?

  @@map("products")
}

model Inventory {
  id                  String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  productId           String   @unique @map("product_id") @db.Uuid
  quantityAvailable   Int      @default(0) @map("quantity_available")
  quantityReserved    Int      @default(0) @map("quantity_reserved")
  lowStockThreshold   Int      @default(5) @map("low_stock_threshold")
  updatedAt           DateTime @updatedAt @map("updated_at")

  product Product @relation(fields: [productId], references: [id], onDelete: Cascade)

  @@map("inventory")
}

model Beneficiary {
  id        String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  userId    String   @map("user_id") @db.Uuid
  name      String
  phone     String
  relationship String?
  location  Json?
  createdAt DateTime @default(now()) @map("created_at")
  updatedAt DateTime @updatedAt @map("updated_at")

  user   User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  orders Order[]

  @@map("beneficiaries")
}

model Order {
  id                    String      @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  orderNumber           String      @unique @map("order_number")
  buyerId               String      @map("buyer_id") @db.Uuid
  merchantId            String      @map("merchant_id") @db.Uuid
  beneficiaryId         String?     @map("beneficiary_id") @db.Uuid
  beneficiaryName       String      @map("beneficiary_name")
  beneficiaryPhone      String      @map("beneficiary_phone")
  items                 Json
  subtotalUsd           Decimal     @map("subtotal_usd") @db.Decimal(10, 2)
  platformFeeUsd        Decimal     @map("platform_fee_usd") @db.Decimal(10, 2)
  totalUsd              Decimal     @map("total_usd") @db.Decimal(10, 2)
  stripePaymentIntentId String?     @map("stripe_payment_intent_id")
  stripeChargeId        String?     @map("stripe_charge_id")
  status                OrderStatus @default(pending_payment)
  pickupCode            String?     @unique @map("pickup_code")
  magicLinkCode         String?     @unique @map("magic_link_code")
  magicLinkExpiresAt    DateTime?   @map("magic_link_expires_at")
  paidAt                DateTime?   @map("paid_at")
  redeemedAt            DateTime?   @map("redeemed_at")
  redeemedBy            String?     @map("redeemed_by") @db.Uuid
  notes                 String?
  createdAt             DateTime    @default(now()) @map("created_at")
  updatedAt             DateTime    @updatedAt @map("updated_at")

  buyer        User         @relation(fields: [buyerId], references: [id])
  merchant     Merchant     @relation(fields: [merchantId], references: [id])
  beneficiary  Beneficiary? @relation(fields: [beneficiaryId], references: [id])
  ofacScreening OfacScreening[]

  @@map("orders")
}

model OfacScreening {
  id               String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  orderId          String?  @map("order_id") @db.Uuid
  screenedName     String   @map("screened_name")
  screeningResult  String   @map("screening_result")
  screeningProvider String  @default("internal_sdn_list") @map("screening_provider")
  matchDetails     Json?    @map("match_details")
  screenedAt       DateTime @default(now()) @map("screened_at")
  createdAt        DateTime @default(now()) @map("created_at")

  order Order? @relation(fields: [orderId], references: [id])

  @@map("ofac_screenings")
}

model SdnEntry {
  id                Int      @id @default(autoincrement())
  entryId           String   @unique @map("entry_id")
  name              String
  nameNormalized    String   @map("name_normalized")
  sdnType           String?  @map("sdn_type")
  program           String?
  countries         String[]
  aliases           String[]
  aliasesNormalized String[] @map("aliases_normalized")
  rawData           Json?    @map("raw_data")
  createdAt         DateTime @default(now()) @map("created_at")
  updatedAt         DateTime @updatedAt @map("updated_at")

  @@map("sdn_entries")
}

model AuditLog {
  id         String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  userId     String?  @map("user_id") @db.Uuid
  action     String
  entityType String   @map("entity_type")
  entityId   String   @map("entity_id") @db.Uuid
  oldValues  Json?    @map("old_values")
  newValues  Json?    @map("new_values")
  ipAddress  String?  @map("ip_address")
  userAgent  String?  @map("user_agent")
  createdAt  DateTime @default(now()) @map("created_at")

  user User? @relation(fields: [userId], references: [id])

  @@map("audit_logs")
}

model PlatformConfig {
  id          String   @id @default(dbgenerated("uuid_generate_v4()")) @db.Uuid
  key         String   @unique
  value       String   // Encriptado
  category    String   // 'stripe', 'gemini', 'twilio', etc.
  isActive    Boolean  @default(true) @map("is_active")
  description String?
  createdAt   DateTime @default(now()) @map("created_at")
  updatedAt   DateTime @updatedAt @map("updated_at")

  @@map("platform_config")
}
```

**Crear archivo de utilidad de Prisma**:

Crea `src/lib/prisma.ts`:

```typescript
import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;
```

**Verificación**:
```bash
# Generar cliente de Prisma (fallará hasta tener DATABASE_URL)
npx prisma generate
```

**Checklist**:
- [ ] Dependencias instaladas
- [ ] Prisma schema creado
- [ ] Prisma client configurado
- [ ] package.json actualizado

---

### PROMPT 2: Configurar Variables de Entorno y Estructura

**Objetivo**: Crear estructura de carpetas y archivos de configuración

**Comando para ejecutar**:
```bash
# Crear estructura de carpetas
mkdir -p src/{app,components,lib,hooks,types,utils}
mkdir -p src/app/{api,auth,marketplace,merchant,admin,redeem}
mkdir -p src/app/api/{stripe,ofac,ai,webhooks,admin}
mkdir -p src/lib/{supabase,stripe,ofac,email,sms,encryption}
mkdir -p src/components/{ui,admin,merchant,client}

# Crear archivos de configuración
touch .env.local
touch .env.example
touch .gitignore.append
```

**Crear `.env.example`**:

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...
DATABASE_URL=postgresql://postgres:[PASSWORD]@db.xxx.supabase.co:5432/postgres
DIRECT_URL=postgresql://postgres:[PASSWORD]@db.xxx.supabase.co:5432/postgres

# Stripe
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Google Gemini
GEMINI_API_KEY=AIza...

# Resend (Email)
RESEND_API_KEY=re_...
RESEND_FROM_EMAIL=noreply@supramercado.com

# Twilio (WhatsApp/SMS)
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886
TWILIO_SMS_NUMBER=+1...

# Upstash Redis
UPSTASH_REDIS_URL=https://xxx.upstash.io
UPSTASH_REDIS_TOKEN=...

# Axiom (Logging)
AXIOM_TOKEN=xaat-...
AXIOM_DATASET=supramercado-logs

# Sentry (Error Tracking)
NEXT_PUBLIC_SENTRY_DSN=https://xxx@sentry.io/xxx
SENTRY_AUTH_TOKEN=...

# Google OAuth
GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...

# App
NEXT_PUBLIC_URL=http://localhost:3000
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=generarandom32chars

# Encryption Key (generar con: openssl rand -base64 32)
ENCRYPTION_KEY=...
```

**Actualizar `.gitignore`**:

```bash
echo "
# Local env files
.env*.local
.env
CREDENCIALES_PENDIENTES.md

# Prisma
prisma/*.db
prisma/*.db-journal

# Logs
logs
*.log
axiom.log
" >> .gitignore
```

**Verificación**:
```bash
# Verificar que no se commiteen archivos sensibles
git status | grep -E "\.env|CREDENCIALES"
# No debe retornar nada
```

**Checklist**:
- [ ] Estructura de carpetas creada
- [ ] `.env.example` creado
- [ ] `.gitignore` actualizado
- [ ] Archivos sensibles NO en git

---

### PROMPT 3: Copiar Componentes del Proyecto Vite

**Objetivo**: Migrar componentes existentes y adaptarlos a Next.js

**Comando para ejecutar**:
```bash
# Copiar componentes (desde el directorio del proyecto Vite)
cp -r ../Supramercado---2good2go--aistudio/components/* src/components/
cp ../Supramercado---2good2go--aistudio/types.ts src/types/
cp ../Supramercado---2good2go--aistudio/constants.tsx src/lib/constants.ts
cp -r ../Supramercado---2good2go--aistudio/utils/* src/utils/
```

**Adaptar componentes a Next.js**:

Crea script `scripts/add-use-client.ts`:

```typescript
import fs from 'fs';
import path from 'path';

const componentsDir = path.join(process.cwd(), 'src/components');

const hooksPatterns = [
  'useState',
  'useEffect',
  'useContext',
  'useReducer',
  'useCallback',
  'useMemo',
  'useRef',
  'useLayoutEffect',
];

function processFile(filePath: string) {
  const content = fs.readFileSync(filePath, 'utf-8');

  // Check if file already has 'use client'
  if (content.includes("'use client'")) {
    return;
  }

  // Check if file uses hooks
  const usesHooks = hooksPatterns.some(pattern => content.includes(pattern));

  if (usesHooks) {
    const newContent = `'use client';\n\n${content}`;
    fs.writeFileSync(filePath, newContent, 'utf-8');
    console.log(`✅ Added 'use client' to: ${path.basename(filePath)}`);
  }
}

function walkDirectory(dir: string) {
  const files = fs.readdirSync(dir);

  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      walkDirectory(filePath);
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      processFile(filePath);
    }
  });
}

walkDirectory(componentsDir);
console.log('✅ Finished processing components');
```

**Ejecutar script**:
```bash
npx tsx scripts/add-use-client.ts
```

**Actualizar imports en components**:

Crea script `scripts/fix-imports.ts`:

```typescript
import fs from 'fs';
import path from 'path';

const componentsDir = path.join(process.cwd(), 'src/components');

function fixImports(filePath: string) {
  let content = fs.readFileSync(filePath, 'utf-8');

  // Fix relative imports to use @/
  content = content.replace(/from ['"]\.\.\/types['"]/g, "from '@/types'");
  content = content.replace(/from ['"]\.\.\/constants['"]/g, "from '@/lib/constants'");
  content = content.replace(/from ['"]\.\.\/utils\//g, "from '@/utils/");
  content = content.replace(/from ['"]\.\//g, "from '@/components/");

  // Fix Vite env vars to Next.js
  content = content.replace(/import\.meta\.env\.VITE_/g, 'process.env.NEXT_PUBLIC_');

  fs.writeFileSync(filePath, content, 'utf-8');
}

function walkDirectory(dir: string) {
  const files = fs.readdirSync(dir);

  files.forEach(file => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);

    if (stat.isDirectory()) {
      walkDirectory(filePath);
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      fixImports(filePath);
    }
  });
}

walkDirectory(componentsDir);
console.log('✅ Fixed imports in components');
```

**Ejecutar**:
```bash
npx tsx scripts/fix-imports.ts
```

**Checklist**:
- [ ] Componentes copiados
- [ ] `'use client'` agregado donde necesario
- [ ] Imports actualizados a aliases (@/)
- [ ] Variables de entorno actualizadas

---

### PROMPT 4: Implementar Sistema de Encriptación y Dashboard de Configuración

**Objetivo**: Sistema seguro para guardar API keys en base de datos

**Crear servicio de encriptación**:

Archivo `src/lib/encryption/crypto.ts`:

```typescript
import CryptoJS from 'crypto-js';

const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY!;

if (!ENCRYPTION_KEY || ENCRYPTION_KEY.length < 32) {
  throw new Error('ENCRYPTION_KEY must be at least 32 characters');
}

export function encrypt(text: string): string {
  return CryptoJS.AES.encrypt(text, ENCRYPTION_KEY).toString();
}

export function decrypt(ciphertext: string): string {
  const bytes = CryptoJS.AES.decrypt(ciphertext, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
}
```

**Crear servicio de configuración**:

Archivo `src/lib/config/platform-config.ts`:

```typescript
import { prisma } from '@/lib/prisma';
import { encrypt, decrypt } from '@/lib/encryption/crypto';

export type ConfigCategory =
  | 'stripe'
  | 'gemini'
  | 'twilio'
  | 'resend'
  | 'upstash'
  | 'axiom'
  | 'sentry'
  | 'google_oauth';

export interface ConfigValue {
  key: string;
  value: string;
  category: ConfigCategory;
  description?: string;
}

export async function getConfig(key: string): Promise<string | null> {
  const config = await prisma.platformConfig.findUnique({
    where: { key, isActive: true },
  });

  if (!config) return null;

  return decrypt(config.value);
}

export async function setConfig(data: ConfigValue): Promise<void> {
  const encryptedValue = encrypt(data.value);

  await prisma.platformConfig.upsert({
    where: { key: data.key },
    update: {
      value: encryptedValue,
      category: data.category,
      description: data.description,
    },
    create: {
      key: data.key,
      value: encryptedValue,
      category: data.category,
      description: data.description,
    },
  });
}

export async function getAllConfig(): Promise<Record<string, any>> {
  const configs = await prisma.platformConfig.findMany({
    where: { isActive: true },
  });

  const result: Record<string, any> = {};

  for (const config of configs) {
    try {
      result[config.key] = decrypt(config.value);
    } catch (error) {
      console.error(`Failed to decrypt config: ${config.key}`);
    }
  }

  return result;
}

export async function deleteConfig(key: string): Promise<void> {
  await prisma.platformConfig.update({
    where: { key },
    data: { isActive: false },
  });
}
```

**Crear API route para admin**:

Archivo `src/app/api/admin/config/route.ts`:

```typescript
import { NextResponse } from 'next/server';
import { getConfig, setConfig, getAllConfig } from '@/lib/config/platform-config';
import { createServerSupabaseClient } from '@/lib/supabase/server';

// GET /api/admin/config
export async function GET() {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is SAAS_ADMIN
    const { data: profile } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profile?.role !== 'SAAS_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const configs = await getAllConfig();

    // Mask sensitive values
    const masked = Object.keys(configs).reduce((acc, key) => {
      const value = configs[key];
      acc[key] = maskSensitiveValue(value);
      return acc;
    }, {} as Record<string, string>);

    return NextResponse.json({ configs: masked });
  } catch (error: any) {
    console.error('[Config GET Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST /api/admin/config
export async function POST(req: Request) {
  try {
    const supabase = createServerSupabaseClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { data: profile } = await supabase
      .from('users')
      .select('role')
      .eq('id', user.id)
      .single();

    if (profile?.role !== 'SAAS_ADMIN') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const { key, value, category, description } = body;

    await setConfig({ key, value, category, description });

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('[Config POST Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

function maskSensitiveValue(value: string): string {
  if (!value) return '';
  if (value.length <= 8) return '****';
  return value.slice(0, 4) + '****' + value.slice(-4);
}
```

**Crear componente de Dashboard Admin**:

Archivo `src/components/admin/ConfigDashboard.tsx`:

```typescript
'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';

interface Config {
  key: string;
  value: string;
  category: string;
  description: string;
}

const CONFIG_TEMPLATES: Config[] = [
  // Stripe
  { key: 'STRIPE_SECRET_KEY', value: '', category: 'stripe', description: 'Stripe Secret Key (sk_...)' },
  { key: 'STRIPE_PUBLISHABLE_KEY', value: '', category: 'stripe', description: 'Stripe Publishable Key (pk_...)' },
  { key: 'STRIPE_WEBHOOK_SECRET', value: '', category: 'stripe', description: 'Stripe Webhook Secret (whsec_...)' },

  // Gemini
  { key: 'GEMINI_API_KEY', value: '', category: 'gemini', description: 'Google Gemini API Key' },

  // Twilio
  { key: 'TWILIO_ACCOUNT_SID', value: '', category: 'twilio', description: 'Twilio Account SID' },
  { key: 'TWILIO_AUTH_TOKEN', value: '', category: 'twilio', description: 'Twilio Auth Token' },
  { key: 'TWILIO_WHATSAPP_NUMBER', value: '', category: 'twilio', description: 'Twilio WhatsApp Number' },
  { key: 'TWILIO_SMS_NUMBER', value: '', category: 'twilio', description: 'Twilio SMS Number' },

  // Resend
  { key: 'RESEND_API_KEY', value: '', category: 'resend', description: 'Resend API Key' },

  // Upstash
  { key: 'UPSTASH_REDIS_URL', value: '', category: 'upstash', description: 'Upstash Redis URL' },
  { key: 'UPSTASH_REDIS_TOKEN', value: '', category: 'upstash', description: 'Upstash Redis Token' },

  // Axiom
  { key: 'AXIOM_TOKEN', value: '', category: 'axiom', description: 'Axiom API Token' },
  { key: 'AXIOM_DATASET', value: 'supramercado-logs', category: 'axiom', description: 'Axiom Dataset Name' },
];

export function ConfigDashboard() {
  const [configs, setConfigs] = useState<Config[]>(CONFIG_TEMPLATES);
  const [loading, setLoading] = useState(false);
  const [savedMessage, setSavedMessage] = useState('');

  const handleSave = async () => {
    setLoading(true);
    setSavedMessage('');

    try {
      for (const config of configs) {
        if (config.value) {
          await fetch('/api/admin/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config),
          });
        }
      }

      setSavedMessage('✅ Configuración guardada exitosamente');
      setTimeout(() => setSavedMessage(''), 3000);
    } catch (error) {
      setSavedMessage('❌ Error al guardar configuración');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (key: string, value: string) => {
    setConfigs(prev =>
      prev.map(c => (c.key === key ? { ...c, value } : c))
    );
  };

  const groupedConfigs = configs.reduce((acc, config) => {
    if (!acc[config.category]) acc[config.category] = [];
    acc[config.category].push(config);
    return acc;
  }, {} as Record<string, Config[]>);

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">🔧 Configuración de Plataforma</h1>

      {savedMessage && (
        <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
          {savedMessage}
        </div>
      )}

      {Object.keys(groupedConfigs).map(category => (
        <div key={category} className="mb-8">
          <h2 className="text-xl font-semibold mb-4 capitalize">{category}</h2>

          <div className="space-y-4">
            {groupedConfigs[category].map(config => (
              <div key={config.key}>
                <label className="block text-sm font-medium mb-1">
                  {config.description}
                </label>
                <Input
                  type="password"
                  placeholder={config.key}
                  value={config.value}
                  onChange={(e) => handleChange(config.key, e.target.value)}
                  className="w-full"
                />
              </div>
            ))}
          </div>
        </div>
      ))}

      <Button
        onClick={handleSave}
        disabled={loading}
        className="w-full"
      >
        {loading ? 'Guardando...' : 'Guardar Configuración'}
      </Button>
    </div>
  );
}
```

**Crear página de admin**:

Archivo `src/app/admin/config/page.tsx`:

```typescript
import { ConfigDashboard } from '@/components/admin/ConfigDashboard';
import { ProtectedRoute } from '@/components/ProtectedRoute';

export default function AdminConfigPage() {
  return (
    <ProtectedRoute allowedRoles={['SAAS_ADMIN']}>
      <ConfigDashboard />
    </ProtectedRoute>
  );
}
```

**Checklist**:
- [ ] Sistema de encriptación implementado
- [ ] API routes de configuración creadas
- [ ] Dashboard admin creado
- [ ] Tabla `platform_config` en schema

---

### PROMPT 5: Migrar a Supabase y Ejecutar Schema

**Objetivo**: Conectar a Supabase y ejecutar schema completo

**Pasos**:

1. **Crear proyecto en Supabase**:
   - Ir a https://supabase.com/dashboard
   - Click "New Project"
   - Nombre: `supramercado-prod`
   - Region: `East US (North Virginia)`
   - Database Password: (generar fuerte)
   - Crear proyecto (toma ~2 minutos)

2. **Copiar credenciales a `.env.local`**:

```bash
# En Supabase Dashboard > Settings > API
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...

# En Supabase Dashboard > Settings > Database
DATABASE_URL=postgresql://postgres.xxx:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true
DIRECT_URL=postgresql://postgres.xxx:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:5432/postgres
```

3. **Ejecutar schema SQL**:

En Supabase Dashboard > SQL Editor, ejecutar el script completo de `IMPLEMENTACION_NEXTJS_1_SEMANA.md` Fase 1B.

4. **Sincronizar Prisma con Supabase**:

```bash
# Pull schema desde Supabase
npx prisma db pull

# Generar cliente
npx prisma generate
```

**Checklist**:
- [ ] Proyecto Supabase creado
- [ ] Schema SQL ejecutado exitosamente
- [ ] Credenciales en `.env.local`
- [ ] Prisma sincronizado

---

### PROMPT 6-15: [Continuaría con los prompts restantes...]

---

## 🎯 DECISIONES TÉCNICAS CLAVE TOMADAS

### 1. **Prisma + Supabase** (en vez de solo Supabase Client)
**Por qué**: Type-safety superior, mejor DX, migrations controladas

### 2. **Dashboard de Configuración** (en vez de hardcodear)
**Por qué**: Puedes actualizar API keys sin redeploy ni tocar código

### 3. **Resend** (en vez de SendGrid/Mailgun)
**Por qué**: Mejor integración con Next.js, 100 emails/día gratis, mejor deliverability

### 4. **Axiom** (en vez de console.log)
**Por qué**: Logs estructurados, búsqueda rápida, 100GB gratis/mes

### 5. **Vercel Edge Functions** para OFAC screening
**Por qué**: Latencia ultra baja (<50ms), escala automáticamente

### 6. **Upstash Redis** (en vez de node-cache)
**Por qué**: Serverless, persiste entre deployments, compartido entre edge functions

### 7. **SWR** para data fetching
**Por qué**: Caching inteligente, revalidación automática, optimistic updates

### 8. **React Server Components** por defecto
**Por qué**: Reduce bundle size ~40%, mejor SEO, faster initial load

### 9. **ISR** para páginas de productos
**Por qué**: SEO perfecto + performance de SPA, revalidación cada 60 segundos

### 10. **Vercel Cron** (en vez de node-cron o externa)
**Por qué**: Sin servidor adicional, gratis, integrado con logs

---

## 📊 MÉTRICAS DE ÉXITO

### Performance:
- ✅ Lighthouse Score > 90
- ✅ First Contentful Paint < 1.5s
- ✅ Time to Interactive < 3s
- ✅ Core Web Vitals: Green

### Seguridad:
- ✅ A+ en SSL Labs
- ✅ Zero API keys expuestas
- ✅ Rate limiting en todos los endpoints
- ✅ OFAC screening 100% de órdenes

### Escalabilidad:
- ✅ Auto-scaling de 0 a 10K usuarios
- ✅ Costo marginal: ~$0.001 por usuario/mes
- ✅ Sin downtime en deploys
- ✅ 99.9% uptime garantizado (Vercel SLA)

---

**SIGUIENTE PASO**: Llena `CREDENCIALES_PENDIENTES.md` y ejecuta prompts secuencialmente
