# 📊 Logging con Axiom - Supramercado

## Sistema de Logging Centralizado y Estructurado

---

## 🎯 Descripción General

Axiom es un servicio de logging serverless que permite capturar, analizar y monitorear logs de la aplicación en tiempo real.

### Características del Sistema

✅ **Structured Logging** - Logs con contexto completo
✅ **Niveles de Log** - Debug, Info, Warn, Error, Fatal
✅ **Categorización** - Auth, Payment, OFAC, Security, Performance
✅ **Integración Automática** - Logs en endpoints críticos
✅ **Analytics** - Dashboards y queries en Axiom Console
✅ **Alertas** - Notificaciones automáticas en eventos críticos
✅ **Graceful Degradation** - Console.log si Axiom no está configurado

---

## 🛠️ Configuración Inicial

### 1. Crear Cuenta en Axiom

1. Ve a [axiom.co](https://axiom.co)
2. Regístrate (gratis hasta 500MB/mes)
3. Verifica tu email

### 2. Crear Dataset

```
Dashboard → Datasets → New Dataset
```

**Configuración:**
- Name: `supramercado-logs`
- Description: Production logs for Supramercado
- Click **Create**

### 3. Obtener API Token

```
Dashboard → Settings → API Tokens → New Token
```

**Configuración:**
- Name: `Supramercado Production`
- Dataset: `supramercado-logs`
- Permissions: **Ingest** only
- Expiration: Never (o 1 año)
- Click **Create**

Copiar el token (solo se muestra una vez)

### 4. Configurar Variables de Entorno

```bash
# .env.local
AXIOM_TOKEN=xapt-...
AXIOM_DATASET=supramercado-logs
AXIOM_ORG_ID=your-org-id  # Opcional
```

### 5. Configurar en Vercel (Producción)

```
Vercel Dashboard → Project → Settings → Environment Variables

Name: AXIOM_TOKEN
Value: xapt-...
Environment: Production, Preview

Name: AXIOM_DATASET
Value: supramercado-logs
Environment: Production, Preview
```

### 6. Verificar Configuración

```bash
# Reiniciar servidor
npm run dev

# Deberías ver en la consola:
🚀 Initializing Supramercado instrumentation...
📊 Axiom logging enabled
   Dataset: supramercado-logs
```

---

## 📚 Cómo Usar en Código

### Logging Básico

```typescript
import * as logger from '@/lib/logger';

// Info
await logger.info('User logged in', {
  userId: '123',
  timestamp: new Date(),
});

// Warning
await logger.warn('Slow database query', {
  queryTime: 3500,
  query: 'SELECT * FROM orders',
});

// Error
await logger.error('Failed to process payment', error, {
  orderId: 'abc-123',
  amount: 100.50,
});

// Fatal (triggers alerts)
await logger.fatal('Database connection lost', error);

// Always flush at end of serverless functions
await logger.flush();
```

### Logging de Eventos de Negocio

**Autenticación:**
```typescript
await logger.logAuth('login', userId, {
  method: 'google-oauth',
  ipAddress: request.headers.get('x-forwarded-for'),
});
```

**Pagos:**
```typescript
await logger.logPayment('succeeded', orderId, 150.00, {
  userId: 'user-123',
  merchantId: 'merchant-456',
  orderNumber: 'ORD-20240101-ABC',
});
```

**OFAC Screening:**
```typescript
await logger.logOfacScreening('Juan Garcia', 'clear', orderId, {
  userId: 'user-123',
  merchantId: 'merchant-456',
});
```

**Notificaciones:**
```typescript
await logger.logNotification('whatsapp', '+18091234567', true, orderId, {
  orderNumber: 'ORD-123',
});
```

**Seguridad:**
```typescript
await logger.logSecurity('OFAC blocked transaction', 'high', userId, {
  beneficiaryName: 'Suspicious Name',
  matches: [...]
});
```

**Rate Limiting:**
```typescript
await logger.logRateLimit('/api/stripe/create-payment-intent', 'user:123', 10, {
  tier: 'strict',
});
```

### Logging en API Routes

```typescript
import * as logger from '@/lib/logger';

export async function POST(request: Request) {
  try {
    // Tu lógica...

    await logger.info('Order created successfully', {
      orderId: order.id,
      userId: user.id,
    });

    await logger.flush();  // Importante en serverless

    return NextResponse.json({ success: true });
  } catch (error) {
    await logger.error('Failed to create order', error, {
      url: request.url,
      method: request.method,
    });

    await logger.flush();

    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
```

### Wrapper para Logging Automático

```typescript
import { withLogging } from '@/lib/logger';

// Envolver función con logging automático
const processPayment = withLogging(
  async (orderId: string) => {
    // Tu lógica...
    return { success: true };
  },
  'processPayment'  // Contexto
);

// Automáticamente loguea:
// - Duración de ejecución
// - Errores (si ocurren)
// - Operaciones lentas (>3s)
```

---

## 📊 Eventos Logueados Automáticamente

### Autenticación
- Login exitoso/fallido
- Logout
- Signup
- Password reset

### Pagos
- Payment created
- Payment succeeded
- Payment failed
- Payment refunded

### OFAC Screening
- Clear
- Potential match
- Blocked (con severidad "high")

### Notificaciones
- Email enviado/fallido
- WhatsApp enviado/fallido
- SMS enviado/fallido

### Seguridad
- OFAC blocks
- Rate limit violations
- Unauthorized access attempts
- Configuration changes

### Performance
- Slow operations (>3s)
- Database query times
- API response times

---

## 🔍 Queries en Axiom

### Ver Logs Recientes

```apl
['supramercado-logs']
| limit 100
```

### Filtrar por Nivel

```apl
['supramercado-logs']
| where level == "error"
| limit 50
```

### Pagos Fallidos

```apl
['supramercado-logs']
| where category == "payment" and level == "error"
| project timestamp, message, metadata
```

### OFAC Blocks

```apl
['supramercado-logs']
| where category == "ofac" and metadata.result == "blocked"
| project timestamp, metadata.screenedName, metadata.matches
```

### Rate Limit Violations

```apl
['supramercado-logs']
| where contains(message, "Rate limit exceeded")
| summarize count() by metadata.endpoint
```

### Errores por Usuario

```apl
['supramercado-logs']
| where level == "error" and userId != ""
| summarize errors=count() by userId
| order by errors desc
```

### Performance Metrics

```apl
['supramercado-logs']
| where category == "performance"
| summarize avg(duration), max(duration), count() by url
```

---

## 📈 Dashboards

### Dashboard de Pagos

```apl
// Total de pagos por estado
['supramercado-logs']
| where category == "payment"
| summarize count() by metadata.event
| render piechart

// Monto total procesado
['supramercado-logs']
| where category == "payment" and metadata.event == "succeeded"
| summarize total=sum(metadata.amount)

// Tasa de éxito
['supramercado-logs']
| where category == "payment"
| summarize
    total=count(),
    succeeded=countif(metadata.event == "succeeded"),
    failed=countif(metadata.event == "failed")
| extend success_rate = (succeeded * 100.0) / total
```

### Dashboard de Seguridad

```apl
// OFAC screenings por resultado
['supramercado-logs']
| where category == "ofac"
| summarize count() by metadata.result
| render columnchart

// Eventos de seguridad por severidad
['supramercado-logs']
| where category == "security"
| summarize count() by metadata.severity
| render piechart
```

### Dashboard de Performance

```apl
// Endpoints más lentos
['supramercado-logs']
| where category == "api"
| summarize avg_duration=avg(duration) by url
| order by avg_duration desc
| limit 10
| render barchart

// Distribución de tiempos de respuesta
['supramercado-logs']
| where category == "api"
| summarize count() by bin(duration, 100)
| render columnchart
```

---

## 🚨 Alertas

### Configurar Alertas en Axiom

```
Dashboard → Monitors → New Monitor
```

**Alerta: Pagos Fallidos**
```apl
['supramercado-logs']
| where category == "payment" and level == "error"
| summarize count() by bin(_time, 5m)
| where count_ > 5  // Más de 5 fallos en 5 minutos
```

**Alerta: OFAC Blocks**
```apl
['supramercado-logs']
| where category == "ofac" and metadata.result == "blocked"
| summarize count() by bin(_time, 1h)
| where count_ > 0  // Cualquier block
```

**Alerta: Errores Críticos**
```apl
['supramercado-logs']
| where level == "fatal"
| summarize count() by bin(_time, 1m)
| where count_ > 0
```

**Alerta: API Lenta**
```apl
['supramercado-logs']
| where category == "api" and duration > 5000  // >5s
| summarize slow_requests=count() by bin(_time, 5m)
| where slow_requests > 10
```

**Configuración de Notificaciones:**
- Slack: #alerts channel
- Email: team@supramercado.com
- PagerDuty: Para errores fatales

---

## 💰 Costos de Axiom

### Plan Gratuito
- **500 MB/mes** incluidos
- Retención: 30 días
- Perfecto para desarrollo y MVP

### Plan Personal ($25/mes)
- **100 GB/mes**
- Retención: 90 días
- Queries ilimitados

### Estimación para Supramercado

```
Eventos estimados:
- 1,000 requests/día × 1KB = 1 MB/día
- 100 pagos/día × 2KB = 0.2 MB/día
- 50 OFAC screenings/día × 1KB = 0.05 MB/día
- 200 notificaciones/día × 1KB = 0.2 MB/día

Total: ~1.5 MB/día × 30 = 45 MB/mes
```

**Conclusión**: Plan gratuito suficiente inicialmente

---

## 🐛 Troubleshooting

### Logs No Aparecen en Axiom

**Síntoma**: `await logger.info(...)` no aparece en Axiom Console

**Soluciones**:
1. Verificar que `AXIOM_TOKEN` y `AXIOM_DATASET` están configurados
2. Verificar que llamaste `await logger.flush()` al final
3. Esperar 30-60 segundos (puede haber delay)
4. Revisar logs de consola para errores de Axiom

### Error: "Failed to send log to Axiom"

**Causa**: Token inválido o dataset no existe

**Solución**:
```bash
# Verificar token
echo $AXIOM_TOKEN

# Verificar dataset en Axiom Console
# Dashboard → Datasets → verificar nombre exacto
```

### Logs Solo en Console, No en Axiom

**Causa**: Axiom no configurado

**Solución**: Esto es normal y esperado. El sistema hace "graceful degradation":
- Sin Axiom → Logs solo en console
- Con Axiom → Logs en console (dev) + Axiom (siempre)

---

## 📋 Checklist

### Desarrollo
- [ ] Cuenta de Axiom creada
- [ ] Dataset creado
- [ ] API token generado
- [ ] Variables en `.env.local`
- [ ] Servidor reiniciado
- [ ] Ver mensaje "Axiom logging enabled" al iniciar
- [ ] Hacer test request y ver log en Axiom Console
- [ ] Queries funcionando

### Producción
- [ ] Variables configuradas en Vercel
- [ ] Deploy realizado
- [ ] Logs llegando a Axiom desde producción
- [ ] Dashboards creados
- [ ] Alertas configuradas
- [ ] Slack/Email webhooks configurados
- [ ] Equipo capacitado en Axiom Console
- [ ] Plan de Axiom adecuado para volumen

---

## 🎓 Mejores Prácticas

### 1. Siempre Flush

```typescript
// ✅ Correcto
await logger.info('Event happened');
await logger.flush();  // Envía logs a Axiom

// ❌ Incorrecto
await logger.info('Event happened');
// Sin flush, logs se pierden en serverless
```

### 2. Contexto Rico

```typescript
// ✅ Bueno
await logger.error('Payment failed', error, {
  userId: user.id,
  orderId: order.id,
  amount: order.totalUSD,
  merchantId: order.merchantId,
  paymentIntentId: pi.id,
});

// ❌ Malo
await logger.error('Payment failed', error);
```

### 3. Niveles Apropiados

```typescript
// debug: Información de desarrollo
await logger.debug('Function called', { params });

// info: Eventos normales del negocio
await logger.info('Order created', { orderId });

// warn: Situaciones inusuales pero no errores
await logger.warn('Slow query', { duration: 3500 });

// error: Errores recuperables
await logger.error('Email failed to send', error);

// fatal: Errores críticos (activan alertas)
await logger.fatal('Database down', error);
```

### 4. No Loggear Datos Sensibles

```typescript
// ❌ Nunca loggear:
- Números de tarjeta completos
- Passwords
- API keys
- Tokens de sesión
- SSN, números de identificación

// ✅ OK loggear:
- User IDs
- Order IDs
- Últimos 4 dígitos de tarjeta
- Emails (masked: u***@email.com)
- Nombres
```

### 5. Categorizar Correctamente

```typescript
await logger.log({
  level: 'info',
  message: 'Payment processed',
  category: 'payment',  // Facilita búsquedas
  orderId: order.id,
  metadata: {...}
});
```

---

## 📚 Recursos

- [Axiom Documentation](https://axiom.co/docs)
- [APL Query Language](https://axiom.co/docs/apl/introduction)
- [Axiom Status](https://status.axiom.co/)

---

**Prompt 12 Status**: COMPLETADO ✅

**Siguiente**: Prompt 13 - Páginas Principales

**Nota**: Logging es fundamental para debugging en producción. Asegúrate de loggear eventos importantes pero sin exceso para controlar costos.
