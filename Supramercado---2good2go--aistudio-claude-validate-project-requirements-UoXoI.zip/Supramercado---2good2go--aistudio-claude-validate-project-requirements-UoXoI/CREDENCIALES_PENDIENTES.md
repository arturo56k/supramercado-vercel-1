# 🔐 CREDENCIALES PENDIENTES - SUPRAMERCADO

**Instrucciones**: Llena este archivo con tus credenciales reales. Una vez completado, podrás copiarlas al dashboard de administración o al archivo `.env.local`.

---

## ✅ CHECKLIST DE SERVICIOS

- [ ] Supabase (Gratis) - Base de datos + Auth
- [ ] Stripe (Gratis) - Pagos
- [ ] Google Gemini (Gratis con límites) - IA
- [ ] Resend (Gratis 100/día) - Emails
- [ ] Twilio (Pay-as-you-go) - WhatsApp/SMS
- [ ] Upstash Redis (Gratis) - Rate limiting
- [ ] Axiom (Gratis 100GB) - Logs
- [ ] Sentry (Gratis 5K errors) - Error tracking
- [ ] Google OAuth (Gratis) - Login con Google
- [ ] Vercel (Gratis) - Hosting

---

## 1. SUPABASE
**Cómo obtener**: https://supabase.com → New Project

```bash
# Ir a: Dashboard > Settings > API
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGc...

# Ir a: Dashboard > Settings > API (scroll down)
SUPABASE_SERVICE_ROLE_KEY=eyJhbGc...

# Ir a: Dashboard > Settings > Database > Connection string
# Seleccionar "Transaction pooler" y copiar el URI
DATABASE_URL=postgresql://postgres.xxx:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true

# Seleccionar "Session pooler" y copiar el URI
DIRECT_URL=postgresql://postgres.xxx:[PASSWORD]@aws-0-us-east-1.pooler.supabase.com:5432/postgres
```

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 2. STRIPE
**Cómo obtener**: https://stripe.com → Create account → Developers > API keys

```bash
# Usar TEST keys primero (comienzan con pk_test_ y sk_test_)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...

# Webhook secret (se genera DESPUÉS de crear el webhook)
# Ir a: Dashboard > Webhooks > Add endpoint > Copiar signing secret
STRIPE_WEBHOOK_SECRET=whsec_...
```

**Pasos adicionales**:
1. Ir a Stripe Dashboard > Webhooks
2. Click "Add endpoint"
3. Endpoint URL: `https://[TU-DOMINIO]/api/stripe/webhook`
4. Eventos a escuchar:
   - payment_intent.succeeded
   - payment_intent.payment_failed
   - account.updated
   - charge.dispute.created
5. Copiar "Signing secret" arriba

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 3. GOOGLE GEMINI
**Cómo obtener**: https://aistudio.google.com/apikey

```bash
GEMINI_API_KEY=AIza...
```

**Límites gratis**:
- 60 requests por minuto
- 1,500 requests por día

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 4. RESEND (Email)
**Cómo obtener**: https://resend.com → Sign up → API Keys

```bash
RESEND_API_KEY=re_...
RESEND_FROM_EMAIL=noreply@supramercado.com
```

**Pasos adicionales**:
1. Verificar dominio (si tienes uno)
2. O usar dominio sandbox de Resend (solo para testing)

**Límites gratis**: 100 emails/día

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 5. TWILIO (WhatsApp + SMS)
**Cómo obtener**: https://twilio.com → Sign up → Console

```bash
# Ir a: Console > Account > Settings
TWILIO_ACCOUNT_SID=AC...
TWILIO_AUTH_TOKEN=...

# Ir a: Console > Messaging > Try it out > Send a WhatsApp message
TWILIO_WHATSAPP_NUMBER=whatsapp:+14155238886

# Ir a: Console > Phone Numbers > Buy a number
TWILIO_SMS_NUMBER=+1...
```

**Pasos adicionales para WhatsApp**:
1. Enviar "join [palabra-clave]" al número de Twilio para activar sandbox
2. Para producción, solicitar acceso a WhatsApp Business API (puede tardar semanas)

**Costo estimado**:
- WhatsApp: $0.005 por mensaje
- SMS: $0.0075 por mensaje
- ~500 mensajes/mes = ~$3.75-5/mes

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 6. UPSTASH REDIS (Rate Limiting)
**Cómo obtener**: https://upstash.com → Sign up → Create Database

```bash
# Tipo: Regional (más barato)
# Region: us-east-1 (mismo que Supabase)
UPSTASH_REDIS_URL=https://xxx.upstash.io
UPSTASH_REDIS_TOKEN=...
```

**Límites gratis**:
- 10,000 comandos/día
- 256 MB almacenamiento

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 7. AXIOM (Logging)
**Cómo obtener**: https://axiom.co → Sign up → Create Dataset

```bash
# Ir a: Settings > Tokens > Create API Token
AXIOM_TOKEN=xaat-...
AXIOM_DATASET=supramercado-logs
```

**Límites gratis**: 100 GB/mes de logs

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 8. SENTRY (Error Tracking) - OPCIONAL
**Cómo obtener**: https://sentry.io → Sign up → Create Project (Next.js)

```bash
# Ir a: Settings > Projects > [Tu Proyecto] > Client Keys (DSN)
NEXT_PUBLIC_SENTRY_DSN=https://xxx@sentry.io/xxx

# Ir a: Settings > Account > API > Auth Tokens
SENTRY_AUTH_TOKEN=sntrys_...
```

**Límites gratis**: 5,000 errores/mes

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 9. GOOGLE OAUTH (Login con Google)
**Cómo obtener**: https://console.cloud.google.com

```bash
GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...
```

**Pasos**:
1. Crear nuevo proyecto en Google Cloud Console
2. Ir a: APIs & Services > Credentials
3. Click "Create Credentials" > OAuth 2.0 Client ID
4. Application type: Web application
5. Authorized redirect URIs:
   - `https://[TU-PROYECTO].supabase.co/auth/v1/callback`
   - `http://localhost:3000/auth/callback` (para desarrollo)
6. Copiar Client ID y Client Secret

**Luego configurar en Supabase**:
1. Ir a: Supabase Dashboard > Authentication > Providers
2. Habilitar Google
3. Pegar Client ID y Client Secret

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 10. VERCEL (Hosting)
**Cómo obtener**: https://vercel.com → Sign up (gratis)

```bash
# Se configura automáticamente con:
vercel login
vercel

# Luego generar estos secrets:

# ENCRYPTION_KEY (para encriptar API keys en DB)
ENCRYPTION_KEY=$(openssl rand -base64 32)

# NEXTAUTH_SECRET (para sessions)
NEXTAUTH_SECRET=$(openssl rand -base64 32)

# CRON_SECRET (para proteger cron jobs)
CRON_SECRET=$(openssl rand -base64 32)

# URL de tu app
NEXT_PUBLIC_URL=https://supramercado.com
NEXTAUTH_URL=https://supramercado.com
```

**Estado**: ⬜ No configurado | ⬜ En progreso | ⬜ Configurado

---

## 📋 RESUMEN DE COSTOS MENSUALES

| Servicio | Tier | Costo |
|----------|------|-------|
| Supabase | Free | $0 |
| Stripe | Pay-per-transaction | 2.9% + $0.30 |
| Gemini | Free tier | $0 |
| Resend | 100/día gratis | $0-20 |
| Twilio | Pay-as-you-go | ~$5 (500 msg) |
| Upstash | Free tier | $0 |
| Axiom | 100GB gratis | $0 |
| Sentry | 5K errors gratis | $0 |
| Google OAuth | Gratis | $0 |
| Vercel | Hobby | $0 |
| **TOTAL** | | **~$5-25/mes** |

---

## 🚀 ORDEN DE CONFIGURACIÓN RECOMENDADO

1. **Supabase** (primero - necesario para DB)
2. **Vercel** (segundo - necesario para deployment)
3. **Google OAuth** (tercero - necesario para login)
4. **Stripe** (cuarto - necesario para pagos)
5. **Gemini** (quinto - necesario para IA)
6. **Upstash** (sexto - necesario para rate limiting)
7. **Resend** (séptimo - necesario para emails)
8. **Twilio** (octavo - necesario para WhatsApp)
9. **Axiom** (noveno - opcional pero recomendado)
10. **Sentry** (décimo - completamente opcional)

---

## ⚠️ IMPORTANTE: Seguridad

1. **NUNCA** commitear este archivo con credenciales reales
2. Este archivo debe estar en `.gitignore`
3. Usar variables de entorno en Vercel para producción
4. Usar dashboard de admin para actualizar credenciales sin redeploy
5. Rotar credenciales cada 90 días (buena práctica)

---

## 📝 NOTAS ADICIONALES

### Ambiente de Desarrollo
Crear archivo `.env.local` en la raíz del proyecto Next.js con todas estas credenciales.

### Ambiente de Producción
Agregar todas las credenciales en Vercel Dashboard > Settings > Environment Variables

### Dashboard de Admin
Una vez desplegado, ir a `https://[TU-DOMINIO]/admin/config` y actualizar credenciales desde la UI.

---

## ✅ CHECKLIST FINAL

- [ ] Todas las credenciales obtenidas
- [ ] Archivo `.env.local` creado con credenciales
- [ ] Credenciales agregadas a Vercel
- [ ] Webhooks de Stripe configurados
- [ ] Google OAuth configurado en Supabase
- [ ] Dashboard de admin testeado
- [ ] Primer email de prueba enviado
- [ ] Primer mensaje de WhatsApp enviado
- [ ] OFAC SDN list descargada
- [ ] Todos los servicios verificados

---

**Última actualización**: [Llenar con fecha cuando completes]
**Completado por**: [Tu nombre]
**Próxima revisión**: [90 días después]

---

## 🆘 SOPORTE

Si tienes problemas configurando algún servicio:

1. Revisar documentación oficial del servicio
2. Buscar en el repositorio de GitHub Issues
3. Contactar soporte del servicio
4. Documentar la solución para futuras referencias

---

**¡Éxito con tu configuración!** 🚀
