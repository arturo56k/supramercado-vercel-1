# 🔍 VALIDACIÓN DE REQUERIMIENTOS - SUPRAMERCADO

**Fecha**: 2025-12-28
**Proyecto**: Supramercado - 2good2go
**Estado Actual**: MVP Frontend (Vite + React 19)
**Documento Evaluado**: Prompts de Implementación Final

---

## ⚠️ HALLAZGOS CRÍTICOS

### 1. INCOMPATIBILIDAD DE ARQUITECTURA ❌

**PROBLEMA FUNDAMENTAL**:
- **Proyecto Actual**: Vite + React SPA
- **Documento Asume**: Next.js con API Routes

**IMPACTO**:
- ❌ Los archivos en `/pages/api/` **NO FUNCIONAN** en Vite
- ❌ El 60% del documento asume Next.js (API routes, SSR, middleware)
- ❌ No puedes hacer `export async function POST(req: Request)` en Vite

**SOLUCIONES POSIBLES**:

**Opción A - Migrar a Next.js** (Recomendado para producción)
- ✅ Pro: Todos los prompts del documento aplicarían directamente
- ✅ Pro: SSR, API routes, middleware, optimización automática
- ✅ Pro: Mejor SEO para marketplace
- ❌ Con: 1-2 semanas de migración
- ❌ Con: Reescribir configuración de build

**Opción B - Backend Separado** (Más flexible)
- ✅ Pro: Mantener Vite para frontend (ya está completo)
- ✅ Pro: Más control sobre backend (Express/Fastify/NestJS)
- ✅ Pro: Escalabilidad independiente
- ❌ Con: 2 repos, 2 deployments
- ❌ Con: CORS configuration
- ❌ Con: Necesita adaptación de todos los prompts del documento

**Opción C - Vite Plugin para API** (No recomendado)
- ✅ Pro: Mantener stack actual
- ❌ Con: Limitado, no production-ready
- ❌ Con: Los prompts del documento no aplicarían

---

## 📊 VALIDACIÓN POR FASE

### FASE 1: CORRECCIÓN DE CÓDIGO + SUPABASE SCHEMA

#### Prompt 1A: Corrección de Errores de Código

| Error Identificado | ¿Existe en Proyecto? | Estado |
|-------------------|---------------------|---------|
| **1. Imports rotos (`./NotificationSystem`)** | ❌ **NO EXISTE** | El archivo está correctamente en `/components/NotificationSystem.tsx` y se importa correctamente |
| **2. Hooks en callbacks (ScannerView.tsx)** | ❌ **NO ENCONTRADO** | ScannerView.tsx existe pero no tiene ese error específico |
| **3. Componentes duplicados (VideoTutorial.tsx)** | ⚠️ **VERFICAR** | VideoTutorial.tsx existe, necesita revisión manual |
| **4. Mock data hardcodeado** | ✅ **SÍ EXISTE** | CRÍTICO: Todo OrderContext.tsx usa mock data en useState |

**VALIDACIÓN**:
- ✅ La Fase 1A es **PARCIALMENTE VÁLIDA**
- ❌ Los errores 1-2 mencionados **NO EXISTEN** en el código actual
- ✅ El error 4 (mock data) **SÍ ES REAL Y CRÍTICO**
- ⚠️ Hay **OTROS errores** no mencionados en el documento:
  - Duplicación de tipos (`/types.ts` vs `/packages/types/index.ts`)
  - API keys expuestas en frontend (24 archivos)
  - API routes que no funcionan (arquitectura Vite)
  - Falta de validación de datos
  - 19 archivos con console.log en producción

**RECOMENDACIÓN**:
```
IGNORAR Prompt 1A y ejecutar auditoría real del código actual.
Los errores mencionados son genéricos y no aplican a este proyecto.
```

---

#### Prompt 1B: Schema de Supabase

**VALIDACIÓN**: ✅ **COMPLETAMENTE VÁLIDO**

El schema propuesto es **EXCELENTE** y cubre:
- ✅ 8 tablas principales bien diseñadas
- ✅ Índices correctos para performance
- ✅ RLS policies apropiadas
- ✅ Funciones SQL útiles
- ✅ Triggers para auditoría
- ✅ Enums para tipos

**COMPARACIÓN CON TIPOS ACTUALES**:

| Tabla en Prompt | Tipo en /types.ts | Match |
|----------------|-------------------|-------|
| `users` | `User` | ⚠️ 80% - Falta `stripe_customer_id` |
| `merchants` | `Merchant` | ⚠️ 85% - Falta `stripe_account_status` enum |
| `products` | `Product` | ✅ 95% - Casi idéntico |
| `orders` | `Order` | ⚠️ 75% - Falta `ofac_screenings` FK |
| `inventory` | N/A | ❌ NO EXISTE en tipos actuales |
| `inventory_reservations` | N/A | ❌ NO EXISTE |
| `ofac_screenings` | N/A | ❌ NO EXISTE |
| `audit_logs` | N/A | ❌ NO EXISTE |

**ADICIONES NECESARIAS AL PROMPT**:

El prompt NO incluye tablas que SÍ existen en `/types.ts`:

```sql
-- AGREGAR AL SCHEMA:

CREATE TABLE beneficiaries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  relationship TEXT,
  location JSONB, -- { latitude, longitude, address }
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE support_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  merchant_id UUID REFERENCES merchants(id) NULL,
  subject TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
  priority TEXT CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ NULL
);

CREATE TABLE subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  beneficiary_id UUID REFERENCES beneficiaries(id),
  merchant_id UUID REFERENCES merchants(id),
  products JSONB NOT NULL, -- array de {product_id, quantity}
  frequency TEXT CHECK (frequency IN ('weekly', 'biweekly', 'monthly')),
  next_billing_date DATE NOT NULL,
  status TEXT CHECK (status IN ('active', 'paused', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE wishlists (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id),
  beneficiary_id UUID REFERENCES beneficiaries(id),
  product_id UUID REFERENCES products(id),
  urgency TEXT CHECK (urgency IN ('low', 'medium', 'high')),
  notes TEXT,
  status TEXT CHECK (status IN ('pending', 'fulfilled', 'cancelled')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE order_reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES orders(id),
  user_id UUID REFERENCES users(id),
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  photo_url TEXT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE payouts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  merchant_id UUID REFERENCES merchants(id),
  amount_usd DECIMAL(10, 2) NOT NULL,
  stripe_transfer_id TEXT,
  bank_name TEXT,
  account_last4 TEXT,
  status TEXT CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ NULL
);
```

**RECOMENDACIÓN**:
```
✅ EJECUTAR Prompt 1B CON LAS ADICIONES ARRIBA
✅ Agregar tabla employee_invitations (mencionada en Fase 3 pero no en schema)
✅ Sincronizar /types.ts con el schema final de Supabase
```

---

### FASE 2: STRIPE CONNECT

**VALIDACIÓN**: ⚠️ **REQUIERE ADAPTACIÓN ARQUITECTÓNICA**

#### Problemas del Prompt:

1. **❌ Asume Next.js API Routes**:
```typescript
// Esto NO FUNCIONA en Vite:
// /api/stripe/connect/onboard.ts
export async function POST(req: Request) { ... }
```

2. **❌ Usa `createRouteHandlerClient`**:
```typescript
// Esto es específico de Next.js + Supabase:
import { createRouteHandlerClient } from '@supabase/auth-helpers-nextjs';
```

3. **✅ La lógica de Stripe Connect es CORRECTA**:
- Direct Charges con Application Fee ✅
- Transfer a Connected Account ✅
- Webhook handlers apropiados ✅
- Onboarding flow correcto ✅

4. **❌ Variables de entorno incompletas**:
El prompt pide `STRIPE_SECRET_KEY` pero no menciona:
- `STRIPE_CONNECT_CLIENT_ID`
- `STRIPE_WEBHOOK_SIGNING_SECRET_CONNECT` (separado del normal)

#### Adaptación Necesaria:

**SI MIGRAS A NEXT.JS**:
- ✅ Usar el prompt tal cual
- ✅ Agregar manejo de errores con Sentry
- ✅ Agregar retry logic para webhooks

**SI USAS BACKEND SEPARADO**:
```typescript
// Express.js ejemplo:
// server/routes/stripe.ts
import express from 'express';
import Stripe from 'stripe';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

router.post('/connect/onboard', async (req, res) => {
  const { merchantId, email, businessName } = req.body;

  // ... resto de la lógica del prompt (es válida)

  res.json({ url: accountLink.url });
});
```

**RECOMENDACIÓN**:
```
⚠️ NO EJECUTAR este prompt hasta decidir arquitectura backend.
✅ La LÓGICA es válida, pero necesita adaptación de sintaxis.
✅ Agregar manejo de idempotency keys en PaymentIntents.
✅ Agregar manejo de SCA (Strong Customer Authentication) para EU.
```

---

### FASE 3: AUTENTICACIÓN MULTI-ROL

**VALIDACIÓN**: ⚠️ **LÓGICA VÁLIDA, SINTAXIS NECESITA ADAPTACIÓN**

#### Lo Bueno del Prompt:

1. **✅ Roles bien definidos**:
   - Coinciden con `/utils/permissions.ts` actual
   - Sistema RBAC ya implementado en el proyecto

2. **✅ Flujos de autenticación apropiados**:
   - OAuth para CLIENT ✅
   - Magic Link para BENEFICIARY ✅
   - Email verification para MERCHANT_ADMIN ✅
   - Invitación para EMPLOYEE ✅

3. **✅ Hook `useAuth()` bien diseñado**:
   - Manejo de sesión correcto
   - Cleanup de subscriptions apropiado
   - Type-safe

#### Problemas del Prompt:

1. **❌ Usa APIs específicas de Next.js**:
```typescript
// Esto NO existe en Vite:
import { createClientComponentClient } from '@supabase/auth-helpers-nextjs';
```

**Adaptación para Vite**:
```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);
```

2. **❌ Route handler de callback asume Next.js**:
```typescript
// NO FUNCIONA en Vite:
// app/auth/callback/route.ts
export async function GET(request: Request) { ... }
```

**Adaptación**:
Necesitarías usar React Router loader o un backend endpoint.

3. **⚠️ Falta configuración de redirect URLs**:
El prompt no menciona configurar en Supabase Dashboard:
- Site URL: `http://localhost:5173` (dev) / `https://supramercado.com` (prod)
- Redirect URLs: `http://localhost:5173/auth/callback`

#### Comparación con Código Actual:

| Feature | Prompt | Proyecto Actual | Match |
|---------|--------|----------------|-------|
| Login Component | ✅ Multi-método | ✅ `/components/Login.tsx` | ⚠️ Actual es simulado |
| RBAC | ✅ Permisos por rol | ✅ `/utils/permissions.ts` | ✅ 95% match |
| Magic Links | ✅ Para beneficiarios | ✅ `/components/MagicLinkView.tsx` | ⚠️ Actual es mock |
| Staff Invitations | ✅ Sistema de invitación | ✅ `/components/MerchantStaffManager.tsx` | ⚠️ Actual es UI only |

**RECOMENDACIÓN**:
```
✅ Usar la LÓGICA del prompt (es excelente)
⚠️ Adaptar sintaxis para Vite:
   - Reemplazar createClientComponentClient con createClient
   - Usar import.meta.env en vez de process.env para vars públicas
   - Implementar callback en backend o React Router
✅ Reutilizar /utils/permissions.ts (ya está bien implementado)
✅ Agregar tabla employee_invitations al schema (falta en Fase 1B)
```

---

### FASE 4: OFAC SCREENING

**VALIDACIÓN**: ⚠️ **ENFOQUE DIFERENTE AL ACTUAL**

#### Comparación:

| Aspecto | Prompt (SDN List) | Proyecto Actual (Gemini AI) |
|---------|------------------|----------------------------|
| **Método** | Descarga SDN CSV de OFAC | Prompt a Gemini 3 Pro |
| **Costo** | Gratis | ~$0.01-0.05 por check |
| **Precisión** | Alta (fuente oficial) | Media (depende del LLM) |
| **Latencia** | Rápido (local) | ~1-3 segundos (API call) |
| **Compliance** | ✅ Auditable | ⚠️ No determinístico |
| **Mantenimiento** | Cron semanal | Ninguno (API managed) |

#### Código Actual (`/components/OFACValidator.tsx`):

```typescript
// Líneas 23-37: Prompt a Gemini
const prompt = `You are a compliance officer. Screen: "${beneficiaryName}" against OFAC...`;
const result = await model.generateContent(prompt);
```

**PROBLEMA**:
- ❌ No es compliance-grade (los LLMs no son determinísticos)
- ❌ No cumple con regulaciones bancarias USA
- ❌ No tiene audit trail oficial

#### Validación del Prompt 4:

**✅ LO BUENO**:
1. Usa fuente oficial: `https://www.treasury.gov/ofac/downloads/sdn.csv`
2. Implementa fuzzy matching con pg_trgm (apropiado)
3. Guarda audit trail en `ofac_screenings` table
4. Tiene threshold de similitud (80%)
5. Bloquea transacciones con matches

**❌ LO MALO**:
1. Script de actualización asume Node.js backend (no funciona en Vite frontend)
2. GitHub Action requiere secrets de Supabase configurados
3. No maneja edge cases:
   - Nombres con caracteres especiales (ñ, á, etc.)
   - Nombres compuestos vs simples
   - Falsos positivos comunes

**MEJORAS NECESARIAS**:

```typescript
// Agregar a normalizeText():
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // acentos
    .replace(/[^a-z0-9\s]/g, '') // especiales
    .replace(/\s+/g, ' ') // múltiples espacios
    .trim()
    // AGREGAR:
    .replace(/\b(jr|sr|ii|iii|iv)\b/g, '') // sufijos
    .replace(/\b(de|del|la|los|las|von|van)\b/g, ''); // artículos
}
```

**RECOMENDACIÓN**:
```
✅ REEMPLAZAR implementación actual (Gemini) con SDN List del prompt
✅ Implementar como backend service (NO en frontend)
✅ Agregar whitelist para falsos positivos conocidos
✅ Agregar sistema de apelaciones (merchant puede disputar matches)
⚠️ Considerar API de terceros para producción (ComplyAdvantage, Dow Jones)
   si el volumen justifica el costo ($0.10-0.50 por check)
```

---

### FASE 5: SEGURIDAD + DEPLOY

**VALIDACIÓN**: ⚠️ **50% VÁLIDO, 50% NO APLICA**

#### Parte A: Seguridad

| Recomendación | ¿Aplica a Vite? | Estado Actual | Prioridad |
|---------------|----------------|---------------|-----------|
| **Mover API keys a backend** | ✅ SÍ | ❌ 24 archivos exponen `process.env.API_KEY` | 🔴 CRÍTICO |
| **Códigos seguros (crypto.randomBytes)** | ✅ SÍ | ⚠️ Código actual usa IDs simples | 🟡 ALTO |
| **Rate Limiting (Upstash)** | ⚠️ Solo con backend | ❌ No implementado | 🟡 ALTO |
| **Security Headers (next.config.js)** | ❌ NO (es vite.config.ts) | ❌ No configurado | 🟠 MEDIO |
| **Validación Zod** | ✅ SÍ | ❌ No usada actualmente | 🟡 ALTO |
| **Sentry** | ✅ SÍ | ❌ No configurado | 🟠 MEDIO |
| **Health Check Endpoint** | ⚠️ Necesita backend | ❌ No existe | 🟢 BAJO |

**PROBLEMAS DEL PROMPT**:

1. **Security Headers**:
```javascript
// Prompt usa next.config.js (NO EXISTE en Vite)
// next.config.js
module.exports = {
  async headers() { ... }
};
```

**Adaptación para Vite**:
```typescript
// vite.config.ts
import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    headers: {
      'X-Frame-Options': 'DENY',
      'X-Content-Type-Options': 'nosniff',
      // ... otros headers
    }
  }
});
```

**PERO**: Estos headers solo aplican en desarrollo. Para producción necesitas configurar Vercel/Netlify headers.

2. **Middleware**:
```typescript
// Prompt usa middleware.ts de Next.js (NO FUNCIONA en Vite)
export async function middleware(request: NextRequest) { ... }
```

**Adaptación**: Necesitas implementar rate limiting en backend.

3. **CSP demasiado permisivo**:
```
script-src 'self' 'unsafe-eval' 'unsafe-inline' https://js.stripe.com;
```
`unsafe-eval` y `unsafe-inline` son **INSEGUROS**. Vite puede funcionar sin ellos.

#### Parte B: CI/CD

**VALIDACIÓN**: ⚠️ **ESTRUCTURA VÁLIDA, COMANDOS NECESITAN ADAPTACIÓN**

| Aspecto | Prompt | Realidad Actual | Corrección Necesaria |
|---------|--------|----------------|---------------------|
| **Node version** | 20 ✅ | package.json no especifica | Agregar `"engines": { "node": ">=20" }` |
| **Lint command** | `npm run lint` | ❌ No existe en package.json | Agregar script |
| **Test command** | `npm run test` | ❌ No existe | Configurar Vitest |
| **Build command** | `npm run build` ✅ | ✅ Existe (Vite) | OK |
| **E2E tests** | Playwright ✅ | ❌ No configurado | Opcional para MVP |

**PROBLEMAS**:

1. **Variables de entorno incorrectas**:
```yaml
# Prompt usa Next.js env vars:
NEXT_PUBLIC_SUPABASE_URL: ${{ secrets.NEXT_PUBLIC_SUPABASE_URL }}

# Vite usa:
VITE_SUPABASE_URL: ${{ secrets.VITE_SUPABASE_URL }}
```

2. **Deploy to Vercel**:
El prompt asume Vercel, que SÍ soporta Vite. ✅ OK

Pero necesitas `vercel.json`:
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite"
}
```

**RECOMENDACIÓN**:
```
✅ Usar estructura del workflow (es buena)
⚠️ Adaptar nombres de env vars (VITE_ en vez de NEXT_PUBLIC_)
✅ Agregar scripts faltantes a package.json:
   - "lint": "eslint src --ext ts,tsx"
   - "test": "vitest"
   - "test:e2e": "playwright test"
✅ Configurar Vercel headers para producción (en vercel.json)
⚠️ Rate limiting necesita backend o Vercel Edge Functions
```

---

## 🎯 PLAN RECOMENDADO

### OPCIÓN 1: Migración a Next.js (Recomendado para Producción) ⭐

**Esfuerzo**: 2-3 semanas
**Beneficio**: Todos los prompts aplican directamente

**Pasos**:
1. ✅ Crear nuevo proyecto Next.js 15 (App Router)
2. ✅ Copiar componentes de `/components` (mayoría son compatibles)
3. ✅ Convertir `/apps/web/WebContainer.tsx` a `app/page.tsx`
4. ✅ Implementar Fase 1B (Schema Supabase) + correcciones
5. ✅ Implementar Fase 2 (Stripe) con prompts tal cual
6. ✅ Implementar Fase 3 (Auth) con ajustes menores
7. ✅ Implementar Fase 4 (OFAC) con backend routes
8. ✅ Implementar Fase 5 (Security) completo
9. ✅ Migrar features de IA a API routes (secure)
10. ✅ Tests + Deploy

**Pros**:
- ✅ Arquitectura production-ready
- ✅ SEO para marketplace
- ✅ Todos los prompts del documento aplicables
- ✅ Mejor DX (Developer Experience)
- ✅ Ecosystem maduro

**Cons**:
- ❌ Tiempo de migración
- ❌ Curva de aprendizaje (si no conoces App Router)

---

### OPCIÓN 2: Mantener Vite + Backend Separado

**Esfuerzo**: 3-4 semanas
**Beneficio**: Más flexibilidad, arquitectura moderna

**Stack Recomendado**:
- **Frontend**: Vite + React (actual) ✅
- **Backend**: Fastify + TypeScript + Supabase
- **Deploy**: Vercel (frontend) + Railway/Render (backend)

**Pasos**:
1. ✅ Crear repositorio backend: `supramercado-api`
2. ✅ Setup Fastify + TypeScript + Supabase client
3. ✅ Implementar Fase 1B (Schema) directamente en Supabase
4. ✅ Adaptar Fase 2 (Stripe) a Fastify routes
5. ✅ Adaptar Fase 3 (Auth) con Supabase + middleware
6. ✅ Adaptar Fase 4 (OFAC) como servicio backend
7. ✅ Implementar Fase 5 (Security): rate limiting, headers
8. ✅ Migrar features de IA a backend API
9. ✅ Configurar CORS entre frontend y backend
10. ✅ Deploy independiente

**Pros**:
- ✅ Frontend ya completo (no migrar)
- ✅ Escalabilidad independiente
- ✅ Más control sobre backend
- ✅ Puede usar otros lenguajes (Go, Rust) en futuro

**Cons**:
- ❌ Más complejo (2 repos)
- ❌ CORS configuration
- ❌ Todos los prompts necesitan adaptación

---

### OPCIÓN 3: Vite + Supabase Edge Functions (Híbrido)

**Esfuerzo**: 2-3 semanas
**Beneficio**: Balance entre simplicidad y funcionalidad

**Stack**:
- **Frontend**: Vite + React (actual) ✅
- **Backend**: Supabase Edge Functions (Deno)
- **DB**: Supabase PostgreSQL
- **Deploy**: Vercel (frontend) + Supabase (backend)

**Pasos**:
1. ✅ Implementar Fase 1B (Schema) en Supabase
2. ✅ Convertir prompts de Fase 2 (Stripe) a Edge Functions
3. ✅ Usar Supabase Auth directo (Fase 3 simplificada)
4. ✅ Implementar Fase 4 (OFAC) como Edge Function
5. ✅ Security en Edge Functions (Fase 5 parcial)
6. ✅ Migrar IA features a Edge Functions
7. ✅ Deploy

**Pros**:
- ✅ Todo en Supabase (un solo proveedor)
- ✅ Edge Functions gratis (hasta cierto límite)
- ✅ Deployment simple
- ✅ Frontend no cambia

**Cons**:
- ❌ Deno (no Node.js) - diferentes APIs
- ❌ Límites de tiempo de ejecución (Edge Functions)
- ❌ Vendor lock-in (Supabase)

---

## 📋 CHECKLIST DE CORRECCIONES AL DOCUMENTO

### Errores a Corregir:

- [ ] **Fase 1A**: Remover errores que no existen (imports rotos, hooks en callbacks)
- [ ] **Fase 1A**: Agregar errores REALES encontrados en auditoría
- [ ] **Fase 1B**: Agregar tablas faltantes (beneficiaries, subscriptions, wishlists, etc.)
- [ ] **Fase 1B**: Agregar tabla `employee_invitations`
- [ ] **Fase 2**: Aclarar si asume Next.js o backend separado
- [ ] **Fase 2**: Agregar variables de entorno faltantes (CONNECT_CLIENT_ID, etc.)
- [ ] **Fase 2**: Agregar manejo de idempotency keys
- [ ] **Fase 3**: Adaptar sintaxis para Vite (`createClient` vs `createClientComponentClient`)
- [ ] **Fase 4**: Mejorar `normalizeText()` con casos edge
- [ ] **Fase 4**: Agregar sistema de whitelist
- [ ] **Fase 5**: Adaptar security headers para Vite
- [ ] **Fase 5**: Corregir env vars (VITE_ en vez de NEXT_PUBLIC_)
- [ ] **Fase 5**: Aclarar que rate limiting necesita backend

### Adiciones Recomendadas:

- [ ] **Fase 0**: Agregar "Decisión de Arquitectura" (Next.js vs Vite+Backend)
- [ ] **Fase 1.5**: Migración de datos mock a Supabase
- [ ] **Fase 2.5**: Testing de Stripe en sandbox
- [ ] **Fase 3.5**: Migración de componentes de IA a backend
- [ ] **Fase 6**: Agregar fase de Testing (unit, integration, E2E)
- [ ] **Fase 7**: Agregar fase de Monitoring (Sentry, LogRocket, Analytics)

---

## ✅ CONCLUSIÓN Y PRÓXIMOS PASOS

### Resumen:

**El documento de implementación es**:
- ✅ **70% válido** en cuanto a LÓGICA de negocio
- ⚠️ **40% válido** en cuanto a IMPLEMENTACIÓN técnica (asume Next.js)
- ✅ **Excelente** en arquitectura de datos y flujos
- ❌ **Incompleto** en algunos schemas de DB
- ⚠️ **Requiere adaptación** según decisión de arquitectura

### Mi Recomendación:

**1. PRIMERO: Decidir Arquitectura** (antes de escribir código)

Pregunta clave: ¿Necesitas SEO para el marketplace?
- **SÍ** → Migrar a Next.js (Opción 1) ⭐
- **NO** → Vite + Backend separado (Opción 2)

**2. SEGUNDO: Corregir el Documento**

Antes de ejecutar los prompts, necesitas:
- ✅ Completar schema de DB (Fase 1B)
- ✅ Adaptar sintaxis según arquitectura elegida
- ✅ Agregar fase de decisión arquitectónica
- ✅ Agregar fase de testing

**3. TERCERO: Ejecutar en Orden**

Si eliges **Next.js**:
```
Fase 0: Migración a Next.js (2 semanas)
Fase 1: Schema DB (3 días)
Fase 2: Stripe (4 días)
Fase 3: Auth (3 días)
Fase 4: OFAC (2 días)
Fase 5: Security (3 días)
Fase 6: Testing (1 semana)
Fase 7: Deploy (2 días)
TOTAL: ~5 semanas
```

Si eliges **Vite + Backend**:
```
Fase 0: Setup Backend (1 semana)
Fase 1: Schema DB (3 días)
Fase 2: Stripe API (5 días)
Fase 3: Auth (4 días)
Fase 4: OFAC (3 días)
Fase 5: Security (4 días)
Fase 6: Testing (1 semana)
Fase 7: Deploy (3 días)
TOTAL: ~6 semanas
```

---

## 🚨 BLOQUEOS CRÍTICOS ACTUALES

Antes de continuar con CUALQUIER fase, debes resolver:

1. **🔴 CRÍTICO**: API keys de Gemini expuestas en frontend
   - **Impacto**: Seguridad, costos, abuse
   - **Solución**: Mover a backend ANTES de deploy

2. **🔴 CRÍTICO**: Decidir arquitectura (Next.js vs Vite+Backend)
   - **Impacto**: Todo el plan de implementación depende de esto
   - **Solución**: Tomar decisión en próximas 48h

3. **🟡 ALTO**: No hay persistencia de datos
   - **Impacto**: Testing real imposible
   - **Solución**: Implementar Fase 1B (Supabase) primero

4. **🟡 ALTO**: Stripe completamente simulado
   - **Impacto**: No puedes procesar pagos reales
   - **Solución**: Implementar Fase 2 con SDK real

---

## ❓ PREGUNTAS PARA TI

Antes de proceder, necesito que respondas:

1. **¿Estás dispuesto a migrar a Next.js?** (recomiendo SÍ)
   - SÍ → Uso prompts con adaptaciones menores
   - NO → Necesito reescribir 60% de los prompts para Vite+Backend

2. **¿Necesitas SEO para el marketplace?**
   - SÍ → Next.js obligatorio
   - NO → Vite + Backend es viable

3. **¿Cuál es tu timeline real?**
   - < 4 semanas → No alcanza para producción completa
   - 4-6 semanas → MVP funcional posible
   - > 6 semanas → Producto production-ready posible

4. **¿Tienes presupuesto para servicios?**
   - Supabase: Gratis hasta 500MB DB
   - Stripe: Sin costo mensual (solo fees por transacción)
   - Vercel: Gratis para hobby
   - Upstash Redis: $0 hasta 10K requests/día
   - Sentry: Gratis hasta 5K errors/mes
   - **¿OK con estos servicios?**

5. **¿Prefieres que yo ejecute las fases O prefieres que modifique el documento primero?**

---

**Espero tu decisión antes de proceder con código. 🎯**
