
/**
 * API Route: N8N Event Dispatcher
 * Puerta de enlace para automatizaciones (WhatsApp, Sync de Tasas, Auditoría).
 */

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { order, beneficiary, eventType } = req.body;
  const N8N_URL = process.env.N8N_WEBHOOK_URL || 'http://localhost:5678/webhook/order-created';

  console.info(`[N8N Trigger] Despachando evento ${eventType} para Orden: ${order.id}`);

  try {
    const response = await fetch(N8N_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        eventType,
        order: {
          id: order.id,
          total: order.totalUSD,
          items: order.items,
          magicLink: `https://supramercado.com/l/${order.magicLinkCode}`
        },
        beneficiary: {
          name: beneficiary.name,
          phone: beneficiary.phone,
          city: beneficiary.city
        }
      })
    });

    if (!response.ok) {
      throw new Error(`N8N respondió con status ${response.status}`);
    }

    return res.status(200).json({ success: true, message: "Evento orquestado exitosamente" });
  } catch (error) {
    console.error("[N8N Error]", error);
    // Fallback: No bloqueamos la UI del cliente si el orquestador falla,
    // pero registramos el error para retry manual.
    return res.status(202).json({ success: false, error: "Orquestador temporalmente fuera de línea" });
  }
}
