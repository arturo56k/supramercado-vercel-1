
/**
 * Stripe Connect Webhook Handler
 * Escucha eventos de transferencias y pagos para sincronizar el SaaS Admin de Supramercado.
 */

export default async function handler(req: any, res: any) {
  const event = req.body;

  switch (event.type) {
    case 'payment_intent.succeeded':
      const paymentIntent = event.data.object;
      console.log(`[Webhook] Pago confirmado exitosamente: ${paymentIntent.id}`);
      break;
    
    case 'transfer.created':
      const transfer = event.data.object;
      console.log(`[Webhook] Transferencia enviada a Merchant: ${transfer.destination}`);
      break;

    case 'account.updated':
      // Manejar cambios en el estado de verificación del comercio (KYC)
      const account = event.data.object;
      console.log(`[Webhook] Estado KYC de comercio actualizado: ${account.id}`);
      break;

    default:
      console.log(`[Webhook] Evento no manejado: ${event.type}`);
  }

  return res.status(200).json({ received: true });
}
