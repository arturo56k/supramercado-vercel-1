# 🔒 Security Headers - Supramercado

## Protección Completa contra Ataques Web

---

## 🎯 Descripción General

Los Security Headers son directivas HTTP que instruyen al navegador sobre cómo comportarse para proteger contra vulnerabilidades comunes como XSS, clickjacking, MIME sniffing, y más.

### Headers Implementados

✅ **Content-Security-Policy (CSP)** - Previene XSS y data injection
✅ **Strict-Transport-Security (HSTS)** - Fuerza HTTPS
✅ **X-Frame-Options** - Previene clickjacking
✅ **X-Content-Type-Options** - Previene MIME sniffing
✅ **X-XSS-Protection** - Filtro XSS en navegadores antiguos
✅ **Referrer-Policy** - Controla información de referrer
✅ **Permissions-Policy** - Controla APIs del navegador

---

## 🛡️ Headers de Seguridad

### 1. Content Security Policy (CSP)

**El más importante**. Previene ataques XSS y data injection controlando qué recursos puede cargar la página.

#### Nuestra Configuración

```
Content-Security-Policy:
  default-src 'self';
  script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://va.vercel-scripts.com;
  style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
  img-src 'self' data: https: blob: https://*.stripe.com https://*.supabase.co;
  font-src 'self' https://fonts.gstatic.com;
  connect-src 'self' https://api.stripe.com https://*.supabase.co https://*.upstash.io https://vitals.vercel-insights.com;
  frame-src 'self' https://js.stripe.com https://hooks.stripe.com;
  object-src 'none';
  base-uri 'self';
  form-action 'self';
  frame-ancestors 'none';
  upgrade-insecure-requests
```

#### Directivas Explicadas

| Directiva | Descripción | Valor |
|-----------|-------------|-------|
| `default-src` | Fallback para todas las directivas | `'self'` (mismo origen) |
| `script-src` | De dónde cargar JavaScript | Mismo origen + Stripe + Vercel |
| `style-src` | De dónde cargar CSS | Mismo origen + Google Fonts |
| `img-src` | De dónde cargar imágenes | Mismo origen + data URIs + HTTPS |
| `font-src` | De dónde cargar fuentes | Mismo origen + Google Fonts |
| `connect-src` | A dónde hacer fetch/XHR | APIs permitidas |
| `frame-src` | Qué puede cargarse en `<iframe>` | Stripe |
| `object-src` | Plugins (`<object>`, `<embed>`) | Ninguno |
| `base-uri` | URLs permitidas en `<base>` | Mismo origen |
| `form-action` | A dónde enviar formularios | Mismo origen |
| `frame-ancestors` | Quién puede embeber esta página | Nadie (previene clickjacking) |
| `upgrade-insecure-requests` | Actualizar HTTP a HTTPS | Activado |

#### ⚠️ Notas sobre `'unsafe-inline'` y `'unsafe-eval'`

```
script-src 'self' 'unsafe-inline' 'unsafe-eval'
```

**Problema**: Estos permiten JavaScript inline, lo cual reduce la seguridad de CSP.

**Por qué los usamos**:
- Next.js usa scripts inline para hydration
- React usa `eval` en desarrollo
- Stripe Elements requiere scripts inline

**Solución Futura**: Usar nonces para scripts inline:
```typescript
// Generar nonce en servidor
const nonce = generateNonce();

// Usar en CSP
script-src 'self' 'nonce-${nonce}' 'strict-dynamic'

// Usar en scripts
<script nonce={nonce}>...</script>
```

---

### 2. Strict-Transport-Security (HSTS)

Fuerza al navegador a usar HTTPS por un período especificado.

```
Strict-Transport-Security: max-age=63072000; includeSubDomains; preload
```

#### Detalles

- **max-age=63072000**: 2 años (en segundos)
- **includeSubDomains**: Aplicar a todos los subdominios
- **preload**: Elegible para lista de preload de navegadores

#### Preload List

Para máxima seguridad, registra tu dominio en [hstspreload.org](https://hstspreload.org).

**Requisitos**:
1. ✅ HTTPS válido en dominio y subdominios
2. ✅ Redirect de HTTP a HTTPS
3. ✅ HSTS header con `max-age >= 31536000` (1 año)
4. ✅ `includeSubDomains`
5. ✅ `preload`

**Advertencia**: Una vez en la preload list, es difícil salir. Solo habilita si estás seguro que SIEMPRE usarás HTTPS.

---

### 3. X-Frame-Options

Previene clickjacking al controlar si la página puede cargarse en un iframe.

```
X-Frame-Options: DENY
```

#### Opciones

| Valor | Descripción |
|-------|-------------|
| `DENY` | Nunca permitir iframes |
| `SAMEORIGIN` | Permitir solo del mismo origen |
| `ALLOW-FROM uri` | Permitir de URI específica (deprecated) |

**Nota**: `frame-ancestors` en CSP es más flexible y moderno.

---

### 4. X-Content-Type-Options

Previene MIME sniffing (navegador adivinando tipo de contenido).

```
X-Content-Type-Options: nosniff
```

Sin esto, el navegador podría interpretar un archivo de texto como JavaScript y ejecutarlo.

**Ejemplo de ataque**:
```html
<!-- Atacante sube un archivo "image.jpg" que en realidad es JS -->
<script src="/uploads/image.jpg"></script>

<!-- Sin nosniff: Navegador ejecuta el JS -->
<!-- Con nosniff: Navegador rechaza el archivo -->
```

---

### 5. X-XSS-Protection

Activa el filtro XSS built-in de navegadores antiguos.

```
X-XSS-Protection: 1; mode=block
```

#### Valores

- `0`: Desactivar filtro
- `1`: Activar filtro (sanitiza la página)
- `1; mode=block`: Bloquear completamente la página si detecta XSS

**Nota**: Deprecated en navegadores modernos (Chrome, Firefox) porque CSP es mejor. Pero útil para IE y Safari antiguos.

---

### 6. Referrer-Policy

Controla qué información de referrer se envía a otros sitios.

```
Referrer-Policy: strict-origin-when-cross-origin
```

#### Opciones

| Valor | Descripción |
|-------|-------------|
| `no-referrer` | Nunca enviar referrer |
| `no-referrer-when-downgrade` | No enviar en HTTPS → HTTP |
| `origin` | Solo enviar origen (no path) |
| `origin-when-cross-origin` | Enviar origen a otros orígenes, URL completa al mismo origen |
| `same-origin` | Solo enviar al mismo origen |
| `strict-origin` | Solo enviar origen, solo si HTTPS |
| `strict-origin-when-cross-origin` | **Nuestra elección** (balance seguridad/funcionalidad) |
| `unsafe-url` | Siempre enviar URL completa (inseguro) |

**Por qué `strict-origin-when-cross-origin`**:
- Mismo origen: Envía URL completa (útil para analytics)
- Otro origen: Solo envía origen (protege privacidad)
- No degrada de HTTPS a HTTP

---

### 7. Permissions-Policy

Controla qué APIs del navegador puede usar la página.

```
Permissions-Policy: camera=(), microphone=(), geolocation=(), interest-cohort=()
```

#### APIs Deshabilitadas

- `camera=()`: No puede acceder a cámara
- `microphone=()`: No puede acceder a micrófono
- `geolocation=()`: No puede acceder a ubicación
- `interest-cohort=()`: Bloquea FLoC (tracking de Google)

#### Sintaxis

```
feature=(self "https://example.com")  // Permitir solo a estos orígenes
feature=()                             // Bloquear completamente
feature=*                              // Permitir a todos (inseguro)
```

#### APIs Comunes

- `accelerometer`: Acelerómetro
- `autoplay`: Reproducción automática de medios
- `battery`: Estado de batería
- `camera`: Cámara
- `clipboard-read`: Leer clipboard
- `display-capture`: Captura de pantalla
- `geolocation`: Ubicación GPS
- `gyroscope`: Giroscopio
- `microphone`: Micrófono
- `payment`: Payment Request API
- `usb`: Acceso a dispositivos USB

---

## 🔧 Configuración en Next.js

Los headers están configurados en `next.config.js`:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/:path*',  // Aplicar a todas las rutas
        headers: [
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload',
          },
          {
            key: 'Content-Security-Policy',
            value: '...',
          },
          // ... otros headers
        ],
      },
    ];
  },
};

module.exports = nextConfig;
```

### Headers por Ruta

Puedes aplicar headers diferentes a rutas específicas:

```javascript
async headers() {
  return [
    {
      source: '/api/:path*',  // Solo APIs
      headers: [
        {
          key: 'Access-Control-Allow-Origin',
          value: 'https://app.example.com',
        },
      ],
    },
    {
      source: '/admin/:path*',  // Solo Admin
      headers: [
        {
          key: 'X-Robots-Tag',
          value: 'noindex, nofollow',  // No indexar en Google
        },
      ],
    },
  ];
}
```

---

## 🧪 Testing

### Herramientas Online

**1. Security Headers**
```
https://securityheaders.com
```
Ingresa tu URL y recibe un reporte completo con calificación (A+, A, B, etc.)

**2. Mozilla Observatory**
```
https://observatory.mozilla.org
```
Análisis completo de seguridad con recomendaciones.

**3. CSP Evaluator**
```
https://csp-evaluator.withgoogle.com
```
Específico para Content Security Policy.

### Testing Manual

```bash
# Ver headers de respuesta
curl -I https://supramercado.com

# Headers específicos
curl -I https://supramercado.com | grep -i "content-security-policy"
curl -I https://supramercado.com | grep -i "strict-transport-security"
```

### Testing en Navegador

**Chrome DevTools:**
```
1. Abrir DevTools (F12)
2. Network tab
3. Reload página
4. Click en request principal
5. Ver "Response Headers"
```

**CSP Violations:**
```
1. DevTools → Console
2. Buscar errores como:
   "Refused to load script because it violates CSP"
3. Ajustar CSP según sea necesario
```

---

## 🐛 Troubleshooting

### CSP Bloqueando Recursos Legítimos

**Síntoma:**
```
Refused to load script from 'https://example.com/script.js'
because it violates the following Content Security Policy directive:
"script-src 'self'"
```

**Solución:**

1. Identificar el origen del recurso bloqueado
2. Decidir si es necesario y confiable
3. Agregar al CSP:

```javascript
// En next.config.js
"script-src 'self' https://example.com"
```

**Herramienta útil**: CSP Report-Only mode

```javascript
{
  key: 'Content-Security-Policy-Report-Only',  // Solo reportar, no bloquear
  value: '...',
}
```

---

### HSTS Causando Problemas

**Síntoma**: No puedes acceder a HTTP durante desarrollo

**Solución**:

**Opción A**: Limpiar HSTS en Chrome
```
chrome://net-internals/#hsts
→ Delete domain security policies
→ Ingresar "localhost"
→ Delete
```

**Opción B**: Usar diferente dominio para desarrollo
```
# En lugar de localhost:3000
# Usar: local.supramercado.test:3000
```

**Opción C**: Deshabilitar HSTS en desarrollo
```javascript
// next.config.js
async headers() {
  if (process.env.NODE_ENV === 'development') {
    return [];  // Sin headers en desarrollo
  }

  return [/* headers de producción */];
}
```

---

### Stripe/Google Fonts Bloqueados

**Síntoma**: Stripe Elements no carga, fuentes no aparecen

**Solución**: Verificar que CSP permite estos orígenes

```javascript
"script-src 'self' https://js.stripe.com",
"style-src 'self' https://fonts.googleapis.com",
"font-src 'self' https://fonts.gstatic.com",
"frame-src 'self' https://js.stripe.com",
```

---

## 🔐 Helpers de Seguridad

Usa los helpers en `src/lib/security.ts`:

### Generar Nonce para CSP

```typescript
import { generateNonce, getCSPWithNonce } from '@/lib/security';

export default function Page() {
  const nonce = generateNonce();

  return (
    <html>
      <head>
        <meta httpEquiv="Content-Security-Policy" content={getCSPWithNonce(nonce)} />
      </head>
      <body>
        <script nonce={nonce}>
          console.log('This script is allowed by nonce');
        </script>
      </body>
    </html>
  );
}
```

### Sanitizar Input de Usuario

```typescript
import { sanitizeHTML } from '@/lib/security';

const userInput = '<script>alert("XSS")</script>';
const safe = sanitizeHTML(userInput);
// Output: &lt;script&gt;alert(&quot;XSS&quot;)&lt;/script&gt;
```

### Validar URLs

```typescript
import { sanitizeURL, isSafeRedirect } from '@/lib/security';

// Validar URL externa
const url = sanitizeURL('https://evil.com', ['stripe.com', 'google.com']);
// null si no es de dominio permitido

// Validar redirect
const safe = isSafeRedirect('/dashboard', 'https://supramercado.com');
// true (mismo origen)

const unsafe = isSafeRedirect('https://evil.com', 'https://supramercado.com');
// false (origen diferente)
```

### Validar Content-Type

```typescript
import { validateContentType } from '@/lib/security';

const contentType = request.headers.get('content-type');
const isValid = validateContentType(contentType, ['application/json']);

if (!isValid) {
  return NextResponse.json({ error: 'Invalid content type' }, { status: 400 });
}
```

---

## 📊 Mejores Prácticas

### 1. Empezar con Report-Only

```javascript
// Primera iteración: Solo reportar
{
  key: 'Content-Security-Policy-Report-Only',
  value: '...',
}

// Después de 1-2 semanas sin errores: Aplicar
{
  key: 'Content-Security-Policy',
  value: '...',
}
```

### 2. Ser Específico en CSP

```javascript
// ❌ Malo
"script-src *"  // Permite cualquier origen

// ✅ Bueno
"script-src 'self' https://js.stripe.com https://va.vercel-scripts.com"
```

### 3. Usar Subresource Integrity (SRI)

Para scripts/styles externos:

```html
<script
  src="https://cdn.example.com/lib.js"
  integrity="sha384-oqVuAfXRKap7fdgcCY5uykM6+R9GqQ8K/uxy9rx7HNQlGYl1kPzQho1wx4JwY8wC"
  crossorigin="anonymous"
></script>
```

Generar hash:
```typescript
import { generateSRIHash } from '@/lib/security';

const scriptContent = '...';
const hash = generateSRIHash(scriptContent);
// sha384-oqVuAfXRKap7fdgcCY5uykM6+R9GqQ8K/uxy9rx7HNQlGYl1kPzQho1wx4JwY8wC
```

### 4. Actualizar Regularmente

Revisar headers cada 6 meses:
- Nuevas directivas CSP
- Cambios en third-party scripts
- Nuevos estándares de seguridad

---

## 📋 Checklist de Seguridad

### Desarrollo
- [ ] Headers configurados en `next.config.js`
- [ ] CSP no bloquea recursos necesarios
- [ ] Stripe Elements funciona correctamente
- [ ] Fuentes cargan correctamente
- [ ] Console sin errores de CSP violations
- [ ] Helpers de seguridad creados

### Pre-Producción
- [ ] Test en securityheaders.com (objetivo: A o A+)
- [ ] Test en observatory.mozilla.org
- [ ] CSP Evaluator sin warnings críticos
- [ ] HSTS configurado correctamente
- [ ] No hay `unsafe-inline`/`unsafe-eval` (o justificados)
- [ ] Permissions-Policy restringe APIs innecesarias

### Producción
- [ ] HTTPS activo y certificado válido
- [ ] Redirect HTTP → HTTPS funcionando
- [ ] Headers presentes en todas las páginas
- [ ] CSP Report-Only → CSP aplicado
- [ ] (Opcional) Dominio en HSTS preload list
- [ ] Monitoring de violaciones CSP
- [ ] Plan de respuesta a incidentes de seguridad

---

## 🎓 Recursos

### Estándares y Documentación

- [MDN: CSP](https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP)
- [MDN: Security Headers](https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers#security)
- [OWASP: Secure Headers](https://owasp.org/www-project-secure-headers/)

### Herramientas

- [Security Headers](https://securityheaders.com)
- [Mozilla Observatory](https://observatory.mozilla.org)
- [CSP Evaluator](https://csp-evaluator.withgoogle.com)
- [HSTS Preload](https://hstspreload.org)

### Lecturas Recomendadas

- [Content Security Policy Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Content_Security_Policy_Cheat_Sheet.html)
- [Security Headers Best Practices](https://blog.cloudflare.com/security-header-quick-reference/)

---

## ⚠️ Avisos Importantes

### No Romper Funcionalidad

Los headers de seguridad pueden romper funcionalidad si están mal configurados:

- CSP muy estricto → Scripts/styles no cargan
- HSTS mal configurado → Usuarios no pueden acceder a HTTP
- X-Frame-Options → Embedding legítimo bloqueado

**Siempre testear en staging antes de producción.**

### Balance Seguridad vs Usabilidad

A veces necesitas compromisos:

```javascript
// Ideal (máxima seguridad)
"script-src 'self' 'nonce-xyz123'"

// Realidad (funcional con Next.js)
"script-src 'self' 'unsafe-inline' 'unsafe-eval'"
```

Documentar por qué cada excepción es necesaria.

---

**Prompt 11 Status**: COMPLETADO ✅

**Siguiente**: Prompt 12 - Logging con Axiom

**Nota de Seguridad**: Los headers de seguridad son una defensa crítica pero no suficiente por sí solos. Combinar con validación de input, autenticación robusta, HTTPS, y rate limiting para protección completa.
