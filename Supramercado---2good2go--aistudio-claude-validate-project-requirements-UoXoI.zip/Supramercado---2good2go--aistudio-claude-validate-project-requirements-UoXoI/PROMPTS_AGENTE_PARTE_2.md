# 🤖 PROMPTS AGENTE PARTE 2 - Implementación Completa

**Continuación de PROMPTS_AGENTE.md**

---

## PROMPT 6: Implementar Autenticación con Supabase Auth

**Objetivo**: Sistema completo de autenticación multi-rol

**Crear clientes de Supabase**:

Archivo `src/lib/supabase/client.ts`:
```typescript
import { createBrowserClient } from '@supabase/ssr';

export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
```

Archivo `src/lib/supabase/server.ts`:
```typescript
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { cookies } from 'next/headers';

export function createServerSupabaseClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {}
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: '', ...options });
          } catch {}
        },
      },
    }
  );
}
```

**Crear middleware de autenticación**:

Archivo `src/middleware.ts`:
```typescript
import { createServerClient, type CookieOptions } from '@supabase/ssr';
import { NextResponse, type NextRequest } from 'next/server';
import { rateLimiters } from '@/lib/rate-limit';

export async function middleware(request: NextRequest) {
  const ip = request.ip ?? '127.0.0.1';
  const path = request.nextUrl.pathname;

  // Rate limiting
  if (path.startsWith('/api/')) {
    let limiter;

    if (path.startsWith('/api/auth')) {
      limiter = rateLimiters.auth;
    } else if (path.startsWith('/api/stripe/checkout')) {
      limiter = rateLimiters.checkout;
    } else if (path.startsWith('/api/')) {
      limiter = rateLimiters.api;
    }

    if (limiter) {
      const { success, limit, reset, remaining } = await limiter.limit(ip);

      if (!success) {
        return new NextResponse('Too Many Requests', {
          status: 429,
          headers: {
            'X-RateLimit-Limit': limit.toString(),
            'X-RateLimit-Remaining': remaining.toString(),
            'X-RateLimit-Reset': reset.toString(),
          },
        });
      }
    }
  }

  // Supabase auth
  let response = NextResponse.next({ request: { headers: request.headers } });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          request.cookies.set({ name, value, ...options });
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options: CookieOptions) {
          request.cookies.set({ name, value: '', ...options });
          response = NextResponse.next({ request: { headers: request.headers } });
          response.cookies.set({ name, value: '', ...options });
        },
      },
    }
  );

  await supabase.auth.getSession();

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
};
```

**Crear hook useAuth**:

Archivo `src/hooks/useAuth.ts`:
```typescript
'use client';

import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import type { User } from '@supabase/supabase-js';
import { UserRole } from '@prisma/client';

export interface AuthUser {
  id: string;
  email: string;
  role: UserRole;
  merchantId?: string;
  fullName?: string;
  avatarUrl?: string;
}

export function useAuth() {
  const supabase = createClient();
  const router = useRouter();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();

      if (session?.user) {
        await loadUserProfile(session.user);
      }

      setLoading(false);
    };

    getSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (event === 'SIGNED_IN' && session?.user) {
          await loadUserProfile(session.user);
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const loadUserProfile = async (authUser: User) => {
    const { data: profile } = await supabase
      .from('users')
      .select('*')
      .eq('id', authUser.id)
      .single();

    if (profile) {
      setUser({
        id: authUser.id,
        email: authUser.email!,
        role: profile.role,
        merchantId: profile.merchant_id,
        fullName: profile.full_name,
        avatarUrl: profile.avatar_url,
      });
    }
  };

  const signInWithGoogle = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
  };

  const signInWithEmail = async (email: string) => {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    if (error) throw error;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    router.push('/');
  };

  return {
    user,
    loading,
    isAuthenticated: !!user,
    signInWithGoogle,
    signInWithEmail,
    signOut,
  };
}
```

**Crear componente ProtectedRoute**:

Archivo `src/components/ProtectedRoute.tsx`:
```typescript
'use client';

import { useAuth } from '@/hooks/useAuth';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { UserRole } from '@prisma/client';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: UserRole[];
  fallbackUrl?: string;
}

export function ProtectedRoute({
  children,
  allowedRoles,
  fallbackUrl = '/login',
}: ProtectedRouteProps) {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;

    if (!user) {
      router.push(fallbackUrl);
      return;
    }

    if (allowedRoles && !allowedRoles.includes(user.role)) {
      router.push('/unauthorized');
      return;
    }
  }, [user, loading, allowedRoles, router, fallbackUrl]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
}
```

**Crear callback route**:

Archivo `src/app/auth/callback/route.ts`:
```typescript
import { createServerSupabaseClient } from '@/lib/supabase/server';
import { NextResponse } from 'next/server';

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get('code');
  const next = searchParams.get('next') ?? '/marketplace';

  if (code) {
    const supabase = createServerSupabaseClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  return NextResponse.redirect(`${origin}/auth/error`);
}
```

**Habilitar Google OAuth en Supabase**:
1. Ir a https://console.cloud.google.com
2. Crear nuevo proyecto
3. Habilitar Google+ API
4. Crear credenciales OAuth 2.0
5. Redirect URL: `https://[TU-PROYECTO].supabase.co/auth/v1/callback`
6. Copiar Client ID y Secret a Supabase Dashboard > Authentication > Providers > Google

**Checklist**:
- [ ] Supabase clients creados
- [ ] Middleware configurado
- [ ] Hook useAuth implementado
- [ ] ProtectedRoute funcionando
- [ ] Google OAuth habilitado

---

## PROMPT 7: Implementar Stripe Connect

**Objetivo**: Pagos reales con Direct Charges + Application Fee

**Crear servicio de Stripe**:

Archivo `src/lib/stripe/client.ts`:
```typescript
import { loadStripe, Stripe } from '@stripe/stripe-js';

let stripePromise: Promise<Stripe | null>;

export function getStripe(): Promise<Stripe | null> {
  if (!stripePromise) {
    stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!);
  }
  return stripePromise;
}
```

Archivo `src/lib/stripe/server.ts`:
```typescript
import Stripe from 'stripe';
import { getConfig } from '@/lib/config/platform-config';

let stripeInstance: Stripe | null = null;

export async function getStripeServer(): Promise<Stripe> {
  if (stripeInstance) return stripeInstance;

  const apiKey = await getConfig('STRIPE_SECRET_KEY');

  if (!apiKey) {
    throw new Error('Stripe API key not configured');
  }

  stripeInstance = new Stripe(apiKey, {
    apiVersion: '2024-12-18.acacia',
  });

  return stripeInstance;
}
```

**Onboarding de Merchants**:

Archivo `src/app/api/stripe/connect/onboard/route.ts`:
```typescript
import { getStripeServer } from '@/lib/stripe/server';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { merchantId, email, businessName } = await req.json();

    const stripe = await getStripeServer();

    // Crear Connected Account
    const account = await stripe.accounts.create({
      type: 'express',
      country: 'US',
      email,
      business_type: 'company',
      company: { name: businessName },
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
      metadata: { merchantId },
    });

    // Guardar en DB
    await prisma.merchant.update({
      where: { id: merchantId },
      data: {
        stripeAccountId: account.id,
        stripeAccountStatus: 'pending',
      },
    });

    // Generar Account Link
    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: `${process.env.NEXT_PUBLIC_URL}/merchant/onboarding/refresh`,
      return_url: `${process.env.NEXT_PUBLIC_URL}/merchant/onboarding/complete`,
      type: 'account_onboarding',
    });

    return NextResponse.json({ url: accountLink.url });
  } catch (error: any) {
    console.error('[Stripe Onboarding Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

**Checkout**:

Archivo `src/app/api/stripe/checkout/route.ts`:
```typescript
import { getStripeServer } from '@/lib/stripe/server';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { orderId } = await req.json();

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { merchant: true },
    });

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    if (order.status !== 'pending_payment') {
      return NextResponse.json({ error: 'Order already processed' }, { status: 400 });
    }

    const stripe = await getStripeServer();

    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(Number(order.totalUsd) * 100),
      currency: 'usd',
      application_fee_amount: Math.round(Number(order.platformFeeUsd) * 100),
      transfer_data: {
        destination: order.merchant.stripeAccountId!,
      },
      metadata: {
        orderId: order.id,
        merchantId: order.merchantId,
        orderNumber: order.orderNumber,
      },
      automatic_payment_methods: { enabled: true },
    });

    await prisma.order.update({
      where: { id: orderId },
      data: { stripePaymentIntentId: paymentIntent.id },
    });

    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error: any) {
    console.error('[Stripe Checkout Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

**Webhook Handler**:

Archivo `src/app/api/stripe/webhook/route.ts`:
```typescript
import { getStripeServer } from '@/lib/stripe/server';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { getConfig } from '@/lib/config/platform-config';
import { nanoid } from 'nanoid';

export async function POST(req: Request) {
  const body = await req.text();
  const signature = headers().get('stripe-signature')!;

  const stripe = await getStripeServer();
  const webhookSecret = await getConfig('STRIPE_WEBHOOK_SECRET');

  if (!webhookSecret) {
    return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 500 });
  }

  let event: any;

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err: any) {
    console.error('[Webhook Error]', err.message);
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  switch (event.type) {
    case 'payment_intent.succeeded': {
      const paymentIntent = event.data.object;
      const orderId = paymentIntent.metadata.orderId;

      await prisma.order.update({
        where: { id: orderId },
        data: {
          status: 'paid',
          paidAt: new Date(),
          stripeChargeId: paymentIntent.latest_charge,
          pickupCode: nanoid(8).toUpperCase(),
          magicLinkCode: nanoid(32),
          magicLinkExpiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        },
      });

      // TODO: Enviar magic link (siguiente prompt)
      console.log('[Payment Succeeded]', orderId);
      break;
    }

    case 'payment_intent.payment_failed': {
      const paymentIntent = event.data.object;
      const orderId = paymentIntent.metadata.orderId;

      await prisma.order.update({
        where: { id: orderId },
        data: { status: 'cancelled' },
      });

      console.log('[Payment Failed]', orderId);
      break;
    }

    case 'account.updated': {
      const account = event.data.object;
      const merchantId = account.metadata.merchantId;

      const status = account.charges_enabled ? 'active' : 'pending';

      await prisma.merchant.update({
        where: { id: merchantId },
        data: { stripeAccountStatus: status },
      });

      console.log('[Account Updated]', merchantId, status);
      break;
    }
  }

  return NextResponse.json({ received: true });
}
```

**Configurar webhook en Stripe Dashboard**:
1. Ir a https://dashboard.stripe.com/test/webhooks
2. Add endpoint: `https://[TU-DOMINIO]/api/stripe/webhook`
3. Seleccionar eventos:
   - payment_intent.succeeded
   - payment_intent.payment_failed
   - account.updated
   - charge.dispute.created
4. Copiar webhook secret a dashboard de configuración

**Checklist**:
- [ ] Servicio Stripe creado
- [ ] Onboarding API implementado
- [ ] Checkout API implementado
- [ ] Webhook handler configurado
- [ ] Webhook registrado en Stripe

---

## PROMPT 8: Implementar OFAC Screening

**Objetivo**: Validación de sanciones con SDN List de OFAC

**Crear servicio de actualización SDN**:

Archivo `src/lib/ofac/update-sdn-list.ts`:
```typescript
import { prisma } from '@/lib/prisma';
import { parse } from 'csv-parse/sync';

const SDN_CSV_URL = 'https://www.treasury.gov/ofac/downloads/sdn.csv';

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // acentos
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\b(jr|sr|ii|iii|iv|de|del|la|los|las|von|van)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function updateSdnList() {
  console.log('📥 Downloading SDN list...');

  const response = await fetch(SDN_CSV_URL);
  const csvText = await response.text();

  const records = parse(csvText, {
    skip_empty_lines: true,
  });

  console.log(`📊 Found ${records.length} SDN entries`);

  // Limpiar tabla
  await prisma.sdnEntry.deleteMany();

  const entries = records.map((row: string[]) => ({
    entryId: row[0],
    name: row[1],
    nameNormalized: normalizeText(row[1]),
    sdnType: row[2] || null,
    program: row[3] || null,
    countries: row[4] ? [row[4]] : [],
    aliases: [],
    aliasesNormalized: [],
    rawData: { originalRow: row },
  }));

  // Insertar en batches
  for (let i = 0; i < entries.length; i += 1000) {
    const batch = entries.slice(i, i + 1000);
    await prisma.sdnEntry.createMany({ data: batch });
    console.log(`✅ Inserted batch ${i / 1000 + 1}`);
  }

  console.log('✅ SDN list updated successfully');
  return entries.length;
}
```

**Crear servicio de screening**:

Archivo `src/lib/ofac/screening.ts`:
```typescript
import { prisma } from '@/lib/prisma';

interface ScreeningResult {
  isClean: boolean;
  matches: Array<{
    sdnEntryId: string;
    name: string;
    matchScore: number;
    matchType: 'exact' | 'fuzzy';
  }>;
  screenedAt: Date;
}

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s]/g, '')
    .replace(/\b(jr|sr|ii|iii|iv|de|del|la|los|las|von|van)\b/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export async function screenBeneficiary(
  beneficiaryName: string
): Promise<ScreeningResult> {
  const normalized = normalizeText(beneficiaryName);

  // Búsqueda exacta
  const exactMatches = await prisma.sdnEntry.findMany({
    where: { nameNormalized: normalized },
    select: { entryId: true, name: true },
  });

  if (exactMatches.length > 0) {
    return {
      isClean: false,
      matches: exactMatches.map((m) => ({
        sdnEntryId: m.entryId,
        name: m.name,
        matchScore: 100,
        matchType: 'exact' as const,
      })),
      screenedAt: new Date(),
    };
  }

  // Búsqueda fuzzy (simulada con LIKE - para producción usar pg_trgm)
  const fuzzyMatches = await prisma.sdnEntry.findMany({
    where: {
      nameNormalized: {
        contains: normalized.split(' ')[0], // Buscar por primer nombre
      },
    },
    take: 10,
  });

  if (fuzzyMatches.length > 0) {
    return {
      isClean: false,
      matches: fuzzyMatches.map((m) => ({
        sdnEntryId: m.entryId,
        name: m.name,
        matchScore: 80,
        matchType: 'fuzzy' as const,
      })),
      screenedAt: new Date(),
    };
  }

  return {
    isClean: true,
    matches: [],
    screenedAt: new Date(),
  };
}
```

**API route para screening**:

Archivo `src/app/api/ofac/screen/route.ts`:
```typescript
import { screenBeneficiary } from '@/lib/ofac/screening';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    const { beneficiaryName, orderId } = await req.json();

    const result = await screenBeneficiary(beneficiaryName);

    await prisma.ofacScreening.create({
      data: {
        orderId: orderId || null,
        screenedName: beneficiaryName,
        screeningResult: result.isClean ? 'clear' : 'potential_match',
        screeningProvider: 'internal_sdn_list',
        matchDetails: result.matches.length > 0 ? result.matches : null,
        screenedAt: result.screenedAt,
      },
    });

    if (!result.isClean) {
      console.error('[OFAC MATCH]', beneficiaryName, result.matches);
      // TODO: Enviar alerta a compliance team
    }

    return NextResponse.json(result);
  } catch (error: any) {
    console.error('[OFAC Screening Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

**Crear Vercel Cron para actualización semanal**:

Archivo `src/app/api/cron/update-sdn/route.ts`:
```typescript
import { updateSdnList } from '@/lib/ofac/update-sdn-list';
import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  // Verificar que es Vercel Cron
  const authHeader = req.headers.get('authorization');
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const count = await updateSdnList();
    return NextResponse.json({ success: true, count });
  } catch (error: any) {
    console.error('[Cron Update SDN Error]', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
```

Archivo `vercel.json`:
```json
{
  "crons": [
    {
      "path": "/api/cron/update-sdn",
      "schedule": "0 6 * * 1"
    }
  ]
}
```

**Checklist**:
- [ ] Servicio de actualización SDN creado
- [ ] Servicio de screening implementado
- [ ] API route de screening funcionando
- [ ] Vercel Cron configurado

---

## PROMPT 9: Implementar Notificaciones (Resend + Twilio)

**Objetivo**: Enviar magic links por email/WhatsApp

**Crear servicio de email (Resend)**:

Archivo `src/lib/email/resend.ts`:
```typescript
import { Resend } from 'resend';
import { getConfig } from '@/lib/config/platform-config';

let resendInstance: Resend | null = null;

async function getResend(): Promise<Resend> {
  if (resendInstance) return resendInstance;

  const apiKey = await getConfig('RESEND_API_KEY');

  if (!apiKey) {
    throw new Error('Resend API key not configured');
  }

  resendInstance = new Resend(apiKey);
  return resendInstance;
}

export async function sendMagicLinkEmail(
  to: string,
  magicLinkCode: string,
  orderNumber: string
) {
  const resend = await getResend();

  const magicLinkUrl = `${process.env.NEXT_PUBLIC_URL}/redeem/${magicLinkCode}`;

  await resend.emails.send({
    from: 'Supramercado <noreply@supramercado.com>',
    to,
    subject: `Tu pedido ${orderNumber} está listo para retirar`,
    html: `
      <h1>¡Tu pedido está listo! 🎉</h1>
      <p>Hola,</p>
      <p>Tu pedido <strong>${orderNumber}</strong> ha sido pagado exitosamente y está listo para retirar.</p>
      <p><strong>Código de retiro:</strong> Usa el siguiente enlace para ver los detalles y retirar tu pedido:</p>
      <p><a href="${magicLinkUrl}" style="background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">Ver Pedido</a></p>
      <p>O copia este enlace: ${magicLinkUrl}</p>
      <p>Saludos,<br>El equipo de Supramercado</p>
    `,
  });
}
```

**Crear servicio de WhatsApp/SMS (Twilio)**:

Archivo `src/lib/sms/twilio.ts`:
```typescript
import twilio from 'twilio';
import { getConfig } from '@/lib/config/platform-config';

let twilioClient: any = null;

async function getTwilio() {
  if (twilioClient) return twilioClient;

  const accountSid = await getConfig('TWILIO_ACCOUNT_SID');
  const authToken = await getConfig('TWILIO_AUTH_TOKEN');

  if (!accountSid || !authToken) {
    throw new Error('Twilio credentials not configured');
  }

  twilioClient = twilio(accountSid, authToken);
  return twilioClient;
}

export async function sendMagicLinkWhatsApp(
  to: string,
  magicLinkCode: string,
  orderNumber: string
) {
  const client = await getTwilio();
  const whatsappNumber = await getConfig('TWILIO_WHATSAPP_NUMBER');

  const magicLinkUrl = `${process.env.NEXT_PUBLIC_URL}/redeem/${magicLinkCode}`;

  await client.messages.create({
    from: whatsappNumber,
    to: `whatsapp:${to}`,
    body: `¡Tu pedido ${orderNumber} está listo para retirar! 🎉\n\nUsa este enlace para ver los detalles:\n${magicLinkUrl}\n\nSaludos, Supramercado`,
  });
}

export async function sendMagicLinkSMS(
  to: string,
  magicLinkCode: string,
  orderNumber: string
) {
  const client = await getTwilio();
  const smsNumber = await getConfig('TWILIO_SMS_NUMBER');

  const magicLinkUrl = `${process.env.NEXT_PUBLIC_URL}/redeem/${magicLinkCode}`;

  await client.messages.create({
    from: smsNumber,
    to,
    body: `Tu pedido ${orderNumber} está listo. Ver: ${magicLinkUrl}`,
  });
}
```

**Actualizar webhook de Stripe para enviar notificaciones**:

Modificar `src/app/api/stripe/webhook/route.ts`, agregar después de actualizar orden:

```typescript
case 'payment_intent.succeeded': {
  // ... código existente ...

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { buyer: true },
  });

  if (order) {
    // Enviar magic link
    try {
      await sendMagicLinkEmail(
        order.buyer.email,
        order.magicLinkCode!,
        order.orderNumber
      );

      // Intentar WhatsApp, si falla usar SMS
      try {
        await sendMagicLinkWhatsApp(
          order.beneficiaryPhone,
          order.magicLinkCode!,
          order.orderNumber
        );
      } catch (whatsappError) {
        console.warn('[WhatsApp Failed, trying SMS]', whatsappError);
        await sendMagicLinkSMS(
          order.beneficiaryPhone,
          order.magicLinkCode!,
          order.orderNumber
        );
      }
    } catch (error) {
      console.error('[Notification Error]', error);
      // No fallar el webhook por error de notificación
    }
  }

  break;
}
```

**Checklist**:
- [ ] Resend configurado
- [ ] Twilio configurado
- [ ] Email de magic link funcionando
- [ ] WhatsApp/SMS fallback funcionando
- [ ] Webhook actualizado

---

## PROMPT 10: Implementar Rate Limiting

**Objetivo**: Protección contra abuse con Upstash Redis

Archivo `src/lib/rate-limit.ts`:
```typescript
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';
import { getConfig } from '@/lib/config/platform-config';

let redis: Redis | null = null;

async function getRedis(): Promise<Redis> {
  if (redis) return redis;

  const url = await getConfig('UPSTASH_REDIS_URL');
  const token = await getConfig('UPSTASH_REDIS_TOKEN');

  if (!url || !token) {
    throw new Error('Upstash Redis not configured');
  }

  redis = new Redis({ url, token });
  return redis;
}

export const rateLimiters = {
  api: new Ratelimit({
    redis: await getRedis(),
    limiter: Ratelimit.slidingWindow(20, '1 m'),
    prefix: 'rl:api',
  }),

  auth: new Ratelimit({
    redis: await getRedis(),
    limiter: Ratelimit.slidingWindow(5, '1 m'),
    prefix: 'rl:auth',
  }),

  checkout: new Ratelimit({
    redis: await getRedis(),
    limiter: Ratelimit.slidingWindow(10, '5 m'),
    prefix: 'rl:checkout',
  }),

  ofac: new Ratelimit({
    redis: await getRedis(),
    limiter: Ratelimit.slidingWindow(3, '1 h'),
    prefix: 'rl:ofac',
  }),
};
```

**Ya configurado en middleware.ts (Prompt 6)**

**Checklist**:
- [ ] Upstash Redis configurado
- [ ] Rate limiters definidos
- [ ] Middleware aplicando limits

---

## PROMPT 11: Implementar Security Headers y Validación

**Objetivo**: Hardening de seguridad

**Configurar Next.js headers**:

Archivo `next.config.js`:
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-DNS-Prefetch-Control', value: 'on' },
          { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'origin-when-cross-origin' },
          {
            key: 'Content-Security-Policy',
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-eval' 'unsafe-inline' https://js.stripe.com",
              "style-src 'self' 'unsafe-inline'",
              "img-src 'self' blob: data: https://images.unsplash.com https://*.supabase.co",
              "font-src 'self'",
              "connect-src 'self' https://*.supabase.co https://api.stripe.com wss://*.supabase.co",
              "frame-src https://js.stripe.com https://hooks.stripe.com",
            ].join('; '),
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
```

**Crear validaciones con Zod**:

Archivo `src/lib/validations.ts`:
```typescript
import { z } from 'zod';

export const createOrderSchema = z.object({
  merchantId: z.string().uuid(),
  beneficiaryName: z
    .string()
    .min(2, 'Nombre muy corto')
    .max(100, 'Nombre muy largo')
    .regex(/^[a-zA-ZáéíóúñÁÉÍÓÚÑ\s'-]+$/, 'Nombre inválido'),
  beneficiaryPhone: z
    .string()
    .regex(/^\+?[1-9]\d{9,14}$/, 'Teléfono inválido'),
  items: z
    .array(
      z.object({
        productId: z.string().uuid(),
        quantity: z.number().int().min(1).max(100),
      })
    )
    .min(1, 'Debe tener al menos un producto'),
});

export const redeemOrderSchema = z.object({
  pickupCode: z.string().length(8).regex(/^[A-Z0-9]+$/),
  employeeId: z.string().uuid().optional(),
});
```

**Checklist**:
- [ ] Security headers configurados
- [ ] Schemas de validación creados
- [ ] CSP policy aplicada

---

## PROMPT 12: Implementar Logging con Axiom

**Objetivo**: Logs estructurados para debugging

Archivo `src/lib/logging/axiom.ts`:
```typescript
import { getConfig } from '@/lib/config/platform-config';

interface LogEvent {
  level: 'info' | 'warn' | 'error';
  message: string;
  data?: Record<string, any>;
  timestamp?: string;
}

export async function log(event: LogEvent) {
  try {
    const axiomToken = await getConfig('AXIOM_TOKEN');
    const axiomDataset = await getConfig('AXIOM_DATASET');

    if (!axiomToken || !axiomDataset) {
      console.log('[Log]', event); // Fallback to console
      return;
    }

    await fetch(`https://api.axiom.co/v1/datasets/${axiomDataset}/ingest`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${axiomToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify([
        {
          ...event,
          timestamp: event.timestamp || new Date().toISOString(),
          environment: process.env.NODE_ENV,
        },
      ]),
    });
  } catch (error) {
    console.error('[Axiom Log Error]', error);
  }
}
```

**Usar en código**:
```typescript
import { log } from '@/lib/logging/axiom';

await log({
  level: 'info',
  message: 'Order created successfully',
  data: { orderId: order.id, orderNumber: order.orderNumber },
});
```

**Checklist**:
- [ ] Axiom configurado
- [ ] Logger implementado
- [ ] Usado en endpoints críticos

---

## PROMPT 13: Crear Páginas Principales de Next.js

**Objetivo**: Rutas principales del app

**Landing**:
Archivo `src/app/page.tsx`:
```typescript
import { Landing } from '@/components/Landing';

export const metadata = {
  title: 'Supramercado - Envía amor a República Dominicana',
  description: 'Marketplace binacional USA → RD. Compra productos frescos y envía a tus seres queridos.',
};

export default function HomePage() {
  return <Landing />;
}
```

**Marketplace**:
Archivo `src/app/marketplace/page.tsx`:
```typescript
import { Marketplace } from '@/components/Marketplace';

export const metadata = {
  title: 'Marketplace - Supramercado',
  description: 'Compra productos frescos de República Dominicana',
};

export default function MarketplacePage() {
  return <Marketplace />;
}
```

**Merchant Hub**:
Archivo `src/app/merchant/page.tsx`:
```typescript
import { MerchantHub } from '@/components/MerchantHub';
import { ProtectedRoute } from '@/components/ProtectedRoute';

export const metadata = {
  title: 'Merchant Hub - Supramercado',
};

export default function MerchantPage() {
  return (
    <ProtectedRoute allowedRoles={['MERCHANT_ADMIN', 'MERCHANT_EMPLOYEE']}>
      <MerchantHub />
    </ProtectedRoute>
  );
}
```

**Admin Config**:
Archivo `src/app/admin/config/page.tsx`:
```typescript
import { ConfigDashboard } from '@/components/admin/ConfigDashboard';
import { ProtectedRoute } from '@/components/ProtectedRoute';

export const metadata = {
  title: 'Admin Config - Supramercado',
};

export default function AdminConfigPage() {
  return (
    <ProtectedRoute allowedRoles={['SAAS_ADMIN']}>
      <ConfigDashboard />
    </ProtectedRoute>
  );
}
```

**Redeem (Magic Link)**:
Archivo `src/app/redeem/[code]/page.tsx`:
```typescript
import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';

export default async function RedeemPage({ params }: { params: { code: string } }) {
  const order = await prisma.order.findUnique({
    where: {
      magicLinkCode: params.code,
      status: 'ready_for_pickup',
      magicLinkExpiresAt: { gt: new Date() },
    },
    include: {
      merchant: true,
      beneficiary: true,
    },
  });

  if (!order) {
    return notFound();
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Tu Pedido está Listo 🎉</h1>
      <div className="bg-white rounded-lg shadow p-6 space-y-4">
        <div>
          <p className="text-sm text-gray-600">Número de Orden</p>
          <p className="text-2xl font-bold">{order.orderNumber}</p>
        </div>

        <div>
          <p className="text-sm text-gray-600">Código de Retiro</p>
          <p className="text-3xl font-mono font-bold text-green-600">{order.pickupCode}</p>
        </div>

        <div>
          <p className="text-sm text-gray-600">Retirar en</p>
          <p className="text-lg font-semibold">{order.merchant.name}</p>
          <p className="text-sm text-gray-600">{order.merchant.address?.street}</p>
        </div>

        <div className="pt-4 border-t">
          <p className="text-sm text-gray-600">Productos</p>
          {/* Renderizar items */}
        </div>
      </div>
    </div>
  );
}
```

**Checklist**:
- [ ] Todas las páginas creadas
- [ ] Metadata SEO configurada
- [ ] ProtectedRoutes aplicadas

---

## PROMPT 14: Deploy a Vercel

**Objetivo**: Desplegar a producción

**Pasos**:

1. **Instalar Vercel CLI**:
```bash
npm install -g vercel
vercel login
```

2. **Configurar proyecto**:
```bash
vercel
# Seguir wizard:
# - Link to existing project: No
# - Project name: supramercado
# - Directory: ./
# - Override build: No
```

3. **Agregar env vars en Vercel Dashboard**:
   - Ir a https://vercel.com/dashboard
   - Proyecto > Settings > Environment Variables
   - Agregar TODAS las variables de `.env.local`
   - Separar en "Production", "Preview", "Development"

4. **Deploy a producción**:
```bash
vercel --prod
```

5. **Configurar dominio custom** (opcional):
   - Vercel Dashboard > Domains
   - Add domain: `supramercado.com`
   - Configurar DNS según instrucciones

6. **Configurar webhooks de Stripe en producción**:
   - Stripe Dashboard > Webhooks
   - Add endpoint: `https://supramercado.com/api/stripe/webhook`
   - Copiar webhook secret
   - Actualizar en Vercel env vars

7. **Actualizar Supabase redirect URLs**:
   - Supabase Dashboard > Authentication > URL Configuration
   - Site URL: `https://supramercado.com`
   - Redirect URLs:
     - `https://supramercado.com/auth/callback`
     - `http://localhost:3000/auth/callback` (dev)

8. **Generar ENCRYPTION_KEY**:
```bash
openssl rand -base64 32
# Agregar a Vercel env vars
```

9. **Generar NEXTAUTH_SECRET**:
```bash
openssl rand -base64 32
# Agregar a Vercel env vars
```

10. **Crear CRON_SECRET**:
```bash
openssl rand -base64 32
# Agregar a Vercel env vars
```

**Verificación Post-Deploy**:
```bash
# Health check
curl https://supramercado.com/api/health

# Test Stripe webhook
stripe listen --forward-to https://supramercado.com/api/stripe/webhook --live

# Actualizar SDN list manualmente
curl -X GET https://supramercado.com/api/cron/update-sdn \
  -H "Authorization: Bearer $CRON_SECRET"
```

**Checklist**:
- [ ] Vercel CLI instalado
- [ ] Proyecto configurado
- [ ] Env vars agregadas
- [ ] Deploy exitoso
- [ ] Dominio configurado
- [ ] Webhooks actualizados
- [ ] Supabase URLs actualizadas
- [ ] Health check OK

---

## PROMPT 15: Testing Final y Checklist

**Objetivo**: Verificar que todo funciona end-to-end

**Testing Manual**:

1. **Autenticación**:
   - [ ] Login con Google funciona
   - [ ] Magic link por email funciona
   - [ ] Logout funciona
   - [ ] ProtectedRoutes bloquean acceso no autorizado

2. **Marketplace**:
   - [ ] Ver productos
   - [ ] Agregar al carrito
   - [ ] Seleccionar beneficiario
   - [ ] Crear orden

3. **OFAC Screening**:
   - [ ] Probar con nombre en SDN list (buscar "NARCO" o "ESCOBAR")
   - [ ] Verificar que bloquea la transacción
   - [ ] Verificar que se guarda en `ofac_screenings`

4. **Checkout + Stripe**:
   - [ ] Usar tarjeta test: 4242424242424242
   - [ ] Verificar PaymentIntent creado
   - [ ] Verificar webhook recibido
   - [ ] Verificar orden actualizada a "paid"
   - [ ] Verificar magic link generado

5. **Notificaciones**:
   - [ ] Email recibido con magic link
   - [ ] WhatsApp recibido (o SMS si falla)

6. **Magic Link (Redeem)**:
   - [ ] Abrir link desde email
   - [ ] Ver detalles de orden
   - [ ] Verificar código de retiro

7. **Merchant Hub**:
   - [ ] Login como merchant
   - [ ] Ver órdenes
   - [ ] Actualizar inventario
   - [ ] Ver analytics

8. **Admin Dashboard**:
   - [ ] Login como SAAS_ADMIN
   - [ ] Configurar API keys
   - [ ] Verificar encriptación
   - [ ] Ver logs

**Testing Automatizado** (opcional para post-MVP):

Archivo `tests/e2e/checkout.spec.ts`:
```typescript
import { test, expect } from '@playwright/test';

test('Complete checkout flow', async ({ page }) => {
  // 1. Go to marketplace
  await page.goto('/marketplace');

  // 2. Add product to cart
  await page.click('button:has-text("Agregar al Carrito")');

  // 3. Go to checkout
  await page.click('a:has-text("Ver Carrito")');

  // 4. Fill beneficiary info
  await page.fill('input[name="beneficiaryName"]', 'Juan Pérez');
  await page.fill('input[name="beneficiaryPhone"]', '+18095551234');

  // 5. Submit order
  await page.click('button:has-text("Proceder al Pago")');

  // 6. Fill Stripe test card
  await page.frameLocator('iframe[name*="stripe"]').locator('input[name="cardnumber"]').fill('4242424242424242');
  await page.frameLocator('iframe[name*="stripe"]').locator('input[name="exp-date"]').fill('12/34');
  await page.frameLocator('iframe[name*="stripe"]').locator('input[name="cvc"]').fill('123');

  // 7. Submit payment
  await page.click('button:has-text("Pagar")');

  // 8. Wait for confirmation
  await expect(page.locator('text=Pago Exitoso')).toBeVisible({ timeout: 10000 });
});
```

**Métricas de Performance**:
```bash
# Lighthouse audit
npx lighthouse https://supramercado.com --view

# Verificar métricas:
# - Performance > 90
# - Accessibility > 95
# - Best Practices > 95
# - SEO > 95
```

**Checklist Final de Producción**:

**Funcionalidad**:
- [ ] Autenticación completa
- [ ] Checkout funcionando
- [ ] OFAC screening activo
- [ ] Notificaciones enviándose
- [ ] Magic links funcionando
- [ ] Merchant hub operativo
- [ ] Admin dashboard configurado

**Seguridad**:
- [ ] API keys encriptadas
- [ ] Rate limiting activo
- [ ] Security headers aplicados
- [ ] RLS policies activas
- [ ] HTTPS enforced
- [ ] CSP configurado

**Performance**:
- [ ] Lighthouse > 90
- [ ] First Contentful Paint < 1.5s
- [ ] Time to Interactive < 3s
- [ ] Images optimizadas

**Monitoring**:
- [ ] Axiom recibiendo logs
- [ ] Sentry configurado (opcional)
- [ ] Vercel Analytics activo
- [ ] Webhooks logging eventos

**Compliance**:
- [ ] OFAC screening 100% de órdenes
- [ ] Audit logs guardando eventos
- [ ] Privacy policy publicada
- [ ] Terms of service publicados

**DevOps**:
- [ ] CI/CD funcionando
- [ ] Vercel Cron ejecutándose
- [ ] Backup de DB configurado
- [ ] DNS propagado

---

## 🎉 ¡PROYECTO COMPLETO!

Has migrado exitosamente de Vite a Next.js y configurado una plataforma production-ready con:

✅ Autenticación multi-rol segura
✅ Pagos reales con Stripe Connect
✅ Compliance OFAC automático
✅ Notificaciones multicanal
✅ Dashboard de configuración
✅ Logging estructurado
✅ Rate limiting
✅ Security hardening
✅ Deploy en Vercel

**Costo operativo**: ~$50-70/mes para primeros 6 meses
**Capacidad**: Soporta hasta 10K usuarios sin cambios

---

## 📚 Documentación para Usuario Final

Crear archivo `MANUAL_ADMINISTRADOR.md`:

```markdown
# Manual del Administrador - Supramercado

## Acceso al Dashboard de Configuración

1. Ir a https://supramercado.com/admin/config
2. Login con cuenta SAAS_ADMIN
3. Configurar todas las integraciones

## Servicios a Configurar

### 1. Stripe
- Crear cuenta en https://stripe.com
- Copiar API keys de Dashboard > Developers > API Keys
- Configurar webhooks en Dashboard > Webhooks

### 2. Supabase
- Ya configurado
- Ver credenciales en Dashboard > Settings > API

### 3. Resend
- Crear cuenta en https://resend.com
- Agregar dominio
- Copiar API key

### 4. Twilio
- Crear cuenta en https://twilio.com
- Comprar número de teléfono
- Configurar WhatsApp (solicitar acceso)
- Copiar Account SID y Auth Token

### 5. Upstash
- Crear cuenta en https://upstash.com
- Crear database Redis
- Copiar URL y Token

### 6. Axiom
- Crear cuenta en https://axiom.co
- Crear dataset "supramercado-logs"
- Copiar API token

## Actualización de Configuración

1. Login en https://supramercado.com/admin/config
2. Editar campos necesarios
3. Click "Guardar Configuración"
4. Cambios aplicados instantáneamente (sin redeploy)

## Monitoreo

- **Logs**: https://app.axiom.co
- **Errors**: https://sentry.io (si configurado)
- **Analytics**: Vercel Dashboard

## Soporte

- Email: soporte@supramercado.com
- Documentación técnica: https://github.com/tu-repo/docs
```

---

**FIN DE PROMPTS SECUENCIALES**

**Siguiente paso**: Ejecutar prompts del 0 al 15 en orden, llenando credenciales según sea necesario.
