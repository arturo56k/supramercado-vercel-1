# Supramercado | Documentación del Proyecto MVP

## 1. Visión General
**Supramercado** es una plataforma de remesas de víveres diseñada para el corredor **Nueva York (USA) -> República Dominicana (RD)**. A diferencia de las remesas de efectivo tradicionales, Supra permite a la diáspora comprar "paquetes de valor" o productos individuales directamente en comercios locales (colmados y supermercados) en RD.

### Problemas que resuelve:
1. **Costos de Transacción:** Elimina las altas comisiones de envío de efectivo.
2. **Uso de Fondos:** Garantiza que el dinero se use exclusivamente para alimentación y salud.
3. **Seguridad:** Evita que los beneficiarios (muchas veces envejecientes) manejen efectivo en la calle.

---

## 2. Arquitectura Técnica
El proyecto está construido como una **Progressive Web App (PWA)** con enfoque *offline-first* para adaptarse a la conectividad inestable en zonas rurales de RD.

*   **Frontend:** React 19 + Tailwind CSS.
*   **Inteligencia Artificial:** Google Gemini API (Modelos 3-flash y 2.5-flash).
*   **Infraestructura de Datos (Pendiente):** Supabase (PostgreSQL + Auth).
*   **Hosting:** Vercel (Frontend) + Hostinger Cloud (Dominio/Email).
*   **Dominio:** `supramercado.com`.

---

## 3. Estado Actual (Lo que ya está construido)

### Interfaces y Experiencia de Usuario (UI/UX):
- **Landing Page Dinámica:** Marketplace con filtrado por categoría y ubicación.
- **Terminal POS (Merchant Hub):** Consola para que el colmadero gestione pedidos, inventario y liquidaciones.
- **Panel SaaS Admin:** Control global de tasas de cambio (BPD), disputas y métricas de red.
- **Magic Link View:** Interfaz del beneficiario con ticket digital y validación de seguridad.

### Funcionalidades Críticas:
- **Resiliencia Offline:** Service Worker configurado, HUD de red y cola de sincronización en LocalStorage.
- **Seguridad Geográfica (GeoGuard):** Validación de proximidad GPS para evitar redenciones fraudulentas.
- **Escaneo Inteligente:** Simulación de escaneo de QR con validación de PIN de seguridad.
- **Capa de IA (Gemini):** 
    - *Voice FAQ:* Conversación TTS multi-hablante.
    - *Freshness Audit:* Visión artificial para verificar estado de perecederos.
    - *Recipe Planner:* Razonamiento para optimizar ingredientes comprados.
    - *Impact Tracker:* Generación de certificados de sostenibilidad.

---

## 4. Pendiente por Construir (Backlog Técnico)

### A. Persistencia de Datos (Integración Supabase):
Actualmente, los datos son volátiles o locales. Se requiere:
1.  **Tablas SQL:**
    - `merchants`: RNC, coordenadas, balance, configuración Stripe.
    - `products`: Precios en DOP, stock, imágenes.
    - `orders`: Relación comprador-beneficiario, estado de pago, código de redención.
    - `payouts`: Registro de transferencias bancarias a comercios.
2.  **Auth:** Implementar Supabase Auth para acceso de Compradores (OAuth) y Comerciantes (Magic Link por Email).

### B. Pasarela de Pagos (Stripe):
- Integrar **Stripe Checkout** para cobros en USD.
- Configurar **Stripe Connect** para la dispersión de fondos (Payouts) a cuentas bancarias dominicanas.

### C. Notificaciones Reales:
- Integración con **Twilio o Meta API** para enviar el Magic Link automáticamente por WhatsApp al completar el pago.

---

## 5. Hoja de Ruta para Implementación (Roadmap)

### Fase 1: Despliegue en Vercel & Dominio
1.  Vincular el repositorio a Vercel.
2.  Configurar los registros DNS en **Hostinger** para apuntar `supramercado.com` a Vercel.
3.  Configurar correos corporativos (`soporte@supramercado.com`) en Hostinger Cloud.

### Fase 2: Configuración de Supabase
1.  Crear proyecto en Supabase.
2.  Ejecutar scripts de migración para las tablas mencionadas en la sección 4.A.
3.  Reemplazar los mocks de `OrderContext.tsx` con llamadas a `supabase-js`.

### Fase 3: Pruebas de Campo (Beta cerrada)
1.  Seleccionar 3 colmados en Santiago/Santo Domingo.
2.  Realizar pruebas de redención en modo offline total para validar la cola de sincronización.
3.  Ajustar el radio del `GeoGuard` según la precisión del GPS local.

---

## 6. Mantenimiento y Operación

### Variables de Entorno Críticas:
- `API_KEY`: Google Gemini API.
- `SUPABASE_URL` / `SUPABASE_ANON_KEY`: Conexión a base de datos.
- `STRIPE_SECRET_KEY`: Procesamiento de pagos.

### Monitoreo:
- El componente `NetworkHUD` es la primera línea de defensa para diagnosticar problemas de los comerciantes en RD.
- Las disputas se gestionan exclusivamente desde la pestaña "Disputas" del SaaS Admin para proteger el *Escrow* (fondos retenidos).

### Escalabilidad:
El sistema permite añadir "Sucursales" fácilmente. La lógica de **Merchant of Record (MoR)** está embebida en la interfaz legal del checkout, asegurando que Supra sea el responsable ante el procesador de pagos mientras que el colmado es un proveedor de última milla.
