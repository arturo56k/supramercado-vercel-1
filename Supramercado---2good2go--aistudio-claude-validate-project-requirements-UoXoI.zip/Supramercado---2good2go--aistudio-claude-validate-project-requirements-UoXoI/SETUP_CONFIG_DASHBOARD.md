# ⚙️ Dashboard de Configuración - Supramercado

## Sistema de Gestión de Claves API con Encriptación AES-256

---

## 🎯 Descripción General

El Dashboard de Configuración permite a los **administradores SaaS** gestionar todas las claves API y configuraciones sensibles **sin tocar código ni variables de entorno**.

### Características Principales

- 🔐 **Encriptación AES-256-GCM** para todos los valores sensibles
- 💾 **Almacenamiento en base de datos** PostgreSQL
- 🎨 **Interfaz visual** fácil de usar
- ✅ **Validación automática** de formatos de claves
- 🔒 **Acceso restringido** solo a SAAS_ADMIN
- 📊 **Indicadores visuales** de configuraciones faltantes
- 🔄 **Actualización en tiempo real** sin reiniciar la aplicación

---

## 🔐 Arquitectura de Seguridad

### Encriptación AES-256-GCM

```
Plain Text API Key
        ↓
Generate Random Salt (64 bytes)
        ↓
Derive Key (PBKDF2, 100k iterations)
        ↓
Generate Random IV (16 bytes)
        ↓
Encrypt with AES-256-GCM
        ↓
Store: salt:iv:authTag:encryptedData
```

### Características de Seguridad

1. **AES-256-GCM**: Algoritmo de encriptación de grado militar
2. **PBKDF2**: 100,000 iteraciones para derivación de clave
3. **Salt único**: 64 bytes aleatorios por cada valor
4. **IV único**: 16 bytes aleatorios por cada valor
5. **Authentication Tag**: Verifica integridad de datos
6. **Timing-safe comparison**: Previene ataques de timing

---

## 🛠️ Configuración Inicial

### 1. Generar ENCRYPTION_KEY

**CRÍTICO**: El `ENCRYPTION_KEY` debe ser una clave de 32 bytes (64 caracteres hexadecimales).

```bash
# Generar clave segura
openssl rand -hex 32

# Output example:
# 8f3d9c7e6b2a1f4d8e3c9b7a6f2d1e4c8b7a6f3d2e1c9b8a7f6e5d4c3b2a1f0e
```

### 2. Configurar en .env.local

```bash
# Development
ENCRYPTION_KEY=8f3d9c7e6b2a1f4d8e3c9b7a6f2d1e4c8b7a6f3d2e1c9b8a7f6e5d4c3b2a1f0e
```

### 3. Configurar en Vercel (Producción)

```
Vercel Dashboard → Project → Settings → Environment Variables

Name: ENCRYPTION_KEY
Value: <tu_clave_generada>
Environment: Production
```

**⚠️ IMPORTANTE**:
- Nunca commitear el `ENCRYPTION_KEY` al repositorio
- Guardar backup de la clave en un gestor de contraseñas seguro
- Si pierdes la clave, **no podrás recuperar las configuraciones encriptadas**

---

## 👤 Crear Usuario Administrador

Para acceder al dashboard necesitas un usuario con rol `SAAS_ADMIN`.

### Opción A: Crear via SQL

```sql
-- Conecta a Supabase SQL Editor

-- 1. Encontrar tu user ID de Supabase Auth
SELECT id, email FROM auth.users;

-- 2. Actualizar rol a SAAS_ADMIN
UPDATE users
SET role = 'SAAS_ADMIN'
WHERE id = 'tu-user-id-aqui';

-- Verificar
SELECT id, email, role FROM users WHERE role = 'SAAS_ADMIN';
```

### Opción B: Primer Usuario Automático

Al hacer login por primera vez, puedes modificar el callback para auto-asignar SAAS_ADMIN al primer usuario:

```typescript
// src/app/auth/callback/route.ts

// Solo para el PRIMER usuario (descomentar temporalmente)
const userCount = await prisma.user.count();
const isFirstUser = userCount === 0;

await prisma.user.upsert({
  where: { id: data.user.id },
  create: {
    id: data.user.id,
    email: data.user.email!,
    fullName: data.user.user_metadata?.full_name,
    role: isFirstUser ? 'SAAS_ADMIN' : 'CLIENT', // <-- Auto-assign SAAS_ADMIN
  },
  // ...
});
```

**⚠️ Recordar comentar esta lógica después de crear el primer admin.**

---

## 📱 Acceder al Dashboard

### URL

```
http://localhost:3000/admin/config         (Desarrollo)
https://supramercado.com/admin/config      (Producción)
```

### Flujo de Acceso

1. **Login** con Google OAuth o Magic Link
2. El sistema verifica que tienes rol `SAAS_ADMIN`
3. Si no eres admin → **403 Forbidden**
4. Si eres admin → Acceso al dashboard

---

## 🎨 Usar el Dashboard

### Categorías Disponibles

| Categoría | Icon | Configuraciones |
|-----------|------|----------------|
| Todas | 📋 | Ver todas las configuraciones |
| Stripe | 💳 | STRIPE_SECRET_KEY, STRIPE_WEBHOOK_SECRET |
| Resend | 📧 | RESEND_API_KEY |
| Twilio | 📱 | TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, números |
| Gemini | 🤖 | GEMINI_API_KEY |
| General | ⚙️ | NEXT_PUBLIC_APP_URL, CRON_SECRET |

### Agregar/Editar Configuración

1. Selecciona la categoría
2. Encuentra la configuración (marcada como "NO CONFIGURADO" si falta)
3. Click en **"➕ Configurar"** o **"✏️ Editar"**
4. Ingresa el valor
5. Click en **"💾 Guardar"**
6. El sistema:
   - Valida el formato
   - Encripta el valor
   - Guarda en base de datos
   - Muestra confirmación

### Eliminar Configuración

1. Solo configuraciones **NO requeridas** pueden eliminarse
2. Click en **"🗑️ Eliminar"**
3. Confirma la acción
4. El valor se elimina de la base de datos

### Indicadores Visuales

**Configuración Requerida Faltante:**
```
🔴 Borde rojo + Background rojo claro
"⚠️ NO CONFIGURADO" + "REQUERIDO"
```

**Configuración Requerida Configurada:**
```
🟢 Borde verde
"✅ CONFIGURADO" + "REQUERIDO"
```

**Configuración Opcional:**
```
⚪ Borde gris
"⚠️ NO CONFIGURADO"
```

**Valor Sensible:**
```
🟡 Badge "🔒 SENSIBLE"
Campo de input tipo password
```

---

## 🔧 Configuraciones Disponibles

### Stripe (Pagos)

**STRIPE_SECRET_KEY** ⚠️ Requerido
- Formato: `sk_test_...` o `sk_live_...`
- Dónde obtener: [Stripe Dashboard → Developers → API Keys](https://dashboard.stripe.com/apikeys)

**STRIPE_WEBHOOK_SECRET** ⚠️ Requerido
- Formato: `whsec_...`
- Dónde obtener: Stripe Dashboard → Developers → Webhooks

---

### Resend (Emails)

**RESEND_API_KEY** ⚠️ Requerido
- Formato: `re_...`
- Dónde obtener: [Resend Dashboard → API Keys](https://resend.com/api-keys)

---

### Twilio (SMS/WhatsApp)

**TWILIO_ACCOUNT_SID** ⚠️ Requerido
- Formato: `AC...`
- Dónde obtener: [Twilio Console](https://console.twilio.com/)

**TWILIO_AUTH_TOKEN** ⚠️ Requerido
- Formato: String de 32 caracteres
- Dónde obtener: Twilio Console (mismo lugar que SID)

**TWILIO_WHATSAPP_NUMBER** (Opcional)
- Formato: `whatsapp:+14155238886`
- Dónde configurar: Twilio Console → Messaging → WhatsApp

**TWILIO_SMS_NUMBER** (Opcional)
- Formato: `+18091234567`
- Dónde comprar: Twilio Console → Phone Numbers → Buy a number

---

### Gemini (AI)

**GEMINI_API_KEY** (Opcional)
- Formato: String
- Dónde obtener: [Google AI Studio](https://makersuite.google.com/app/apikey)

---

### General

**NEXT_PUBLIC_APP_URL** ⚠️ Requerido
- Formato: `https://supramercado.com` (sin trailing slash)
- Valor de desarrollo: `http://localhost:3000`
- Valor de producción: Tu dominio de Vercel

**CRON_SECRET** ⚠️ Requerido
- Formato: String aleatorio seguro
- Generar con: `openssl rand -hex 32`
- Uso: Proteger endpoints de cron jobs

---

## 📊 Estado de Validación

En la esquina superior derecha del dashboard verás:

### ✅ Configurado (Verde)
```
Todas las configuraciones requeridas están presentes
Sistema listo para producción
```

### ⚠️ Incompleto (Rojo)
```
Faltan X configuraciones requeridas
Lista de configuraciones faltantes mostrada abajo
```

---

## 🔄 Cómo Funciona Internamente

### Orden de Prioridad

Al obtener una configuración, el sistema busca en este orden:

1. **Base de datos** (encriptado) - Primera prioridad
2. **Variable de entorno** (.env.local o Vercel) - Fallback

### Ejemplo de Flujo

```typescript
// En tu código de aplicación
import { getConfig } from '@/lib/config';

const stripeKey = await getConfig('STRIPE_SECRET_KEY');
// 1. Busca en platform_config table
// 2. Si encuentra → desencripta y retorna
// 3. Si no encuentra → retorna process.env.STRIPE_SECRET_KEY
// 4. Si ninguno → retorna null
```

### Migración Gradual

Puedes migrar gradualmente de variables de entorno a base de datos:

```
Día 1: Configurar STRIPE_SECRET_KEY en dashboard
       → Sistema usa valor de DB
       → Variable de env queda como fallback

Día 2: Configurar RESEND_API_KEY en dashboard
       → Sistema usa valor de DB para Resend
       → Resto sigue usando env vars

Día N: Todas configuradas en DB
       → Eliminar variables de entorno (opcional)
```

---

## 🔒 Seguridad Avanzada

### Prevención de Ataques

**1. Timing Attacks**
```typescript
// secureCompare() previene timing attacks
import { secureCompare } from '@/lib/encryption';

if (secureCompare(inputSecret, storedSecret)) {
  // Authorized
}
```

**2. SQL Injection**
- Prisma ORM sanitiza automáticamente todas las queries

**3. XSS**
- Next.js escapa automáticamente el output
- Valores sensibles nunca se renderizan completos en el frontend

**4. Unauthorized Access**
```typescript
// Todos los endpoints están protegidos
const authError = await requireAdmin();
if (authError) return authError;
```

---

## 🧪 Testing

### Test de Encriptación

```typescript
// src/lib/encryption.ts
import { testEncryption } from '@/lib/encryption';

const isWorking = testEncryption();
console.log(isWorking); // true si funciona correctamente
```

### Test Manual

```bash
# 1. Configurar una clave de prueba
curl -X POST http://localhost:3000/api/admin/config \
  -H "Content-Type: application/json" \
  -H "Cookie: sb-access-token=..." \
  -d '{
    "key": "TEST_KEY",
    "value": "test-value-123",
    "category": "general"
  }'

# 2. Obtener la clave
curl http://localhost:3000/api/admin/config/TEST_KEY \
  -H "Cookie: sb-access-token=..."

# 3. Verificar en base de datos que está encriptada
```

---

## 🐛 Troubleshooting

### Error: "ENCRYPTION_KEY not configured"

**Causa**: Falta la variable `ENCRYPTION_KEY` en el entorno

**Solución**:
```bash
# 1. Generar clave
openssl rand -hex 32

# 2. Agregar a .env.local
echo "ENCRYPTION_KEY=<tu_clave>" >> .env.local

# 3. Reiniciar servidor
npm run dev
```

---

### Error: "Invalid encrypted data format"

**Causa**: Intentando desencriptar un valor que no fue encriptado correctamente

**Solución**:
1. Eliminar la configuración corrupta de la base de datos
2. Volver a configurar desde el dashboard

```sql
DELETE FROM platform_config WHERE key = 'NOMBRE_CLAVE';
```

---

### Error: "Forbidden: Admin access required"

**Causa**: Usuario no tiene rol `SAAS_ADMIN`

**Solución**:
```sql
UPDATE users
SET role = 'SAAS_ADMIN'
WHERE email = 'tu@email.com';
```

---

### Configuración no se refleja inmediatamente

**Causa**: El valor está cacheado en memoria

**Solución**:
- En desarrollo: Reiniciar el servidor
- En producción: El cambio aplica inmediatamente en nuevas peticiones

---

## 📚 API Reference

### GET /api/admin/config

Lista todas las configuraciones disponibles.

**Query Params:**
- `category` (opcional): Filtrar por categoría

**Response:**
```json
{
  "configs": [
    {
      "key": "STRIPE_SECRET_KEY",
      "category": "stripe",
      "description": "Stripe Secret Key for API calls",
      "required": true,
      "sensitive": true,
      "isConfigured": true,
      "isActive": true,
      "createdAt": "2024-01-01T00:00:00Z",
      "updatedAt": "2024-01-02T00:00:00Z"
    }
  ]
}
```

---

### GET /api/admin/config/[key]

Obtiene una configuración específica.

**Response:**
```json
{
  "key": "STRIPE_SECRET_KEY",
  "value": "sk_test_***abc123", // Masked if sensitive
  "masked": true
}
```

---

### POST /api/admin/config

Crea o actualiza una configuración.

**Body:**
```json
{
  "key": "STRIPE_SECRET_KEY",
  "value": "sk_test_51ABC123...",
  "category": "stripe",
  "description": "Stripe Secret Key"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Configuration STRIPE_SECRET_KEY updated successfully"
}
```

---

### DELETE /api/admin/config/[key]

Elimina una configuración (solo si NO es requerida).

**Response:**
```json
{
  "success": true,
  "message": "Configuration deleted successfully"
}
```

---

### GET /api/admin/config/validate

Valida que todas las configuraciones requeridas estén presentes.

**Response:**
```json
{
  "valid": false,
  "missing": ["STRIPE_SECRET_KEY", "RESEND_API_KEY"],
  "message": "Missing 2 required configuration(s)"
}
```

---

## 📋 Checklist de Configuración

### Desarrollo
- [ ] `ENCRYPTION_KEY` generada y configurada
- [ ] Usuario SAAS_ADMIN creado
- [ ] Acceso al dashboard verificado (`/admin/config`)
- [ ] Configuraciones de prueba guardadas correctamente
- [ ] Encriptación/desencriptación funcionando
- [ ] Validación de formatos funcionando

### Producción
- [ ] `ENCRYPTION_KEY` configurada en Vercel (igual que desarrollo)
- [ ] Usuario SAAS_ADMIN creado en producción
- [ ] Todas las configuraciones requeridas ingresadas
- [ ] Estado de validación: ✅ Configurado
- [ ] Backup del `ENCRYPTION_KEY` guardado de forma segura
- [ ] Variables de entorno eliminadas (opcional, usar DB como source of truth)
- [ ] Test de acceso al dashboard en producción
- [ ] Documentación entregada al equipo

---

## 🔐 Mejores Prácticas

### 1. Rotación de Claves

```
Cada 90 días:
1. Generar nuevas API keys en servicios externos
2. Actualizar en el dashboard
3. Verificar funcionamiento
4. Revocar claves antiguas
```

### 2. Backup de ENCRYPTION_KEY

```
Guardar en:
- ✅ 1Password / LastPass / Bitwarden
- ✅ Vault empresarial
- ❌ NUNCA en repositorio git
- ❌ NUNCA en archivos de texto plano
```

### 3. Auditoría

```sql
-- Revisar quién modificó configuraciones
SELECT
  a.action,
  a.entity_id,
  u.email,
  a.created_at
FROM audit_logs a
JOIN users u ON a.user_id = u.id
WHERE a.entity_type = 'platform_config'
ORDER BY a.created_at DESC
LIMIT 100;
```

### 4. Acceso Limitado

```
Solo 1-2 personas del equipo deben tener rol SAAS_ADMIN
Todos los demás: CLIENT, MERCHANT_ADMIN, etc.
```

---

## 🎓 Capacitación del Equipo

### Para SAAS_ADMIN

1. Leer esta documentación completa
2. Entender encriptación AES-256
3. Saber generar y rotar claves
4. Conocer procedimiento de backup
5. Practicar en ambiente de desarrollo

### Para Desarrolladores

1. Saber usar `getConfig()` en código
2. Entender orden de prioridad (DB → Env)
3. NO hardcodear API keys en código
4. Reportar configuraciones faltantes a SAAS_ADMIN

---

**Prompt 9 Status**: COMPLETADO ✅

**Siguiente**: Prompt 10 - Rate Limiting con Upstash Redis

**Nota de Seguridad**: El `ENCRYPTION_KEY` es la clave maestra. Si se pierde, todas las configuraciones encriptadas serán irrecuperables. Mantén backups seguros.
