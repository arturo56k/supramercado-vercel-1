
import { UserRole } from '../types';

export const COLORS = {
  primary: '#0056B3',
  secondary: '#FF8C00',
  accent: '#7C3AED',
};

export const ROLE_CONFIG = {
  [UserRole.CLIENT]: { label: 'Comprador (USA)', color: 'bg-blue-600', domain: 'web.supramercado.com' },
  [UserRole.BENEFICIARY]: { label: 'Beneficiario (RD)', color: 'bg-orange-500', domain: 'redeem.supramercado.com' },
  [UserRole.MERCHANT_ADMIN]: { label: 'Admin Comercio', color: 'bg-purple-600', domain: 'admin.supramercado.com' },
  [UserRole.MERCHANT_BRANCH_ADMIN]: { label: 'Admin Sucursal', color: 'bg-indigo-600', domain: 'admin.supramercado.com' },
  [UserRole.MERCHANT_EMPLOYEE]: { label: 'Empleado', color: 'bg-teal-600', domain: 'admin.supramercado.com' },
  [UserRole.SAAS_SUPPORT]: { label: 'Soporte SaaS', color: 'bg-gray-600', domain: 'admin.supramercado.com' },
  [UserRole.SAAS_ADMIN]: { label: 'Admin SaaS', color: 'bg-red-600', domain: 'admin.supramercado.com' },
};

export const GLOBAL_APP_CONFIG = {
  ITBIS: 0.18,
  PLATFORM_FEE: 0.05,
  STRIPE_FIXED_FEE: 0.30,
  STRIPE_PERCENT_FEE: 0.029,
};
