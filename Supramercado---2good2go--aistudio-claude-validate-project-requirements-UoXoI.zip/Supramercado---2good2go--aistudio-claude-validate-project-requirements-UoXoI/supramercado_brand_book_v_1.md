# Brand Book — Supramercado.com (v1.0)

## 1. Esencia de marca
**Promesa:** Compra desde EE.UU. y entrega en República Dominicana sin fricción.

**Arquetipo:** Cuidador resolutivo (cálido, confiable, rápido).

**Personalidad:** humana, tranquila, directa, cero tecnicismos.

**Regla de oro:** *Debe sentirse como alivio, no como trámite.*

---

## 2. Lectura estratégica del logo

- Dos formas entrelazadas → conexión / puente
- Azul ↔ Naranja → EE.UU. ↔ RD
- Forma continua → flujo, cercanía, sin fricción
- Bordes redondeados → confianza y familiaridad

**Conclusión:** El logo comunica cercanía y control a distancia. Toda la identidad visual debe proteger esa sensación.

---

## 3. Paleta de colores

### Colores primarios

**Azul Supramercado**  
HEX: `#0E5FB2`  
Uso:
- Botones principales
- Enlaces
- Estados seguros (pagado / confirmado)

Psicología: confianza, estabilidad, seguridad en el pago.

---

**Naranja Supramercado**  
HEX: `#F68606`  
Uso:
- Acentos
- Progreso
- Highlights

Regla: **no usar para textos largos**.

---

### Colores neutrales

- Fondo principal: `#F4F6F8`
- Texto secundario: `#4A4A4A`
- Bordes/divisores: `#E5E7EB`

---

### Colores de estado

- Error crítico: `#D92D20` (uso puntual)

---

## 4. Tipografía

### Tipografía primaria

**Poppins**
- 700 / 600 → Titulares
- 500 → Botones
- 400 → Textos cortos

Características: redondeada, moderna, cercana.

---

### Tipografía secundaria

**Inter**
- 400 / 500 → Párrafos, formularios, microcopy

Características: altamente legible y neutral.

Fallback web:
```
system-ui, -apple-system, Segoe UI, Roboto, Arial
```

---

## 5. Estilo visual UI

- Diseño **mobile-first**
- Grid de 8pt
- Bordes redondeados:
  - Cards: 12px
  - Botones: 14–16px
  - Modales: 20–24px
- Sombras suaves (1–2 niveles)
- Iconografía lineal, esquinas redondeadas

### Fotografía

- Personas reales
- Familias
- Contexto cotidiano en RD
- Luz natural

Evitar:
- Stock genérico
- Oficinas
- Imágenes corporativas

---

## 6. Checkout mobile-first

### Arquitectura de pasos
1. Producto
2. Beneficiario
3. Resumen
4. Pago

**Regla:** sin menú ni links externos durante el checkout.

---

### Componentes clave

#### CTA sticky (móvil)
- Botón azul fijo abajo
- Mostrar total
- Textos recomendados:
  - "Continuar"
  - "Confirmar compra y entregar en RD"

---

#### Formularios de pago

Orden de campos:
1. Email
2. Nombre
3. Tarjeta

Reglas:
- No pedir dirección del pagador
- Teclados optimizados (email / numérico)
- Auto-avance entre campos

---

#### Microcopy obligatorio

> "El cargo aparecerá como [empresa intermediaria]"

Reduce chargebacks y confusión post-pago.

---

#### Error de pago

Mensaje:
> "Hubo un problema con el pago. Intenta nuevamente."

Botón:
> "Reintentar pago"

Microcopy:
> "Tu compra sigue reservada."

---

## 7. Uso del logo (ads y app)

### Recomendaciones

- Ads y app icon: **solo isotipo**
- Web y emails: **logo horizontal**
- No usar slogan dentro del logo en ads

### Safe area

- Mantener 12% de margen interno alrededor del isotipo

### Exportables

- SVG (web)
- PNG: 1024 / 512 / 256 / 128
- Assets adaptativos para app

---

## 8. Meta Ads (Facebook / Instagram)

### Formatos recomendados
- Feed: 1:1 (1080×1080)
- Stories / Reels: 9:16 (1080×1920)

### Estructura creativa
1. Hook emocional
2. Promesa clara
3. Prueba de entrega
4. CTA

### Reglas visuales
- Titulares en azul
- Palabras clave en naranja
- Logo pequeño en esquina

---

## 9. Google Ads

### Display / Performance Max

- Landscape 1.91:1 → 1200×628
- Square 1:1 → 1200×1200

### Mensajes clave
- "Compra desde EE.UU. y entrega en RD"
- "En 2 minutos"
- "Tu familia no hace nada"

### YouTube

- Video 16:9
- Bumper 6s con una sola idea + CTA

---

## 10. Emails transaccionales

### Estilo
- Fondo blanco
- Logo horizontal
- Un solo CTA

### Estructura
1. Estado grande (Compra confirmada)
2. Resumen de compra
3. Línea emocional
4. CTA: Ver estado
5. Nota del cargo (solo confirmación)

---

## 11. Newsletter

### Objetivo

Recompra y hábito (no descuentos constantes).

### Cadencia

- Quincenal
- Fines de semana
- Fechas familiares

### Estructura

- Historia corta
- 3 recomendaciones
- CTA único

---

## 12. Redes sociales (Instagram / TikTok)

### Formato principal

- Vertical 9:16
- Estilo UGC
- Subtítulos grandes

### Formatos base

1. Necesidad → entrega
2. Compra en 2 minutos
3. Entregas reales
4. Recompra 1 click

---

## 13. Biblioteca de copy

- Headline: *Compra desde EE.UU. y entrégalo hoy en República Dominicana.*
- Subheadline: *Sin remesas. Sin llamadas. Tú pagas. Nosotros lo resolvemos.*
- CTA: *Comprar ahora* / *Confirmar compra y entregar en RD*
- Confianza: *Confirmación inmediata*
- Pago: *El cargo aparecerá como [intermediaria]*
- Post-pago: *Tu compra ya está en proceso. Tu familia la recibirá pronto.*

---

**Supramercado es un puente emocional.**  
Todo el diseño debe comunicar: *"Yo me encargo."*

