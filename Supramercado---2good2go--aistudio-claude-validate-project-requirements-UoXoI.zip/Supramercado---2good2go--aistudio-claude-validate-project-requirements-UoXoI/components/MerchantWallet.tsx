
import React, { useState, useMemo } from 'react';
import { 
  Landmark, TrendingUp, ArrowUpRight, 
  ShieldCheck, X, CheckCircle2, 
  Loader2, CreditCard, Plus, Eye, Copy,
  ArrowRightLeft, AlertCircle, Lock, DollarSign,
  FileText, Sparkles, Send, Download, Clock, History, ChevronRight, Ban, ListFilter
} from 'lucide-react';
import { useOrders } from './OrderContext';
import { GoogleGenAI } from "@google/genai";
import { Payout, Order } from '../types';

export const MerchantWallet: React.FC = () => {
  const [showPayout, setShowPayout] = useState(false);
  const [selectedPayout, setSelectedPayout] = useState<Payout | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [payoutDone, setPayoutDone] = useState(false);
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  const [dailyReport, setDailyReport] = useState<string | null>(null);
  
  const { orders, payouts, addPayout, updateOrder } = useOrders();
  const merchantId = 'm1';
  
  const walletStats = useMemo(() => {
    const mOrders = orders.filter(o => o.merchantId === merchantId);
    
    // Balance disponible: Órdenes ya capturadas (REDEEMED) pero no pagadas en un Payout
    const availableOrders = mOrders.filter(o => o.status === 'REDEEMED' && !o.payoutId);
    const availableDOP = availableOrders.reduce((acc, curr) => acc + (curr.merchantPayoutDOP || 0), 0);
    
    // Balance en tránsito: Órdenes autorizadas esperando el swipe (PENDING)
    const inTransitOrders = mOrders.filter(o => o.status === 'PENDING' || o.status === 'READY_FOR_PICKUP');
    const inTransitDOP = inTransitOrders.reduce((acc, curr) => acc + (curr.merchantPayoutDOP || 0), 0);
      
    return { availableDOP, inTransitDOP, availableOrders };
  }, [orders]);

  const generateDailyClosure = async () => {
    setIsGeneratingReport(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Genera un reporte de cierre contable para un comercio en RD que recibe remesas en víveres. Balance hoy disponible: RD$ ${walletStats.availableDOP.toLocaleString()}. Analiza ITBIS y rendimiento.`,
      });
      setDailyReport(response.text || "Reporte generado.");
    } catch (e) { setDailyReport("Error en reporte."); } finally { setIsGeneratingReport(false); }
  };

  const handlePayout = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const payoutId = `pay-${Date.now()}`;
      const orderIds = walletStats.availableOrders.map(o => o.id);
      
      const newPayout: Payout = {
        id: payoutId,
        amountDOP: walletStats.availableDOP,
        status: 'SUCCESS',
        date: new Date().toISOString(),
        bankName: 'Banreservas',
        accountLast4: '4492',
        orderIds
      };

      addPayout(newPayout);
      orderIds.forEach(id => updateOrder(id, { payoutId }));
      
      setIsProcessing(false);
      setPayoutDone(true);
      setTimeout(() => {
        setPayoutDone(false);
        setShowPayout(false);
      }, 2000);
    }, 2000);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col xl:flex-row gap-12 justify-between">
          <div className="space-y-8 flex-1">
            <div className="flex items-center gap-3">
               <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center"><Landmark className="w-5 h-5" /></div>
               <div>
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-300">Stripe Connected Node</p>
                  <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">acct_1N2345</p>
               </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
               <div>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-3">Disponible para Liquidar</p>
                  <h3 className="text-5xl font-black tracking-tight text-white">RD${walletStats.availableDOP.toLocaleString()}</h3>
               </div>
               <div className="opacity-60">
                  <p className="text-blue-400 text-[10px] font-black uppercase tracking-widest mb-3 flex items-center gap-2"><Lock className="w-3 h-3" /> En Tránsito (Autorizado)</p>
                  <h3 className="text-4xl font-black tracking-tight text-blue-300">RD${walletStats.inTransitDOP.toLocaleString()}</h3>
               </div>
            </div>

            <div className="flex flex-wrap gap-4">
               <button onClick={() => setShowPayout(true)} disabled={walletStats.availableDOP <= 0} className="bg-white text-slate-900 px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-100 transition-all flex items-center gap-2 disabled:opacity-30">Enviar a Banco RD</button>
               <button onClick={generateDailyClosure} disabled={isGeneratingReport} className="bg-white/10 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest border border-white/10 flex items-center gap-2">
                 {isGeneratingReport ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />} Auditoría Contable AI
               </button>
            </div>
          </div>
          <div className="xl:w-[350px]">
             <div className="p-8 bg-blue-700 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
                <div className="relative z-10 space-y-8">
                  <div className="flex justify-between items-center"><CreditCard className="w-8 h-8" /><span className="text-[10px] font-black opacity-60">Balance Conectado</span></div>
                  <p className="text-xl font-black tracking-widest">•••• •••• •••• 4492</p>
                  <p className="text-[10px] font-black uppercase tracking-widest">Banreservas RD</p>
                </div>
                <div className="absolute top-0 right-0 p-4 opacity-10"><ShieldCheck className="w-20 h-20" /></div>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h4 className="text-xl font-black text-slate-900 flex items-center gap-2 px-2"><History className="w-6 h-6 text-blue-600" /> Historial de Payouts</h4>
          <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
            {payouts.length === 0 ? (
              <div className="p-20 text-center text-slate-300 font-bold italic">No hay transferencias liquidadas aún.</div>
            ) : (
              payouts.map((p) => (
                <div key={p.id} onClick={() => setSelectedPayout(p)} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors border-b border-slate-100 cursor-pointer group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-all"><Landmark className="w-6 h-6" /></div>
                    <div>
                      <p className="font-black text-slate-900">RD$ {p.amountDOP.toLocaleString()}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase">{new Date(p.date).toLocaleDateString()} • {p.bankName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                     <span className="text-[9px] font-black text-green-600 uppercase bg-green-50 px-3 py-1 rounded-full">Liquidado</span>
                     <ChevronRight className="w-5 h-5 text-slate-300" />
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="space-y-6">
          <h4 className="text-xl font-black text-slate-900 flex items-center gap-2"><ListFilter className="w-6 h-6 text-orange-500" /> Conciliación Diaria</h4>
          {dailyReport ? (
            <div className="bg-white p-8 rounded-[2.5rem] border-2 border-orange-100 shadow-xl animate-in slide-in-from-right-6">
              <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Análisis del día</h5>
              <div className="text-[11px] text-slate-700 font-medium leading-relaxed italic border-l-4 border-orange-200 pl-4 whitespace-pre-wrap">{dailyReport}</div>
              <button onClick={() => setDailyReport(null)} className="mt-6 w-full text-[10px] font-black text-orange-600 uppercase tracking-widest py-2 bg-orange-50 rounded-xl">Cerrar Reporte</button>
            </div>
          ) : (
            <div className="bg-slate-50 p-10 rounded-[2.5rem] border border-dashed text-center">
              <Sparkles className="w-8 h-8 text-slate-200 mx-auto mb-4" />
              <p className="text-xs font-bold text-slate-400 uppercase">Usa la IA para generar un informe de cierre contable basado en tus ventas del día.</p>
            </div>
          )}
        </div>
      </div>

      {selectedPayout && (
        <div className="fixed inset-0 z-[350] bg-slate-900/90 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-xl rounded-[3rem] p-10 shadow-2xl animate-in zoom-in">
             <div className="flex justify-between items-center mb-8">
                <div>
                   <h4 className="text-2xl font-black text-slate-900">Detalle de Payout</h4>
                   <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Referencia: {selectedPayout.id}</p>
                </div>
                <button onClick={() => setSelectedPayout(null)} className="p-2 bg-slate-100 rounded-full hover:bg-slate-200"><X className="w-5 h-5" /></button>
             </div>
             
             <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 scrollbar-hide">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">Órdenes Consolidadas</p>
                {orders.filter(o => o.payoutId === selectedPayout.id).map(o => (
                  <div key={o.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
                    <div className="flex items-center gap-4">
                       <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center text-[10px] font-black border">RD$</div>
                       <div>
                          <p className="text-xs font-black text-slate-900">Orden #{o.id.split('-')[1]}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">{o.beneficiaryName}</p>
                       </div>
                    </div>
                    <p className="font-black text-slate-900 text-sm">RD$ {(o.merchantPayoutDOP || 0).toLocaleString()}</p>
                  </div>
                ))}
             </div>
             
             <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between items-center">
                <span className="text-sm font-black text-slate-400 uppercase tracking-widest">Total Transferido</span>
                <span className="text-2xl font-black text-blue-700">RD$ {selectedPayout.amountDOP.toLocaleString()}</span>
             </div>
             <button onClick={() => setSelectedPayout(null)} className="w-full mt-8 bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase shadow-xl tracking-widest">Cerrar Ventana</button>
          </div>
        </div>
      )}

      {showPayout && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-[2.5rem] p-10 text-slate-900 animate-in zoom-in duration-300">
            {payoutDone ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto"><CheckCircle2 className="w-8 h-8" /></div>
                <h4 className="text-xl font-black">Liquidación Solicitada</h4>
                <p className="text-sm text-slate-500 font-medium">Los fondos estarán en tu cuenta Banreservas en un plazo de 24 horas hábiles.</p>
              </div>
            ) : (
              <div className="space-y-8">
                <div className="flex justify-between items-center"><h4 className="text-xl font-black text-slate-900">Retirar a Banco</h4><button onClick={() => setShowPayout(false)} className="text-slate-300 hover:text-slate-900"><X className="w-6 h-6" /></button></div>
                <div className="p-8 bg-slate-50 rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-4 text-center">
                   <Landmark className="w-10 h-10 text-blue-600" />
                   <div>
                      <p className="text-xs font-black text-slate-400 uppercase mb-1">Disponible para Liquidar</p>
                      <p className="text-3xl font-black text-slate-900">RD$ {walletStats.availableDOP.toLocaleString()}</p>
                   </div>
                </div>
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-center gap-3">
                   <AlertCircle className="w-4 h-4 text-blue-600" />
                   <p className="text-[9px] font-black text-blue-700 uppercase">Transferencia vía ACH / LBTR</p>
                </div>
                <button onClick={handlePayout} disabled={isProcessing} className="w-full bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl flex items-center justify-center gap-3 uppercase tracking-widest text-xs">
                  {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowUpRight className="w-5 h-5" />} {isProcessing ? 'PROCESANDO...' : 'CONFIRMAR TRANSFERENCIA'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
