
import { GoogleGenAI, Type } from "@google/genai";

export interface OFACValidationResult {
  status: 'APPROVED' | 'REJECTED';
  reason?: string;
}

/**
 * Simula la integración con Plaid Identity Verification o Chainalysis Sanctions Screening
 * utilizando Gemini 3 Pro para razonamiento de cumplimiento regulatorio.
 */
export const validateOFAC = async (
  beneficiaryName: string,
  phone: string,
  address: string
): Promise<OFACValidationResult> => {
  try {
    // Fix: Re-initialize GoogleGenAI right before use to ensure latest API key.
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Prompt específico para screening de sanciones
    const prompt = `Actúa como un oficial de cumplimiento (Compliance Officer) especializado en sanciones de la OFAC.
    Analiza los siguientes datos de un beneficiario en República Dominicana para una remesa desde USA:
    Nombre: ${beneficiaryName}
    Teléfono: ${phone}
    Dirección: ${address}

    Debes determinar si estos datos coinciden con personas o entidades sancionadas o si presentan patrones de alto riesgo (lavado de dinero, financiamiento ilícito).
    
    IMPORTANTE: Para propósitos de esta simulación, rechaza nombres que contengan palabras como "NARCO", "TEST" o nombres de dictadores conocidos.
    
    Responde estrictamente en formato JSON con el esquema:
    {
      "status": "APPROVED" | "REJECTED",
      "reason": "breve explicación en español si es rechazado"
    }`;

    // Fix: Use 'gemini-3-pro-preview' for complex text reasoning tasks like compliance screening.
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING, enum: ["APPROVED", "REJECTED"] },
            reason: { type: Type.STRING }
          },
          required: ["status"]
        }
      }
    });

    // Fix: Access .text as a property of GenerateContentResponse.
    const result = JSON.parse(response.text || '{"status": "REJECTED", "reason": "Error en servicio de validación"}');
    
    // Auditoría local (Simulación de tabla de logs)
    console.info(`[OFAC Audit] Beneficiary: ${beneficiaryName} | Status: ${result.status} | Timestamp: ${new Date().toISOString()}`);
    
    return result;
  } catch (error) {
    console.error("OFAC Validation Error:", error);
    return { status: 'REJECTED', reason: "No se pudo completar la verificación de seguridad." };
  }
};
