
import React from 'react';
import { QrCode, MapPin, Clock, Share2, CheckCircle2, ChevronRight } from 'lucide-react';
import { Order, Merchant } from '../types';

interface PickupPassProps {
  order: Order;
  merchant: Merchant;
}

export const PickupPass: React.FC<PickupPassProps> = ({ order, merchant }) => {
  return (
    <div className="max-w-md mx-auto bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-100 animate-in zoom-in duration-500">
      {/* Cabecera estilo Ticket */}
      <div className="bg-slate-900 p-8 text-white text-center relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-orange-500 to-blue-600"></div>
        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 mb-2">Pase de Retiro Supramercado</p>
        <h2 className="text-3xl font-black">#{order.pickupCode}</h2>
      </div>

      <div className="p-8 space-y-8">
        {/* Información del Beneficiario */}
        <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl border border-slate-100">
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Para retirar por:</p>
            <p className="text-lg font-black text-slate-900">{order.beneficiaryName}</p>
          </div>
          <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        {/* Detalle del Comercio */}
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <img src={merchant.logo} className="w-12 h-12 rounded-xl object-cover shadow-sm" />
            <div>
              <h4 className="font-black text-slate-900">{merchant.name}</h4>
              <p className="text-xs text-slate-500 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> {merchant.address}, {merchant.city}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-orange-600 bg-orange-50 p-3 rounded-xl border border-orange-100">
            <Clock className="w-4 h-4" />
            <p className="text-[10px] font-black uppercase">Retirar antes de las {merchant.closingTime} (Hora RD)</p>
          </div>
        </div>

        {/* QR dinámico */}
        <div className="flex flex-col items-center justify-center py-4 border-2 border-dashed border-slate-100 rounded-[2rem]">
          <div className="p-4 bg-white shadow-inner rounded-2xl mb-4">
            <img 
              src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${order.pickupCode}`} 
              className="w-40 h-40 grayscale hover:grayscale-0 transition-all"
              alt="QR de Retiro"
            />
          </div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Muestra este código en caja</p>
        </div>

        <button 
          className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl hover:bg-slate-800 transition-all"
          onClick={() => {
            const text = `¡Hola! Aquí tienes tu pase para retirar la comida en ${merchant.name}. Código: ${order.pickupCode}`;
            window.open(`https://wa.me/?text=${encodeURIComponent(text)}`);
          }}
        >
          <Share2 className="w-4 h-4" /> Enviar por WhatsApp
        </button>
      </div>
      
      <div className="bg-slate-50 p-4 text-center border-t border-slate-100">
        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Evitemos el desperdicio de comida juntos 🇩🇴</p>
      </div>
    </div>
  );
};
