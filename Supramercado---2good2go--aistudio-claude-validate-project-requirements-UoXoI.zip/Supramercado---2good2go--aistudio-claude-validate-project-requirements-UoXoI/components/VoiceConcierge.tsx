
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { Mic, MicOff, Volume2, X, Sparkles, Radio, MessageCircle } from 'lucide-react';

export const VoiceConcierge: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [isUserSpeaking, setIsUserSpeaking] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext) => {
    const dataInt16 = new Int16Array(data.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }
    return buffer;
  };

  const createBlob = (data: Float32Array) => {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const startSession = async () => {
    setIsConnecting(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
    const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    audioContextRef.current = outputCtx;
    
    let nextStartTime = 0;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
          },
          onmessage: async (message) => {
            // Handle Audio
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              const buffer = await decodeAudioData(decode(audioData), outputCtx);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              nextStartTime = Math.max(nextStartTime, outputCtx.currentTime);
              source.start(nextStartTime);
              nextStartTime += buffer.duration;
            }

            // Handle Transcriptions
            if (message.serverContent?.inputTranscription) {
              setTranscription(prev => prev + ' ' + message.serverContent?.inputTranscription?.text);
              setIsUserSpeaking(true);
            } else if (message.serverContent?.outputTranscription) {
              setTranscription(prev => prev + ' ' + message.serverContent?.outputTranscription?.text);
              setIsUserSpeaking(false);
            }

            if (message.serverContent?.turnComplete) {
              // Limpiar transcripción vieja después de un tiempo para no saturar
              setTimeout(() => setTranscription(''), 5000);
            }
          },
          onclose: () => setIsActive(false),
          onerror: (e) => console.error("Error Live API:", e),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
          },
          systemInstruction: 'Eres el conserje de Supramercado. Tu misión es ayudar a abuelitos y familiares en RD. Responde de forma muy breve y cálida.',
        },
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
    }
  };

  const stopSession = () => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(s => s.close());
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    setIsActive(false);
    setTranscription('');
  };

  return (
    <div className="fixed bottom-24 left-6 z-[100] flex flex-col items-start gap-4 pointer-events-none">
      {transcription && (
        <div className="bg-white/90 backdrop-blur-md p-4 rounded-[2rem] shadow-xl border border-slate-100 max-w-xs animate-in slide-in-from-bottom-2 pointer-events-auto">
          <div className="flex items-center gap-2 mb-1">
            <div className={`w-2 h-2 rounded-full ${isUserSpeaking ? 'bg-orange-500 animate-pulse' : 'bg-blue-600'}`}></div>
            <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">
              {isUserSpeaking ? 'Usted' : 'Supramercado'}
            </span>
          </div>
          <p className="text-xs font-bold text-slate-800 leading-relaxed italic">"{transcription.trim()}"</p>
        </div>
      )}

      {!isActive ? (
        <button 
          onClick={startSession}
          disabled={isConnecting}
          className="w-16 h-16 bg-orange-500 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all group relative overflow-hidden pointer-events-auto"
        >
          {isConnecting ? <Sparkles className="animate-spin w-7 h-7" /> : <Mic className="w-7 h-7" />}
          <div className="absolute inset-0 bg-white/20 scale-0 group-hover:scale-100 transition-transform rounded-full"></div>
        </button>
      ) : (
        <div className="bg-slate-900 text-white p-5 rounded-[2.5rem] shadow-2xl flex items-center gap-6 animate-in slide-in-from-left-4 border border-white/10 backdrop-blur-xl pointer-events-auto">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center">
                <Radio className="w-6 h-6 animate-pulse" />
              </div>
              <div className="absolute -inset-2 border-2 border-orange-500 rounded-full animate-ping opacity-40"></div>
            </div>
            <div>
              <p className="text-sm font-black uppercase tracking-widest text-orange-400">En vivo</p>
              <p className="text-xs text-slate-400">Escuchando su voz...</p>
            </div>
          </div>
          <button onClick={stopSession} className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl transition-colors border border-white/5">
            <X className="w-5 h-5" />
          </button>
        </div>
      )}
    </div>
  );
};
