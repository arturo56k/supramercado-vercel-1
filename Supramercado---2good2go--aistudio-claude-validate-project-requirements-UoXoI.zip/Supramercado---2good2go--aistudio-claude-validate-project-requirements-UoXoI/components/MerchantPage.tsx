import React from 'react';
import { ArrowLeft, Star, MapPin, ShieldCheck, ShoppingBag, Plus } from 'lucide-react';
import { Merchant, Product } from '../types';
import { MOCK_PRODUCTS } from '../constants';

interface MerchantPageProps {
  merchant: Merchant;
  onBack: () => void;
  onAddToCart: (product: Product) => void;
}

export const MerchantPage: React.FC<MerchantPageProps> = ({ merchant, onBack, onAddToCart }) => {
  const merchantProducts = MOCK_PRODUCTS.filter(p => p.merchantId === merchant.id);

  return (
    <div className="space-y-12 animate-in fade-in slide-in-from-right-8 duration-500">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-slate-400 font-black text-xs uppercase tracking-widest hover:text-slate-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" /> Volver a Comercios
      </button>

      {/* Header */}
      <header className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm flex flex-col md:flex-row items-center gap-10">
        <div className="w-40 h-40 bg-slate-50 rounded-full border-4 border-white shadow-2xl shrink-0 overflow-hidden">
           <img src={merchant.logo} className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 text-center md:text-left space-y-4">
           <div className="flex flex-wrap items-center justify-center md:justify-start gap-4">
              <h2 className="text-4xl font-black text-slate-900 tracking-tight">{merchant.name}</h2>
              <div className="flex items-center gap-1.5 bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full border border-orange-100">
                <Star className="w-4 h-4 fill-orange-500" />
                <span className="text-sm font-black">{merchant.rating}</span>
              </div>
           </div>
           <p className="text-slate-500 text-lg font-medium max-w-2xl">{merchant.description}</p>
           <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 pt-2">
              <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest">
                <MapPin className="w-4 h-4 text-blue-700" /> Santiago, Rep. Dom.
              </div>
              <div className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest">
                <ShieldCheck className="w-4 h-4 text-green-500" /> Verificado por Supra
              </div>
           </div>
        </div>
        <div className="bg-blue-700 text-white p-8 rounded-[2rem] text-center shrink-0 shadow-2xl shadow-blue-700/30">
           <p className="text-[10px] font-black uppercase tracking-widest mb-1 opacity-80">Liquidación</p>
           <p className="text-3xl font-black tracking-tight">DOP / USD</p>
           <p className="text-[10px] font-bold uppercase mt-2 text-blue-200">Entrega Instantánea</p>
        </div>
      </header>

      {/* Products */}
      <section className="space-y-8">
        <h3 className="text-2xl font-black text-slate-900 px-2 flex items-center gap-3">
          <ShoppingBag className="w-6 h-6 text-blue-700" /> Inventario Disponible
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {merchantProducts.map(product => (
            <div key={product.id} className="group bg-white rounded-[2rem] border border-slate-200 p-6 hover:shadow-2xl transition-all duration-300">
              <div className="h-48 rounded-2xl overflow-hidden mb-6 relative">
                 <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                 <span className="absolute bottom-3 left-3 px-3 py-1 bg-white/90 backdrop-blur-md text-[10px] font-black uppercase tracking-widest rounded-lg">
                   Stock: {product.stock}
                 </span>
              </div>
              <h4 className="font-black text-slate-900 mb-2">{product.name}</h4>
              <p className="text-xs text-slate-500 font-medium line-clamp-2 mb-6">{product.description}</p>
              <div className="flex items-center justify-between">
                 {/* Fix: Property 'price' does not exist on type 'Product'. Use 'basePriceDOP' instead. */}
                 <span className="text-2xl font-black text-blue-700">${product.basePriceDOP.toFixed(2)}</span>
                 <button 
                  onClick={() => onAddToCart(product)}
                  className="p-3 bg-blue-700 text-white rounded-xl shadow-lg hover:scale-105 active:scale-95 transition-all"
                 >
                   <Plus className="w-5 h-5" />
                 </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};