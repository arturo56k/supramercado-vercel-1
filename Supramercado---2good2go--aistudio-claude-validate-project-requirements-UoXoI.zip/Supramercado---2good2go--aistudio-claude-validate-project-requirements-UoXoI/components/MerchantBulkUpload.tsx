
import React, { useState, useRef } from 'react';
import { 
  FileUp, X, CheckCircle2, AlertCircle, Loader2, 
  Table as TableIcon, Sparkles, Database, Download 
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';
import { parseMerchantCSV, CSVRow } from '../utils/csvParser';
import { Product } from '../types';

interface MerchantBulkUploadProps {
  onClose: () => void;
}

export const MerchantBulkUpload: React.FC<MerchantBulkUploadProps> = ({ onClose }) => {
  const { addProduct, calculateFinancials } = useOrders();
  const { notify } = useNotify();
  const [file, setFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<CSVRow[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;
    
    setFile(selectedFile);
    const result = await parseMerchantCSV(selectedFile);
    setParsedData(result.data);
    setErrors(result.errors);
  };

  const enrichDescriptionWithAI = async (productName: string): Promise<string> => {
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Genera una descripción de producto breve (máximo 15 palabras) y atractiva para: "${productName}" en el contexto de un supermercado dominicano. Sé cálido y profesional.`,
      });
      return response.text || "Producto esencial de calidad garantizada.";
    } catch (e) {
      return "Producto esencial para tu canasta básica.";
    }
  };

  const handleImport = async () => {
    if (parsedData.length === 0) return;
    
    setIsImporting(true);
    let successCount = 0;
    
    for (let i = 0; i < parsedData.length; i++) {
      const row = parsedData[i];
      
      // AI Enrichment for empty descriptions
      let description = row.description;
      if (!description || description.trim() === '') {
        description = await enrichDescriptionWithAI(row.name);
      }
      
      const { totalUSD } = calculateFinancials(row.basePriceDOP);
      
      const newProduct: Product = {
        id: `bulk-${Date.now()}-${i}`,
        name: row.name,
        description: description,
        priceUSD: totalUSD,
        basePriceDOP: row.basePriceDOP,
        category: row.category,
        stock: row.stock,
        merchantId: 'm1', // Default current merchant
        image: row.image,
        type: 'INDIVIDUAL'
      };
      
      addProduct(newProduct);
      successCount++;
      setImportProgress(Math.round(((i + 1) / parsedData.length) * 100));
    }
    
    setIsImporting(false);
    notify("Importación Exitosa", `Se han añadido ${successCount} productos a tu catálogo.`, "SUCCESS");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[140] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md">
      <div className="bg-white w-full max-w-3xl rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300 flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-start mb-8 shrink-0">
          <div>
            <h3 className="text-2xl font-black text-slate-900">Importación Masiva</h3>
            <p className="text-slate-500 font-medium">Sube tu catálogo completo mediante archivo CSV.</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-slate-400" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-8 scrollbar-hide pr-2">
          {!file ? (
            <div 
              onClick={() => fileInputRef.current?.click()}
              className="border-4 border-dashed border-slate-100 rounded-[2.5rem] p-16 flex flex-col items-center justify-center gap-6 group cursor-pointer hover:border-blue-200 transition-all hover:bg-blue-50/30"
            >
              <input type="file" hidden ref={fileInputRef} accept=".csv" onChange={handleFileChange} />
              <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-3xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <FileUp className="w-10 h-10" />
              </div>
              <div className="text-center">
                <p className="text-lg font-black text-slate-900">Haz clic para subir archivo</p>
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mt-1">Soporta formato .CSV UTF-8</p>
              </div>
              <div className="flex gap-4 mt-4">
                 <button className="flex items-center gap-2 text-[10px] font-black text-blue-700 bg-blue-50 px-4 py-2 rounded-xl uppercase tracking-widest border border-blue-100">
                   <Download className="w-3 h-3" /> Descargar Plantilla
                 </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm border">
                    <TableIcon className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="font-black text-slate-900">{file.name}</p>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{(file.size / 1024).toFixed(1)} KB • {parsedData.length} productos detectados</p>
                  </div>
                </div>
                <button onClick={() => { setFile(null); setParsedData([]); setErrors([]); }} className="text-red-500 font-black text-xs uppercase tracking-widest">Cambiar</button>
              </div>

              {errors.length > 0 && (
                <div className="bg-red-50 border-2 border-red-100 rounded-[2rem] p-6 space-y-3">
                  <div className="flex items-center gap-2 text-red-600">
                    <AlertCircle className="w-5 h-5" />
                    <h4 className="font-black text-sm uppercase tracking-widest">Errores en el archivo</h4>
                  </div>
                  <ul className="space-y-1">
                    {errors.map((err, i) => (
                      <li key={i} className="text-xs font-bold text-red-700 list-disc ml-5">{err}</li>
                    ))}
                  </ul>
                </div>
              )}

              {parsedData.length > 0 && (
                <div className="space-y-4">
                  <h4 className="font-black text-sm text-slate-400 uppercase tracking-widest ml-2">Vista Previa (Primeros 5)</h4>
                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 border-b">
                        <tr>
                          <th className="px-4 py-3 font-black uppercase text-slate-500">Producto</th>
                          <th className="px-4 py-3 font-black uppercase text-slate-500">Categoría</th>
                          <th className="px-4 py-3 font-black uppercase text-slate-500 text-right">Precio DOP</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y">
                        {parsedData.slice(0, 5).map((row, i) => (
                          <tr key={i}>
                            <td className="px-4 py-3 font-bold text-slate-900">{row.name}</td>
                            <td className="px-4 py-3 font-medium text-slate-500">{row.category}</td>
                            <td className="px-4 py-3 font-black text-slate-900 text-right">RD$ {row.basePriceDOP.toLocaleString()}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-center gap-3">
                     <Sparkles className="w-5 h-5 text-orange-600 shrink-0" />
                     <p className="text-[10px] font-bold text-orange-800 uppercase leading-relaxed">La IA completará automáticamente las descripciones faltantes durante la importación.</p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="pt-8 mt-4 border-t border-slate-100 shrink-0">
          {isImporting ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center px-2">
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] animate-pulse">Importando Catálogo...</span>
                <span className="text-sm font-black text-slate-900">{importProgress}%</span>
              </div>
              <div className="w-full bg-slate-100 h-4 rounded-full overflow-hidden border border-slate-200">
                <div 
                  className="bg-blue-600 h-full transition-all duration-300 ease-out"
                  style={{ width: `${importProgress}%` }}
                ></div>
              </div>
            </div>
          ) : (
            <button 
              onClick={handleImport}
              disabled={!file || parsedData.length === 0}
              className="w-full bg-blue-700 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-blue-700/30 flex items-center justify-center gap-2 disabled:opacity-30 disabled:scale-100 hover:bg-blue-800 transition-all"
            >
              <Database className="w-4 h-4" /> INICIAR IMPORTACIÓN ({parsedData.length} PRODUCTOS)
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
