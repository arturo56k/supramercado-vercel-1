
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Utensils, Sparkles, Loader2, Calendar, BookOpen, ChevronRight } from 'lucide-react';
import { Product } from '../types';

interface RecipePlannerProps {
  cart: { product: Product, qty: number }[];
}

export const RecipePlanner: React.FC<RecipePlannerProps> = ({ cart }) => {
  const [plan, setPlan] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);

  const generatePlan = async () => {
    if (cart.length === 0) return;
    setIsThinking(true);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: `Analiza estos productos comprados para una familia en RD: ${cart.map(i => `${i.qty}x ${i.product.name}`).join(', ')}. 
        Crea un plan de comidas dominicanas para 3 días que aproveche al máximo estos ingredientes. 
        Explica tu razonamiento culinario brevemente.`,
        config: {
          thinkingConfig: { thinkingBudget: 16000 }
        },
      });

      setPlan(response.text || "No pude generar el plan en este momento.");
    } catch (error) {
      console.error(error);
      setPlan("Error al razonar el plan culinario.");
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-200 p-8 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center">
            <Utensils className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-black text-lg text-slate-900 leading-tight">Planificador Inteligente</h4>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Optimiza la canasta básica</p>
          </div>
        </div>
        <button 
          onClick={generatePlan}
          disabled={isThinking || cart.length === 0}
          className="p-3 bg-slate-900 text-white rounded-xl hover:scale-110 active:scale-95 transition-all disabled:opacity-30"
        >
          {isThinking ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
        </button>
      </div>

      {plan ? (
        <div className="prose prose-slate prose-sm max-w-none animate-in fade-in slide-in-from-bottom-2">
          <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 relative">
            <div className="absolute -top-3 left-6 bg-blue-700 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest flex items-center gap-1">
              <BookOpen className="w-3 h-3" /> Sugerencia de Chef AI
            </div>
            <div className="whitespace-pre-wrap text-slate-700 font-medium leading-relaxed mt-2 italic">
              {plan}
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-6 border-2 border-dashed border-slate-100 rounded-[2rem]">
          <p className="text-sm text-slate-400 font-bold px-6">
            {cart.length > 0 ? "Presiona la chispa para cocinar un plan con estos ingredientes." : "Añade productos al carrito para activar el planificador."}
          </p>
        </div>
      )}
    </div>
  );
};
