
import React, { useState } from 'react';
import { Users, UserPlus, Mail, Shield, Trash2, CheckCircle, X, Search, MoreHorizontal, UserCheck } from 'lucide-react';
import { User, UserRole } from '../types';
import { useNotify } from './NotificationSystem';

const MOCK_STAFF: User[] = [
  { id: 'u1', name: 'Pedro Dueño', email: 'admin@colnacional.do', role: UserRole.MERCHANT_ADMIN, joinedAt: '2023-10-01' },
  { id: 'u2', name: 'Jose Cajero', email: 'jose@colnacional.do', role: UserRole.MERCHANT_EMPLOYEE, joinedAt: '2023-12-15' },
];

export const MerchantStaffManager: React.FC = () => {
  const [staff, setStaff] = useState<User[]>(MOCK_STAFF);
  const [showInvite, setShowInvite] = useState(false);
  const [inviteData, setInviteData] = useState({ email: '', role: UserRole.MERCHANT_EMPLOYEE });
  const { notify } = useNotify();

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: User = {
      id: `u-${Date.now()}`,
      name: inviteData.email.split('@')[0],
      email: inviteData.email,
      role: inviteData.role,
      joinedAt: new Date().toISOString().split('T')[0]
    };
    setStaff([...staff, newUser]);
    setShowInvite(false);
    notify("Invitación Enviada", `Se ha enviado un acceso de ${inviteData.role} a ${inviteData.email}`, "SUCCESS");
  };

  const removeUser = (id: string) => {
    setStaff(staff.filter(u => u.id !== id));
    notify("Acceso Revocado", "El empleado ya no tiene acceso a la terminal.", "WARNING");
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Gestión de Equipo</h2>
          <p className="text-slate-500 font-medium mt-1">Controla quién tiene acceso a tu terminal de cobro.</p>
        </div>
        <button 
          onClick={() => setShowInvite(true)}
          className="bg-blue-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-xl hover:bg-blue-800 transition-all"
        >
          <UserPlus className="w-5 h-5" /> Invitar Empleado
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Empleado</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Rol</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Desde</th>
                <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {staff.map(user => (
                <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                       <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 font-black">
                         {user.name.charAt(0)}
                       </div>
                       <div>
                         <p className="font-black text-slate-900">{user.name}</p>
                         <p className="text-xs text-slate-400 font-medium">{user.email}</p>
                       </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase border ${
                      user.role === UserRole.MERCHANT_ADMIN ? 'bg-purple-50 text-purple-600 border-purple-100' : 'bg-slate-50 text-slate-600 border-slate-100'
                    }`}>
                      {user.role === UserRole.MERCHANT_ADMIN ? 'Administrador' : 'Cajero / Empleado'}
                    </span>
                  </td>
                  <td className="px-8 py-6 text-sm font-bold text-slate-500">{user.joinedAt}</td>
                  <td className="px-8 py-6 text-right">
                     {user.role !== UserRole.MERCHANT_ADMIN && (
                       <button onClick={() => removeUser(user.id)} className="p-3 text-slate-300 hover:text-red-500 transition-colors">
                         <Trash2 className="w-4 h-4" />
                       </button>
                     )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showInvite && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-[3rem] p-10 shadow-2xl animate-in zoom-in">
             <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-slate-900">Invitar al Equipo</h3>
                <button onClick={() => setShowInvite(false)} className="p-2 hover:bg-slate-100 rounded-full"><X className="w-5 h-5 text-slate-400" /></button>
             </div>
             <form onSubmit={handleInvite} className="space-y-6">
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Email del Empleado</label>
                   <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                      <input 
                        required 
                        type="email" 
                        className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold focus:border-blue-500 outline-none" 
                        placeholder="empleado@colnacional.do"
                        value={inviteData.email}
                        onChange={e => setInviteData({...inviteData, email: e.target.value})}
                      />
                   </div>
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Asignar Rol</label>
                   <div className="grid grid-cols-1 gap-3">
                      <RoleCard 
                        active={inviteData.role === UserRole.MERCHANT_EMPLOYEE} 
                        onClick={() => setInviteData({...inviteData, role: UserRole.MERCHANT_EMPLOYEE})}
                        title="Empleado / Cajero"
                        desc="Solo puede redimir órdenes. Sin acceso a finanzas."
                      />
                      <RoleCard 
                        active={inviteData.role === UserRole.MERCHANT_BRANCH_ADMIN} 
                        onClick={() => setInviteData({...inviteData, role: UserRole.MERCHANT_BRANCH_ADMIN})}
                        title="Admin de Sucursal"
                        desc="Gestiona inventario y órdenes de una sede."
                      />
                   </div>
                </div>
                <button className="w-full bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl uppercase tracking-widest text-xs flex items-center justify-center gap-2">
                  <UserPlus className="w-4 h-4" /> Enviar Invitación
                </button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};

const RoleCard = ({ active, onClick, title, desc }: any) => (
  <button 
    type="button"
    onClick={onClick}
    className={`w-full p-4 rounded-2xl border-2 text-left transition-all ${active ? 'border-blue-600 bg-blue-50' : 'border-slate-100 bg-slate-50'}`}
  >
    <div className="flex justify-between items-center mb-1">
      <p className={`font-black text-sm ${active ? 'text-blue-700' : 'text-slate-900'}`}>{title}</p>
      {active && <CheckCircle className="w-4 h-4 text-blue-700" />}
    </div>
    <p className="text-[10px] font-medium text-slate-500 leading-tight">{desc}</p>
  </button>
);
