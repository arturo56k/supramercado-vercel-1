
import React from 'react';
import { Plus, MapPin, CheckCircle2, Navigation } from 'lucide-react';
import { Beneficiary } from '../types';

interface BeneficiarySelectorProps {
  beneficiaries: Beneficiary[];
  selectedId: string | null;
  onSelect: (id: string) => void;
  onAdd: () => void;
}

export const BeneficiarySelector: React.FC<BeneficiarySelectorProps> = ({ beneficiaries, selectedId, onSelect, onAdd }) => {
  return (
    <div className="bg-white p-8 rounded-[3rem] border border-slate-200 shadow-sm space-y-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-[0.03]">
        <Navigation className="w-32 h-32 rotate-12" />
      </div>

      <div className="flex items-center justify-between relative z-10">
        <div>
          <h3 className="font-black text-sm uppercase tracking-widest text-slate-400 mb-1">Cuidando de...</h3>
          <p className="text-2xl font-black text-slate-900">Familiares Registrados</p>
        </div>
        <button 
          onClick={onAdd}
          className="w-12 h-12 bg-blue-50 text-blue-700 rounded-2xl flex items-center justify-center hover:bg-blue-100 transition-all shadow-sm border border-blue-100"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>
      
      <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide relative z-10">
        {beneficiaries.map((b) => (
          <button
            key={b.id}
            onClick={() => onSelect(b.id)}
            className={`flex flex-col items-center gap-3 min-w-[130px] p-6 rounded-[2.5rem] border-2 transition-all group ${
              selectedId === b.id 
                ? 'border-blue-600 bg-blue-50/50 shadow-2xl scale-105' 
                : 'border-slate-100 bg-slate-50 opacity-60 hover:opacity-100 hover:border-slate-300'
            }`}
          >
            <div className="relative">
              <div className={`w-20 h-20 rounded-3xl overflow-hidden border-4 ${selectedId === b.id ? 'border-blue-600 shadow-xl' : 'border-white'}`}>
                <img src={b.avatar} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              </div>
              {selectedId === b.id && (
                <div className="absolute -top-3 -right-3 bg-blue-600 text-white rounded-full p-2 border-4 border-white shadow-lg animate-in zoom-in">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              )}
            </div>
            <div className="text-center">
              <p className={`text-sm font-black tracking-tight ${selectedId === b.id ? 'text-blue-700' : 'text-slate-900'}`}>{b.name}</p>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-0.5">{b.relationship}</p>
            </div>
          </button>
        ))}
      </div>
      
      {selectedId && (
        <div className="flex items-center justify-between p-4 bg-slate-900 rounded-2xl animate-in slide-in-from-bottom-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <MapPin className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-[9px] font-black text-blue-300 uppercase tracking-widest">Ubicación de Retiro</p>
              <p className="text-xs font-bold text-white">{beneficiaries.find(b => b.id === selectedId)?.address}, {beneficiaries.find(b => b.id === selectedId)?.city}</p>
            </div>
          </div>
          <span className="text-[9px] font-black text-green-400 uppercase bg-green-400/10 px-3 py-1 rounded-full border border-green-400/20">Marketplace Localizado</span>
        </div>
      )}
    </div>
  );
};
