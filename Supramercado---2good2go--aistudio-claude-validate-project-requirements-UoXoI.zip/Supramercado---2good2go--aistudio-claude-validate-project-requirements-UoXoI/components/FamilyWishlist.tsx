
import React, { useState } from 'react';
import { ShoppingBasket, Plus, Bell, Trash2, Sparkles, AlertCircle } from 'lucide-react';
import { WishlistItem } from '../types';

export const FamilyWishlist: React.FC = () => {
  const [items, setItems] = useState<WishlistItem[]>([
    { id: 'w1', productName: 'Aceite de Girasol', urgency: 'HIGH', status: 'PENDING' },
    { id: 'w2', productName: 'Café Santo Domingo', urgency: 'MEDIUM', status: 'PENDING' }
  ]);
  const [newItem, setNewItem] = useState('');

  const addItem = () => {
    if (!newItem.trim()) return;
    const item: WishlistItem = {
      id: Math.random().toString(),
      productName: newItem,
      urgency: 'MEDIUM',
      status: 'PENDING'
    };
    setItems([item, ...items]);
    setNewItem('');
  };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h4 className="font-black text-2xl text-slate-900">Lo que falta en casa</h4>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Sugerencias para tu familiar</p>
        </div>
        <div className="w-12 h-12 bg-blue-50 text-blue-700 rounded-2xl flex items-center justify-center">
          <ShoppingBasket className="w-6 h-6" />
        </div>
      </div>

      <div className="flex gap-2 mb-8">
        <input 
          type="text" 
          placeholder="Ej: Leche, Arroz, Salami..." 
          className="flex-1 px-5 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && addItem()}
        />
        <button 
          onClick={addItem}
          className="p-4 bg-blue-700 text-white rounded-2xl hover:scale-105 transition-all shadow-lg"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      <div className="space-y-3">
        {items.map(item => (
          <div key={item.id} className="flex items-center justify-between p-5 bg-slate-50 rounded-[1.5rem] border border-slate-100 group">
            <div className="flex items-center gap-4">
              <div className={`w-2 h-2 rounded-full ${item.urgency === 'HIGH' ? 'bg-red-500' : 'bg-orange-400'}`}></div>
              <p className="font-bold text-slate-900">{item.productName}</p>
            </div>
            <div className="flex items-center gap-3">
              <button className="text-slate-300 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
                <Trash2 className="w-4 h-4" />
              </button>
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-white px-3 py-1 rounded-full border border-slate-100">
                {item.urgency}
              </span>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 p-4 bg-blue-700 text-white rounded-2xl flex items-center gap-4 shadow-xl shadow-blue-700/20">
        <Sparkles className="w-6 h-6 shrink-0" />
        <p className="text-xs font-bold leading-relaxed italic">"Tu familiar recibirá una notificación para que pueda añadir esto a su próxima compra."</p>
      </div>
    </div>
  );
};
