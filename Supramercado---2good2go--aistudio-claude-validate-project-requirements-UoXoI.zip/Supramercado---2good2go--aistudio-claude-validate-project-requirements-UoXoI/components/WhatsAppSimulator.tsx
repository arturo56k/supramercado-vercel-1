
import React from 'react';
import { MessageCircle, Send, CheckCheck, Smartphone, X } from 'lucide-react';

interface WhatsAppSimulatorProps {
  orderId: string;
  beneficiaryName: string;
  onClose: () => void;
}

export const WhatsAppSimulator: React.FC<WhatsAppSimulatorProps> = ({ orderId, beneficiaryName, onClose }) => {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="bg-[#E5DDD5] w-full max-w-sm rounded-[2.5rem] shadow-2xl overflow-hidden border-8 border-slate-900 relative h-[600px] flex flex-col">
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-20"></div>
        
        {/* Header */}
        <div className="bg-[#075E54] p-6 pt-10 text-white flex items-center gap-3">
          <div className="w-10 h-10 bg-slate-300 rounded-full flex items-center justify-center text-[#075E54] font-black">
            S
          </div>
          <div>
            <h4 className="font-bold text-sm">Supramercado Bot</h4>
            <p className="text-[10px] text-green-200 uppercase font-black tracking-widest">En línea</p>
          </div>
          <button onClick={onClose} className="ml-auto p-2 hover:bg-white/10 rounded-full transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Chat Area */}
        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm relative max-w-[85%] animate-in slide-in-from-left-4 duration-500">
            <p className="text-xs font-medium text-slate-800 leading-relaxed">
              Hola **{beneficiaryName}** 👋, te han enviado una compra desde el extranjero por Supramercado.
            </p>
          </div>
          <div className="bg-[#DCF8C6] p-4 rounded-2xl rounded-tr-none shadow-sm relative self-end ml-auto max-w-[85%] animate-in slide-in-from-right-4 duration-700 delay-300">
            <div className="border-l-4 border-blue-600 bg-white/40 p-3 rounded-lg mb-2">
              <p className="text-[10px] font-black text-blue-600 uppercase mb-1">Compra Autorizada</p>
              <p className="text-[10px] font-bold text-slate-600 line-clamp-2">Click para ver tu ticket digital de retiro y ubicación del comercio.</p>
            </div>
            <p className="text-xs font-bold text-blue-700 underline mb-2 break-all">
              https://supra.do/l/{orderId}
            </p>
            <div className="flex justify-end gap-1">
              <span className="text-[9px] text-slate-400">12:45 PM</span>
              <CheckCheck className="w-3 h-3 text-blue-500" />
            </div>
          </div>
        </div>

        {/* Input Bar */}
        <div className="bg-[#F0F0F0] p-4 flex gap-2">
          <div className="flex-1 bg-white rounded-full px-4 py-3 text-xs text-slate-400 font-medium">Escribe un mensaje...</div>
          <div className="w-10 h-10 bg-[#128C7E] rounded-full flex items-center justify-center text-white">
            <Smartphone className="w-5 h-5" />
          </div>
        </div>
      </div>
    </div>
  );
};
