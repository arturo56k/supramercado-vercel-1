
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { TrendingUp, AlertCircle, Zap, ArrowRight, Loader2, Landmark } from 'lucide-react';

export const MarketPulse: React.FC = () => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMarketAdvice = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: 'Dime brevemente si hoy es un buen día para enviar remesas a República Dominicana basándote en la tasa del dólar (DOP) y posibles ofertas locales. Sé breve y útil.',
          config: { tools: [{ googleSearch: {} }] }
        });
        setAdvice(response.text || null);
      } catch (e) {
        setAdvice("Hoy es un buen día para ayudar. Los precios se mantienen estables en los principales mercados.");
      } finally {
        setIsLoading(false);
      }
    };
    fetchMarketAdvice();
  }, []);

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm relative overflow-hidden group">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 bg-blue-50 text-blue-700 rounded-2xl flex items-center justify-center">
          <Landmark className="w-6 h-6" />
        </div>
        <div>
          <h4 className="font-black text-lg text-slate-900">Consejero Financiero</h4>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Tasa & Suministro RD</p>
        </div>
      </div>

      <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
        {isLoading ? (
          <div className="flex items-center gap-3 text-slate-400 py-4">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span className="text-xs font-bold uppercase tracking-widest">Consultando el mercado...</span>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 bg-green-500 rounded-full mt-1.5 shrink-0"></div>
              <p className="text-sm font-bold text-slate-700 leading-relaxed italic">"{advice}"</p>
            </div>
            <button className="w-full flex items-center justify-between text-blue-700 font-black text-[10px] uppercase tracking-widest mt-2 group-hover:translate-x-1 transition-transform">
              Ver tasa oficial <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
