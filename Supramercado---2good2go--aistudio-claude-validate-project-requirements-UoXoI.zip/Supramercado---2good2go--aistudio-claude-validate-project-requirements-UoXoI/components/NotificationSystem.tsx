
import React, { useState, useEffect, createContext, useContext } from 'react';
import { Bell, CheckCircle2, AlertCircle, X, ShoppingBag, ShieldCheck } from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'SUCCESS' | 'INFO' | 'WARNING';
}

interface NotificationContextType {
  notify: (title: string, message: string, type?: 'SUCCESS' | 'INFO' | 'WARNING') => void;
  requestNativePermissions: () => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const notify = (title: string, message: string, type: 'SUCCESS' | 'INFO' | 'WARNING' = 'INFO') => {
    const id = Math.random().toString(36).substring(7);
    setNotifications(prev => [{ id, title, message, type }, ...prev]);
    
    // Notificación Nativa si hay permiso
    if (Notification.permission === 'granted') {
      new Notification(`Supra: ${title}`, { body: message });
    }

    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  const requestNativePermissions = () => {
    if ('Notification' in window) {
      Notification.requestPermission();
    }
  };

  return (
    <NotificationContext.Provider value={{ notify, requestNativePermissions }}>
      {children}
      <div className="fixed top-24 right-6 z-[200] space-y-3 w-full max-w-sm pointer-events-none">
        {notifications.map(n => (
          <div 
            key={n.id} 
            className="pointer-events-auto bg-white border border-slate-200 shadow-2xl rounded-2xl p-4 flex items-start gap-4 animate-in slide-in-from-right-8 duration-300"
          >
            <div className={`p-2 rounded-xl shrink-0 ${
              n.type === 'SUCCESS' ? 'bg-green-100 text-green-600' : 
              n.type === 'WARNING' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
            }`}>
              {n.type === 'SUCCESS' ? <CheckCircle2 className="w-5 h-5" /> : 
               n.type === 'WARNING' ? <AlertCircle className="w-5 h-5" /> : <ShoppingBag className="w-5 h-5" />}
            </div>
            <div className="flex-1">
              <h5 className="font-black text-sm text-slate-900 leading-tight">{n.title}</h5>
              <p className="text-xs font-medium text-slate-500 mt-1">{n.message}</p>
            </div>
            <button onClick={() => setNotifications(prev => prev.filter(notif => notif.id !== n.id))} className="text-slate-300 hover:text-slate-900">
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};

export const useNotify = () => {
  const context = useContext(NotificationContext);
  if (!context) throw new Error('useNotify must be used within NotificationProvider');
  return context;
};
