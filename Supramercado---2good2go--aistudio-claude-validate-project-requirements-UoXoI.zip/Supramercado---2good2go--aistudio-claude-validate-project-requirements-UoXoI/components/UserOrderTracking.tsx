
import React, { useState } from 'react';
import { Package, Clock, CheckCircle2, ChevronRight, MapPin, Smartphone, Truck, ShoppingBag, ShieldCheck, XCircle, RotateCcw, AlertTriangle, Lock, Landmark, DollarSign } from 'lucide-react';
import { Order } from '../types';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

export const UserOrderTracking: React.FC = () => {
  const { orders, merchants, cancelOrder } = useOrders();
  const { notify } = useNotify();
  const [confirmCancel, setConfirmCancel] = useState<string | null>(null);
  const myOrders = orders.filter(o => o.buyerId === 'user1');

  if (myOrders.length === 0) return null;

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
      <h3 className="text-xl font-black text-slate-900 mb-8 flex items-center gap-3">
        <Package className="w-6 h-6 text-blue-700" /> Estado de Remesas de Víveres
      </h3>
      <div className="space-y-12">
        {myOrders.map(order => {
          const merchant = merchants.find(m => m.id === order.merchantId);
          const isCancelled = order.status === 'CANCELLED';

          return (
            <div key={order.id} className={`space-y-8 pb-8 border-b border-slate-100 last:border-0 ${isCancelled ? 'opacity-50' : ''}`}>
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center overflow-hidden border border-slate-200">
                     <img src={merchant?.logo} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900 text-lg">Retiro: {order.beneficiaryName}</h4>
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1"><MapPin className="w-3 h-3" /> {merchant?.name} • {merchant?.city}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                   <div className="text-right">
                      <p className="text-[10px] font-black text-slate-400 uppercase">Total Enviado</p>
                      <p className="text-xl font-black text-blue-700">${order.totalUSD.toFixed(2)} USD</p>
                   </div>
                   {!isCancelled && order.status === 'PENDING' && (
                     <button onClick={() => setConfirmCancel(order.id)} className="p-3 text-red-400 hover:bg-red-50 rounded-xl transition-all"><XCircle className="w-6 h-6" /></button>
                   )}
                </div>
              </div>

              {/* Barra de Transparencia Financiera (Escrow) */}
              {!isCancelled && (
                <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 space-y-6">
                   <div className="flex items-center justify-between mb-2">
                      <h5 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Lock className="w-3 h-3" /> Ruta del Pago Seguro (Escrow)</h5>
                      <span className={`text-[9px] font-black px-3 py-1 rounded-full uppercase ${order.payoutId ? 'bg-green-100 text-green-600' : 'bg-blue-100 text-blue-600'}`}>
                        {order.payoutId ? 'Liquidado' : 'Fondos Protegidos'}
                      </span>
                   </div>
                   <div className="relative flex justify-between items-center px-2">
                      <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 -z-0"></div>
                      <EscrowStep active={true} done={true} label="NY Cobrado" icon={DollarSign} />
                      <EscrowStep active={true} done={true} label="Escrow Activo" icon={ShieldCheck} />
                      <EscrowStep active={order.status === 'REDEEMED'} done={order.status === 'REDEEMED'} label="Retirado RD" icon={ShoppingBag} />
                      <EscrowStep active={!!order.payoutId} done={!!order.payoutId} label="Liquidado" icon={Landmark} />
                   </div>
                </div>
              )}

              {confirmCancel === order.id && (
                <div className="bg-red-50 p-6 rounded-3xl border-2 border-red-100 flex items-center justify-between gap-6 animate-in slide-in-from-top-4">
                   <div className="flex items-center gap-4">
                      <AlertTriangle className="w-8 h-8 text-red-600" />
                      <div>
                        <p className="text-sm font-black text-red-900">¿Reembolsar esta remesa?</p>
                        <p className="text-xs text-red-700 font-medium italic">Los fondos volverán a tu balance Supra inmediatamente.</p>
                      </div>
                   </div>
                   <div className="flex gap-2">
                      <button onClick={() => setConfirmCancel(null)} className="px-4 py-2 bg-white text-slate-900 rounded-xl text-[10px] font-black uppercase border">No</button>
                      <button onClick={() => { cancelOrder(order.id); setConfirmCancel(null); notify("Reembolsado", "Fondos devueltos a tu cuenta.", "SUCCESS"); }} className="px-4 py-2 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase">Sí, Cancelar</button>
                   </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

const EscrowStep = ({ active, done, label, icon: Icon }: any) => (
  <div className="flex flex-col items-center gap-2 relative z-10">
    <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all border-2 ${
      done ? 'bg-green-500 border-green-500 text-white' : active ? 'bg-white border-blue-600 text-blue-600 scale-110 shadow-lg' : 'bg-white border-slate-200 text-slate-200'
    }`}>
      <Icon className="w-4 h-4" />
    </div>
    <span className={`text-[8px] font-black uppercase tracking-tighter text-center max-w-[50px] ${active ? 'text-slate-900' : 'text-slate-300'}`}>{label}</span>
  </div>
);
