
import React from 'react';
import { 
  User, Mail, Phone, MapPin, CreditCard, 
  ShieldCheck, Bell, LogOut, ChevronRight,
  PlusCircle, Trash2, Camera
} from 'lucide-react';
import { UserRole } from '../types';
import { ROLE_CONFIG } from '../constants';

interface ProfileProps {
  role: UserRole;
}

export const Profile: React.FC<ProfileProps> = ({ role }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      {/* Profile Header */}
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-r from-blue-700 to-orange-500 opacity-10"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
          <div className="relative group">
            <div className="w-32 h-32 rounded-3xl bg-slate-100 border-4 border-white shadow-xl overflow-hidden">
               <img src={`https://picsum.photos/seed/${role}/200/200`} className="w-full h-full object-cover" />
            </div>
            <button className="absolute -bottom-2 -right-2 p-2 bg-blue-700 text-white rounded-xl shadow-lg border-2 border-white hover:bg-blue-800 transition-colors">
              <Camera className="w-4 h-4" />
            </button>
          </div>
          <div className="text-center md:text-left flex-1">
             <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mb-2">
               <h2 className="text-3xl font-black text-slate-900">Pedro Alberto Santana</h2>
               <span className={`px-4 py-1 rounded-full text-white text-[10px] font-black uppercase tracking-widest ${ROLE_CONFIG[role].color}`}>
                 {ROLE_CONFIG[role].label}
               </span>
             </div>
             <p className="text-slate-500 font-medium">Gestionando felicidad desde New York City 🍎</p>
             <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 mt-4">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-400">
                  <Mail className="w-4 h-4" /> p.santana@example.com
                </div>
                <div className="flex items-center gap-2 text-sm font-bold text-slate-400">
                  <Phone className="w-4 h-4" /> +1 (917) 555-0123
                </div>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Profile Settings Menu */}
        <div className="space-y-4">
          <h4 className="font-black text-slate-400 text-xs uppercase tracking-widest px-4">Configuración</h4>
          <nav className="space-y-1">
            <ProfileLink icon={User} label="Información Personal" active />
            <ProfileLink icon={CreditCard} label="Métodos de Pago" />
            <ProfileLink icon={ShieldCheck} label="Seguridad & MoR" />
            <ProfileLink icon={Bell} label="Notificaciones" />
            <div className="pt-4 mt-4 border-t border-slate-100">
              <ProfileLink icon={LogOut} label="Cerrar Sesión" color="text-red-500" />
            </div>
          </nav>
        </div>

        {/* Content Area */}
        <div className="md:col-span-2 space-y-8">
          {/* Payment Methods */}
          <section className="space-y-4">
             <div className="flex items-center justify-between">
                <h3 className="font-black text-xl text-slate-900">Métodos de Pago</h3>
                <button className="text-blue-700 font-bold text-sm flex items-center gap-1">
                  <PlusCircle className="w-4 h-4" /> Añadir
                </button>
             </div>
             <div className="grid grid-cols-1 gap-4">
                {[
                  { id: '1', type: 'VISA', last4: '4242', exp: '12/26', primary: true },
                  { id: '2', type: 'MASTERCARD', last4: '8812', exp: '08/25', primary: false }
                ].map(card => (
                  <div key={card.id} className="bg-white p-5 rounded-3xl border border-slate-200 flex items-center justify-between shadow-sm hover:border-blue-300 transition-colors cursor-pointer group">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-[10px]">
                        {card.type}
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">•••• •••• •••• {card.last4}</p>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">EXP: {card.exp}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {card.primary && <span className="bg-blue-50 text-blue-700 text-[10px] font-black px-3 py-1 rounded-full border border-blue-100 uppercase">Principal</span>}
                      <button className="p-2 text-slate-300 group-hover:text-red-500 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
             </div>
          </section>

          {/* Contact & Location */}
          <section className="space-y-4">
             <h3 className="font-black text-xl text-slate-900">Ubicación & Contacto</h3>
             <div className="bg-white p-6 rounded-3xl border border-slate-200 space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-blue-50 text-blue-700 rounded-xl">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Dirección de Facturación (USA)</label>
                    <p className="font-bold text-slate-900">345 Broadway St, New York, NY 10013</p>
                    <button className="text-xs font-bold text-blue-700 mt-1">Editar Dirección</button>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-orange-50 text-orange-600 rounded-xl">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Teléfono Beneficiario Principal (RD)</label>
                    <p className="font-bold text-slate-900">+1 (829) 555-0982 <span className="text-slate-400 font-normal ml-2">WhatsApp vinculado</span></p>
                    <button className="text-xs font-bold text-orange-600 mt-1">Sincronizar Contacto</button>
                  </div>
                </div>
             </div>
          </section>
        </div>
      </div>
    </div>
  );
};

const ProfileLink = ({ icon: Icon, label, active = false, color = "text-slate-600" }: any) => (
  <button className={`
    w-full flex items-center justify-between px-4 py-3 rounded-2xl text-sm font-bold transition-all
    ${active ? 'bg-blue-700 text-white shadow-lg' : `${color} hover:bg-slate-100 hover:text-slate-900`}
  `}>
    <div className="flex items-center gap-3">
      <Icon className="w-5 h-5" />
      {label}
    </div>
    <ChevronRight className={`w-4 h-4 ${active ? 'text-white' : 'text-slate-300'}`} />
  </button>
);
