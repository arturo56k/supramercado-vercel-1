
import React, { useState, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Camera, ShieldCheck, AlertTriangle, Loader2, Sparkles, X, CheckCircle2 } from 'lucide-react';

export const FreshnessAudit: React.FC = () => {
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<{status: 'OK' | 'WARN', note: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAuditing(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = (event.target?.result as string).split(',')[1];
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [
            { inlineData: { data: base64Data, mimeType: file.type } },
            { text: "Analiza esta foto de alimentos perecederos que acaban de ser entregados. ¿Se ven frescos y seguros para consumir? Responde con un JSON: { 'status': 'OK' o 'WARN', 'note': 'breve explicación en español' }" }
          ]
        });
        
        const cleanJson = response.text.replace(/```json|```/g, '').trim();
        const result = JSON.parse(cleanJson);
        setAuditResult(result);
      } catch (err) {
        setAuditResult({ status: 'WARN', note: 'No pudimos verificar la imagen. Por favor, inspecciona manualmente.' });
      } finally {
        setIsAuditing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h4 className="font-black text-xl text-slate-900">Control de Calidad</h4>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Auditoría Visual Supra</p>
        </div>
        <div className="w-12 h-12 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center">
          <ShieldCheck className="w-6 h-6" />
        </div>
      </div>

      {!auditResult ? (
        <div className="text-center py-8 bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200">
          <input type="file" hidden ref={fileInputRef} accept="image/*" onChange={handlePhoto} />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isAuditing}
            className="flex flex-col items-center gap-4 mx-auto"
          >
            <div className="w-16 h-16 bg-white rounded-2xl shadow-xl flex items-center justify-center text-blue-700 hover:scale-110 transition-transform">
              {isAuditing ? <Loader2 className="w-8 h-8 animate-spin" /> : <Camera className="w-8 h-8" />}
            </div>
            <p className="text-sm font-bold text-slate-500 max-w-[200px]">Toma una foto de tu pedido para verificar frescura</p>
          </button>
        </div>
      ) : (
        <div className={`p-6 rounded-[2rem] border-2 animate-in zoom-in ${auditResult.status === 'OK' ? 'bg-green-50 border-green-100' : 'bg-orange-50 border-orange-100'}`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              {auditResult.status === 'OK' ? <CheckCircle2 className="w-5 h-5 text-green-600" /> : <AlertTriangle className="w-5 h-5 text-orange-600" />}
              <span className={`text-[10px] font-black uppercase tracking-widest ${auditResult.status === 'OK' ? 'text-green-600' : 'text-orange-600'}`}>
                Resultado: {auditResult.status}
              </span>
            </div>
            <button onClick={() => setAuditResult(null)} className="text-slate-400 hover:text-slate-900"><X className="w-4 h-4" /></button>
          </div>
          <p className="text-sm font-bold text-slate-700 italic">"{auditResult.note}"</p>
          <div className="mt-6 flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest justify-center">
            <Sparkles className="w-3 h-3 text-blue-500" /> Verificación AI completada
          </div>
        </div>
      )}
    </div>
  );
};
