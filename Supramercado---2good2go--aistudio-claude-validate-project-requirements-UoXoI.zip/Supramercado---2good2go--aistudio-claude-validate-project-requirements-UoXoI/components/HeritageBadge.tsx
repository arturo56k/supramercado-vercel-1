
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Trophy, Shield, Star, Sparkles, Loader2, Award } from 'lucide-react';

interface HeritageBadgeProps {
  points: number;
  level: string;
}

export const HeritageBadge: React.FC<HeritageBadgeProps> = ({ points, level }) => {
  const [badgeImage, setBadgeImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateBadge = async () => {
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `A vibrant, high-quality 3D digital badge for a "Dominican Heritage Hero" with the title "${level}". Design elements: Tropical fruits, a Dominican flag ribbon, golden metallic finish, stylized and modern, white background.` }]
        },
        config: { imageConfig: { aspectRatio: "1:1" } }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setBadgeImage(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl">
      <div className="relative z-10 flex flex-col items-center text-center">
        <div className="w-20 h-20 bg-blue-600 rounded-[2rem] flex items-center justify-center mb-6 shadow-2xl border border-white/10 group cursor-pointer relative" onClick={generateBadge}>
          {isGenerating ? (
            <Loader2 className="w-10 h-10 animate-spin" />
          ) : badgeImage ? (
            <img src={badgeImage} className="w-full h-full object-cover rounded-[2rem]" />
          ) : (
            <Trophy className="w-10 h-10" />
          )}
          {!badgeImage && !isGenerating && (
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-[2rem] transition-opacity">
              <Sparkles className="w-6 h-6" />
            </div>
          )}
        </div>
        
        <h4 className="text-2xl font-black tracking-tight">{level}</h4>
        <p className="text-blue-300 text-[10px] font-black uppercase tracking-widest mt-1">Nivel de Impacto Familiar</p>
        
        <div className="w-full bg-white/10 h-3 rounded-full mt-8 overflow-hidden">
          <div 
            className="bg-gradient-to-r from-blue-500 to-orange-500 h-full transition-all duration-1000" 
            style={{ width: `${(points % 100)}%` }}
          ></div>
        </div>
        
        <div className="flex justify-between w-full mt-4">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{points} PTS</span>
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">SIGUIENTE RANGO</span>
        </div>

        <button 
          onClick={generateBadge}
          className="mt-8 px-6 py-3 bg-white/5 hover:bg-white/10 rounded-xl text-[10px] font-black uppercase tracking-widest border border-white/10 transition-all"
        >
          {badgeImage ? 'Actualizar Medalla' : 'Generar mi Medalla AI'}
        </button>
      </div>
      <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-blue-600 rounded-full blur-[100px] opacity-20"></div>
    </div>
  );
};
