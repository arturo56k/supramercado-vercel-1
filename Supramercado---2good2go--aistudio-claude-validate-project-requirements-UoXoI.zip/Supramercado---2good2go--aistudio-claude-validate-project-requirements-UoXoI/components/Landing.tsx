
import React, { useState } from 'react';
import { 
  Store, Star, ArrowRight, MapPin, Search, ChevronRight, 
  Filter, Globe, Menu, User, Map as MapIcon, List, 
  Home, Briefcase, Pill, Utensils, Heart, ChevronLeft, Volume2
} from 'lucide-react';
import { MOCK_MERCHANTS, EnhancedMerchant } from '../constants';
import { Merchant } from '../types';
import { VoiceFAQ } from './VoiceFAQ';

interface LandingProps {
  onSelectMerchant: (merchant: Merchant) => void;
  onBrowseAll: () => void;
}

const CATEGORIES = [
  { id: 'All', label: 'Todo', icon: Globe },
  { id: 'Groceries', label: 'Súper', icon: Home },
  { id: 'Health', label: 'Salud', icon: Pill },
  { id: 'Local', label: 'Tiendas', icon: Store },
  { id: 'Food', label: 'Comida', icon: Utensils },
];

export const Landing: React.FC<LandingProps> = ({ onSelectMerchant, onBrowseAll }) => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [showMap, setShowMap] = useState(false);
  const [selectedLocation, setSelectedLocation] = useState('');

  const filteredMerchants = MOCK_MERCHANTS.filter(m => {
    const categoryMatch = activeCategory === 'All' || m.category === activeCategory;
    const locationMatch = !selectedLocation || m.locationName.toLowerCase().includes(selectedLocation.toLowerCase());
    return categoryMatch && locationMatch;
  });

  // Using React.FC to properly handle the 'key' prop and other standard component props
  const MerchantCard: React.FC<{ merchant: EnhancedMerchant }> = ({ merchant }) => (
    <div 
      onClick={() => onSelectMerchant(merchant)}
      className="group cursor-pointer flex flex-col gap-3 animate-in fade-in duration-500"
    >
      <div className="relative aspect-square w-full rounded-[1.2rem] overflow-hidden bg-slate-100 shadow-sm transition-shadow hover:shadow-md">
        <img 
          src={merchant.logo} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
          alt={merchant.name}
        />
        <button className="absolute top-3 right-3 p-2 text-white/90 hover:text-white transition-colors drop-shadow-md">
          <Heart className="w-5 h-5 fill-black/20 stroke-white stroke-[2px]" />
        </button>
      </div>
      <div className="flex flex-col gap-0.5 px-0.5">
        <div className="flex justify-between items-center">
          <h3 className="font-bold text-[15px] text-slate-900 truncate">{merchant.name}</h3>
          <div className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 fill-slate-900" />
            <span className="text-sm text-slate-900 font-medium">{merchant.rating}</span>
          </div>
        </div>
        <p className="text-sm text-slate-500">{merchant.locationName}, Rep. Dom.</p>
        <div className="mt-1.5 flex items-center gap-1">
          <span className="font-bold text-slate-900">${merchant.priceLevel === '$' ? '15' : merchant.priceLevel === '$$' ? '45' : '90'} USD</span>
          <span className="text-slate-500 text-sm font-normal"> promedio</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="bg-white min-h-screen">
      <div className="sticky top-0 z-50 bg-white pt-4 pb-0">
        <div className="max-w-[1600px] mx-auto px-6 lg:px-20 mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => window.location.reload()}>
            <div className="w-8 h-8 bg-blue-700 rounded-lg flex items-center justify-center text-white font-black italic">S</div>
            <span className="text-blue-700 font-black text-xl tracking-tighter hidden md:block">supramercado</span>
          </div>

          <div className="flex-1 max-w-lg mx-8">
            <div className="flex items-center bg-white border border-slate-200 rounded-full shadow-sm hover:shadow-md transition-all py-1.5 px-2">
              <div className="flex-1 px-4 border-r border-slate-100 flex flex-col">
                <span className="text-[9px] font-black uppercase text-slate-900">Ubicación</span>
                <input 
                  type="text" 
                  placeholder="Santiago, SDQ..." 
                  className="text-xs font-medium outline-none placeholder:text-slate-400"
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                />
              </div>
              <div className="flex-1 px-4 border-r border-slate-100 flex flex-col hidden sm:flex">
                <span className="text-[9px] font-black uppercase text-slate-900">Servicio</span>
                <span className="text-xs font-medium text-slate-400">Entrega Garantizada</span>
              </div>
              <button className="bg-blue-700 p-2.5 rounded-full text-white hover:bg-blue-800 transition-colors">
                <Search className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex items-center gap-4">
             <button className="text-xs font-black uppercase tracking-widest text-slate-900 hidden lg:block">Hazte socio</button>
             <div className="flex items-center gap-2 border border-slate-200 rounded-full py-1 px-1 pl-3 hover:shadow-md transition-shadow cursor-pointer">
               <Menu className="w-4 h-4 text-slate-600" />
               <div className="w-8 h-8 bg-slate-400 rounded-full flex items-center justify-center text-white">
                 <User className="w-4 h-4" />
               </div>
             </div>
          </div>
        </div>

        <div className="border-t border-slate-100 shadow-sm bg-white overflow-x-auto scrollbar-hide">
          <div className="max-w-[1600px] mx-auto px-6 lg:px-20 flex items-center gap-8 py-4">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex flex-col items-center gap-2 min-w-max pb-3 border-b-2 transition-all ${
                    activeCategory === cat.id ? 'border-slate-900 text-slate-900 opacity-100' : 'border-transparent text-slate-500 opacity-60 hover:opacity-100 hover:border-slate-200'
                  }`}
                >
                  <Icon className="w-6 h-6" />
                  <span className="text-[11px] font-bold tracking-tight">{cat.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <div className={`relative ${showMap ? 'flex' : 'max-w-[1600px] mx-auto px-6 lg:px-20 py-8 space-y-12'}`}>
        {!showMap && (
          <div className="animate-in slide-in-from-top-4 duration-700">
            <VoiceFAQ />
          </div>
        )}

        <div className={`${showMap ? 'w-full lg:w-[60%] overflow-y-auto px-6 lg:px-10 py-8 scrollbar-hide' : 'w-full'}`}>
          <div className={`grid gap-x-6 gap-y-10 ${
            showMap 
              ? 'grid-cols-1 sm:grid-cols-2' 
              : 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5'
          }`}>
            {filteredMerchants.map((merchant) => (
              <MerchantCard key={merchant.id} merchant={merchant} />
            ))}
          </div>
        </div>

        {showMap && (
          <div className="hidden lg:block w-[40%] sticky top-[140px] h-[calc(100vh-140px)] bg-slate-100 border-l border-slate-200">
            <div className="relative w-full h-full bg-[#E5E3DF]">
              <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ backgroundImage: 'linear-gradient(#000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)', backgroundSize: '100px 100px' }}></div>
              {filteredMerchants.map((m, i) => (
                <div 
                  key={m.id}
                  className="absolute animate-in fade-in zoom-in duration-500"
                  style={{ top: `${15 + (i * 15) % 70}%`, left: `${15 + (i * 20) % 70}%` }}
                >
                  <button onClick={() => onSelectMerchant(m)} className="bg-white px-3 py-1.5 rounded-full shadow-lg border border-white font-bold text-sm text-slate-900 active:bg-slate-900 active:text-white">
                    ${m.priceLevel === '$' ? '15' : m.priceLevel === '$$' ? '45' : '90'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] sm:bottom-12">
        <button 
          onClick={() => setShowMap(!showMap)}
          className="bg-slate-900 text-white px-6 py-3.5 rounded-full font-bold text-[13px] shadow-2xl flex items-center gap-2 hover:scale-105 active:scale-95 transition-all"
        >
          {showMap ? 'Mostrar lista' : 'Mostrar mapa'}
          {showMap ? <List className="w-4 h-4" /> : <MapIcon className="w-4 h-4" />}
        </button>
      </div>
    </div>
  );
};
