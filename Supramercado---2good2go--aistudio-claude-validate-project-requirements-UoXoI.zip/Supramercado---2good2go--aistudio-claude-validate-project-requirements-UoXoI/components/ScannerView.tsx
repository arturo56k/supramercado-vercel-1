
import React, { useState, useEffect } from 'react';
import { Camera, X, CheckCircle2, AlertCircle, Loader2, Zap, Smartphone, Lock, MapPin, Wifi, WifiOff, Navigation } from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

export const ScannerView: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [scanStatus, setScanStatus] = useState<'IDLE' | 'SCANNING' | 'PIN_REQUIRED' | 'SUCCESS' | 'ERROR'>('IDLE');
  const [scannedOrder, setScannedOrder] = useState<any>(null);
  const [pin, setPin] = useState('');
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [errorMessage, setErrorMessage] = useState('');
  const { getOrderByCode, redeemOrder } = useOrders();
  const { notify } = useNotify();

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    // Solicitar ubicación al abrir el escáner
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => console.error("GPS Error:", err),
        { enableHighAccuracy: true }
      );
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const simulateScan = () => {
    setScanStatus('SCANNING');
    setErrorMessage('');
    
    setTimeout(() => {
      const order = useOrders().orders.find(o => o.status !== 'REDEEMED' && o.status !== 'CANCELLED'); 
      if (order) {
        setScannedOrder(order);
        setScanStatus('PIN_REQUIRED');
      } else {
        setErrorMessage("No se encontraron tickets activos.");
        setScanStatus('ERROR');
      }
    }, 1500);
  };

  const handlePinSubmit = () => {
    if (pin.length === 4) {
      const result = redeemOrder(scannedOrder.magicLinkCode, undefined, location || undefined);
      
      if (result.success) {
        setScanStatus('SUCCESS');
        notify("Redención Exitosa", "La entrega ha sido grabada con GPS.", "SUCCESS");
      } else {
        setErrorMessage(result.reason || "Error de validación");
        setScanStatus('ERROR');
        notify("Validación Fallida", result.reason || "Error desconocido", "WARNING");
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[250] bg-slate-900 flex flex-col animate-in fade-in">
      <div className="p-6 flex justify-between items-center text-white border-b border-white/5">
        <div className="flex items-center gap-3">
           <div className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`}></div>
           <h3 className="font-black uppercase tracking-widest text-[10px]">Terminal POS Supra {isOnline ? '' : '(OFFLINE)'}</h3>
        </div>
        <button onClick={onClose} className="p-2 bg-white/10 rounded-full hover:bg-white/20 transition-colors"><X className="w-5 h-5" /></button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {scanStatus === 'IDLE' || scanStatus === 'SCANNING' ? (
          <div className="text-center space-y-8">
            <div className="relative w-full max-w-sm aspect-square">
              <div className="absolute inset-0 border-2 border-white/20 rounded-[3rem] overflow-hidden bg-slate-800 flex items-center justify-center">
                <Camera className={`w-16 h-16 text-white/10 ${scanStatus === 'SCANNING' ? 'animate-pulse' : ''}`} />
                {scanStatus === 'SCANNING' && (
                  <div className="absolute inset-x-0 top-0 h-1 bg-blue-500 shadow-[0_0_20px_blue] animate-[scan_2s_infinite]"></div>
                )}
              </div>
              <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-blue-500 rounded-tl-3xl"></div>
              <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-blue-500 rounded-br-3xl"></div>
              {scanStatus === 'IDLE' && (
                <button onClick={simulateScan} className="absolute inset-0 m-auto w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center shadow-2xl animate-bounce">
                  <Zap className="w-10 h-10 text-white fill-white" />
                </button>
              )}
            </div>
            <div className="space-y-2">
              <p className="text-slate-400 font-bold text-sm uppercase tracking-widest">Escanea el Ticket de Supra</p>
              {location ? (
                <p className="text-[9px] text-green-500 font-black uppercase flex items-center justify-center gap-1"><Navigation className="w-3 h-3" /> Coordenadas GPS Vinculadas</p>
              ) : (
                <p className="text-[9px] text-orange-500 font-black uppercase flex items-center justify-center gap-1 animate-pulse"><AlertCircle className="w-3 h-3" /> Esperando Señal GPS...</p>
              )}
            </div>
          </div>
        ) : scanStatus === 'PIN_REQUIRED' ? (
          <div className="w-full max-w-sm bg-white rounded-[3rem] p-10 text-center space-y-8 animate-in zoom-in">
             <div className="flex justify-center mb-2">
                <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-2 ${isOnline ? 'bg-blue-50 text-blue-700' : 'bg-red-50 text-red-600'}`}>
                   {isOnline ? <MapPin className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />} {isOnline ? 'GPS Listo' : 'Modo Offline Activado'}
                </div>
             </div>
             <div>
                <h4 className="text-xl font-black text-slate-900">Validar Identidad</h4>
                <p className="text-xs text-slate-400 font-bold uppercase mt-1">Beneficiario: {scannedOrder?.beneficiaryName}</p>
             </div>
             <div className="flex justify-center gap-3">
                {[...Array(4)].map((_, i) => (
                  <div key={i} className={`w-12 h-16 rounded-2xl border-2 flex items-center justify-center text-2xl font-black ${pin.length > i ? 'border-blue-600 bg-blue-50 text-blue-700' : 'border-slate-100 bg-slate-50'}`}>
                    {pin[i] ? '•' : ''}
                  </div>
                ))}
             </div>
             <div className="grid grid-cols-3 gap-2">
                {[1,2,3,4,5,6,7,8,9,0].map(n => (
                  <button 
                    key={n} 
                    onClick={() => pin.length < 4 && setPin(p => p + n)}
                    className="h-14 bg-slate-50 rounded-xl font-black text-slate-900 hover:bg-slate-100 active:scale-95 transition-all"
                  >
                    {n}
                  </button>
                ))}
                <button onClick={() => setPin('')} className="h-14 bg-red-50 text-red-600 rounded-xl font-black text-[10px] uppercase">Borrar</button>
             </div>
             <button 
                onClick={handlePinSubmit}
                disabled={pin.length < 4}
                className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl disabled:opacity-30"
             >
                Confirmar Entrega
             </button>
          </div>
        ) : scanStatus === 'SUCCESS' ? (
          <div className="w-full max-w-sm bg-white rounded-[3rem] p-10 text-center space-y-8 animate-in zoom-in">
            <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-xl">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <div>
              <h4 className="text-3xl font-black text-slate-900">¡Validado!</h4>
              <p className="text-sm font-medium text-slate-500 mt-2">La transacción ha sido grabada y los fondos se liberarán al cierre.</p>
            </div>
            <button onClick={onClose} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase shadow-xl">Finalizar</button>
          </div>
        ) : (
          <div className="text-center space-y-8 animate-in zoom-in">
            <div className="w-24 h-24 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto">
              <AlertCircle className="w-12 h-12" />
            </div>
            <div>
              <h4 className="text-2xl font-black text-white">Fallo de Validación</h4>
              <p className="text-red-400 font-bold mt-2 uppercase text-xs tracking-widest">{errorMessage}</p>
            </div>
            <button onClick={() => setScanStatus('IDLE')} className="bg-white/10 text-white px-10 py-5 rounded-2xl font-black text-xs uppercase tracking-widest border border-white/10">Reintentar</button>
          </div>
        )}
      </div>
    </div>
  );
};
