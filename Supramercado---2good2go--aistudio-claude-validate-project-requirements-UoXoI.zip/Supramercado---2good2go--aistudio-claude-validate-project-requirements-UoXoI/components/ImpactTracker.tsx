
import React, { useState } from 'react';
import { Leaf, ShoppingBag, Zap, Heart, Sparkles, Share2, Loader2, Award, Download, X } from 'lucide-react';
import { useOrders } from './OrderContext';
import { GoogleGenAI } from "@google/genai";

export const ImpactTracker: React.FC = () => {
  const { totalImpactKg } = useOrders();
  const [isGenerating, setIsGenerating] = useState(false);
  const [certificateImg, setCertificateImg] = useState<string | null>(null);
  
  const generateCertificate = async () => {
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `A professional and high-quality "Sustainability Hero" certificate for a person who saved ${totalImpactKg.toFixed(1)}kg of food. Tropical Dominican theme, golden accents, modern typography, bright and inspiring colors, white background.` }]
        },
        config: { imageConfig: { aspectRatio: "4:3" } }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setCertificateImg(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-white rounded-[2.5rem] border border-slate-200 p-8 shadow-sm overflow-hidden relative group">
      <div className="absolute -right-4 -top-4 w-24 h-24 bg-green-500/5 rounded-full blur-2xl group-hover:bg-green-500/10 transition-all"></div>
      
      <div className="flex items-center justify-between mb-8">
        <div>
          <h4 className="font-black text-xl text-slate-900">Tu Legado Supra</h4>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Sostenibilidad & Apoyo Social</p>
        </div>
        <div className="w-12 h-12 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center">
          <Leaf className="w-6 h-6" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 relative overflow-hidden">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-tighter mb-1 relative z-10">Comida Salvada</p>
          <div className="flex items-end gap-1 relative z-10">
            <span className="text-3xl font-black text-slate-900 animate-in zoom-in">{totalImpactKg.toFixed(1)}</span>
            <span className="text-xs font-bold text-slate-400 mb-1">kg</span>
          </div>
          <div className="absolute -bottom-2 -right-2 opacity-5">
             <ShoppingBag className="w-12 h-12" />
          </div>
        </div>
        <div className="bg-orange-50 p-6 rounded-[2rem] border border-orange-100">
          <p className="text-[10px] font-black text-orange-400 uppercase tracking-tighter mb-1">Eco-Puntos</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-black text-orange-600">{(totalImpactKg * 10).toFixed(0)}</span>
            <Sparkles className="w-4 h-4 text-orange-400 mb-1" />
          </div>
        </div>
      </div>

      <button 
        onClick={generateCertificate}
        disabled={isGenerating || totalImpactKg === 0}
        className="mt-6 w-full py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl hover:bg-slate-800 transition-all disabled:opacity-30"
      >
        {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Award className="w-4 h-4" />}
        Generar Certificado de Impacto
      </button>

      <div className="mt-8 pt-6 border-t border-slate-100">
        <div className="flex items-center gap-3">
          <div className="flex -space-x-2">
            {[1,2,3].map(i => (
              <div key={i} className="w-8 h-8 rounded-full border-4 border-white bg-slate-200 overflow-hidden shadow-sm">
                <img src={`https://picsum.photos/seed/user${i}/100/100`} className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-tight">Eres de los principales guardianes de Santiago</p>
        </div>
      </div>

      {certificateImg && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-6 bg-slate-900/90 backdrop-blur-md">
           <div className="bg-white rounded-[3rem] p-10 max-w-lg w-full shadow-2xl animate-in zoom-in duration-300">
              <div className="flex justify-between items-center mb-8">
                 <h4 className="text-2xl font-black text-slate-900">Tu Certificado AI</h4>
                 <button onClick={() => setCertificateImg(null)}><X className="w-6 h-6" /></button>
              </div>
              <img src={certificateImg} className="w-full rounded-2xl shadow-xl mb-8 border border-slate-100" />
              <div className="flex gap-4">
                 <button className="flex-1 bg-blue-700 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                    <Download className="w-4 h-4" /> Descargar
                 </button>
                 <button className="flex-1 bg-slate-900 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2">
                    <Share2 className="w-4 h-4" /> Compartir en IG
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
