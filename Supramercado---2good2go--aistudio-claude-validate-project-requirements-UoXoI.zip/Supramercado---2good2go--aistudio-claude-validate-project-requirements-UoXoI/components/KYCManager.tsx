
import React, { useState, useRef } from 'react';
import { ShieldCheck, Upload, Loader2, CheckCircle, FileText, Camera, AlertCircle } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

export const KYCManager: React.FC = () => {
  const [isUploading, setIsUploading] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDocument = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    setError(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = (event.target?.result as string).split(',')[1];
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [
            { inlineData: { data: base64Data, mimeType: file.type } },
            { text: "Analiza este documento de identidad o RNC dominicano. ¿Es un documento válido? Responde solo 'VALID' o 'INVALID' seguido de una breve razón." }
          ]
        });

        if (response.text.includes('VALID')) {
          setIsVerified(true);
        } else {
          setError("Documento no reconocido como RNC oficial.");
        }
      } catch (err) {
        setError("Error en la conexión con el servicio de verificación.");
      } finally {
        setIsUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden relative">
      <div className="flex items-center gap-4 mb-8">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${isVerified ? 'bg-green-100 text-green-600' : 'bg-blue-50 text-blue-700'}`}>
          {isVerified ? <CheckCircle className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
        </div>
        <div>
          <h4 className="font-black text-xl text-slate-900">Verificación de Comercio</h4>
          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Cumplimiento Fiscal RD</p>
        </div>
      </div>

      {isVerified ? (
        <div className="p-6 bg-green-50 border-2 border-green-100 rounded-[2rem] text-center animate-in zoom-in">
          <p className="text-green-700 font-black text-sm uppercase tracking-widest">¡Comercio Verificado!</p>
          <p className="text-xs text-green-600 mt-1 font-medium italic">Ahora puedes recibir remesas en USD y liquidar en DOP.</p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="p-6 bg-slate-50 border-2 border-dashed border-slate-200 rounded-[2rem] text-center group cursor-pointer hover:border-blue-300 transition-all" onClick={() => fileInputRef.current?.click()}>
            <input type="file" hidden ref={fileInputRef} onChange={handleDocument} accept="image/*,.pdf" />
            {isUploading ? (
              <Loader2 className="w-10 h-10 text-blue-700 animate-spin mx-auto mb-4" />
            ) : (
              <Upload className="w-10 h-10 text-slate-300 mx-auto mb-4 group-hover:text-blue-500 transition-colors" />
            )}
            <p className="text-sm font-bold text-slate-500">Sube tu RNC o Cédula Dominicana</p>
            <p className="text-[10px] text-slate-400 uppercase font-black mt-2">JPG, PNG o PDF</p>
          </div>
          {error && (
            <div className="flex items-center gap-2 text-red-500 bg-red-50 p-3 rounded-xl border border-red-100">
              <AlertCircle className="w-4 h-4" />
              <p className="text-xs font-bold">{error}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
