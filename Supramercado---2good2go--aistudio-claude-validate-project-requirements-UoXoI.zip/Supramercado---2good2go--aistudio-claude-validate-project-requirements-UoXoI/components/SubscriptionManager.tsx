
import React from 'react';
import { Calendar, RefreshCcw, Pause, Play, Trash2, Clock, AlertCircle } from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

export const SubscriptionManager: React.FC = () => {
  const { subscriptions, updateSubscription, merchants } = useOrders();
  const { notify } = useNotify();

  const handleToggle = (id: string, currentStatus: string) => {
    const nextStatus = currentStatus === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
    updateSubscription(id, { status: nextStatus });
    notify(
      nextStatus === 'ACTIVE' ? "Suscripción Reactivada" : "Suscripción Pausada",
      nextStatus === 'ACTIVE' ? "Tu próximo envío se procesará según lo programado." : "No se realizarán cobros hasta que reactives.",
      nextStatus === 'ACTIVE' ? "SUCCESS" : "INFO"
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-8 rounded-[3rem] border border-slate-200 shadow-sm">
        <div className="flex items-center gap-4 mb-8">
           <div className="w-12 h-12 bg-blue-100 text-blue-700 rounded-2xl flex items-center justify-center">
              <Calendar className="w-6 h-6" />
           </div>
           <div>
              <h3 className="text-2xl font-black text-slate-900">Envíos Programados</h3>
              <p className="text-slate-500 font-medium">Gestiona tus canastas básicas recurrentes.</p>
           </div>
        </div>

        <div className="space-y-4">
          {subscriptions.length === 0 ? (
            <div className="text-center py-12 bg-slate-50 rounded-[2rem] border-2 border-dashed border-slate-200">
               <Clock className="w-12 h-12 text-slate-300 mx-auto mb-4" />
               <p className="font-black text-slate-400 uppercase tracking-widest text-xs">No tienes suscripciones activas.</p>
               <p className="text-xs text-slate-500 mt-2 px-6">Activa una frecuencia semanal o mensual al hacer checkout.</p>
            </div>
          ) : (
            subscriptions.map(sub => {
              const merchant = merchants.find(m => m.id === sub.merchantId);
              return (
                <div key={sub.id} className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 hover:border-blue-300 transition-all">
                   <div className="flex items-center gap-5">
                      <img src={merchant?.logo} className="w-16 h-16 rounded-2xl object-cover shadow-md" />
                      <div>
                        <h4 className="font-black text-lg text-slate-900">{sub.items}</h4>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{sub.frequency} • Próximo: {new Date(sub.nextBillingDate).toLocaleDateString()}</p>
                      </div>
                   </div>

                   <div className="flex items-center gap-8">
                      <div className="text-right">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cargo Estimado</p>
                        <p className="text-xl font-black text-slate-900">${sub.amountUSD.toFixed(2)}</p>
                      </div>
                      
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleToggle(sub.id, sub.status)}
                          className={`p-4 rounded-2xl transition-all ${sub.status === 'ACTIVE' ? 'bg-orange-50 text-orange-600 hover:bg-orange-100' : 'bg-green-50 text-green-600 hover:bg-green-100'}`}
                        >
                          {sub.status === 'ACTIVE' ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                        </button>
                        <button className="p-4 bg-slate-50 text-slate-300 hover:text-red-500 rounded-2xl transition-all">
                           <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                   </div>
                </div>
              )
            })
          )}
        </div>
      </div>

      <div className="bg-blue-700 p-8 rounded-[3rem] text-white flex items-center gap-6 shadow-2xl shadow-blue-700/30">
        <AlertCircle className="w-10 h-10 shrink-0 text-blue-300" />
        <div>
          <h4 className="font-black text-lg">Garantía de Suministro Supra</h4>
          <p className="text-blue-100 text-sm leading-relaxed">
            Las suscripciones aseguran que los productos críticos (arroz, leche, medicinas) se reserven en inventario prioritariamente para tu familia en RD.
          </p>
        </div>
      </div>
    </div>
  );
};
