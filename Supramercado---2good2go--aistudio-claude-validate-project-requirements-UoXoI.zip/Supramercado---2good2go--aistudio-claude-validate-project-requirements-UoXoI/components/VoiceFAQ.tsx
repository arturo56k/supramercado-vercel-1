
import React, { useState } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { Play, Pause, Loader2, MessageSquareText, Volume2, Users } from 'lucide-react';

export const VoiceFAQ: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const playConversation = async () => {
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `TTS the following conversation between Pedro (in New York) and Doña Maria (in Santiago, RD):
      Pedro: Doña Maria, ¡le envié una Suprabolsa del Nacional por la app! ¿Ya le llegó el link?
      Doña Maria: ¡Ay Pedro! Sí, me llegó al WhatsApp. ¿Y esto cómo funciona mi hijo?
      Pedro: Solo vaya allá, enseñe el código y deslice el dedo en la pantalla del cajero. ¡Es magia!
      Doña Maria: ¡Qué maravilla! Así no tengo que andar con efectivo en la calle. ¡Gracias hijo!`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            multiSpeakerVoiceConfig: {
              speakerVoiceConfigs: [
                { speaker: 'Pedro', voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
                { speaker: 'Doña Maria', voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } } }
              ]
            }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const binary = atob(base64Audio);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        
        const dataInt16 = new Int16Array(bytes.buffer);
        const buffer = audioCtx.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
        
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(audioCtx.destination);
        setIsPlaying(true);
        source.onended = () => setIsPlaying(false);
        source.start();
      }
    } catch (error) {
      console.error("Multi-speaker TTS error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-8 opacity-10">
        <Users className="w-24 h-24" />
      </div>
      <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-2xl shrink-0">
          {isLoading ? <Loader2 className="w-8 h-8 animate-spin" /> : <Volume2 className="w-8 h-8" />}
        </div>
        <div className="flex-1 text-center md:text-left">
          <h4 className="text-xl font-black uppercase tracking-tight">Escucha cómo funciona</h4>
          <p className="text-slate-400 text-sm font-medium mt-1">Una conversación entre Pedro (NY) y Doña Maria (RD).</p>
        </div>
        <button 
          onClick={playConversation}
          disabled={isLoading || isPlaying}
          className="px-8 py-4 bg-white text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest hover:scale-105 active:scale-95 transition-all shadow-xl disabled:opacity-50"
        >
          {isPlaying ? 'Reproduciendo...' : 'Reproducir Audio'}
        </button>
      </div>
    </div>
  );
};
