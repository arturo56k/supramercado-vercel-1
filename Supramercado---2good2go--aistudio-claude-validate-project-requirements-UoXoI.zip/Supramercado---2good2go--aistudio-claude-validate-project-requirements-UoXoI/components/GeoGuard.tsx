
import React, { useState, useEffect } from 'react';
import { MapPin, ShieldAlert, CheckCircle2, Navigation } from 'lucide-react';

interface GeoGuardProps {
  merchantLat: number;
  merchantLng: number;
  onVerified: (coords: { lat: number, lng: number }) => void;
}

export const GeoGuard: React.FC<GeoGuardProps> = ({ merchantLat, merchantLng, onVerified }) => {
  const [distance, setDistance] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [userCoords, setUserCoords] = useState<{lat: number, lng: number} | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      setError("El GPS es obligatorio para retirar.");
      return;
    }

    const watchId = navigator.geolocation.watchPosition((pos) => {
      const { latitude: lat1, longitude: lon1 } = pos.coords;
      setUserCoords({ lat: lat1, lng: lon1 });

      // Cálculo de Haversine para distancia en metros
      const R = 6371e3; 
      const φ1 = lat1 * Math.PI/180;
      const φ2 = merchantLat * Math.PI/180;
      const Δφ = (merchantLat-lat1) * Math.PI/180;
      const Δλ = (merchantLng-lon1) * Math.PI/180;

      const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
                Math.cos(φ1) * Math.cos(φ2) *
                Math.sin(Δλ/2) * Math.sin(Δλ/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
      const d = R * c; 

      setDistance(d);
      if (d <= 150) { // Margen de 150 metros
        onVerified({ lat: lat1, lng: lon1 });
      }
    }, (err) => {
      setError("Por favor activa tu ubicación para validar el retiro.");
    }, { enableHighAccuracy: true });

    return () => navigator.geolocation.clearWatch(watchId);
  }, [merchantLat, merchantLng, onVerified]);

  return (
    <div className={`p-6 rounded-[2rem] border-2 transition-all ${distance && distance <= 150 ? 'bg-green-50 border-green-200' : 'bg-orange-50 border-orange-200'}`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${distance && distance <= 150 ? 'bg-green-500 text-white' : 'bg-orange-500 text-white'}`}>
          {distance && distance <= 150 ? <ShieldCheck className="w-6 h-6" /> : <Navigation className="w-6 h-6 animate-pulse" />}
        </div>
        <div className="flex-1">
          <h4 className="font-black text-sm uppercase tracking-widest text-slate-900">Validación de Presencia</h4>
          <p className="text-[10px] font-bold text-slate-500">
            {error ? error : distance ? `Estás a ${Math.round(distance)}m del colmado.` : 'Calculando proximidad...'}
          </p>
        </div>
        {distance && distance <= 150 && (
          <CheckCircle2 className="text-green-600 w-6 h-6 animate-in zoom-in" />
        )}
      </div>
      {distance && distance > 150 && (
        <div className="mt-4 flex items-center gap-2 text-[9px] font-black text-orange-600 uppercase tracking-tighter">
          <ShieldAlert className="w-3 h-3" /> Debes estar en el comercio para habilitar el retiro.
        </div>
      )}
    </div>
  );
};

const ShieldCheck = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
