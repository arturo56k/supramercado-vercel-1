
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, ShoppingBag, Package, 
  Landmark, Smartphone, Settings, Bell,
  ArrowUpRight, Users, History, Store,
  Camera, Zap, PlusCircle, Volume2, Wifi, Cloud
} from 'lucide-react';
import { OrderManagement } from './OrderManagement';
import { MerchantInventory } from './MerchantInventory';
import { MerchantWallet } from './MerchantWallet';
import { MerchantSettings } from './MerchantSettings';
import { MerchantOnboarding } from './MerchantOnboarding';
import { MerchantStaffManager } from './MerchantStaffManager';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';
import { UserRole } from '../types';
import { hasPermission } from '../utils/permissions';

export const MerchantHub: React.FC = () => {
  // Simulamos el rol actual para propósitos de la demo. En producción vendría del Auth Context.
  const [currentRole, setCurrentRole] = useState<UserRole>(UserRole.MERCHANT_ADMIN);
  const [activeTab, setActiveTab] = useState<'TERMINAL' | 'INVENTORY' | 'WALLET' | 'SETTINGS' | 'ONBOARDING' | 'STAFF'>('TERMINAL');
  const { orders, merchants, cloudSync } = useOrders();
  const { notify } = useNotify();
  const merchant = merchants.find(m => m.id === 'm1') || merchants[0];
  
  const pendingOrders = orders.filter(o => o.merchantId === (merchant?.id || 'm1') && o.status === 'PENDING');
  const pendingCount = pendingOrders.length;

  useEffect(() => {
    if (pendingCount > 0) {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.volume = 0.5;
      audio.play().catch(() => {});
      notify("Nueva Orden", "Un cliente en NY acaba de enviar un pedido.", "INFO");
    }
  }, [pendingCount]);

  return (
    <div className="flex flex-col lg:flex-row gap-8 animate-in fade-in duration-500 pb-20">
      {/* Selector de Rol para Demo */}
      <div className="fixed top-4 right-32 z-[400] flex bg-slate-900 p-1 rounded-full border border-white/10 shadow-2xl">
         <button onClick={() => setCurrentRole(UserRole.MERCHANT_ADMIN)} className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${currentRole === UserRole.MERCHANT_ADMIN ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>Admin</button>
         <button onClick={() => setCurrentRole(UserRole.MERCHANT_EMPLOYEE)} className={`px-4 py-1.5 rounded-full text-[8px] font-black uppercase tracking-widest transition-all ${currentRole === UserRole.MERCHANT_EMPLOYEE ? 'bg-orange-600 text-white' : 'text-slate-400'}`}>Empleado</button>
      </div>

      {/* Mini Sidebar Táctil */}
      <div className="lg:w-24 flex lg:flex-col bg-slate-900 rounded-[2rem] p-4 gap-4 overflow-x-auto lg:overflow-visible scrollbar-hide border border-white/5 shadow-2xl">
        <TabIcon 
          active={activeTab === 'TERMINAL'} 
          onClick={() => setActiveTab('TERMINAL')} 
          icon={Smartphone} 
          label="POS" 
          badge={pendingCount} 
          pulse={pendingCount > 0}
        />
        
        {hasPermission(currentRole, 'edit_inventory') && (
          <TabIcon active={activeTab === 'INVENTORY'} onClick={() => setActiveTab('INVENTORY')} icon={Package} label="Stock" />
        )}
        
        {hasPermission(currentRole, 'view_wallet') && (
          <TabIcon active={activeTab === 'WALLET'} onClick={() => setActiveTab('WALLET')} icon={Landmark} label="Bolsa" />
        )}

        {hasPermission(currentRole, 'manage_staff') && (
          <TabIcon active={activeTab === 'STAFF'} onClick={() => setActiveTab('STAFF')} icon={Users} label="Equipo" />
        )}
        
        {hasPermission(currentRole, 'view_settings') && (
          <TabIcon active={activeTab === 'SETTINGS'} onClick={() => setActiveTab('SETTINGS')} icon={Settings} label="Perfil" />
        )}

        <div className="mt-auto hidden lg:block pt-4 border-t border-white/10">
          <TabIcon active={activeTab === 'ONBOARDING'} onClick={() => setActiveTab('ONBOARDING')} icon={PlusCircle} label="Sumar" />
        </div>
      </div>

      {/* Área de Trabajo Principal */}
      <div className="flex-1 space-y-8">
        {activeTab === 'TERMINAL' && (
          <div className="space-y-8">
            <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-[0.03] rotate-12">
                <Smartphone className="w-32 h-32" />
              </div>
              <div className="flex items-center gap-5 relative z-10">
                <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white shadow-xl">
                  <Store className="w-8 h-8" />
                </div>
                <div>
                  <h2 className="text-3xl font-black text-slate-900 tracking-tight">{merchant?.name || "Terminal Nueva"}</h2>
                  <div className="flex items-center gap-4 mt-1">
                    <div className="flex items-center gap-2">
                       <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Rol: {currentRole}</p>
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-50 border border-slate-100 rounded-full">
                       <Cloud className="w-3 h-3 text-blue-500" />
                       <span className="text-[9px] font-black text-slate-400">{cloudSync.latencyMs}ms Sync</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex bg-slate-50 p-2 rounded-2xl border relative z-10">
                 <div className="px-6 py-2 text-center border-r">
                    <p className="text-[10px] font-black text-slate-400 uppercase">Pendientes</p>
                    <p className={`text-2xl font-black transition-all ${pendingCount > 0 ? 'text-blue-700 scale-110' : 'text-slate-300'}`}>{pendingCount}</p>
                 </div>
                 <div className="px-6 py-2 text-center">
                    <p className="text-[10px] font-black text-slate-400 uppercase">Hoy</p>
                    <p className="text-2xl font-black text-slate-900">{orders.filter(o => o.status === 'REDEEMED').length}</p>
                 </div>
              </div>
            </div>
            <OrderManagement userRole={currentRole} />
          </div>
        )}

        {activeTab === 'INVENTORY' && <MerchantInventory />}
        {activeTab === 'WALLET' && <MerchantWallet />}
        {activeTab === 'SETTINGS' && <MerchantSettings />}
        {activeTab === 'STAFF' && <MerchantStaffManager />}
        {activeTab === 'ONBOARDING' && <MerchantOnboarding onComplete={() => setActiveTab('TERMINAL')} />}
      </div>
    </div>
  );
};

const TabIcon = ({ active, onClick, icon: Icon, label, badge, pulse }: any) => (
  <button 
    onClick={onClick}
    className={`relative flex flex-col items-center justify-center min-w-[75px] lg:min-w-0 lg:w-full aspect-square rounded-2xl transition-all ${active ? 'bg-blue-600 text-white shadow-2xl scale-110' : 'text-slate-500 hover:bg-white/10'}`}
  >
    <Icon className="w-6 h-6" />
    <span className="text-[8px] font-black uppercase mt-2 tracking-tighter">{label}</span>
    {badge > 0 && (
      <span className={`absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-black w-6 h-6 rounded-full flex items-center justify-center border-2 border-slate-900 ${pulse ? 'animate-bounce shadow-lg shadow-red-500/50' : ''}`}>
        {badge}
      </span>
    )}
    {pulse && (
      <span className="absolute inset-0 rounded-2xl border-2 border-blue-400 animate-ping opacity-20 pointer-events-none"></span>
    )}
  </button>
);
