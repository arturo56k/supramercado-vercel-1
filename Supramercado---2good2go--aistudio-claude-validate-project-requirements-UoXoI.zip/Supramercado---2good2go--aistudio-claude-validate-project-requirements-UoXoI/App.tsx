
import React, { useState, useEffect } from 'react';
import { WebContainer } from './apps/web/WebContainer';
import { RedemptionContainer } from './apps/redemption/RedemptionContainer';
import { PortalContainer } from './apps/portal/PortalContainer';
import { NetworkHUD } from './components/NetworkHUD';
import { NotificationProvider } from './components/NotificationSystem';
import { Globe, Smartphone, ShieldCheck, Zap } from 'lucide-react';

const App: React.FC = () => {
  // En un entorno Turborepo real, esto se manejaría mediante DNS o subdominios.
  // Aquí simulamos el switcher de aplicaciones para la demo.
  const [activeApp, setActiveApp] = useState<'WEB' | 'REDEEM' | 'PORTAL'>('WEB');

  return (
    <div className="font-sans antialiased">
      <NetworkHUD />
      
      {/* App Switcher (Solo para propósitos de navegación en el monolito actual) */}
      <div className="fixed bottom-6 right-6 z-[500] bg-slate-900 p-2 rounded-full border border-white/10 shadow-2xl flex items-center gap-2">
         <AppTab active={activeApp === 'WEB'} onClick={() => setActiveApp('WEB')} icon={Globe} label="WEB" />
         <AppTab active={activeApp === 'REDEEM'} onClick={() => setActiveApp('REDEEM')} icon={Smartphone} label="REDEEM" />
         <AppTab active={activeApp === 'PORTAL'} onClick={() => setActiveApp('PORTAL')} icon={ShieldCheck} label="PORTAL" />
      </div>

      <div className="animate-in fade-in duration-700">
        {activeApp === 'WEB' && <WebContainer />}
        {activeApp === 'REDEEM' && <RedemptionContainer />}
        {activeApp === 'PORTAL' && <PortalContainer />}
      </div>
    </div>
  );
};

const AppTab = ({ active, onClick, icon: Icon, label }: any) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-2 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${active ? 'bg-white text-slate-900 shadow-xl scale-110' : 'text-slate-500 hover:text-white'}`}
  >
    <Icon className="w-3 h-3" /> {label}
  </button>
);

export default App;
