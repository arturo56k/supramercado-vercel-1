/**
 * Next.js Instrumentation
 *
 * This file runs once when the Next.js server starts
 * Perfect for initializing logging and monitoring services
 */

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    // Only run on Node.js runtime (not Edge)
    console.log('🚀 Initializing Supramercado instrumentation...');

    // Initialize Axiom logging
    if (process.env.AXIOM_TOKEN && process.env.AXIOM_DATASET) {
      console.log('📊 Axiom logging enabled');
      console.log(`   Dataset: ${process.env.AXIOM_DATASET}`);
    } else {
      console.warn('⚠️  Axiom logging not configured');
      console.warn('   Logs will only be available in console');
    }

    // Log startup event
    const logger = await import('./src/lib/logger');
    await logger.info('Application started', {
      environment: process.env.NODE_ENV,
      nodeVersion: process.version,
      platform: process.platform,
    });

    await logger.flush();
  }
}

/**
 * This function is called on errors during instrumentation
 */
export async function onRequestError(
  err: Error,
  request: Request,
  context: {
    routerKind: 'Pages Router' | 'App Router';
    routePath: string;
    routeType: 'render' | 'route' | 'action' | 'middleware';
  }
) {
  const logger = await import('./src/lib/logger');

  await logger.error('Request error in Next.js', err, {
    url: request.url,
    method: request.method,
    routerKind: context.routerKind,
    routePath: context.routePath,
    routeType: context.routeType,
    userAgent: request.headers.get('user-agent'),
    ipAddress: request.headers.get('x-forwarded-for'),
  });

  await logger.flush();
}
