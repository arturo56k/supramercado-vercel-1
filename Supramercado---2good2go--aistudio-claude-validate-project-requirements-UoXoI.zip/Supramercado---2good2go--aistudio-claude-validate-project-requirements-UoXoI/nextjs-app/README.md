# 🛒 Supramercado - Next.js

Marketplace binacional USA → República Dominicana

## 🚀 Stack Tecnológico

- **Frontend**: Next.js 15 (App Router) + React 19
- **Styling**: Tailwind CSS
- **Database**: Supabase PostgreSQL + Prisma ORM
- **Auth**: Supabase Auth + Google OAuth
- **Payments**: Stripe Connect (Direct Charges)
- **Compliance**: OFAC SDN List Screening
- **Notifications**: Resend (Email) + Twilio (WhatsApp/SMS)
- **Cache**: Upstash Redis
- **Logging**: Axiom
- **Deployment**: Vercel

## 📋 Requisitos

- Node.js 20+
- npm 10+
- Cuenta en Supabase
- Cuenta en Stripe (modo test)

## 🛠️ Instalación

```bash
# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env.local
# Editar .env.local con tus credenciales

# Ejecutar migraciones de base de datos
npx prisma generate
npx prisma db push

# Iniciar servidor de desarrollo
npm run dev
```

## 📁 Estructura del Proyecto

```
supramercado-nextjs/
├── src/
│   ├── app/              # App Router (páginas)
│   ├── components/       # Componentes React
│   ├── lib/             # Utilidades y configuración
│   ├── hooks/           # React hooks personalizados
│   ├── types/           # Definiciones de TypeScript
│   └── utils/           # Funciones auxiliares
├── prisma/              # Schema de Prisma
├── public/              # Assets estáticos
└── scripts/             # Scripts de utilidad
```

## 🔐 Configuración

Ver `CREDENCIALES_PENDIENTES.md` para instrucciones detalladas de configuración.

## 📝 Scripts Disponibles

- `npm run dev` - Iniciar servidor de desarrollo
- `npm run build` - Build para producción
- `npm run start` - Iniciar servidor de producción
- `npm run lint` - Ejecutar linter

## 🌐 Deployment

Este proyecto está optimizado para desplegarse en Vercel.

```bash
vercel
```

## 📄 Licencia

Propietario

## 👥 Equipo

Desarrollado para 2good2go
