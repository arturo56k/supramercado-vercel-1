import type { Config } from "tailwindcss";

export default {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Brand colors
        primary: {
          DEFAULT: "#0E5FB2", // Azul Supramercado - trust, security
          50: "#E6F0FA",
          100: "#CCE1F5",
          200: "#99C3EB",
          300: "#66A5E1",
          400: "#3387D7",
          500: "#0E5FB2", // Main
          600: "#0B4C8F",
          700: "#08396B",
          800: "#062648",
          900: "#031324",
        },
        accent: {
          DEFAULT: "#F68606", // Naranja Supramercado - progress, highlights
          50: "#FEF2E6",
          100: "#FDE5CC",
          200: "#FBCB99",
          300: "#F9B166",
          400: "#F79733",
          500: "#F68606", // Main
          600: "#C56B05",
          700: "#945004",
          800: "#623503",
          900: "#311B01",
        },
        neutral: {
          background: "#F4F6F8", // Fondo principal
          text: "#4A4A4A",        // Texto secundario
          border: "#E5E7EB",      // Bordes/divisores
        },
        error: {
          DEFAULT: "#D92D20",      // Error crítico
          50: "#FEF2F2",
          100: "#FEE2E2",
          500: "#D92D20",
          900: "#7F1D1D",
        },
      },
      fontFamily: {
        // Poppins: Titulares, botones
        sans: ["Poppins", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Arial", "sans-serif"],
        // Inter: Párrafos, formularios, microcopy
        body: ["Inter", "system-ui", "-apple-system", "Segoe UI", "Roboto", "Arial", "sans-serif"],
      },
      borderRadius: {
        card: "12px",
        button: "14px",
        modal: "20px",
      },
      spacing: {
        // 8pt grid system
        "0.5": "4px",
        "1": "8px",
        "2": "16px",
        "3": "24px",
        "4": "32px",
        "5": "40px",
        "6": "48px",
        "8": "64px",
        "10": "80px",
        "12": "96px",
      },
      boxShadow: {
        soft: "0 2px 8px rgba(0, 0, 0, 0.08)",
        card: "0 4px 12px rgba(0, 0, 0, 0.12)",
      },
    },
  },
  plugins: [],
} satisfies Config;
