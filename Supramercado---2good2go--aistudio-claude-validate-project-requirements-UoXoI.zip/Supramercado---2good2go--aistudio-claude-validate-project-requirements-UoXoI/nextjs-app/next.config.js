/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable instrumentation for Axiom logging
  experimental: {
    instrumentationHook: true,
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          // DNS Prefetch Control
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on',
          },
          // Strict Transport Security (HSTS)
          // Force HTTPS for 2 years, include subdomains, enable preload
          {
            key: 'Strict-Transport-Security',
            value: 'max-age=63072000; includeSubDomains; preload',
          },
          // X-Frame-Options
          // Prevent clickjacking by disallowing embedding in iframes
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          // X-Content-Type-Options
          // Prevent MIME type sniffing
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          // X-XSS-Protection
          // Enable XSS filter in older browsers (deprecated but still useful)
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block',
          },
          // Referrer Policy
          // Control referrer information sent to other origins
          {
            key: 'Referrer-Policy',
            value: 'strict-origin-when-cross-origin',
          },
          // Permissions Policy (formerly Feature Policy)
          // Disable potentially dangerous browser features
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=(), interest-cohort=()',
          },
          // Content Security Policy (CSP)
          // Comprehensive protection against XSS and data injection attacks
          {
            key: 'Content-Security-Policy',
            value: [
              // Default: Only load resources from same origin
              "default-src 'self'",

              // Scripts: Allow self, Stripe, Vercel Analytics, and inline scripts with nonce
              "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://va.vercel-scripts.com",

              // Styles: Allow self, Google Fonts, and inline styles
              "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",

              // Images: Allow self, data URIs, Stripe, Supabase storage
              "img-src 'self' data: https: blob: https://*.stripe.com https://*.supabase.co",

              // Fonts: Allow self and Google Fonts
              "font-src 'self' https://fonts.gstatic.com",

              // Connect (AJAX/fetch): Allow self, APIs, Stripe, Supabase, Upstash
              "connect-src 'self' https://api.stripe.com https://*.supabase.co https://*.upstash.io https://vitals.vercel-insights.com",

              // Frames: Allow Stripe for payment elements
              "frame-src 'self' https://js.stripe.com https://hooks.stripe.com",

              // Objects: Disallow plugins (Flash, etc.)
              "object-src 'none'",

              // Base URI: Restrict to same origin
              "base-uri 'self'",

              // Form actions: Only submit to same origin
              "form-action 'self'",

              // Frame ancestors: Prevent embedding (redundant with X-Frame-Options but more flexible)
              "frame-ancestors 'none'",

              // Upgrade insecure requests to HTTPS
              'upgrade-insecure-requests',
            ].join('; '),
          },
        ],
      },
    ];
  },
};

module.exports = nextConfig;
