#!/bin/bash

# Script to adapt Vite components for Next.js

cd /home/user/supramercado-nextjs/src

# 1. Add 'use client' directive to all component files
for file in components/*.tsx; do
  if ! grep -q "'use client'" "$file"; then
    echo "'use client';" | cat - "$file" > temp && mv temp "$file"
  fi
done

# 2. Fix imports in all TypeScript files
find . -name "*.tsx" -o -name "*.ts" | while read file; do
  # Fix relative imports to types
  sed -i "s|from '\./types'|from '@/types'|g" "$file"
  sed -i "s|from './types'|from '@/types'|g" "$file"

  # Fix relative imports to components
  sed -i "s|from '\./components/|from '@/components/|g" "$file"
  sed -i "s|from './components/|from '@/components/|g" "$file"

  # Fix imports to constants
  sed -i "s|from '\./constants'|from '@/lib/constants'|g" "$file"
  sed -i "s|from './constants'|from '@/lib/constants'|g" "$file"

  # Fix imports to utils
  sed -i "s|from '\.\./utils/|from '@/utils/|g" "$file"
  sed -i "s|from '../utils/|from '@/utils/|g" "$file"
  sed -i "s|from '\./utils/|from '@/utils/|g" "$file"
  sed -i "s|from './utils/|from '@/utils/|g" "$file"
done

# 3. Fix constants.ts extension (it's already .ts)
if [ -f lib/constants.ts ]; then
  sed -i "s|from '\./types'|from '@/types'|g" lib/constants.ts
  sed -i "s|from './types'|from '@/types'|g" lib/constants.ts
fi

echo "✅ Components adapted for Next.js"
