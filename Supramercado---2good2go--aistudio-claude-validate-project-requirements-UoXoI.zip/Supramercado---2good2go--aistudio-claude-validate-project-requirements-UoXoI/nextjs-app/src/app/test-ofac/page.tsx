'use client';

import { useState } from 'react';

export default function TestOFACPage() {
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);

  const testNames = [
    { name: 'Juan Pérez', expected: 'clear' },
    { name: 'Pablo Escobar', expected: 'blocked' },
    { name: 'Maria Rodriguez', expected: 'clear' },
    { name: 'ESCOBAR Pablo', expected: 'blocked' },
  ];

  const handleScreen = async (testName?: string) => {
    const nameToScreen = testName || name;
    if (!nameToScreen) return;

    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/ofac/screen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: nameToScreen }),
      });

      const data = await response.json();
      setResult(data);
    } catch (error: any) {
      setResult({ error: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h1 className="text-4xl font-bold text-indigo-600 mb-2">
            🛡️ OFAC Screening Test
          </h1>
          <p className="text-gray-600 mb-8">
            Prueba el sistema de validación contra la lista SDN
          </p>

          <div className="space-y-6">
            {/* Manual Test */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4">Test Manual</h2>
              <div className="flex gap-4">
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Nombre a validar..."
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button
                  onClick={() => handleScreen()}
                  disabled={loading || !name}
                  className="bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? '⏳ Validando...' : '🔍 Validar'}
                </button>
              </div>
            </div>

            {/* Quick Tests */}
            <div className="bg-gray-50 rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4">Tests Rápidos</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {testNames.map((test, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleScreen(test.name)}
                    className="bg-white border border-gray-300 px-4 py-3 rounded-lg hover:bg-gray-50 transition-colors text-left"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{test.name}</span>
                      <span className={`text-xs px-2 py-1 rounded ${
                        test.expected === 'clear'
                          ? 'bg-green-100 text-green-800'
                          : 'bg-red-100 text-red-800'
                      }`}>
                        {test.expected}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Results */}
            {result && (
              <div className={`rounded-lg p-6 ${
                result.error
                  ? 'bg-red-50 border border-red-200'
                  : result.result === 'blocked'
                  ? 'bg-red-50 border border-red-200'
                  : result.result === 'potential_match'
                  ? 'bg-yellow-50 border border-yellow-200'
                  : 'bg-green-50 border border-green-200'
              }`}>
                <div className="flex items-start gap-4">
                  <div className="text-4xl">
                    {result.error
                      ? '❌'
                      : result.result === 'blocked'
                      ? '🚫'
                      : result.result === 'potential_match'
                      ? '⚠️'
                      : '✅'}
                  </div>
                  <div className="flex-1">
                    <h3 className={`text-xl font-bold mb-2 ${
                      result.error
                        ? 'text-red-800'
                        : result.result === 'blocked'
                        ? 'text-red-800'
                        : result.result === 'potential_match'
                        ? 'text-yellow-800'
                        : 'text-green-800'
                    }`}>
                      {result.error
                        ? 'Error'
                        : result.result === 'blocked'
                        ? 'BLOQUEADO'
                        : result.result === 'potential_match'
                        ? 'COINCIDENCIA POTENCIAL'
                        : 'APROBADO'}
                    </h3>
                    <p className={`mb-4 ${
                      result.error
                        ? 'text-red-700'
                        : result.result === 'blocked'
                        ? 'text-red-700'
                        : result.result === 'potential_match'
                        ? 'text-yellow-700'
                        : 'text-green-700'
                    }`}>
                      {result.message || result.error}
                    </p>

                    {result.matches && result.matches.length > 0 && (
                      <div className="bg-white rounded-lg p-4 space-y-2">
                        <h4 className="font-semibold text-gray-800">Coincidencias:</h4>
                        {result.matches.map((match: any, idx: number) => (
                          <div key={idx} className="border-l-4 border-gray-300 pl-4">
                            <p className="font-medium text-gray-900">{match.name}</p>
                            <div className="text-sm text-gray-600 space-y-1">
                              <p>Similitud: {match.similarity.toFixed(1)}%</p>
                              <p>Tipo: {match.type}</p>
                              <p>Programa: {match.program}</p>
                              <p>ID: {match.entryId}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h3 className="font-semibold text-blue-900 mb-2">ℹ️ Información</h3>
              <ul className="text-blue-800 text-sm space-y-1">
                <li>• La validación se hace contra la lista SDN de OFAC</li>
                <li>• Nombres bloqueados: No se puede procesar el pago</li>
                <li>• Coincidencias potenciales: Requieren revisión manual</li>
                <li>• La lista se actualiza semanalmente de forma automática</li>
                <li>• Threshold de similitud: 85%</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
