export default function AuthErrorPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-100">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md text-center">
        <div className="text-6xl mb-4">⚠️</div>
        <h1 className="text-3xl font-bold text-red-600 mb-4">
          Error de Autenticación
        </h1>
        <p className="text-gray-600 mb-6">
          Hubo un problema al iniciar sesión. Por favor, intenta nuevamente.
        </p>
        <a
          href="/login"
          className="inline-block bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors font-medium"
        >
          Volver a intentar
        </a>
      </div>
    </div>
  );
}
