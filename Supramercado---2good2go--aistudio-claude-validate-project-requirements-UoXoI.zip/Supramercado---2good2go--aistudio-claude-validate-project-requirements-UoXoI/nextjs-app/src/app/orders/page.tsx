import { Suspense } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

async function getOrders(userId: string) {
  try {
    const orders = await prisma.order.findMany({
      where: {
        buyerId: userId,
      },
      include: {
        merchant: {
          select: {
            name: true,
            logoUrl: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });
    return orders;
  } catch (error) {
    console.error("Error fetching orders:", error);
    return [];
  }
}

function getStatusColor(status: string) {
  const statusColors: Record<string, string> = {
    pending_payment: "bg-yellow-100 text-yellow-800",
    paid: "bg-blue-100 text-blue-800",
    ready_for_pickup: "bg-accent-100 text-accent-800",
    redeemed: "bg-green-100 text-green-800",
    cancelled: "bg-gray-100 text-gray-800",
    disputed: "bg-red-100 text-red-800",
    refunded: "bg-purple-100 text-purple-800",
  };
  return statusColors[status] || "bg-gray-100 text-gray-800";
}

function getStatusLabel(status: string) {
  const statusLabels: Record<string, string> = {
    pending_payment: "Pendiente de pago",
    paid: "Pagado",
    ready_for_pickup: "Listo para recoger",
    redeemed: "Entregado",
    cancelled: "Cancelado",
    disputed: "En disputa",
    refunded: "Reembolsado",
  };
  return statusLabels[status] || status;
}

async function OrdersList({ userId }: { userId: string }) {
  const orders = await getOrders(userId);

  if (orders.length === 0) {
    return (
      <div className="card text-center py-12">
        <div className="w-20 h-20 bg-neutral-background rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">📦</span>
        </div>
        <h3 className="text-xl font-semibold text-primary mb-2">
          No tienes órdenes todavía
        </h3>
        <p className="text-neutral-text font-body mb-6">
          Empieza a enviar amor a República Dominicana hoy mismo.
        </p>
        <Link href="/marketplace" className="btn-primary inline-block">
          Ver productos
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {orders.map((order) => {
        const items = JSON.parse(order.items as any);
        const itemCount = Array.isArray(items)
          ? items.reduce((sum: number, item: any) => sum + (item.quantity || 1), 0)
          : 0;

        return (
          <div key={order.id} className="card hover:shadow-xl transition-shadow">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-4">
              {/* Order Number & Date */}
              <div>
                <h3 className="text-lg font-semibold text-primary">
                  {order.orderNumber}
                </h3>
                <p className="text-sm text-neutral-text font-body">
                  {new Date(order.createdAt).toLocaleDateString("es-DO", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>

              {/* Status Badge */}
              <span
                className={`${getStatusColor(order.status)} px-3 py-1 rounded-full text-sm font-medium`}
              >
                {getStatusLabel(order.status)}
              </span>
            </div>

            {/* Order Details */}
            <div className="border-t border-neutral-border pt-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {/* Merchant */}
                <div>
                  <p className="text-xs text-neutral-text font-body mb-1">
                    Supermercado
                  </p>
                  <div className="flex items-center gap-2">
                    {order.merchant.logoUrl ? (
                      <img
                        src={order.merchant.logoUrl}
                        alt={order.merchant.name}
                        className="w-6 h-6 rounded object-cover"
                      />
                    ) : (
                      <span className="text-lg">🏪</span>
                    )}
                    <p className="font-medium text-primary">
                      {order.merchant.name}
                    </p>
                  </div>
                </div>

                {/* Beneficiary */}
                <div>
                  <p className="text-xs text-neutral-text font-body mb-1">
                    Beneficiario
                  </p>
                  <p className="font-medium text-primary">
                    {order.beneficiaryName}
                  </p>
                  <p className="text-sm text-neutral-text font-body">
                    {order.beneficiaryPhone}
                  </p>
                </div>

                {/* Total */}
                <div>
                  <p className="text-xs text-neutral-text font-body mb-1">
                    Total
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    ${Number(order.totalUsd).toFixed(2)}
                  </p>
                  <p className="text-xs text-neutral-text font-body">
                    {itemCount} {itemCount === 1 ? "producto" : "productos"}
                  </p>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 mt-6">
                <Link
                  href={`/order/${order.id}`}
                  className="btn-primary text-sm px-4 py-2 flex-1 sm:flex-none text-center"
                >
                  Ver detalles
                </Link>
                {order.magicLinkCode && (
                  <Link
                    href={`/magic/${order.magicLinkCode}`}
                    className="btn-secondary text-sm px-4 py-2 flex-1 sm:flex-none text-center"
                  >
                    Enlace mágico
                  </Link>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="card animate-pulse">
          <div className="h-6 bg-neutral-background rounded w-48 mb-2"></div>
          <div className="h-4 bg-neutral-background rounded w-32 mb-4"></div>
          <div className="h-24 bg-neutral-background rounded"></div>
        </div>
      ))}
    </div>
  );
}

export default async function OrdersPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login?redirect=/orders");
  }

  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header */}
      <header className="bg-white border-b border-neutral-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">Supramercado</span>
            </Link>
            <div className="flex items-center gap-4">
              <Link
                href="/marketplace"
                className="text-neutral-text hover:text-primary transition-colors font-body"
              >
                Marketplace
              </Link>
              <Link
                href="/dashboard"
                className="text-neutral-text hover:text-primary transition-colors font-body"
              >
                Mi cuenta
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Page Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Mis Órdenes
          </h1>
          <p className="text-neutral-text font-body">
            Historial completo de tus compras y envíos
          </p>
        </div>

        <Suspense fallback={<LoadingSkeleton />}>
          <OrdersList userId={user.id} />
        </Suspense>
      </div>
    </div>
  );
}
