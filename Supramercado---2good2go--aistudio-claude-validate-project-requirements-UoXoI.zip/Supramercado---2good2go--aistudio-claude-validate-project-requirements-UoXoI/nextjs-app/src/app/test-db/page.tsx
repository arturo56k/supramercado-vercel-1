import { createClient } from '@/lib/supabase/server';

export default async function TestDBPage() {
  const supabase = await createClient();

  // Test database connection by fetching merchants
  const { data: merchants, error } = await supabase
    .from('merchants')
    .select('*')
    .limit(5);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-emerald-800 mb-8">
          🧪 Test de Conexión a Supabase
        </h1>

        <div className="bg-white rounded-lg shadow-xl p-6 mb-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            Estado de la Conexión
          </h2>

          {error ? (
            <div className="bg-red-50 border-l-4 border-red-500 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <span className="text-2xl">❌</span>
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-red-800">Error de Conexión</h3>
                  <p className="text-red-700 mt-2">{error.message}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-green-50 border-l-4 border-green-500 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <span className="text-2xl">✅</span>
                </div>
                <div className="ml-3">
                  <h3 className="text-lg font-medium text-green-800">
                    Conexión Exitosa
                  </h3>
                  <p className="text-green-700 mt-2">
                    Base de datos conectada correctamente
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-xl p-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">
            Merchants en la Base de Datos
          </h2>

          {merchants && merchants.length > 0 ? (
            <div className="space-y-4">
              {merchants.map((merchant) => (
                <div
                  key={merchant.id}
                  className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">
                        {merchant.name}
                      </h3>
                      <p className="text-gray-600 text-sm mt-1">
                        {merchant.description}
                      </p>
                      <div className="mt-2 flex gap-2">
                        <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {merchant.country}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded ${
                          merchant.is_active
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}>
                          {merchant.is_active ? 'Activo' : 'Inactivo'}
                        </span>
                      </div>
                    </div>
                    <div className="text-right text-sm text-gray-500">
                      <p>ID: {merchant.id.substring(0, 8)}...</p>
                      <p>Slug: {merchant.slug}</p>
                    </div>
                  </div>
                </div>
              ))}

              <div className="mt-6 p-4 bg-emerald-50 rounded-lg">
                <p className="text-emerald-800 font-medium">
                  📊 Total de merchants: {merchants.length}
                </p>
              </div>
            </div>
          ) : (
            <p className="text-gray-500 text-center py-8">
              No se encontraron merchants en la base de datos
            </p>
          )}
        </div>

        <div className="mt-6 text-center">
          <a
            href="/"
            className="inline-block bg-emerald-600 text-white px-6 py-3 rounded-lg hover:bg-emerald-700 transition-colors"
          >
            ← Volver al Inicio
          </a>
        </div>
      </div>
    </div>
  );
}
