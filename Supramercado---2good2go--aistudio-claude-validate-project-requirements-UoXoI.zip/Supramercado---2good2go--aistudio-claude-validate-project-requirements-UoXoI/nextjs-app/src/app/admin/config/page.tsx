'use client';

import { useState, useEffect } from 'react';

interface ConfigKey {
  key: string;
  category: string;
  description: string;
  required: boolean;
  sensitive: boolean;
  isConfigured: boolean;
  isActive: boolean;
  createdAt: string | null;
  updatedAt: string | null;
}

const CATEGORIES = [
  { id: 'all', name: 'Todas', icon: '📋' },
  { id: 'stripe', name: 'Stripe', icon: '💳' },
  { id: 'resend', name: 'Resend', icon: '📧' },
  { id: 'twilio', name: 'Twilio', icon: '📱' },
  { id: 'gemini', name: 'Gemini', icon: '🤖' },
  { id: 'general', name: 'General', icon: '⚙️' },
];

export default function AdminConfigPage() {
  const [configs, setConfigs] = useState<ConfigKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [saving, setSaving] = useState(false);
  const [validation, setValidation] = useState<{ valid: boolean; missing: string[] } | null>(null);

  useEffect(() => {
    loadConfigs();
    validateConfigs();
  }, [selectedCategory]);

  const loadConfigs = async () => {
    try {
      setLoading(true);
      const params = selectedCategory !== 'all' ? `?category=${selectedCategory}` : '';
      const response = await fetch(`/api/admin/config${params}`);
      const data = await response.json();

      if (response.ok) {
        setConfigs(data.configs);
      } else {
        alert('Error al cargar configuraciones: ' + data.error);
      }
    } catch (error: any) {
      alert('Error: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const validateConfigs = async () => {
    try {
      const response = await fetch('/api/admin/config/validate');
      const data = await response.json();

      if (response.ok) {
        setValidation(data);
      }
    } catch (error) {
      console.error('Validation error:', error);
    }
  };

  const handleEdit = (key: string) => {
    setEditingKey(key);
    setEditValue('');
  };

  const handleSave = async (config: ConfigKey) => {
    if (!editValue.trim()) {
      alert('El valor no puede estar vacío');
      return;
    }

    try {
      setSaving(true);

      const response = await fetch('/api/admin/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: config.key,
          value: editValue,
          category: config.category,
          description: config.description,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        alert('✅ Configuración guardada exitosamente');
        setEditingKey(null);
        setEditValue('');
        loadConfigs();
        validateConfigs();
      } else {
        alert('❌ Error: ' + data.error);
      }
    } catch (error: any) {
      alert('Error: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (key: string) => {
    if (!confirm(`¿Estás seguro de eliminar la configuración ${key}?`)) {
      return;
    }

    try {
      const response = await fetch(`/api/admin/config/${key}`, {
        method: 'DELETE',
      });

      const data = await response.json();

      if (response.ok) {
        alert('✅ Configuración eliminada');
        loadConfigs();
        validateConfigs();
      } else {
        alert('❌ Error: ' + data.error);
      }
    } catch (error: any) {
      alert('Error: ' + error.message);
    }
  };

  const filteredConfigs = selectedCategory === 'all'
    ? configs
    : configs.filter((c) => c.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                ⚙️ Configuración del Sistema
              </h1>
              <p className="text-gray-600">
                Gestiona las claves API y configuraciones de forma segura
              </p>
            </div>
            {validation && (
              <div className={`px-6 py-3 rounded-lg text-center ${
                validation.valid
                  ? 'bg-green-100 border border-green-300'
                  : 'bg-red-100 border border-red-300'
              }`}>
                <p className={`font-semibold ${
                  validation.valid ? 'text-green-800' : 'text-red-800'
                }`}>
                  {validation.valid ? '✅ Configurado' : '⚠️ Incompleto'}
                </p>
                {!validation.valid && (
                  <p className="text-sm text-red-700 mt-1">
                    Faltan {validation.missing.length} configuraciones
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Categories */}
          <div className="flex gap-2 overflow-x-auto pb-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                  selectedCategory === cat.id
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {cat.icon} {cat.name}
              </button>
            ))}
          </div>
        </div>

        {/* Configurations List */}
        {loading ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="animate-spin text-6xl mb-4">⏳</div>
            <p className="text-gray-600">Cargando configuraciones...</p>
          </div>
        ) : filteredConfigs.length === 0 ? (
          <div className="bg-white rounded-2xl shadow-lg p-12 text-center">
            <div className="text-6xl mb-4">📭</div>
            <p className="text-gray-600">No hay configuraciones en esta categoría</p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredConfigs.map((config) => (
              <div
                key={config.key}
                className={`bg-white rounded-xl shadow-md p-6 border-2 ${
                  config.required && !config.isConfigured
                    ? 'border-red-300 bg-red-50'
                    : config.isConfigured
                    ? 'border-green-300'
                    : 'border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-bold text-gray-900">
                        {config.key}
                      </h3>
                      {config.required && (
                        <span className="px-2 py-1 bg-red-100 text-red-800 text-xs font-semibold rounded">
                          REQUERIDO
                        </span>
                      )}
                      {config.sensitive && (
                        <span className="px-2 py-1 bg-yellow-100 text-yellow-800 text-xs font-semibold rounded">
                          🔒 SENSIBLE
                        </span>
                      )}
                      {config.isConfigured ? (
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-semibold rounded">
                          ✅ CONFIGURADO
                        </span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-semibold rounded">
                          ⚠️ NO CONFIGURADO
                        </span>
                      )}
                    </div>

                    <p className="text-gray-600 mb-4">{config.description}</p>

                    {editingKey === config.key ? (
                      <div className="space-y-3">
                        <input
                          type={config.sensitive ? 'password' : 'text'}
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          placeholder={`Ingresa ${config.key}...`}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                          autoFocus
                        />
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleSave(config)}
                            disabled={saving}
                            className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {saving ? '⏳ Guardando...' : '💾 Guardar'}
                          </button>
                          <button
                            onClick={() => {
                              setEditingKey(null);
                              setEditValue('');
                            }}
                            className="bg-gray-200 text-gray-700 px-6 py-2 rounded-lg hover:bg-gray-300 transition-colors"
                          >
                            ❌ Cancelar
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleEdit(config.key)}
                          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          {config.isConfigured ? '✏️ Editar' : '➕ Configurar'}
                        </button>
                        {config.isConfigured && !config.required && (
                          <button
                            onClick={() => handleDelete(config.key)}
                            className="bg-red-600 text-white px-6 py-2 rounded-lg hover:bg-red-700 transition-colors"
                          >
                            🗑️ Eliminar
                          </button>
                        )}
                      </div>
                    )}

                    {config.isConfigured && config.updatedAt && (
                      <p className="text-sm text-gray-500 mt-3">
                        Última actualización: {new Date(config.updatedAt).toLocaleString('es-ES')}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Missing Configs Warning */}
        {validation && !validation.valid && (
          <div className="bg-red-50 border-2 border-red-300 rounded-xl p-6 mt-6">
            <h3 className="text-xl font-bold text-red-800 mb-3">
              ⚠️ Configuraciones Faltantes
            </h3>
            <p className="text-red-700 mb-4">
              Las siguientes configuraciones requeridas no están configuradas:
            </p>
            <ul className="list-disc list-inside space-y-1 text-red-700">
              {validation.missing.map((key) => (
                <li key={key} className="font-mono">{key}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Security Notice */}
        <div className="bg-blue-50 border-2 border-blue-300 rounded-xl p-6 mt-6">
          <h3 className="text-xl font-bold text-blue-800 mb-2">
            🔒 Seguridad
          </h3>
          <ul className="list-disc list-inside space-y-1 text-blue-700">
            <li>Todos los valores sensibles se almacenan encriptados con AES-256-GCM</li>
            <li>Solo usuarios con rol SAAS_ADMIN pueden acceder a esta página</li>
            <li>Las configuraciones se guardan en la base de datos, no en archivos</li>
            <li>Los valores sensibles nunca se muestran completos en la interfaz</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
