"use client";

import { useState, useEffect, Suspense } from "react";
import { Elements } from "@stripe/react-stripe-js";
import { getStripe } from "@/lib/stripe-client";
import CheckoutForm from "@/components/CheckoutForm";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";

const STEPS = [
  { id: 1, name: "Producto", icon: "🛒" },
  { id: 2, name: "Beneficiario", icon: "👨‍👩‍👧‍👦" },
  { id: 3, name: "Resumen", icon: "📋" },
  { id: 4, name: "Pago", icon: "💳" },
];

interface Product {
  id: string;
  name: string;
  description?: string;
  priceUsd: number;
  imageUrl?: string;
  merchantId: string;
  merchantName: string;
}

interface CartItem {
  product: Product;
  quantity: number;
}

function StepIndicator({ currentStep }: { currentStep: number }) {
  return (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        {STEPS.map((step, index) => (
          <div key={step.id} className="flex items-center flex-1">
            <div className="flex flex-col items-center">
              <div
                className={`
                  w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all
                  ${
                    currentStep === step.id
                      ? "bg-accent text-white scale-110"
                      : currentStep > step.id
                      ? "bg-primary text-white"
                      : "bg-neutral-background text-neutral-text"
                  }
                `}
              >
                <span className="text-2xl">{step.icon}</span>
              </div>
              <p
                className={`
                  text-xs mt-2 font-body
                  ${
                    currentStep === step.id
                      ? "text-accent font-medium"
                      : "text-neutral-text"
                  }
                `}
              >
                {step.name}
              </p>
            </div>
            {index < STEPS.length - 1 && (
              <div
                className={`
                  flex-1 h-1 mx-2 transition-all
                  ${
                    currentStep > step.id ? "bg-primary" : "bg-neutral-border"
                  }
                `}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function CheckoutContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const [currentStep, setCurrentStep] = useState(1);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Beneficiary form
  const [beneficiaryName, setBeneficiaryName] = useState("");
  const [beneficiaryPhone, setBeneficiaryPhone] = useState("");

  // Payment
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [orderNumber, setOrderNumber] = useState<string | null>(null);

  // Step 1: Load product
  useEffect(() => {
    async function loadProduct() {
      try {
        const productId = searchParams.get("productId");
        if (!productId) {
          setError("No se especificó un producto");
          setLoading(false);
          return;
        }

        const response = await fetch(`/api/products/${productId}`);
        if (!response.ok) {
          throw new Error("Producto no encontrado");
        }

        const product = await response.json();
        setCart([{ product, quantity: 1 }]);
        setLoading(false);
      } catch (err: any) {
        setError(err.message);
        setLoading(false);
      }
    }

    loadProduct();
  }, [searchParams]);

  const handleContinueToStep2 = () => {
    if (cart.length === 0) {
      alert("No hay productos en el carrito");
      return;
    }
    setCurrentStep(2);
  };

  const handleContinueToStep3 = () => {
    if (!beneficiaryName.trim()) {
      alert("Por favor ingresa el nombre del beneficiario");
      return;
    }
    if (!beneficiaryPhone.trim()) {
      alert("Por favor ingresa el teléfono del beneficiario");
      return;
    }
    setCurrentStep(3);
  };

  const handleContinueToStep4 = async () => {
    try {
      setLoading(true);

      const items = cart.map((item) => ({
        productId: item.product.id,
        name: item.product.name,
        price: Number(item.product.priceUsd),
        quantity: item.quantity,
      }));

      const response = await fetch("/api/stripe/create-payment-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          merchantId: cart[0].product.merchantId,
          items,
          beneficiaryName,
          beneficiaryPhone,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Error creando la orden");
      }

      setClientSecret(data.clientSecret);
      setOrderId(data.orderId);
      setOrderNumber(data.orderNumber);
      setCurrentStep(4);
      setLoading(false);
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  const getTotalUSD = () => {
    return cart.reduce(
      (sum, item) => sum + Number(item.product.priceUsd) * item.quantity,
      0
    );
  };

  if (loading && currentStep === 1) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-background">
        <div className="text-center">
          <div className="text-6xl mb-4">⏳</div>
          <p className="text-xl text-neutral-text font-body">
            Preparando checkout...
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-background">
        <div className="card max-w-md text-center">
          <div className="text-6xl mb-4">⚠️</div>
          <h1 className="text-2xl font-bold text-error mb-4">Error</h1>
          <p className="text-neutral-text font-body mb-6">{error}</p>
          <Link href="/marketplace" className="btn-primary inline-block">
            Volver al Marketplace
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header - sin menú ni links externos durante checkout */}
      <header className="bg-white border-b border-neutral-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">
                Supramercado
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <StepIndicator currentStep={currentStep} />

        {/* Step 1: Producto */}
        {currentStep === 1 && (
          <div className="card max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-primary mb-6">
              Producto Seleccionado
            </h2>
            {cart.map((item) => (
              <div key={item.product.id} className="flex gap-4 mb-6">
                <div className="w-24 h-24 bg-neutral-background rounded-lg flex-shrink-0 overflow-hidden">
                  {item.product.imageUrl ? (
                    <img
                      src={item.product.imageUrl}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <span className="text-3xl">🛒</span>
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-primary mb-1">
                    {item.product.name}
                  </h3>
                  <p className="text-neutral-text font-body text-sm mb-2">
                    {item.product.description}
                  </p>
                  <p className="text-2xl font-bold text-primary">
                    ${Number(item.product.priceUsd).toFixed(2)} USD
                  </p>
                </div>
              </div>
            ))}
            <div className="sticky-cta sm:relative sm:bottom-auto sm:border-0 sm:p-0">
              <button
                onClick={handleContinueToStep2}
                className="btn-primary w-full text-lg"
              >
                Continuar
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Beneficiario */}
        {currentStep === 2 && (
          <div className="card max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-primary mb-2">
              ¿Quién lo recibe?
            </h2>
            <p className="text-neutral-text font-body mb-6">
              Nombre y teléfono de tu familiar en RD. Ellos no hacen nada.
            </p>
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-primary mb-2">
                  Nombre completo del beneficiario
                </label>
                <input
                  type="text"
                  className="input"
                  placeholder="Ej: Juan Pérez"
                  value={beneficiaryName}
                  onChange={(e) => setBeneficiaryName(e.target.value)}
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-primary mb-2">
                  Teléfono (WhatsApp)
                </label>
                <input
                  type="tel"
                  className="input"
                  placeholder="+1 (809) 123-4567"
                  value={beneficiaryPhone}
                  onChange={(e) => setBeneficiaryPhone(e.target.value)}
                  inputMode="tel"
                />
              </div>
            </div>
            <div className="sticky-cta sm:relative sm:bottom-auto sm:border-0 sm:p-0 flex gap-3">
              <button
                onClick={() => setCurrentStep(1)}
                className="btn-secondary flex-1"
              >
                Atrás
              </button>
              <button
                onClick={handleContinueToStep3}
                className="btn-primary flex-1 text-lg"
              >
                Continuar
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Resumen */}
        {currentStep === 3 && (
          <div className="card max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-primary mb-6">
              Resumen de tu Compra
            </h2>

            {/* Products */}
            <div className="mb-6">
              <h3 className="font-semibold text-primary mb-3">Productos</h3>
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex justify-between items-center mb-2"
                >
                  <p className="text-neutral-text font-body">
                    {item.product.name} x{item.quantity}
                  </p>
                  <p className="font-medium text-primary">
                    ${(Number(item.product.priceUsd) * item.quantity).toFixed(2)}
                  </p>
                </div>
              ))}
            </div>

            {/* Beneficiary */}
            <div className="mb-6 p-4 bg-primary-50 rounded-lg">
              <h3 className="font-semibold text-primary mb-2">Beneficiario</h3>
              <p className="text-neutral-text font-body">
                <span className="font-medium">Nombre:</span> {beneficiaryName}
              </p>
              <p className="text-neutral-text font-body">
                <span className="font-medium">Teléfono:</span> {beneficiaryPhone}
              </p>
            </div>

            {/* Total */}
            <div className="border-t border-neutral-border pt-4 mb-6">
              <div className="flex justify-between items-center mb-2">
                <p className="text-neutral-text font-body">Subtotal</p>
                <p className="font-medium text-primary">
                  ${getTotalUSD().toFixed(2)}
                </p>
              </div>
              <div className="flex justify-between items-center mb-2">
                <p className="text-neutral-text font-body">
                  Comisión de plataforma (5%)
                </p>
                <p className="font-medium text-primary">
                  ${(getTotalUSD() * 0.05).toFixed(2)}
                </p>
              </div>
              <div className="flex justify-between items-center text-xl font-bold text-primary">
                <p>Total</p>
                <p>${getTotalUSD().toFixed(2)} USD</p>
              </div>
            </div>

            <div className="sticky-cta sm:relative sm:bottom-auto sm:border-0 sm:p-0 flex gap-3">
              <button
                onClick={() => setCurrentStep(2)}
                className="btn-secondary flex-1"
              >
                Atrás
              </button>
              <button
                onClick={handleContinueToStep4}
                className="btn-primary flex-1 text-lg"
                disabled={loading}
              >
                {loading ? "Procesando..." : "Confirmar compra y entregar en RD"}
              </button>
            </div>
          </div>
        )}

        {/* Step 4: Pago */}
        {currentStep === 4 && clientSecret && (
          <div className="card max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-primary mb-2">
              Pago Seguro
            </h2>
            <p className="text-neutral-text font-body mb-6">
              Completa tu pago con tarjeta de débito o crédito
            </p>

            <Elements
              stripe={getStripe()}
              options={{
                clientSecret,
                appearance: {
                  theme: "stripe",
                  variables: {
                    colorPrimary: "#0E5FB2",
                    colorBackground: "#ffffff",
                    colorText: "#1A1A1A",
                    colorDanger: "#D92D20",
                    fontFamily: "Inter, system-ui, sans-serif",
                    borderRadius: "14px",
                  },
                },
              }}
            >
              <CheckoutForm
                orderId={orderId!}
                orderNumber={orderNumber!}
                totalUSD={getTotalUSD()}
              />
            </Elements>

            <div className="mt-6 p-4 bg-neutral-background rounded-lg">
              <p className="text-xs text-neutral-text font-body text-center">
                El cargo aparecerá como <span className="font-medium">Supramercado</span> en tu estado de cuenta
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-neutral-background">
          <div className="text-2xl">Cargando...</div>
        </div>
      }
    >
      <CheckoutContent />
    </Suspense>
  );
}
