import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Supramercado - Envía amor a República Dominicana",
  description: "Marketplace binacional USA → RD. Compra productos frescos y envía a tus seres queridos.",
  keywords: ["remesas", "dominicana", "marketplace", "envios", "2good2go"],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
