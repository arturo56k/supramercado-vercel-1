import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/prisma";
import Link from "next/link";

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login?redirect=/dashboard");
  }

  // Get user data and stats
  const dbUser = await prisma.user.findUnique({
    where: { id: user.id },
  });

  const ordersCount = await prisma.order.count({
    where: { buyerId: user.id },
  });

  const totalSpent = await prisma.order.aggregate({
    where: {
      buyerId: user.id,
      status: { in: ["paid", "ready_for_pickup", "redeemed"] },
    },
    _sum: { totalUsd: true },
  });

  const beneficiariesCount = await prisma.beneficiary.count({
    where: { userId: user.id },
  });

  const handleSignOut = async () => {
    "use server";
    const supabase = await createClient();
    await supabase.auth.signOut();
    redirect("/");
  };

  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header */}
      <header className="bg-white border-b border-neutral-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">
                Supramercado
              </span>
            </Link>
            <div className="flex items-center gap-4">
              <span className="text-neutral-text font-body hidden sm:block">
                {user.email}
              </span>
              <form action={handleSignOut}>
                <button
                  type="submit"
                  className="text-neutral-text hover:text-error transition-colors font-body"
                >
                  Cerrar sesión
                </button>
              </form>
            </div>
          </div>
        </div>
      </header>

      {/* Page Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Section */}
        <div className="card mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            ¡Hola, {dbUser?.fullName || "amigo"}! 👋
          </h1>
          <p className="text-neutral-text font-body text-lg">
            Bienvenido a tu cuenta de Supramercado
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-8">
          <div className="card text-center">
            <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-3xl">📦</span>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              {ordersCount}
            </p>
            <p className="text-neutral-text font-body">
              {ordersCount === 1 ? "Orden enviada" : "Órdenes enviadas"}
            </p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-accent-50 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-3xl">💵</span>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              ${Number(totalSpent._sum.totalUsd || 0).toFixed(2)}
            </p>
            <p className="text-neutral-text font-body">Total enviado</p>
          </div>

          <div className="card text-center">
            <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-3xl">👨‍👩‍👧‍👦</span>
            </div>
            <p className="text-3xl font-bold text-primary mb-1">
              {beneficiariesCount}
            </p>
            <p className="text-neutral-text font-body">
              {beneficiariesCount === 1
                ? "Beneficiario"
                : "Beneficiarios"}
            </p>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-primary mb-4">
            Acciones rápidas
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <Link
              href="/marketplace"
              className="card hover:shadow-xl transition-shadow group cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-accent rounded-button flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">🛒</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-primary group-hover:text-accent transition-colors mb-1">
                    Hacer una compra
                  </h3>
                  <p className="text-neutral-text font-body text-sm">
                    Envía productos a RD hoy mismo
                  </p>
                </div>
              </div>
            </Link>

            <Link
              href="/orders"
              className="card hover:shadow-xl transition-shadow group cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary rounded-button flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">📦</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-primary group-hover:text-accent transition-colors mb-1">
                    Ver mis órdenes
                  </h3>
                  <p className="text-neutral-text font-body text-sm">
                    Historial completo de envíos
                  </p>
                </div>
              </div>
            </Link>

            <Link
              href="/profile"
              className="card hover:shadow-xl transition-shadow group cursor-pointer"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary rounded-button flex items-center justify-center flex-shrink-0">
                  <span className="text-2xl">⚙️</span>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-primary group-hover:text-accent transition-colors mb-1">
                    Mi perfil
                  </h3>
                  <p className="text-neutral-text font-body text-sm">
                    Gestionar beneficiarios y datos
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>

        {/* Account Info */}
        <div className="card">
          <h2 className="text-2xl font-bold text-primary mb-4">
            Información de cuenta
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div>
              <p className="text-xs text-neutral-text font-body mb-1">
                Email
              </p>
              <p className="font-medium text-primary">{user.email}</p>
            </div>
            <div>
              <p className="text-xs text-neutral-text font-body mb-1">
                Miembro desde
              </p>
              <p className="font-medium text-primary">
                {dbUser?.createdAt
                  ? new Date(dbUser.createdAt).toLocaleDateString("es-DO", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })
                  : "Hoy"}
              </p>
            </div>
            <div>
              <p className="text-xs text-neutral-text font-body mb-1">
                Tipo de cuenta
              </p>
              <p className="font-medium text-primary">
                {dbUser?.role === "CLIENT" ? "Cliente" : dbUser?.role}
              </p>
            </div>
            <div>
              <p className="text-xs text-neutral-text font-body mb-1">
                Nombre completo
              </p>
              <p className="font-medium text-primary">
                {dbUser?.fullName || "No configurado"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
