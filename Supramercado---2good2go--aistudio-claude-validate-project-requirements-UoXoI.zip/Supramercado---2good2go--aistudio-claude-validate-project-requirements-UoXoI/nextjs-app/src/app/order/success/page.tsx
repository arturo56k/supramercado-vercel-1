import { createClient } from '@/lib/supabase/server';
import { prisma } from '@/lib/prisma';
import { redirect } from 'next/navigation';

export default async function OrderSuccessPage({
  searchParams,
}: {
  searchParams: { orderId?: string };
}) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  const { orderId } = searchParams;

  if (!orderId) {
    redirect('/dashboard');
  }

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      merchant: {
        select: {
          name: true,
          logo_url: true,
        },
      },
    },
  });

  if (!order || order.buyerId !== user.id) {
    redirect('/dashboard');
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
        <div className="text-center mb-8">
          <div className="text-8xl mb-4">✅</div>
          <h1 className="text-4xl font-bold text-green-600 mb-2">
            ¡Pago Exitoso!
          </h1>
          <p className="text-gray-600 text-lg">
            Tu orden ha sido procesada correctamente
          </p>
        </div>

        <div className="bg-emerald-50 border-2 border-emerald-200 rounded-xl p-6 mb-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600 mb-1">Número de Orden</p>
              <p className="font-mono font-bold text-gray-900">{order.orderNumber}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Pagado</p>
              <p className="font-bold text-green-600 text-xl">
                ${order.totalUsd.toFixed(2)} USD
              </p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Comercio</p>
              <p className="font-semibold text-gray-900">{order.merchant.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Beneficiario</p>
              <p className="font-semibold text-gray-900">{order.beneficiaryName}</p>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <h3 className="font-semibold text-blue-900 mb-2">📧 Próximos pasos:</h3>
          <ul className="text-blue-800 text-sm space-y-1">
            <li>✉️ Recibirás un email de confirmación</li>
            <li>📱 El beneficiario recibirá un magic link por WhatsApp/SMS</li>
            <li>🏪 Podrá recoger la orden en el comercio</li>
            <li>📦 Código de retiro generado automáticamente</li>
          </ul>
        </div>

        <div className="flex gap-4">
          <a
            href="/dashboard"
            className="flex-1 bg-emerald-600 text-white py-3 px-6 rounded-lg hover:bg-emerald-700 transition-colors text-center font-medium"
          >
            Ver Dashboard
          </a>
          <a
            href="/marketplace"
            className="flex-1 bg-gray-200 text-gray-800 py-3 px-6 rounded-lg hover:bg-gray-300 transition-colors text-center font-medium"
          >
            Seguir Comprando
          </a>
        </div>
      </div>
    </div>
  );
}
