import Link from "next/link";

export default function Home() {
  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header */}
      <header className="bg-white border-b border-neutral-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">Supramercado</span>
            </div>
            <Link
              href="/login"
              className="text-primary font-medium hover:text-primary-600 transition-colors"
            >
              Iniciar sesión
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-50 to-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-primary mb-6">
              Compra desde EE.UU. y entrégalo hoy en{" "}
              <span className="text-accent">República Dominicana</span>
            </h1>
            <p className="text-xl sm:text-2xl text-neutral-text mb-8 font-body">
              Sin remesas. Sin llamadas. Tú pagas. Nosotros lo resolvemos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/marketplace"
                className="btn-primary text-lg px-8 py-4 text-center"
              >
                Comprar ahora
              </Link>
              <Link
                href="/dashboard"
                className="btn-secondary text-lg px-8 py-4 text-center"
              >
                Ver cómo funciona
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-center text-primary mb-12">
            Un puente emocional entre países
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="card text-center">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🛒</span>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-3">
                Compra en 2 minutos
              </h3>
              <p className="text-neutral-text font-body">
                Selecciona productos, elige el beneficiario y paga. Así de simple.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="card text-center">
              <div className="w-16 h-16 bg-accent-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">🚀</span>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-3">
                Entrega el mismo día
              </h3>
              <p className="text-neutral-text font-body">
                Tu familia recibe hoy mismo. Sin esperas ni complicaciones.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="card text-center">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">✨</span>
              </div>
              <h3 className="text-xl font-semibold text-primary mb-3">
                Confirmación inmediata
              </h3>
              <p className="text-neutral-text font-body">
                Recibe notificación al instante. Tu familia también.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="bg-white py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl sm:text-4xl font-bold text-center text-primary mb-12">
            ¿Cómo funciona?
          </h2>

          <div className="max-w-3xl mx-auto space-y-8">
            {/* Step 1 */}
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">1</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">
                  Elige el producto
                </h3>
                <p className="text-neutral-text font-body">
                  Navega nuestro catálogo de supermercados en República Dominicana.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">2</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">
                  Indica quién lo recibe
                </h3>
                <p className="text-neutral-text font-body">
                  Nombre y teléfono de tu familiar en RD. Ellos no hacen nada.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">3</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">
                  Paga desde EE.UU.
                </h3>
                <p className="text-neutral-text font-body">
                  Tarjeta de débito o crédito. Pago seguro con Stripe.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">4</span>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-primary mb-2">
                  Listo. Ya está en camino.
                </h3>
                <p className="text-neutral-text font-body">
                  Tu compra ya está en proceso. Tu familia la recibirá pronto.
                </p>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Link
              href="/marketplace"
              className="btn-primary text-lg px-8 py-4 inline-block"
            >
              Comprar ahora
            </Link>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="card max-w-3xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl font-bold text-primary mb-4">
              "Yo me encargo."
            </h2>
            <p className="text-neutral-text font-body text-lg mb-6">
              Supramercado es un puente emocional. No es una remesa. Es cuidado a distancia.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm text-neutral-text">
              <div className="flex items-center gap-2">
                <span className="text-primary">✓</span>
                <span>Pago seguro con Stripe</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-primary">✓</span>
                <span>Entrega garantizada</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-primary">✓</span>
                <span>Soporte 24/7</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-neutral-border py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center text-neutral-text text-sm font-body">
            <p>© 2024 Supramercado. Conectando corazones entre EE.UU. y República Dominicana.</p>
            <div className="mt-4 flex justify-center gap-6">
              <Link href="/terms" className="hover:text-primary transition-colors">
                Términos
              </Link>
              <Link href="/privacy" className="hover:text-primary transition-colors">
                Privacidad
              </Link>
              <Link href="/support" className="hover:text-primary transition-colors">
                Soporte
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
