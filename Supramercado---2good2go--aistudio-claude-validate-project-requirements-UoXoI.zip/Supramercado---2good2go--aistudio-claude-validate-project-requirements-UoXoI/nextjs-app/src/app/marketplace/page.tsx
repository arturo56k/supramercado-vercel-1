import { Suspense } from "react";
import Link from "next/link";
import { prisma } from "@/lib/prisma";

async function getProducts() {
  try {
    const products = await prisma.product.findMany({
      where: {
        isAvailable: true,
      },
      include: {
        merchant: {
          select: {
            name: true,
            logoUrl: true,
            isActive: true,
          },
        },
      },
      orderBy: {
        createdAt: "desc",
      },
    });
    return products;
  } catch (error) {
    console.error("Error fetching products:", error);
    return [];
  }
}

async function ProductGrid() {
  const products = await getProducts();

  if (products.length === 0) {
    return (
      <div className="card text-center py-12">
        <p className="text-neutral-text font-body text-lg">
          No hay productos disponibles en este momento.
        </p>
        <Link href="/" className="btn-primary mt-4 inline-block">
          Volver al inicio
        </Link>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <Link
          key={product.id}
          href={`/checkout?productId=${product.id}`}
          className="card hover:shadow-xl transition-shadow cursor-pointer group"
        >
          {/* Product Image */}
          <div className="relative aspect-square mb-4 bg-neutral-background rounded-lg overflow-hidden">
            {product.imageUrl ? (
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-6xl">🛒</span>
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-2">
            <h3 className="text-xl font-semibold text-primary group-hover:text-accent transition-colors">
              {product.name}
            </h3>

            {product.description && (
              <p className="text-neutral-text font-body text-sm line-clamp-2">
                {product.description}
              </p>
            )}

            {/* Merchant */}
            <div className="flex items-center gap-2 text-sm text-neutral-text">
              {product.merchant.logoUrl ? (
                <img
                  src={product.merchant.logoUrl}
                  alt={product.merchant.name}
                  className="w-5 h-5 rounded object-cover"
                />
              ) : (
                <span className="text-xs">🏪</span>
              )}
              <span className="font-body">{product.merchant.name}</span>
            </div>

            {/* Price & CTA */}
            <div className="flex items-center justify-between pt-4 border-t border-neutral-border">
              <div>
                <p className="text-2xl font-bold text-primary">
                  ${Number(product.priceUsd).toFixed(2)}
                </p>
                <p className="text-xs text-neutral-text font-body">USD</p>
              </div>
              <button className="btn-primary text-sm px-4 py-2">
                Comprar
              </button>
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="card animate-pulse">
          <div className="aspect-square bg-neutral-background rounded-lg mb-4"></div>
          <div className="h-6 bg-neutral-background rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-neutral-background rounded w-full mb-2"></div>
          <div className="h-4 bg-neutral-background rounded w-5/6"></div>
        </div>
      ))}
    </div>
  );
}

export default function MarketplacePage() {
  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header */}
      <header className="bg-white border-b border-neutral-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">Supramercado</span>
            </Link>
            <div className="flex items-center gap-4">
              <Link
                href="/orders"
                className="text-neutral-text hover:text-primary transition-colors font-body hidden sm:block"
              >
                Mis órdenes
              </Link>
              <Link
                href="/dashboard"
                className="text-neutral-text hover:text-primary transition-colors font-body hidden sm:block"
              >
                Mi cuenta
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary to-primary-600 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">
              ¿Qué quieres enviar hoy?
            </h1>
            <p className="text-lg sm:text-xl font-body opacity-90">
              Elige productos de supermercados en República Dominicana. Entrega el mismo día.
            </p>
          </div>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-primary mb-2">
              Productos Disponibles
            </h2>
            <p className="text-neutral-text font-body">
              Selecciona un producto para continuar con tu compra
            </p>
          </div>

          <Suspense fallback={<LoadingSkeleton />}>
            <ProductGrid />
          </Suspense>
        </div>
      </section>

      {/* Trust Banner */}
      <section className="bg-white py-8 border-t border-neutral-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-8 text-center">
            <div className="flex items-center gap-2">
              <span className="text-2xl">✓</span>
              <span className="text-neutral-text font-body">Pago seguro con Stripe</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">✓</span>
              <span className="text-neutral-text font-body">Entrega el mismo día</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">✓</span>
              <span className="text-neutral-text font-body">Confirmación inmediata</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
