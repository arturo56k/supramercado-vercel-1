import { NextResponse } from 'next/server';
import { headers } from 'next/headers';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/prisma';
import Stripe from 'stripe';
import {
  sendOrderConfirmationEmail,
  sendMagicLinkWhatsApp,
  generateMagicLink,
} from '@/lib/notifications';
import * as logger from '@/lib/logger';

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

export async function POST(request: Request) {
  const body = await request.text();
  const headersList = await headers();
  const signature = headersList.get('stripe-signature');

  if (!signature) {
    return NextResponse.json({ error: 'No signature' }, { status: 400 });
  }

  let event: Stripe.Event;

  try {
    event = stripe.webhooks.constructEvent(body, signature, webhookSecret);
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
  }

  // Handle the event
  try {
    switch (event.type) {
      case 'payment_intent.succeeded': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;

        // Update order status
        const updatedOrders = await prisma.order.updateMany({
          where: { stripePaymentIntentId: paymentIntent.id },
          data: {
            status: 'paid',
            paidAt: new Date(),
            stripeChargeId: paymentIntent.latest_charge as string,
            updatedAt: new Date(),
          },
        });

        // Fetch full order details for notifications
        const order = await prisma.order.findFirst({
          where: { stripePaymentIntentId: paymentIntent.id },
          include: {
            buyer: {
              select: {
                email: true,
                fullName: true,
              },
            },
            merchant: {
              select: {
                name: true,
                address: true,
              },
            },
          },
        });

        if (order && order.buyer.email) {
          try {
            // Parse items for email
            const items = typeof order.items === 'string'
              ? JSON.parse(order.items)
              : order.items;

            // Send confirmation email to buyer
            await sendOrderConfirmationEmail({
              to: order.buyer.email,
              orderNumber: order.orderNumber,
              totalUSD: order.totalUSD,
              beneficiaryName: order.beneficiaryName,
              merchantName: order.merchant.name,
              items: items.map((item: any) => ({
                name: item.name || item.productId,
                quantity: item.quantity || item.qty || 1,
                price: item.price || 0,
              })),
            });

            console.log(`✅ Confirmation email sent to ${order.buyer.email}`);

            // Generate magic link if not exists
            let magicLinkCode = order.magicLinkCode;
            if (!magicLinkCode) {
              magicLinkCode = `ML-${Date.now()}-${Math.random().toString(36).substring(7).toUpperCase()}`;

              await prisma.order.update({
                where: { id: order.id },
                data: {
                  magicLinkCode,
                  magicLinkExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
                  updatedAt: new Date(),
                },
              });
            }

            // Send magic link to beneficiary
            const magicLink = generateMagicLink(
              magicLinkCode,
              process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
            );

            await sendMagicLinkWhatsApp({
              to: order.beneficiaryPhone,
              beneficiaryName: order.beneficiaryName,
              magicLink,
              merchantName: order.merchant.name,
              orderNumber: order.orderNumber,
            });

            console.log(`✅ Magic link sent to ${order.beneficiaryPhone}`);

          } catch (notificationError: any) {
            console.error('Notification error (non-blocking):', notificationError);

            // Log notification failure
            await logger.logNotification(
              'whatsapp',
              order.beneficiaryPhone,
              false,
              order.id,
              {
                error: notificationError.message,
                orderNumber: order.orderNumber,
              }
            );
          }
        }

        // Log successful payment
        if (order) {
          await logger.logPayment('succeeded', order.id, Number(order.totalUSD), {
            paymentIntentId: paymentIntent.id,
            orderNumber: order.orderNumber,
            userId: order.buyerId,
            merchantId: order.merchantId,
          });
        }

        console.log('Payment succeeded:', paymentIntent.id);
        break;
      }

      case 'payment_intent.payment_failed': {
        const paymentIntent = event.data.object as Stripe.PaymentIntent;

        const failedOrder = await prisma.order.findFirst({
          where: { stripePaymentIntentId: paymentIntent.id },
        });

        await prisma.order.updateMany({
          where: { stripePaymentIntentId: paymentIntent.id },
          data: {
            status: 'cancelled',
            updatedAt: new Date(),
          },
        });

        // Log payment failure
        if (failedOrder) {
          await logger.logPayment('failed', failedOrder.id, Number(failedOrder.totalUSD), {
            paymentIntentId: paymentIntent.id,
            orderNumber: failedOrder.orderNumber,
            userId: failedOrder.buyerId,
            merchantId: failedOrder.merchantId,
            failureReason: paymentIntent.last_payment_error?.message,
          });
        }

        console.log('Payment failed:', paymentIntent.id);
        break;
      }

      case 'charge.refunded': {
        const charge = event.data.object as Stripe.Charge;

        await prisma.order.updateMany({
          where: { stripeChargeId: charge.id },
          data: {
            status: 'refunded',
            updatedAt: new Date(),
          },
        });

        console.log('Charge refunded:', charge.id);
        break;
      }

      case 'account.updated': {
        const account = event.data.object as Stripe.Account;

        // Update merchant Stripe account status
        await prisma.merchant.updateMany({
          where: { stripeAccountId: account.id },
          data: {
            stripeAccountStatus: account.charges_enabled ? 'active' : 'restricted',
            updatedAt: new Date(),
          },
        });

        console.log('Account updated:', account.id);
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    // Flush logs before returning
    await logger.flush();

    return NextResponse.json({ received: true });

  } catch (error: any) {
    console.error('Webhook handler error:', error);

    // Log webhook error
    await logger.error('Stripe webhook handler error', error, {
      eventType: event?.type,
    });

    await logger.flush();

    return NextResponse.json(
      { error: `Webhook handler failed: ${error.message}` },
      { status: 500 }
    );
  }
}
