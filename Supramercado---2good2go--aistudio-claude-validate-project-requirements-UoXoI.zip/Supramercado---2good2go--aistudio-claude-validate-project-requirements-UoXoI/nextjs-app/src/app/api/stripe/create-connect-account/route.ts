import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { stripe } from '@/lib/stripe';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if user is a merchant admin
    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { role: true, merchantId: true },
    });

    if (dbUser?.role !== 'MERCHANT_ADMIN' || !dbUser.merchantId) {
      return NextResponse.json({ error: 'Not authorized as merchant admin' }, { status: 403 });
    }

    const body = await request.json();
    const { returnUrl } = body;

    // Create Stripe Connect account
    const account = await stripe.accounts.create({
      type: 'express',
      country: 'DO', // Dominican Republic
      email: user.email,
      capabilities: {
        card_payments: { requested: true },
        transfers: { requested: true },
      },
    });

    // Update merchant with Stripe account ID
    await prisma.merchant.update({
      where: { id: dbUser.merchantId },
      data: {
        stripeAccountId: account.id,
        stripeAccountStatus: 'pending',
        updatedAt: new Date(),
      },
    });

    // Create account link for onboarding
    const accountLink = await stripe.accountLinks.create({
      account: account.id,
      refresh_url: `${returnUrl}?refresh=true`,
      return_url: `${returnUrl}?success=true`,
      type: 'account_onboarding',
    });

    return NextResponse.json({
      accountId: account.id,
      onboardingUrl: accountLink.url,
    });

  } catch (error: any) {
    console.error('Create connect account error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
