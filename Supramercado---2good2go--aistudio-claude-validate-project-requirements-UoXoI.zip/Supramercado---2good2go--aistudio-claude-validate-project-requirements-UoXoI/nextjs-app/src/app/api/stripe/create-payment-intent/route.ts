import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { createPaymentIntent, getOrCreateStripeCustomer, calculatePlatformFee } from '@/lib/stripe';
import { screenName, logScreening } from '@/lib/ofac';
import { prisma } from '@/lib/prisma';
import { checkRateLimit, createRateLimitResponse } from '@/lib/rate-limit';
import * as logger from '@/lib/logger';

export async function POST(request: Request) {
  try {
    // Check authentication first
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Apply strict rate limiting (10 requests per minute)
    const rateLimitResult = await checkRateLimit(request, 'strict', user.id);
    if (!rateLimitResult.success) {
      return createRateLimitResponse(rateLimitResult);
    }

    const body = await request.json();
    const { merchantId, items, beneficiaryName, beneficiaryPhone, beneficiaryId } = body;

    // OFAC Screening - CRITICAL COMPLIANCE CHECK
    const screeningResult = await screenName(beneficiaryName);

    if (screeningResult.result === 'blocked') {
      // Log the blocked attempt
      await logScreening(
        beneficiaryName,
        'blocked',
        undefined,
        { matches: screeningResult.matches }
      );

      // Log to Axiom
      await logger.logOfacScreening(beneficiaryName, 'blocked', undefined, {
        userId: user.id,
        merchantId,
        matches: screeningResult.matches,
      });

      await logger.logSecurity(
        `OFAC blocked: ${beneficiaryName}`,
        'high',
        user.id,
        {
          beneficiaryName,
          matches: screeningResult.matches,
        }
      );

      await logger.flush();

      return NextResponse.json(
        {
          error: 'OFAC_BLOCKED',
          message: 'Transaction cannot be processed due to compliance restrictions',
          details: 'The beneficiary name matches the OFAC SDN list',
        },
        { status: 403 }
      );
    }

    if (screeningResult.result === 'potential_match') {
      // Log potential match for manual review
      await logScreening(
        beneficiaryName,
        'potential_match',
        undefined,
        { matches: screeningResult.matches }
      );

      // For now, we'll allow but flag for review
      // In production, you might want to block and require manual approval
      console.warn('⚠️ OFAC potential match:', beneficiaryName, screeningResult.matches);
    }

    // Validate merchant
    const merchant = await prisma.merchant.findUnique({
      where: { id: merchantId },
      select: {
        id: true,
        stripeAccountId: true,
        commissionRate: true,
        isActive: true,
      },
    });

    if (!merchant || !merchant.isActive) {
      return NextResponse.json({ error: 'Merchant not found or inactive' }, { status: 404 });
    }

    if (!merchant.stripeAccountId) {
      return NextResponse.json({ error: 'Merchant has not connected Stripe' }, { status: 400 });
    }

    // Calculate totals
    const subtotalUSD = items.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);
    const platformFeeUSD = calculatePlatformFee(subtotalUSD);
    const totalUSD = subtotalUSD;

    // Get or create Stripe customer
    const customerId = await getOrCreateStripeCustomer(user.id, user.email!);

    // Generate unique order number
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substring(7).toUpperCase()}`;

    // Create order in database
    const order = await prisma.order.create({
      data: {
        orderNumber,
        buyerId: user.id,
        merchantId: merchant.id,
        beneficiaryId: beneficiaryId || null,
        beneficiaryName,
        beneficiaryPhone,
        items: JSON.stringify(items),
        subtotalUsd: subtotalUSD,
        platformFeeUsd: platformFeeUSD,
        totalUsd: totalUSD,
        status: 'pending_payment',
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    });

    // Create payment intent
    const paymentIntent = await createPaymentIntent({
      amount: Math.round(totalUSD * 100), // Convert to cents
      customerId,
      merchantStripeAccountId: merchant.stripeAccountId,
      orderId: order.id,
      platformFee: Math.round(platformFeeUSD * 100), // Convert to cents
    });

    // Update order with payment intent ID
    await prisma.order.update({
      where: { id: order.id },
      data: {
        stripePaymentIntentId: paymentIntent.id,
      },
    });

    // Log successful payment creation
    await logger.logPayment('created', order.id, totalUSD, {
      userId: user.id,
      merchantId,
      beneficiaryName,
      orderNumber: order.orderNumber,
      paymentIntentId: paymentIntent.id,
    });

    await logger.flush();

    const response = NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      orderId: order.id,
      orderNumber: order.orderNumber,
    });

    return createRateLimitResponse(rateLimitResult, response);

  } catch (error: any) {
    console.error('Create payment intent error:', error);

    // Log error to Axiom
    await logger.error('Failed to create payment intent', error, {
      url: request.url,
      method: request.method,
    });

    await logger.flush();

    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
