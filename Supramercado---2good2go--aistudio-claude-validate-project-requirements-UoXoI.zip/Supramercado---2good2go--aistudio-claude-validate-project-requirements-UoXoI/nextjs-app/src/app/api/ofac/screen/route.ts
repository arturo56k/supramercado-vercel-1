import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { screenName, logScreening } from '@/lib/ofac';

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const { name, orderId } = body;

    if (!name) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 });
    }

    // Screen the name
    const screeningResult = await screenName(name);

    // Log the screening
    await logScreening(
      name,
      screeningResult.result,
      orderId,
      screeningResult.matches.length > 0 ? { matches: screeningResult.matches } : null
    );

    // Return result
    return NextResponse.json({
      result: screeningResult.result,
      matches: screeningResult.matches,
      message:
        screeningResult.result === 'blocked'
          ? 'Transaction blocked: Name matches OFAC SDN list'
          : screeningResult.result === 'potential_match'
          ? 'Potential match found - Manual review required'
          : 'Clear - No matches found',
    });

  } catch (error: any) {
    console.error('OFAC screening error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
