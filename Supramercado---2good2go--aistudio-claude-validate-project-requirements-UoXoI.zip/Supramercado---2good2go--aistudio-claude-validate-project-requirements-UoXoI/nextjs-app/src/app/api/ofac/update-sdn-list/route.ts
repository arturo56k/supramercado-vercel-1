import { NextResponse } from 'next/server';
import { updateSDNList } from '@/lib/ofac';
import { headers } from 'next/headers';

export async function POST(request: Request) {
  try {
    // Verify cron secret to prevent unauthorized updates
    const headersList = await headers();
    const authHeader = headersList.get('authorization');

    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const result = await updateSDNList();

    return NextResponse.json({
      success: true,
      message: `SDN list updated successfully`,
      count: result.count,
      timestamp: new Date().toISOString(),
    });

  } catch (error: any) {
    console.error('Update SDN list error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to update SDN list' },
      { status: 500 }
    );
  }
}

export const dynamic = 'force-dynamic';
