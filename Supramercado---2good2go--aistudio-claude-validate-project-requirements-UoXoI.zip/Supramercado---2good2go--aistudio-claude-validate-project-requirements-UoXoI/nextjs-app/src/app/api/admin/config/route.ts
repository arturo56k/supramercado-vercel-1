import { NextResponse } from 'next/server';
import { requireAdmin, getCurrentUser } from '@/lib/auth-helpers';
import {
  listConfigs,
  setConfig,
  getAvailableConfigKeys,
  validateConfigValue,
  getConfig,
  maskValue,
  CONFIG_KEYS,
} from '@/lib/config';
import { checkRateLimit, createRateLimitResponse } from '@/lib/rate-limit';

/**
 * GET /api/admin/config
 * List all configuration keys with metadata
 */
export async function GET(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  // Apply admin rate limiting (200 requests per minute)
  const user = await getCurrentUser();
  const rateLimitResult = await checkRateLimit(request, 'admin', user?.id);
  if (!rateLimitResult.success) {
    return createRateLimitResponse(rateLimitResult);
  }

  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category') as any;

    // Get all configured values
    const configs = await listConfigs(category);

    // Get all available keys
    const availableKeys = getAvailableConfigKeys(category);

    // Merge them - show which keys are available but not configured
    const allKeys = availableKeys.map((availableKey) => {
      const configured = configs.find((c) => c.key === availableKey.key);

      return {
        key: availableKey.key,
        category: availableKey.category,
        description: availableKey.description,
        required: availableKey.required,
        sensitive: availableKey.sensitive,
        isConfigured: !!configured,
        isActive: configured?.isActive ?? false,
        createdAt: configured?.createdAt ?? null,
        updatedAt: configured?.updatedAt ?? null,
      };
    });

    const response = NextResponse.json({ configs: allKeys });
    return createRateLimitResponse(rateLimitResult, response);
  } catch (error: any) {
    console.error('List config error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to list configurations' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/admin/config
 * Create or update a configuration value
 */
export async function POST(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  // Apply admin rate limiting (200 requests per minute)
  const user = await getCurrentUser();
  const rateLimitResult = await checkRateLimit(request, 'admin', user?.id);
  if (!rateLimitResult.success) {
    return createRateLimitResponse(rateLimitResult);
  }

  try {
    const body = await request.json();
    const { key, value, category, description } = body;

    if (!key || !value) {
      return NextResponse.json(
        { error: 'Key and value are required' },
        { status: 400 }
      );
    }

    // Validate the value
    const validationError = validateConfigValue(key, value);
    if (validationError) {
      return NextResponse.json(
        { error: validationError },
        { status: 400 }
      );
    }

    // Set the configuration
    await setConfig(key, value, category, description);

    const response = NextResponse.json({
      success: true,
      message: `Configuration ${key} updated successfully`,
    });

    return createRateLimitResponse(rateLimitResult, response);
  } catch (error: any) {
    console.error('Set config error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to set configuration' },
      { status: 500 }
    );
  }
}
