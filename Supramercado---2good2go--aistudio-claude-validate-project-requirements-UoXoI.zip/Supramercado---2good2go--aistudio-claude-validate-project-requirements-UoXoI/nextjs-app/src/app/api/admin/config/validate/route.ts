import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth-helpers';
import { validateRequiredConfigs } from '@/lib/config';

/**
 * GET /api/admin/config/validate
 * Validate that all required configurations are set
 */
export async function GET(request: Request) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const validation = await validateRequiredConfigs();

    return NextResponse.json({
      valid: validation.valid,
      missing: validation.missing,
      message: validation.valid
        ? 'All required configurations are set'
        : `Missing ${validation.missing.length} required configuration(s)`,
    });
  } catch (error: any) {
    console.error('Validate config error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to validate configurations' },
      { status: 500 }
    );
  }
}
