import { NextResponse } from 'next/server';
import { requireAdmin } from '@/lib/auth-helpers';
import { getConfig, deleteConfig, maskValue, CONFIG_KEYS } from '@/lib/config';

/**
 * GET /api/admin/config/[key]
 * Get a specific configuration value (masked if sensitive)
 */
export async function GET(
  request: Request,
  { params }: { params: { key: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { key } = params;

    const value = await getConfig(key);
    const configMeta = CONFIG_KEYS[key];

    if (!value) {
      return NextResponse.json(
        { error: 'Configuration not found' },
        { status: 404 }
      );
    }

    // Mask sensitive values
    const displayValue = configMeta?.sensitive
      ? maskValue(value)
      : value;

    return NextResponse.json({
      key,
      value: displayValue,
      fullValue: configMeta?.sensitive ? undefined : value, // Only include full value if not sensitive
      masked: configMeta?.sensitive ?? false,
    });
  } catch (error: any) {
    console.error('Get config error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to get configuration' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/admin/config/[key]
 * Delete a configuration value
 */
export async function DELETE(
  request: Request,
  { params }: { params: { key: string } }
) {
  const authError = await requireAdmin();
  if (authError) return authError;

  try {
    const { key } = params;

    // Check if it's a required config
    const configMeta = CONFIG_KEYS[key];
    if (configMeta?.required) {
      return NextResponse.json(
        { error: 'Cannot delete required configuration' },
        { status: 400 }
      );
    }

    await deleteConfig(key);

    return NextResponse.json({
      success: true,
      message: `Configuration ${key} deleted successfully`,
    });
  } catch (error: any) {
    console.error('Delete config error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to delete configuration' },
      { status: 500 }
    );
  }
}
