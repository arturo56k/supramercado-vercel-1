import { updateSDNList } from '@/lib/ofac';
import { NextResponse } from 'next/server';

// This endpoint will be called by Vercel Cron Jobs
// Configure in vercel.json

export async function GET(request: Request) {
  try {
    // Verify cron secret
    const authHeader = request.headers.get('authorization');

    if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    console.log('🔄 Starting SDN list update...');

    const result = await updateSDNList();

    console.log(`✅ SDN list updated: ${result.count} entries`);

    return NextResponse.json({
      success: true,
      count: result.count,
      timestamp: new Date().toISOString(),
    });

  } catch (error: any) {
    console.error('❌ SDN update failed:', error);

    return NextResponse.json(
      {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}
