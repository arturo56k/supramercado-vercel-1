import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const product = await prisma.product.findUnique({
      where: {
        id: params.id,
        isAvailable: true,
      },
      include: {
        merchant: {
          select: {
            id: true,
            name: true,
            logoUrl: true,
            isActive: true,
          },
        },
      },
    });

    if (!product || !product.merchant.isActive) {
      return NextResponse.json(
        { error: "Producto no encontrado" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      id: product.id,
      name: product.name,
      description: product.description,
      priceUsd: Number(product.priceUsd),
      imageUrl: product.imageUrl,
      merchantId: product.merchant.id,
      merchantName: product.merchant.name,
    });
  } catch (error) {
    console.error("Error fetching product:", error);
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
