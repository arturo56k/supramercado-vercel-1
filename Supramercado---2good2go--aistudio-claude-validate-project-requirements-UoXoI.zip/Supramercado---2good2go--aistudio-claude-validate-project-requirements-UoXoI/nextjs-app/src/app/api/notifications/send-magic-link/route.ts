import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import { sendMagicLinkWhatsApp, generateMagicLink } from '@/lib/notifications';
import { prisma } from '@/lib/prisma';
import { checkRateLimit, createRateLimitResponse } from '@/lib/rate-limit';

export async function POST(request: Request) {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Apply moderate rate limiting (30 requests per minute)
    const rateLimitResult = await checkRateLimit(request, 'moderate', user.id);
    if (!rateLimitResult.success) {
      return createRateLimitResponse(rateLimitResult);
    }

    const body = await request.json();
    const { orderId } = body;

    // Get order details
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        merchant: {
          select: {
            name: true,
            address: true,
          },
        },
      },
    });

    if (!order) {
      return NextResponse.json({ error: 'Order not found' }, { status: 404 });
    }

    // Verify ownership
    if (order.buyerId !== user.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
    }

    // Generate magic link code if not exists
    let magicLinkCode = order.magicLinkCode;
    if (!magicLinkCode) {
      magicLinkCode = `ML-${Date.now()}-${Math.random().toString(36).substring(7).toUpperCase()}`;

      await prisma.order.update({
        where: { id: orderId },
        data: {
          magicLinkCode,
          magicLinkExpiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days
          updatedAt: new Date(),
        },
      });
    }

    const magicLink = generateMagicLink(magicLinkCode, process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000');

    // Send via WhatsApp/SMS
    const result = await sendMagicLinkWhatsApp({
      to: order.beneficiaryPhone,
      beneficiaryName: order.beneficiaryName,
      magicLink,
      merchantName: order.merchant.name,
      orderNumber: order.orderNumber,
    });

    const response = NextResponse.json({
      success: result.success,
      method: result.method || result.reason,
      magicLink: process.env.NODE_ENV === 'development' ? magicLink : undefined,
    });

    return createRateLimitResponse(rateLimitResult, response);

  } catch (error: any) {
    console.error('Send magic link error:', error);
    return NextResponse.json(
      { error: error.message || 'Internal server error' },
      { status: 500 }
    );
  }
}
