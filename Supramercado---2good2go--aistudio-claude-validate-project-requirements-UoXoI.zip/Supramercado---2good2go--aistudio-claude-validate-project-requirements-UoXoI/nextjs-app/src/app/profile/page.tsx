import { Suspense } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";

async function getBeneficiaries(userId: string) {
  try {
    const beneficiaries = await prisma.beneficiary.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
    });
    return beneficiaries;
  } catch (error) {
    console.error("Error fetching beneficiaries:", error);
    return [];
  }
}

async function BeneficiariesList({ userId }: { userId: string }) {
  const beneficiaries = await getBeneficiaries(userId);

  if (beneficiaries.length === 0) {
    return (
      <div className="card text-center py-8">
        <p className="text-neutral-text font-body">
          No has añadido beneficiarios todavía.
        </p>
        <p className="text-sm text-neutral-text font-body mt-2">
          Añade los datos de tus familiares para enviarles productos más rápido.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {beneficiaries.map((beneficiary) => (
        <div
          key={beneficiary.id}
          className="card hover:shadow-xl transition-shadow"
        >
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-primary mb-1">
                {beneficiary.name}
              </h3>
              <p className="text-neutral-text font-body text-sm mb-2">
                📱 {beneficiary.phone}
              </p>
              {beneficiary.relationship && (
                <span className="inline-block bg-primary-50 text-primary px-3 py-1 rounded-full text-xs font-medium">
                  {beneficiary.relationship}
                </span>
              )}
            </div>
            <div className="flex gap-2">
              <button className="text-primary hover:text-accent transition-colors text-sm font-body">
                Editar
              </button>
              <button className="text-neutral-text hover:text-error transition-colors text-sm font-body">
                Eliminar
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function LoadingSkeleton() {
  return (
    <div className="space-y-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="card animate-pulse">
          <div className="h-6 bg-neutral-background rounded w-48 mb-2"></div>
          <div className="h-4 bg-neutral-background rounded w-32"></div>
        </div>
      ))}
    </div>
  );
}

export default async function ProfilePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login?redirect=/profile");
  }

  const dbUser = await prisma.user.findUnique({
    where: { id: user.id },
  });

  return (
    <div className="min-h-screen bg-neutral-background">
      {/* Header */}
      <header className="bg-white border-b border-neutral-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-gradient-to-r from-primary to-accent rounded-lg"></div>
              <span className="text-2xl font-bold text-primary">
                Supramercado
              </span>
            </Link>
            <div className="flex items-center gap-4">
              <Link
                href="/marketplace"
                className="text-neutral-text hover:text-primary transition-colors font-body hidden sm:block"
              >
                Marketplace
              </Link>
              <Link
                href="/dashboard"
                className="text-neutral-text hover:text-primary transition-colors font-body"
              >
                Dashboard
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Page Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold text-primary mb-2">
            Mi Perfil
          </h1>
          <p className="text-neutral-text font-body">
            Gestiona tu información personal y beneficiarios
          </p>
        </div>

        <div className="space-y-8">
          {/* Personal Information */}
          <section>
            <h2 className="text-2xl font-bold text-primary mb-4">
              Información Personal
            </h2>
            <div className="card">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs text-neutral-text font-body mb-2">
                    Nombre completo
                  </label>
                  <input
                    type="text"
                    className="input"
                    placeholder="Tu nombre completo"
                    defaultValue={dbUser?.fullName || ""}
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-xs text-neutral-text font-body mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    className="input"
                    value={user.email || ""}
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-xs text-neutral-text font-body mb-2">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    className="input"
                    placeholder="+1 (123) 456-7890"
                    defaultValue={dbUser?.phone || ""}
                    disabled
                  />
                </div>
                <div>
                  <label className="block text-xs text-neutral-text font-body mb-2">
                    Tipo de cuenta
                  </label>
                  <input
                    type="text"
                    className="input"
                    value={dbUser?.role === "CLIENT" ? "Cliente" : dbUser?.role || ""}
                    disabled
                  />
                </div>
              </div>
              <div className="mt-6 flex gap-3">
                <button className="btn-primary text-sm px-4 py-2" disabled>
                  Guardar cambios
                </button>
                <button className="btn-secondary text-sm px-4 py-2" disabled>
                  Cambiar contraseña
                </button>
              </div>
              <p className="text-xs text-neutral-text font-body mt-4">
                * La edición de perfil estará disponible próximamente
              </p>
            </div>
          </section>

          {/* Beneficiaries */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-primary">
                Mis Beneficiarios
              </h2>
              <button className="btn-accent text-sm px-4 py-2" disabled>
                + Añadir beneficiario
              </button>
            </div>
            <Suspense fallback={<LoadingSkeleton />}>
              <BeneficiariesList userId={user.id} />
            </Suspense>
            <p className="text-xs text-neutral-text font-body mt-4">
              * La gestión de beneficiarios se hará durante el checkout
            </p>
          </section>

          {/* Payment Methods */}
          <section>
            <h2 className="text-2xl font-bold text-primary mb-4">
              Métodos de Pago
            </h2>
            <div className="card text-center py-8">
              <div className="w-16 h-16 bg-primary-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-3xl">💳</span>
              </div>
              <h3 className="text-lg font-semibold text-primary mb-2">
                Pago seguro con Stripe
              </h3>
              <p className="text-neutral-text font-body max-w-md mx-auto">
                Tus métodos de pago se gestionan de forma segura durante el
                proceso de compra. Nunca almacenamos información de tarjetas.
              </p>
            </div>
          </section>

          {/* Danger Zone */}
          <section>
            <h2 className="text-2xl font-bold text-error mb-4">Zona Peligrosa</h2>
            <div className="card border-2 border-error-100">
              <h3 className="text-lg font-semibold text-error mb-2">
                Eliminar cuenta
              </h3>
              <p className="text-neutral-text font-body text-sm mb-4">
                Esta acción es permanente y no se puede deshacer. Se eliminarán
                todos tus datos, órdenes y beneficiarios.
              </p>
              <button
                className="bg-error text-white font-medium px-4 py-2 rounded-button hover:bg-error-600 transition-colors"
                disabled
              >
                Eliminar mi cuenta
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
