import { prisma } from '@/lib/prisma';
import { redirect } from 'next/navigation';

export default async function MagicLinkPage({
  params,
}: {
  params: { code: string };
}) {
  const { code } = params;

  // Find order by magic link code
  const order = await prisma.order.findUnique({
    where: { magicLinkCode: code },
    include: {
      merchant: {
        select: {
          name: true,
          address: true,
          phone: true,
          logoUrl: true,
        },
      },
    },
  });

  if (!order) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md text-center">
          <div className="text-6xl mb-4">❌</div>
          <h1 className="text-2xl font-bold text-red-600 mb-4">Link Inválido</h1>
          <p className="text-gray-600">
            Este link mágico no existe o ha expirado.
          </p>
        </div>
      </div>
    );
  }

  // Check if expired
  if (order.magicLinkExpiresAt && new Date() > order.magicLinkExpiresAt) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md text-center">
          <div className="text-6xl mb-4">⏰</div>
          <h1 className="text-2xl font-bold text-orange-600 mb-4">Link Expirado</h1>
          <p className="text-gray-600 mb-6">
            Este link mágico ha expirado. Por favor contacta al remitente.
          </p>
        </div>
      </div>
    );
  }

  const items = typeof order.items === 'string' ? JSON.parse(order.items) : order.items;
  const merchantAddress = typeof order.merchant.address === 'string'
    ? JSON.parse(order.merchant.address)
    : order.merchant.address;

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-teal-100 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-t-2xl shadow-2xl p-8 text-center">
          <div className="text-6xl mb-4">🎁</div>
          <h1 className="text-3xl font-bold text-emerald-600 mb-2">
            ¡Te han enviado una orden!
          </h1>
          <p className="text-gray-600 text-lg">
            Desde Estados Unidos con amor 💚
          </p>
        </div>

        {/* Beneficiary Info */}
        <div className="bg-white border-x border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">
            👤 Para: {order.beneficiaryName}
          </h2>
          <div className="bg-emerald-50 border-2 border-emerald-200 rounded-lg p-4">
            <p className="text-sm text-gray-600 mb-1">Número de Orden</p>
            <p className="font-mono font-bold text-lg text-gray-900">{order.orderNumber}</p>
          </div>
        </div>

        {/* Status */}
        <div className="bg-white border-x border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center text-2xl ${
              order.status === 'paid' ? 'bg-blue-100' :
              order.status === 'ready_for_pickup' ? 'bg-green-100' :
              order.status === 'redeemed' ? 'bg-gray-100' :
              'bg-yellow-100'
            }`}>
              {order.status === 'paid' && '💳'}
              {order.status === 'ready_for_pickup' && '✅'}
              {order.status === 'redeemed' && '🎉'}
            </div>
            <div>
              <p className="font-semibold text-gray-800">
                {order.status === 'paid' && 'Pagado - Preparando orden'}
                {order.status === 'ready_for_pickup' && '¡Lista para recoger!'}
                {order.status === 'redeemed' && 'Orden entregada'}
                {!['paid', 'ready_for_pickup', 'redeemed'].includes(order.status) && 'Procesando'}
              </p>
              <p className="text-sm text-gray-600">
                {order.paidAt ? `Pagado el ${new Date(order.paidAt).toLocaleDateString('es-ES')}` : 'Esperando confirmación'}
              </p>
            </div>
          </div>
        </div>

        {/* Pickup Code */}
        {order.pickupCode && (
          <div className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white p-8 border-x border-emerald-600">
            <p className="text-center text-sm mb-2 opacity-90">Código de Retiro</p>
            <p className="text-center text-5xl font-bold tracking-wider font-mono">
              {order.pickupCode}
            </p>
            <p className="text-center text-sm mt-2 opacity-90">
              Presenta este código al recoger
            </p>
          </div>
        )}

        {/* Products */}
        <div className="bg-white border-x border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">🛍️ Productos</h3>
          <div className="space-y-3">
            {items.map((item: any, idx: number) => (
              <div key={idx} className="flex justify-between items-center py-3 border-b border-gray-200 last:border-0">
                <div>
                  <p className="font-medium text-gray-900">{item.name || item.productId}</p>
                  <p className="text-sm text-gray-600">Cantidad: {item.quantity || item.qty}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Merchant Info */}
        <div className="bg-white border-x border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">🏪 Dónde recoger</h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <p className="font-semibold text-gray-900 mb-2">{order.merchant.name}</p>
            {merchantAddress && (
              <p className="text-gray-600 text-sm mb-2">
                📍 {merchantAddress.street || ''} {merchantAddress.city || ''} {merchantAddress.state || ''}
              </p>
            )}
            {order.merchant.phone && (
              <p className="text-gray-600 text-sm">
                📞 {order.merchant.phone}
              </p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-white rounded-b-2xl shadow-2xl p-6 text-center">
          <p className="text-gray-600 text-sm mb-4">
            ¿Preguntas? Contacta al comercio directamente
          </p>
          <p className="text-xs text-gray-500">
            Powered by Supramercado 🛒
          </p>
        </div>
      </div>
    </div>
  );
}
