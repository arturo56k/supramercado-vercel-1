
import Papa from 'papaparse';

export interface CSVRow {
  name: string;
  description: string;
  basePriceDOP: number;
  category: string;
  stock: number;
  image: string;
}

export interface ParseResult {
  data: CSVRow[];
  errors: string[];
}

export const parseMerchantCSV = (file: File): Promise<ParseResult> => {
  return new Promise((resolve) => {
    const errors: string[] = [];
    
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const validatedData: CSVRow[] = [];
        
        results.data.forEach((row: any, index: number) => {
          const rowNum = index + 2; // +1 for header, +1 for 0-indexing
          
          // Required fields validation
          if (!row.name) {
            errors.push(`Fila ${rowNum}: El campo 'name' es obligatorio.`);
            return;
          }
          
          const price = parseFloat(row.basePriceDOP);
          if (isNaN(price) || price <= 0) {
            errors.push(`Fila ${rowNum}: 'basePriceDOP' debe ser un número mayor a 0.`);
            return;
          }
          
          const stock = parseInt(row.stock);
          if (isNaN(stock) || stock < 0) {
            errors.push(`Fila ${rowNum}: 'stock' debe ser un número entero no negativo.`);
            return;
          }

          validatedData.push({
            name: row.name,
            description: row.description || '',
            basePriceDOP: price,
            category: row.category || 'General',
            stock: stock,
            image: row.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400'
          });
        });
        
        resolve({ data: validatedData, errors });
      },
      error: (error) => {
        resolve({ data: [], errors: [`Error crítico al leer el archivo: ${error.message}`] });
      }
    });
  });
};
