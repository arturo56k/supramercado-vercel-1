
import { UserRole } from '../types';

export type Action = 
  | 'view_wallet' 
  | 'edit_inventory' 
  | 'redeem_order' 
  | 'view_settings' 
  | 'manage_staff'
  | 'generate_invoice'
  | 'view_payouts'
  | 'manage_all_branches';

const PERMISSIONS: Record<UserRole, Action[]> = {
  [UserRole.SAAS_ADMIN]: [
    'view_wallet', 'edit_inventory', 'redeem_order', 'view_settings', 
    'manage_staff', 'generate_invoice', 'view_payouts', 'manage_all_branches'
  ],
  [UserRole.MERCHANT_ADMIN]: [
    'view_wallet', 'edit_inventory', 'redeem_order', 'view_settings', 
    'manage_staff', 'generate_invoice', 'view_payouts', 'manage_all_branches'
  ],
  [UserRole.MERCHANT_BRANCH_ADMIN]: [
    'edit_inventory', 'redeem_order', 'generate_invoice'
  ],
  [UserRole.MERCHANT_EMPLOYEE]: [
    'redeem_order'
  ],
  [UserRole.CLIENT]: [],
  [UserRole.BENEFICIARY]: ['redeem_order'],
  [UserRole.SAAS_SUPPORT]: ['redeem_order', 'generate_invoice'],
};

export const hasPermission = (role: UserRole, action: Action): boolean => {
  return PERMISSIONS[role]?.includes(action) || false;
};
