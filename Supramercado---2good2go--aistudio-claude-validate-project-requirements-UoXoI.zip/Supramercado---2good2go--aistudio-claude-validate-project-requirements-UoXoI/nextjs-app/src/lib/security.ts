import crypto from 'crypto';

/**
 * Security Helpers
 *
 * Utilities for managing Content Security Policy, nonces, and other security features
 */

/**
 * Generate a cryptographically secure nonce for CSP
 *
 * Usage in Server Component:
 * ```tsx
 * const nonce = generateNonce();
 * return (
 *   <html>
 *     <head>
 *       <meta httpEquiv="Content-Security-Policy" content={getCSPWithNonce(nonce)} />
 *     </head>
 *     <body>
 *       <script nonce={nonce}>console.log('Safe!')</script>
 *     </body>
 *   </html>
 * );
 * ```
 */
export function generateNonce(): string {
  return crypto.randomBytes(16).toString('base64');
}

/**
 * Get Content Security Policy with nonce
 *
 * @param nonce - The nonce to include in script-src and style-src
 * @returns CSP header value with nonce
 */
export function getCSPWithNonce(nonce: string): string {
  return [
    "default-src 'self'",
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic' https://js.stripe.com https://va.vercel-scripts.com`,
    `style-src 'self' 'nonce-${nonce}' https://fonts.googleapis.com`,
    "img-src 'self' data: https: blob: https://*.stripe.com https://*.supabase.co",
    "font-src 'self' https://fonts.gstatic.com",
    "connect-src 'self' https://api.stripe.com https://*.supabase.co https://*.upstash.io https://vitals.vercel-insights.com",
    "frame-src 'self' https://js.stripe.com https://hooks.stripe.com",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    'upgrade-insecure-requests',
  ].join('; ');
}

/**
 * Sanitize user input to prevent XSS
 *
 * Basic HTML sanitization - for production, consider using a library like DOMPurify
 */
export function sanitizeHTML(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

/**
 * Validate and sanitize URL to prevent open redirect vulnerabilities
 *
 * @param url - The URL to validate
 * @param allowedDomains - List of allowed domains (optional)
 * @returns Sanitized URL or null if invalid
 */
export function sanitizeURL(
  url: string,
  allowedDomains: string[] = []
): string | null {
  try {
    const parsedURL = new URL(url, process.env.NEXT_PUBLIC_APP_URL);

    // Only allow https and http protocols
    if (!['http:', 'https:'].includes(parsedURL.protocol)) {
      return null;
    }

    // If allowed domains specified, check if URL matches
    if (allowedDomains.length > 0) {
      const isAllowed = allowedDomains.some((domain) =>
        parsedURL.hostname.endsWith(domain)
      );

      if (!isAllowed) {
        return null;
      }
    }

    return parsedURL.toString();
  } catch (error) {
    return null;
  }
}

/**
 * Check if a redirect URL is safe (same origin or allowed domain)
 *
 * @param redirectUrl - The URL to check
 * @param currentOrigin - The current origin (e.g., 'https://supramercado.com')
 * @returns True if safe, false otherwise
 */
export function isSafeRedirect(
  redirectUrl: string,
  currentOrigin: string
): boolean {
  try {
    const url = new URL(redirectUrl, currentOrigin);
    const origin = new URL(currentOrigin);

    // Allow relative URLs and same-origin
    return url.origin === origin.origin;
  } catch {
    return false;
  }
}

/**
 * Security headers for API responses
 *
 * Usage in API route:
 * ```ts
 * const headers = getSecurityHeaders();
 * return NextResponse.json({ data }, { headers });
 * ```
 */
export function getSecurityHeaders(): Headers {
  const headers = new Headers();

  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('X-Frame-Options', 'DENY');
  headers.set('X-XSS-Protection', '1; mode=block');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  headers.set(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=(), interest-cohort=()'
  );

  return headers;
}

/**
 * Validate Content-Type header to prevent MIME confusion attacks
 *
 * @param contentType - The Content-Type header value
 * @param expectedTypes - Array of expected content types
 * @returns True if valid, false otherwise
 */
export function validateContentType(
  contentType: string | null,
  expectedTypes: string[]
): boolean {
  if (!contentType) return false;

  // Extract the main type (ignore charset, boundary, etc.)
  const mainType = contentType.split(';')[0].trim().toLowerCase();

  return expectedTypes.some((type) => mainType === type.toLowerCase());
}

/**
 * Check if request origin is allowed (CORS validation)
 *
 * @param origin - The Origin header value
 * @param allowedOrigins - List of allowed origins
 * @returns True if allowed, false otherwise
 */
export function isAllowedOrigin(
  origin: string | null,
  allowedOrigins: string[]
): boolean {
  if (!origin) return false;

  return allowedOrigins.includes(origin);
}

/**
 * Generate Subresource Integrity (SRI) hash for a script or stylesheet
 *
 * @param content - The script or stylesheet content
 * @param algorithm - The hash algorithm (sha256, sha384, sha512)
 * @returns SRI hash string
 */
export function generateSRIHash(
  content: string,
  algorithm: 'sha256' | 'sha384' | 'sha512' = 'sha384'
): string {
  const hash = crypto.createHash(algorithm).update(content).digest('base64');
  return `${algorithm}-${hash}`;
}

/**
 * Check if user agent is a known bot/crawler
 *
 * @param userAgent - The User-Agent header value
 * @returns True if bot, false otherwise
 */
export function isBot(userAgent: string | null): boolean {
  if (!userAgent) return false;

  const botPatterns = [
    /bot/i,
    /crawler/i,
    /spider/i,
    /scraper/i,
    /curl/i,
    /wget/i,
    /python/i,
    /java/i,
  ];

  return botPatterns.some((pattern) => pattern.test(userAgent));
}

/**
 * Rate limit key for security-sensitive operations
 *
 * Creates a compound key based on IP, user ID, and action
 * Useful for preventing brute force attacks
 */
export function getSecurityRateLimitKey(
  ip: string,
  userId: string | null,
  action: string
): string {
  const parts = ['security', action, ip];

  if (userId) {
    parts.push(userId);
  }

  return parts.join(':');
}

/**
 * Check if password meets security requirements
 *
 * @param password - The password to check
 * @returns Object with validity and error message
 */
export function validatePasswordStrength(password: string): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }

  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (!/[^a-zA-Z0-9]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  // Check for common weak passwords
  const weakPasswords = ['password', '12345678', 'qwerty', 'admin', 'letmein'];
  if (weakPasswords.includes(password.toLowerCase())) {
    errors.push('Password is too common');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Constant-time string comparison to prevent timing attacks
 * (Wrapper around crypto.timingSafeEqual for convenience)
 */
export function secureCompare(a: string, b: string): boolean {
  // Ensure same length to use timingSafeEqual
  const bufferA = Buffer.from(a);
  const bufferB = Buffer.from(b);

  if (bufferA.length !== bufferB.length) {
    return false;
  }

  try {
    return crypto.timingSafeEqual(bufferA, bufferB);
  } catch {
    return false;
  }
}
