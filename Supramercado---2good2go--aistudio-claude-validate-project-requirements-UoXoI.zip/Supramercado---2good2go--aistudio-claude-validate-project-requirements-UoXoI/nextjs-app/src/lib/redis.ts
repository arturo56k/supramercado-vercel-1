import { Redis } from '@upstash/redis';

/**
 * Upstash Redis Client
 *
 * Serverless Redis for rate limiting, caching, and session management
 *
 * Setup:
 * 1. Create account at https://upstash.com
 * 2. Create Redis database
 * 3. Copy UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN
 * 4. Add to .env.local and Vercel
 */

// Check if Redis is configured
const isRedisConfigured =
  process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN;

if (!isRedisConfigured) {
  console.warn('⚠️  Upstash Redis not configured. Rate limiting will be disabled.');
  console.warn('   Set UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN to enable.');
}

/**
 * Redis client instance
 * Returns null if not configured (graceful degradation)
 */
export const redis = isRedisConfigured
  ? new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL!,
      token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    })
  : null;

/**
 * Check if Redis is available
 */
export function isRedisAvailable(): boolean {
  return redis !== null;
}

/**
 * Ping Redis to check connection
 */
export async function pingRedis(): Promise<boolean> {
  if (!redis) return false;

  try {
    const result = await redis.ping();
    return result === 'PONG';
  } catch (error) {
    console.error('Redis ping failed:', error);
    return false;
  }
}

/**
 * Get a value from Redis
 */
export async function getRedisValue<T = string>(key: string): Promise<T | null> {
  if (!redis) return null;

  try {
    return await redis.get<T>(key);
  } catch (error) {
    console.error(`Redis GET error for key ${key}:`, error);
    return null;
  }
}

/**
 * Set a value in Redis with optional expiration
 */
export async function setRedisValue(
  key: string,
  value: any,
  expirationSeconds?: number
): Promise<boolean> {
  if (!redis) return false;

  try {
    if (expirationSeconds) {
      await redis.setex(key, expirationSeconds, value);
    } else {
      await redis.set(key, value);
    }
    return true;
  } catch (error) {
    console.error(`Redis SET error for key ${key}:`, error);
    return false;
  }
}

/**
 * Delete a key from Redis
 */
export async function deleteRedisKey(key: string): Promise<boolean> {
  if (!redis) return false;

  try {
    await redis.del(key);
    return true;
  } catch (error) {
    console.error(`Redis DEL error for key ${key}:`, error);
    return false;
  }
}

/**
 * Increment a counter in Redis
 */
export async function incrementRedisCounter(
  key: string,
  expirationSeconds?: number
): Promise<number | null> {
  if (!redis) return null;

  try {
    const value = await redis.incr(key);

    // Set expiration on first increment
    if (value === 1 && expirationSeconds) {
      await redis.expire(key, expirationSeconds);
    }

    return value;
  } catch (error) {
    console.error(`Redis INCR error for key ${key}:`, error);
    return null;
  }
}
