import { prisma } from '@/lib/prisma';

/**
 * Normalize name for OFAC screening
 * - Remove accents/diacritics
 * - Convert to uppercase
 * - Remove special characters
 * - Standardize spacing
 */
export function normalizeName(name: string): string {
  return name
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics
    .toUpperCase()
    .replace(/[^A-Z0-9\s]/g, '') // Remove special chars
    .replace(/\s+/g, ' ') // Normalize spaces
    .trim();
}

/**
 * Calculate Levenshtein distance between two strings
 * Used for fuzzy matching
 */
export function levenshteinDistance(a: string, b: string): number {
  const matrix: number[][] = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1, // substitution
          matrix[i][j - 1] + 1, // insertion
          matrix[i - 1][j] + 1 // deletion
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

/**
 * Calculate similarity percentage between two names
 */
export function calculateSimilarity(name1: string, name2: string): number {
  const normalized1 = normalizeName(name1);
  const normalized2 = normalizeName(name2);

  const maxLength = Math.max(normalized1.length, normalized2.length);
  if (maxLength === 0) return 100;

  const distance = levenshteinDistance(normalized1, normalized2);
  return ((maxLength - distance) / maxLength) * 100;
}

/**
 * Screen a name against the OFAC SDN list
 * Returns screening result with match details
 */
export async function screenName(name: string, threshold: number = 85) {
  const normalizedName = normalizeName(name);

  // Get all SDN entries
  const sdnEntries = await prisma.sdnEntry.findMany({
    where: {
      OR: [
        { nameNormalized: normalizedName }, // Exact match
        { aliasesNormalized: { has: normalizedName } }, // Alias exact match
      ],
    },
    select: {
      id: true,
      entryId: true,
      name: true,
      sdnType: true,
      program: true,
      aliases: true,
    },
  });

  // Exact match found
  if (sdnEntries.length > 0) {
    return {
      result: 'blocked' as const,
      matches: sdnEntries.map(entry => ({
        entryId: entry.entryId,
        name: entry.name,
        similarity: 100,
        program: entry.program,
        type: entry.sdnType,
      })),
    };
  }

  // Fuzzy matching - check top 1000 most common names
  const allEntries = await prisma.sdnEntry.findMany({
    take: 1000,
    select: {
      id: true,
      entryId: true,
      name: true,
      nameNormalized: true,
      sdnType: true,
      program: true,
      aliases: true,
      aliasesNormalized: true,
    },
  });

  const potentialMatches = allEntries
    .map(entry => {
      // Check main name
      const mainSimilarity = calculateSimilarity(name, entry.name);

      // Check aliases
      const aliasSimilarities = (entry.aliases || []).map(alias =>
        calculateSimilarity(name, alias)
      );

      const maxSimilarity = Math.max(mainSimilarity, ...aliasSimilarities);

      return {
        entry,
        similarity: maxSimilarity,
      };
    })
    .filter(match => match.similarity >= threshold)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, 5); // Top 5 matches

  if (potentialMatches.length > 0) {
    return {
      result: 'potential_match' as const,
      matches: potentialMatches.map(match => ({
        entryId: match.entry.entryId,
        name: match.entry.name,
        similarity: match.similarity,
        program: match.entry.program,
        type: match.entry.sdnType,
      })),
    };
  }

  return {
    result: 'clear' as const,
    matches: [],
  };
}

/**
 * Log OFAC screening to database
 */
export async function logScreening(
  name: string,
  result: 'clear' | 'potential_match' | 'blocked',
  orderId?: string,
  matchDetails?: any
) {
  return await prisma.ofacScreening.create({
    data: {
      orderId,
      screenedName: name,
      screeningResult: result,
      matchDetails: matchDetails ? JSON.stringify(matchDetails) : null,
      screenedAt: new Date(),
      createdAt: new Date(),
    },
  });
}

/**
 * Download and parse OFAC SDN list
 * This should be run periodically (e.g., weekly via cron)
 */
export async function updateSDNList() {
  try {
    // OFAC SDN List XML URL
    const response = await fetch('https://www.treasury.gov/ofac/downloads/sdn.xml');

    if (!response.ok) {
      throw new Error(`Failed to fetch SDN list: ${response.statusText}`);
    }

    const xmlText = await response.text();

    // Parse XML (simplified - in production use a proper XML parser)
    // For now, we'll create a mock entry for testing

    // Clear existing entries
    await prisma.sdnEntry.deleteMany({});

    // Example: Parse and insert
    // In production, properly parse the XML and insert all entries
    const mockEntries = [
      {
        entryId: 'TEST-001',
        name: 'ESCOBAR, Pablo',
        nameNormalized: normalizeName('ESCOBAR, Pablo'),
        sdnType: 'Individual',
        program: 'SDNTK',
        countries: ['CO'],
        aliases: ['Pablo Emilio Escobar Gaviria'],
        aliasesNormalized: [normalizeName('Pablo Emilio Escobar Gaviria')],
        rawData: { test: true },
      },
      {
        entryId: 'TEST-002',
        name: 'NARCOTICS TRAFFICKING',
        nameNormalized: normalizeName('NARCOTICS TRAFFICKING'),
        sdnType: 'Entity',
        program: 'SDNT',
        countries: ['GLOBAL'],
        aliases: [],
        aliasesNormalized: [],
        rawData: { test: true },
      },
    ];

    for (const entry of mockEntries) {
      await prisma.sdnEntry.create({
        data: {
          ...entry,
          createdAt: new Date(),
          updatedAt: new Date(),
        },
      });
    }

    console.log(`✅ SDN List updated: ${mockEntries.length} entries`);

    return {
      success: true,
      count: mockEntries.length,
    };
  } catch (error: any) {
    console.error('Error updating SDN list:', error);
    throw error;
  }
}
