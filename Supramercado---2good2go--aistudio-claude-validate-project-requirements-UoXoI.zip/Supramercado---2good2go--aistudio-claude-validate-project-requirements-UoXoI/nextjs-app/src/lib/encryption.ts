import crypto from 'crypto';

/**
 * AES-256-GCM Encryption for storing sensitive configuration
 *
 * IMPORTANT: ENCRYPTION_KEY must be a 32-byte (64-character hex) string
 * Generate with: openssl rand -hex 32
 */

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 16; // 16 bytes for AES
const AUTH_TAG_LENGTH = 16; // 16 bytes for GCM authentication tag
const SALT_LENGTH = 64; // 64 bytes salt for key derivation

if (!process.env.ENCRYPTION_KEY) {
  console.warn('⚠️  ENCRYPTION_KEY not set. Configuration encryption disabled.');
}

/**
 * Derive a 32-byte key from the ENCRYPTION_KEY using PBKDF2
 */
function deriveKey(salt: Buffer): Buffer {
  const encryptionKey = process.env.ENCRYPTION_KEY!;

  return crypto.pbkdf2Sync(
    encryptionKey,
    salt,
    100000, // iterations
    32, // key length in bytes
    'sha256'
  );
}

/**
 * Encrypt a value using AES-256-GCM
 *
 * Returns: base64-encoded string with format:
 * [salt]:[iv]:[authTag]:[encryptedData]
 */
export function encrypt(plaintext: string): string {
  if (!process.env.ENCRYPTION_KEY) {
    throw new Error('ENCRYPTION_KEY not configured');
  }

  // Generate random salt and IV
  const salt = crypto.randomBytes(SALT_LENGTH);
  const iv = crypto.randomBytes(IV_LENGTH);

  // Derive encryption key from master key
  const key = deriveKey(salt);

  // Create cipher
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);

  // Encrypt
  let encrypted = cipher.update(plaintext, 'utf8', 'base64');
  encrypted += cipher.final('base64');

  // Get authentication tag
  const authTag = cipher.getAuthTag();

  // Combine all parts: salt:iv:authTag:encrypted
  const combined = [
    salt.toString('base64'),
    iv.toString('base64'),
    authTag.toString('base64'),
    encrypted,
  ].join(':');

  return combined;
}

/**
 * Decrypt a value encrypted with encrypt()
 *
 * Input format: [salt]:[iv]:[authTag]:[encryptedData]
 */
export function decrypt(encryptedData: string): string {
  if (!process.env.ENCRYPTION_KEY) {
    throw new Error('ENCRYPTION_KEY not configured');
  }

  // Split the combined string
  const parts = encryptedData.split(':');
  if (parts.length !== 4) {
    throw new Error('Invalid encrypted data format');
  }

  const [saltB64, ivB64, authTagB64, encrypted] = parts;

  // Convert from base64
  const salt = Buffer.from(saltB64, 'base64');
  const iv = Buffer.from(ivB64, 'base64');
  const authTag = Buffer.from(authTagB64, 'base64');

  // Derive the same encryption key
  const key = deriveKey(salt);

  // Create decipher
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(authTag);

  // Decrypt
  let decrypted = decipher.update(encrypted, 'base64', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

/**
 * Hash a value using SHA-256 (one-way, for comparison)
 */
export function hash(value: string): string {
  return crypto
    .createHash('sha256')
    .update(value)
    .digest('hex');
}

/**
 * Validate that encryption is working correctly
 */
export function testEncryption(): boolean {
  try {
    const testValue = 'test-encryption-' + Date.now();
    const encrypted = encrypt(testValue);
    const decrypted = decrypt(encrypted);
    return decrypted === testValue;
  } catch (error) {
    console.error('Encryption test failed:', error);
    return false;
  }
}

/**
 * Securely compare two strings in constant time
 * Prevents timing attacks
 */
export function secureCompare(a: string, b: string): boolean {
  if (a.length !== b.length) {
    return false;
  }

  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);

  return crypto.timingSafeEqual(bufA, bufB);
}
