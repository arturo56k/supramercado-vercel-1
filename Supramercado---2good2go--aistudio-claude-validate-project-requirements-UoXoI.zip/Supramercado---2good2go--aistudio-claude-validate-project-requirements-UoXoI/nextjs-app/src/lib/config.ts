import { prisma } from '@/lib/prisma';
import { encrypt, decrypt } from '@/lib/encryption';

/**
 * Configuration Management System
 *
 * All API keys and sensitive configuration are stored encrypted in the database.
 * This allows admins to update credentials without touching code or environment variables.
 */

export type ConfigCategory =
  | 'stripe'
  | 'resend'
  | 'twilio'
  | 'gemini'
  | 'supabase'
  | 'general';

export interface ConfigKey {
  key: string;
  category: ConfigCategory;
  description: string;
  required: boolean;
  sensitive: boolean; // If true, value will be masked in UI
}

/**
 * Available configuration keys
 */
export const CONFIG_KEYS: Record<string, ConfigKey> = {
  // Stripe
  STRIPE_SECRET_KEY: {
    key: 'STRIPE_SECRET_KEY',
    category: 'stripe',
    description: 'Stripe Secret Key for API calls',
    required: true,
    sensitive: true,
  },
  STRIPE_WEBHOOK_SECRET: {
    key: 'STRIPE_WEBHOOK_SECRET',
    category: 'stripe',
    description: 'Stripe Webhook Secret for signature verification',
    required: true,
    sensitive: true,
  },

  // Resend (Email)
  RESEND_API_KEY: {
    key: 'RESEND_API_KEY',
    category: 'resend',
    description: 'Resend API Key for sending emails',
    required: true,
    sensitive: true,
  },

  // Twilio (SMS/WhatsApp)
  TWILIO_ACCOUNT_SID: {
    key: 'TWILIO_ACCOUNT_SID',
    category: 'twilio',
    description: 'Twilio Account SID',
    required: true,
    sensitive: false,
  },
  TWILIO_AUTH_TOKEN: {
    key: 'TWILIO_AUTH_TOKEN',
    category: 'twilio',
    description: 'Twilio Auth Token',
    required: true,
    sensitive: true,
  },
  TWILIO_WHATSAPP_NUMBER: {
    key: 'TWILIO_WHATSAPP_NUMBER',
    category: 'twilio',
    description: 'Twilio WhatsApp Number (e.g., whatsapp:+14155238886)',
    required: false,
    sensitive: false,
  },
  TWILIO_SMS_NUMBER: {
    key: 'TWILIO_SMS_NUMBER',
    category: 'twilio',
    description: 'Twilio SMS Number (e.g., +18091234567)',
    required: false,
    sensitive: false,
  },

  // Gemini (AI)
  GEMINI_API_KEY: {
    key: 'GEMINI_API_KEY',
    category: 'gemini',
    description: 'Google Gemini API Key for AI features',
    required: false,
    sensitive: true,
  },

  // General
  NEXT_PUBLIC_APP_URL: {
    key: 'NEXT_PUBLIC_APP_URL',
    category: 'general',
    description: 'Public URL of the application (e.g., https://supramercado.com)',
    required: true,
    sensitive: false,
  },
  CRON_SECRET: {
    key: 'CRON_SECRET',
    category: 'general',
    description: 'Secret for protecting cron job endpoints',
    required: true,
    sensitive: true,
  },
};

/**
 * Get a configuration value (decrypted)
 *
 * Falls back to environment variable if not found in database
 */
export async function getConfig(key: string): Promise<string | null> {
  try {
    // Try database first
    const config = await prisma.platformConfig.findUnique({
      where: { key, isActive: true },
    });

    if (config) {
      try {
        return decrypt(config.value);
      } catch (error) {
        console.error(`Failed to decrypt config ${key}:`, error);
        // Fall through to env var
      }
    }

    // Fallback to environment variable
    return process.env[key] || null;
  } catch (error) {
    console.error(`Error getting config ${key}:`, error);
    return process.env[key] || null;
  }
}

/**
 * Get multiple configuration values at once
 */
export async function getConfigs(keys: string[]): Promise<Record<string, string | null>> {
  const result: Record<string, string | null> = {};

  await Promise.all(
    keys.map(async (key) => {
      result[key] = await getConfig(key);
    })
  );

  return result;
}

/**
 * Set a configuration value (encrypted)
 */
export async function setConfig(
  key: string,
  value: string,
  category?: ConfigCategory,
  description?: string
): Promise<void> {
  const configKey = CONFIG_KEYS[key];
  const encryptedValue = encrypt(value);

  await prisma.platformConfig.upsert({
    where: { key },
    create: {
      key,
      value: encryptedValue,
      category: category || configKey?.category || 'general',
      description: description || configKey?.description || '',
      isActive: true,
    },
    update: {
      value: encryptedValue,
      category: category || configKey?.category,
      description: description || configKey?.description,
      updatedAt: new Date(),
    },
  });
}

/**
 * Delete a configuration value
 */
export async function deleteConfig(key: string): Promise<void> {
  await prisma.platformConfig.delete({
    where: { key },
  });
}

/**
 * List all configuration keys with metadata (values are NOT included for security)
 */
export async function listConfigs(category?: ConfigCategory): Promise<
  Array<{
    key: string;
    category: string;
    description: string | null;
    isActive: boolean;
    hasValue: boolean; // Whether a value is set
    isConfigured: boolean; // Whether it's in database vs env var
    createdAt: Date;
    updatedAt: Date;
  }>
> {
  const where = category ? { category } : {};

  const configs = await prisma.platformConfig.findMany({
    where,
    select: {
      key: true,
      category: true,
      description: true,
      isActive: true,
      createdAt: true,
      updatedAt: true,
    },
    orderBy: { category: 'asc' },
  });

  // Add info about which keys exist
  return configs.map((config) => ({
    ...config,
    hasValue: true,
    isConfigured: true,
  }));
}

/**
 * Get all available configuration keys with their metadata
 */
export function getAvailableConfigKeys(category?: ConfigCategory): ConfigKey[] {
  const keys = Object.values(CONFIG_KEYS);

  if (category) {
    return keys.filter((k) => k.category === category);
  }

  return keys;
}

/**
 * Check if all required configurations are set
 */
export async function validateRequiredConfigs(): Promise<{
  valid: boolean;
  missing: string[];
}> {
  const required = Object.values(CONFIG_KEYS).filter((k) => k.required);
  const missing: string[] = [];

  for (const configKey of required) {
    const value = await getConfig(configKey.key);
    if (!value) {
      missing.push(configKey.key);
    }
  }

  return {
    valid: missing.length === 0,
    missing,
  };
}

/**
 * Validate a specific configuration value
 * Returns error message if invalid, null if valid
 */
export function validateConfigValue(key: string, value: string): string | null {
  if (!value || value.trim().length === 0) {
    return 'Value cannot be empty';
  }

  switch (key) {
    case 'STRIPE_SECRET_KEY':
      if (!value.startsWith('sk_')) {
        return 'Stripe secret key must start with sk_';
      }
      break;

    case 'STRIPE_WEBHOOK_SECRET':
      if (!value.startsWith('whsec_')) {
        return 'Stripe webhook secret must start with whsec_';
      }
      break;

    case 'RESEND_API_KEY':
      if (!value.startsWith('re_')) {
        return 'Resend API key must start with re_';
      }
      break;

    case 'TWILIO_ACCOUNT_SID':
      if (!value.startsWith('AC')) {
        return 'Twilio Account SID must start with AC';
      }
      break;

    case 'TWILIO_WHATSAPP_NUMBER':
      if (!value.startsWith('whatsapp:+')) {
        return 'WhatsApp number must start with whatsapp:+';
      }
      break;

    case 'TWILIO_SMS_NUMBER':
      if (!value.startsWith('+')) {
        return 'SMS number must start with +';
      }
      break;

    case 'NEXT_PUBLIC_APP_URL':
      try {
        new URL(value);
      } catch {
        return 'Must be a valid URL';
      }
      break;
  }

  return null;
}

/**
 * Mask a sensitive value for display
 */
export function maskValue(value: string, showLast: number = 4): string {
  if (value.length <= showLast) {
    return '***';
  }

  const masked = '*'.repeat(Math.max(0, value.length - showLast));
  const visible = value.slice(-showLast);

  return masked + visible;
}
