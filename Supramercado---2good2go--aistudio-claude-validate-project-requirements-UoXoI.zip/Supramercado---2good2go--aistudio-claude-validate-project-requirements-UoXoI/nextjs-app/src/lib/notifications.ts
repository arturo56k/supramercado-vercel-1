import { Resend } from 'resend';
import twilio from 'twilio';

// Initialize Resend
const resend = new Resend(process.env.RESEND_API_KEY);

// Initialize Twilio
const twilioClient = process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN
  ? twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN)
  : null;

/**
 * Generate magic link for beneficiary
 */
export function generateMagicLink(magicLinkCode: string, baseUrl: string): string {
  return `${baseUrl}/magic/${magicLinkCode}`;
}

/**
 * Generate pickup code (6 digits)
 */
export function generatePickupCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

/**
 * Send order confirmation email to buyer
 */
export async function sendOrderConfirmationEmail({
  to,
  orderNumber,
  totalUSD,
  beneficiaryName,
  merchantName,
  items,
}: {
  to: string;
  orderNumber: string;
  totalUSD: number;
  beneficiaryName: string;
  merchantName: string;
  items: Array<{ name: string; quantity: number; price: number }>;
}) {
  try {
    const itemsHtml = items
      .map(
        item => `
        <tr>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb;">${item.name}</td>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: center;">${item.quantity}</td>
          <td style="padding: 8px; border-bottom: 1px solid #e5e7eb; text-align: right;">$${item.price.toFixed(2)}</td>
        </tr>
      `
      )
      .join('');

    await resend.emails.send({
      from: 'Supramercado <orders@supramercado.com>',
      to,
      subject: `✅ Orden Confirmada - ${orderNumber}`,
      html: `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #374151; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0; font-size: 28px;">🛒 Supramercado</h1>
              <p style="color: white; margin: 10px 0 0 0;">¡Gracias por tu compra!</p>
            </div>

            <div style="background: white; padding: 30px; border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 10px 10px;">
              <h2 style="color: #059669; margin-top: 0;">✅ Orden Confirmada</h2>

              <div style="background: #f0fdf4; border-left: 4px solid #059669; padding: 15px; margin: 20px 0;">
                <p style="margin: 0;"><strong>Número de Orden:</strong> ${orderNumber}</p>
                <p style="margin: 10px 0 0 0;"><strong>Total Pagado:</strong> $${totalUSD.toFixed(2)} USD</p>
              </div>

              <h3 style="color: #374151; margin-top: 30px;">📦 Detalles de la Orden</h3>
              <p><strong>Comercio:</strong> ${merchantName}</p>
              <p><strong>Beneficiario:</strong> ${beneficiaryName}</p>

              <h3 style="color: #374151; margin-top: 30px;">🛍️ Productos</h3>
              <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                <thead>
                  <tr style="background: #f9fafb;">
                    <th style="padding: 8px; text-align: left; border-bottom: 2px solid #e5e7eb;">Producto</th>
                    <th style="padding: 8px; text-align: center; border-bottom: 2px solid #e5e7eb;">Cant.</th>
                    <th style="padding: 8px; text-align: right; border-bottom: 2px solid #e5e7eb;">Precio</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsHtml}
                </tbody>
              </table>

              <h3 style="color: #374151; margin-top: 30px;">📱 Próximos Pasos</h3>
              <ul style="line-height: 2;">
                <li>✉️ Hemos enviado un <strong>magic link</strong> a ${beneficiaryName}</li>
                <li>📱 Recibirá el link por WhatsApp o SMS</li>
                <li>🏪 Podrá recoger la orden en ${merchantName}</li>
                <li>🔐 Un código de retiro será generado</li>
              </ul>

              <div style="background: #eff6ff; border-left: 4px solid #3b82f6; padding: 15px; margin: 30px 0;">
                <p style="margin: 0; color: #1e40af;">
                  <strong>💡 Tip:</strong> Puedes ver el estado de tu orden en cualquier momento desde tu dashboard.
                </p>
              </div>

              <div style="text-align: center; margin-top: 40px;">
                <a href="https://supramercado.com/dashboard" style="background: #059669; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block;">Ver Dashboard</a>
              </div>

              <p style="text-align: center; color: #9ca3af; font-size: 14px; margin-top: 40px;">
                ¿Necesitas ayuda? Contáctanos en soporte@supramercado.com
              </p>
            </div>
          </body>
        </html>
      `,
    });

    console.log(`✅ Email sent to ${to}`);
    return { success: true };
  } catch (error: any) {
    console.error('Error sending email:', error);
    throw error;
  }
}

/**
 * Send magic link to beneficiary via WhatsApp
 */
export async function sendMagicLinkWhatsApp({
  to,
  beneficiaryName,
  magicLink,
  merchantName,
  orderNumber,
}: {
  to: string;
  beneficiaryName: string;
  magicLink: string;
  merchantName: string;
  orderNumber: string;
}) {
  if (!twilioClient || !process.env.TWILIO_WHATSAPP_NUMBER) {
    console.warn('Twilio not configured, skipping WhatsApp');
    return { success: false, reason: 'Twilio not configured' };
  }

  try {
    // Format phone number (ensure it starts with +)
    const formattedPhone = to.startsWith('+') ? to : `+${to}`;

    await twilioClient.messages.create({
      from: process.env.TWILIO_WHATSAPP_NUMBER,
      to: `whatsapp:${formattedPhone}`,
      body: `
🛒 *Supramercado*

¡Hola ${beneficiaryName}! 👋

Te han enviado una orden desde Estados Unidos.

📦 *Orden:* ${orderNumber}
🏪 *Comercio:* ${merchantName}

🔗 *Abre este link para ver los detalles:*
${magicLink}

Podrás ver:
✅ Productos incluidos
✅ Código de retiro
✅ Ubicación del comercio

¡Gracias por usar Supramercado! 💚
      `.trim(),
    });

    console.log(`✅ WhatsApp sent to ${to}`);
    return { success: true, method: 'whatsapp' };
  } catch (error: any) {
    console.error('Error sending WhatsApp:', error);
    // Fallback to SMS
    return await sendMagicLinkSMS({ to, beneficiaryName, magicLink, merchantName, orderNumber });
  }
}

/**
 * Send magic link to beneficiary via SMS (fallback)
 */
export async function sendMagicLinkSMS({
  to,
  beneficiaryName,
  magicLink,
  merchantName,
  orderNumber,
}: {
  to: string;
  beneficiaryName: string;
  magicLink: string;
  merchantName: string;
  orderNumber: string;
}) {
  if (!twilioClient || !process.env.TWILIO_SMS_NUMBER) {
    console.warn('Twilio not configured, skipping SMS');
    return { success: false, reason: 'Twilio not configured' };
  }

  try {
    const formattedPhone = to.startsWith('+') ? to : `+${to}`;

    await twilioClient.messages.create({
      from: process.env.TWILIO_SMS_NUMBER,
      to: formattedPhone,
      body: `Supramercado: ¡Hola ${beneficiaryName}! Te han enviado una orden (${orderNumber}) desde USA. Ver detalles: ${magicLink}`,
    });

    console.log(`✅ SMS sent to ${to}`);
    return { success: true, method: 'sms' };
  } catch (error: any) {
    console.error('Error sending SMS:', error);
    return { success: false, reason: error.message };
  }
}

/**
 * Send order ready for pickup notification
 */
export async function sendOrderReadyNotification({
  to,
  beneficiaryName,
  pickupCode,
  merchantName,
  merchantAddress,
}: {
  to: string;
  beneficiaryName: string;
  pickupCode: string;
  merchantName: string;
  merchantAddress: string;
}) {
  if (!twilioClient) {
    return { success: false, reason: 'Twilio not configured' };
  }

  try {
    const formattedPhone = to.startsWith('+') ? to : `+${to}`;

    // Try WhatsApp first
    try {
      await twilioClient.messages.create({
        from: process.env.TWILIO_WHATSAPP_NUMBER,
        to: `whatsapp:${formattedPhone}`,
        body: `
🎉 *¡Tu orden está lista!*

Hola ${beneficiaryName},

Tu orden ya está lista para recoger en:
🏪 ${merchantName}
📍 ${merchantAddress}

🔐 *Código de retiro:* ${pickupCode}

Por favor presenta este código al llegar al comercio.

¡Gracias por usar Supramercado! 💚
        `.trim(),
      });

      return { success: true, method: 'whatsapp' };
    } catch {
      // Fallback to SMS
      await twilioClient.messages.create({
        from: process.env.TWILIO_SMS_NUMBER,
        to: formattedPhone,
        body: `Supramercado: ¡Hola ${beneficiaryName}! Tu orden está lista para recoger en ${merchantName}. Código: ${pickupCode}`,
      });

      return { success: true, method: 'sms' };
    }
  } catch (error: any) {
    console.error('Error sending ready notification:', error);
    return { success: false, reason: error.message };
  }
}
