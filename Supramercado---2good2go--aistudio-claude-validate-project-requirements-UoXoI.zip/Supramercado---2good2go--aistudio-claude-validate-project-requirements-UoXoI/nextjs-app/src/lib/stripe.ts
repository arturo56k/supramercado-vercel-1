import Stripe from 'stripe';

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY is not defined');
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-12-18.acacia',
  typescript: true,
});

// Helper: Create or get Stripe customer
export async function getOrCreateStripeCustomer(
  userId: string,
  email: string
): Promise<string> {
  const { prisma } = await import('@/lib/prisma');

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { stripeCustomerId: true },
  });

  if (user?.stripeCustomerId) {
    return user.stripeCustomerId;
  }

  // Create new Stripe customer
  const customer = await stripe.customers.create({
    email,
    metadata: {
      userId,
    },
  });

  // Save customer ID to database
  await prisma.user.update({
    where: { id: userId },
    data: { stripeCustomerId: customer.id },
  });

  return customer.id;
}

// Helper: Calculate platform fee (5%)
export function calculatePlatformFee(subtotalUSD: number): number {
  return Math.round(subtotalUSD * 0.05 * 100) / 100; // 5% commission
}

// Helper: Create payment intent with application fee
export async function createPaymentIntent({
  amount,
  currency = 'usd',
  customerId,
  merchantStripeAccountId,
  orderId,
  platformFee,
}: {
  amount: number; // in cents
  currency?: string;
  customerId: string;
  merchantStripeAccountId: string;
  orderId: string;
  platformFee: number; // in cents
}) {
  return await stripe.paymentIntents.create({
    amount,
    currency,
    customer: customerId,
    application_fee_amount: platformFee,
    transfer_data: {
      destination: merchantStripeAccountId,
    },
    metadata: {
      orderId,
    },
    automatic_payment_methods: {
      enabled: true,
    },
  });
}
