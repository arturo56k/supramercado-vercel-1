import { createClient } from '@/lib/supabase/server';
import { prisma } from '@/lib/prisma';
import { NextResponse } from 'next/server';

/**
 * Check if the current user is a SAAS_ADMIN
 */
export async function isAdmin(): Promise<boolean> {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return false;
    }

    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: { role: true },
    });

    return dbUser?.role === 'SAAS_ADMIN';
  } catch (error) {
    console.error('Error checking admin status:', error);
    return false;
  }
}

/**
 * Get current authenticated user from database
 */
export async function getCurrentUser() {
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return null;
    }

    const dbUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        email: true,
        fullName: true,
        role: true,
        merchantId: true,
        avatarUrl: true,
      },
    });

    return dbUser;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
}

/**
 * Require admin access or return 403 error
 * Use in API routes
 */
export async function requireAdmin() {
  const admin = await isAdmin();

  if (!admin) {
    return NextResponse.json(
      { error: 'Forbidden: Admin access required' },
      { status: 403 }
    );
  }

  return null; // No error, proceed
}

/**
 * Require authentication or return 401 error
 * Use in API routes
 */
export async function requireAuth() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json(
      { error: 'Unauthorized: Authentication required' },
      { status: 401 }
    );
  }

  return user;
}

/**
 * Check if user has merchant access
 */
export async function hasMerchantAccess(merchantId: string): Promise<boolean> {
  try {
    const user = await getCurrentUser();

    if (!user) {
      return false;
    }

    // SAAS_ADMIN has access to everything
    if (user.role === 'SAAS_ADMIN') {
      return true;
    }

    // Check if user belongs to this merchant
    if (user.role === 'MERCHANT_ADMIN' || user.role === 'MERCHANT_EMPLOYEE') {
      return user.merchantId === merchantId;
    }

    return false;
  } catch (error) {
    console.error('Error checking merchant access:', error);
    return false;
  }
}
