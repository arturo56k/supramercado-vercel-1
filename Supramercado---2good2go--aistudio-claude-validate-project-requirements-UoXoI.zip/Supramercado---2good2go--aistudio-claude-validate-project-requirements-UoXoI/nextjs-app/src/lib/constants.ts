
import { UserRole, Product, Merchant } from '@/types';

export const COLORS = {
  primary: '#0056B3',
  secondary: '#FF8C00',
};

export interface EnhancedMerchant extends Merchant {
  locationName: string;
  priceLevel: string;
  lat: number;
  lng: number;
}

export const MOCK_MERCHANTS: EnhancedMerchant[] = [
  // Fixed: EnhancedMerchant now includes category via base Merchant interface update
  { id: 'm1', name: 'Supermercado Nacional', logo: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400', description: 'El supermercado de los dominicanos.', rating: 4.8, categories: ['Groceries'], category: 'Groceries', locationName: 'Santiago', priceLevel: '$$', lat: 19.4517, lng: -70.6970, isVerified: true, isOpen: true, walletBalance: 24500.50, stripeConnectedId: 'acct_1N2345', hasIssuingCard: true, status: 'ACTIVE', address: 'Santiago Main St', city: 'Santiago', closingTime: '21:00' },
  { id: 'm2', name: 'Farmacia Carol', logo: 'https://images.unsplash.com/photo-1586015555751-63bb77f4322a?auto=format&fit=crop&q=80&w=400', description: 'Cuidamos tu salud siempre.', rating: 4.9, categories: ['Health'], category: 'Health', locationName: 'Santiago', priceLevel: '$$', lat: 19.4469, lng: -70.6836, isVerified: true, isOpen: true, walletBalance: 15000.00, stripeConnectedId: 'acct_1N6789', hasIssuingCard: false, status: 'ACTIVE', address: 'Santiago Health Blvd', city: 'Santiago', closingTime: '22:00' },
  { id: 'm3', name: 'Colmado La Fe', logo: 'https://images.unsplash.com/photo-1604719312566-8912e9227c6a?auto=format&fit=crop&q=80&w=400', description: 'Lo mejor del barrio.', rating: 4.5, categories: ['Local'], category: 'Local', locationName: 'Santo Domingo', priceLevel: '$', lat: 18.4861, lng: -69.9312, isVerified: false, isOpen: true, walletBalance: 0, hasIssuingCard: false, status: 'ACTIVE', address: 'Calle Principal 123', city: 'Santo Domingo', closingTime: '23:00' },
];

export const MOCK_PRODUCTS: Product[] = [
  // Added priceUSD and fixed types for mock products
  { id: 'p1', name: 'Arroz Premium 5lb', description: 'Grano largo seleccionado.', priceUSD: 5.80, basePriceDOP: 345.00, category: 'Groceries', stock: 50, merchantId: 'm1', image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=400', type: 'INDIVIDUAL', subscriptionDiscount: 5 },
  { id: 'p2', name: 'Pack Familiar Semanal', description: 'Arroz (10lb), Aceite (1L), Habichuelas (2lb), Pollo entero (3lb).', priceUSD: 41.20, basePriceDOP: 2450.00, originalPriceDOP: 2800.00, category: 'Packs Ahorro 📦', stock: 20, merchantId: 'm1', image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400', type: 'PREDESIGNED_PACK', subscriptionDiscount: 10 },
  { id: 'p3', name: 'Kit Salud Senior', description: 'Multivitamínicos, Glucómetro y Ensure (4 pack).', priceUSD: 83.30, basePriceDOP: 4950.00, category: 'Health', stock: 15, merchantId: 'm2', image: 'https://images.unsplash.com/photo-1584017945516-03f443586f1e?auto=format&fit=crop&q=80&w=400', type: 'PREDESIGNED_PACK', subscriptionDiscount: 12 },
  { id: 'p4', name: 'Salami Super Especial 2lb', description: 'El favorito de los dominicanos.', priceUSD: 7.40, basePriceDOP: 440.00, category: 'Groceries', stock: 100, merchantId: 'm1', image: 'https://images.unsplash.com/photo-1593001874117-c99c800e3eb7?auto=format&fit=crop&q=80&w=400', type: 'INDIVIDUAL' },
];

export const ROLE_CONFIG = {
  [UserRole.CLIENT]: { label: 'Comprador (USA)', color: 'bg-blue-600' },
  [UserRole.BENEFICIARY]: { label: 'Beneficiario (RD)', color: 'bg-orange-500' },
  [UserRole.MERCHANT_ADMIN]: { label: 'Admin Comercio', color: 'bg-purple-600' },
  [UserRole.MERCHANT_BRANCH_ADMIN]: { label: 'Admin Sucursal', color: 'bg-indigo-600' },
  [UserRole.MERCHANT_EMPLOYEE]: { label: 'Empleado', color: 'bg-teal-600' },
  [UserRole.SAAS_SUPPORT]: { label: 'Soporte SaaS', color: 'bg-gray-600' },
  [UserRole.SAAS_ADMIN]: { label: 'Admin SaaS', color: 'bg-red-600' },
};
