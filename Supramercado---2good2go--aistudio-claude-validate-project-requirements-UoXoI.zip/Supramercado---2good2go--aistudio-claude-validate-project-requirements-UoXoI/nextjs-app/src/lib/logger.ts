import { Axiom } from '@axiomhq/js';

/**
 * Structured Logging System with Axiom
 *
 * Centralized logging for errors, events, and analytics
 *
 * Setup:
 * 1. Create account at https://axiom.co
 * 2. Create dataset (e.g., "supramercado-logs")
 * 3. Get API token
 * 4. Set AXIOM_TOKEN and AXIOM_DATASET in .env.local
 */

// Log levels
export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'fatal';

// Event categories
export type EventCategory =
  | 'auth'
  | 'payment'
  | 'ofac'
  | 'notification'
  | 'api'
  | 'config'
  | 'security'
  | 'performance';

// Structured log entry
export interface LogEntry {
  level: LogLevel;
  message: string;
  category?: EventCategory;
  userId?: string;
  orderId?: string;
  merchantId?: string;
  ipAddress?: string;
  userAgent?: string;
  url?: string;
  method?: string;
  statusCode?: number;
  duration?: number; // milliseconds
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
  metadata?: Record<string, any>;
  timestamp?: Date;
}

// Initialize Axiom client
const isAxiomConfigured =
  process.env.AXIOM_TOKEN && process.env.AXIOM_DATASET;

const axiom = isAxiomConfigured
  ? new Axiom({
      token: process.env.AXIOM_TOKEN!,
      orgId: process.env.AXIOM_ORG_ID,
    })
  : null;

const dataset = process.env.AXIOM_DATASET || 'supramercado-logs';

if (!isAxiomConfigured) {
  console.warn(
    '⚠️  Axiom not configured. Logs will only be written to console.'
  );
  console.warn('   Set AXIOM_TOKEN and AXIOM_DATASET to enable centralized logging.');
}

/**
 * Core logging function
 */
async function log(entry: LogEntry): Promise<void> {
  const enrichedEntry = {
    ...entry,
    timestamp: entry.timestamp || new Date(),
    environment: process.env.NODE_ENV || 'development',
    app: 'supramercado',
  };

  // Always log to console in development
  if (process.env.NODE_ENV === 'development') {
    const prefix = `[${entry.level.toUpperCase()}]`;
    const category = entry.category ? `[${entry.category}]` : '';
    console.log(
      `${prefix}${category} ${entry.message}`,
      entry.metadata || ''
    );
  }

  // Send to Axiom if configured
  if (axiom) {
    try {
      await axiom.ingest(dataset, [enrichedEntry]);
    } catch (error) {
      console.error('Failed to send log to Axiom:', error);
    }
  }
}

/**
 * Log debug information
 */
export async function debug(
  message: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'debug',
    message,
    metadata,
  });
}

/**
 * Log informational message
 */
export async function info(
  message: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'info',
    message,
    metadata,
  });
}

/**
 * Log warning
 */
export async function warn(
  message: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'warn',
    message,
    metadata,
  });
}

/**
 * Log error
 */
export async function error(
  message: string,
  err?: Error | unknown,
  metadata?: Record<string, any>
): Promise<void> {
  const errorData =
    err instanceof Error
      ? {
          name: err.name,
          message: err.message,
          stack: err.stack,
        }
      : undefined;

  await log({
    level: 'error',
    message,
    error: errorData,
    metadata,
  });
}

/**
 * Log fatal error (should trigger alerts)
 */
export async function fatal(
  message: string,
  err?: Error | unknown,
  metadata?: Record<string, any>
): Promise<void> {
  const errorData =
    err instanceof Error
      ? {
          name: err.name,
          message: err.message,
          stack: err.stack,
        }
      : undefined;

  await log({
    level: 'fatal',
    message,
    error: errorData,
    metadata,
  });
}

/**
 * Business Event Loggers
 * These log important business events for analytics and auditing
 */

/**
 * Log authentication event
 */
export async function logAuth(
  event: 'login' | 'logout' | 'signup' | 'password_reset',
  userId: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'info',
    message: `User ${event}`,
    category: 'auth',
    userId,
    metadata,
  });
}

/**
 * Log payment event
 */
export async function logPayment(
  event: 'created' | 'succeeded' | 'failed' | 'refunded',
  orderId: string,
  amount: number,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: event === 'failed' ? 'error' : 'info',
    message: `Payment ${event}`,
    category: 'payment',
    orderId,
    metadata: {
      ...metadata,
      amount,
      currency: 'USD',
    },
  });
}

/**
 * Log OFAC screening
 */
export async function logOfacScreening(
  name: string,
  result: 'clear' | 'potential_match' | 'blocked',
  orderId?: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: result === 'blocked' ? 'warn' : 'info',
    message: `OFAC screening: ${result}`,
    category: 'ofac',
    orderId,
    metadata: {
      ...metadata,
      screenedName: name,
      result,
    },
  });
}

/**
 * Log notification sent
 */
export async function logNotification(
  type: 'email' | 'sms' | 'whatsapp',
  recipient: string,
  success: boolean,
  orderId?: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: success ? 'info' : 'error',
    message: `Notification ${success ? 'sent' : 'failed'}: ${type}`,
    category: 'notification',
    orderId,
    metadata: {
      ...metadata,
      type,
      recipient: recipient.replace(/\d(?=\d{4})/g, '*'), // Mask phone/email
      success,
    },
  });
}

/**
 * Log API request
 */
export async function logApiRequest(
  method: string,
  url: string,
  statusCode: number,
  duration: number,
  userId?: string,
  metadata?: Record<string, any>
): Promise<void> {
  const level = statusCode >= 500 ? 'error' : statusCode >= 400 ? 'warn' : 'info';

  await log({
    level,
    message: `${method} ${url} ${statusCode}`,
    category: 'api',
    userId,
    method,
    url,
    statusCode,
    duration,
    metadata,
  });
}

/**
 * Log configuration change
 */
export async function logConfigChange(
  key: string,
  action: 'created' | 'updated' | 'deleted',
  userId: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'info',
    message: `Configuration ${action}: ${key}`,
    category: 'config',
    userId,
    metadata: {
      ...metadata,
      configKey: key,
      action,
    },
  });
}

/**
 * Log security event
 */
export async function logSecurity(
  event: string,
  severity: 'low' | 'medium' | 'high' | 'critical',
  userId?: string,
  metadata?: Record<string, any>
): Promise<void> {
  const levelMap = {
    low: 'info' as LogLevel,
    medium: 'warn' as LogLevel,
    high: 'error' as LogLevel,
    critical: 'fatal' as LogLevel,
  };

  await log({
    level: levelMap[severity],
    message: `Security: ${event}`,
    category: 'security',
    userId,
    metadata: {
      ...metadata,
      severity,
    },
  });
}

/**
 * Log rate limit violation
 */
export async function logRateLimit(
  endpoint: string,
  identifier: string,
  limit: number,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'warn',
    message: `Rate limit exceeded: ${endpoint}`,
    category: 'security',
    metadata: {
      ...metadata,
      endpoint,
      identifier,
      limit,
    },
  });
}

/**
 * Log performance metrics
 */
export async function logPerformance(
  metric: string,
  value: number,
  url?: string,
  metadata?: Record<string, any>
): Promise<void> {
  await log({
    level: 'info',
    message: `Performance: ${metric}`,
    category: 'performance',
    url,
    metadata: {
      ...metadata,
      metric,
      value,
      unit: 'ms',
    },
  });
}

/**
 * Flush logs to Axiom
 * Call this at the end of serverless functions
 */
export async function flush(): Promise<void> {
  if (axiom) {
    try {
      await axiom.flush();
    } catch (error) {
      console.error('Failed to flush logs to Axiom:', error);
    }
  }
}

/**
 * Helper to wrap async functions with error logging
 */
export function withLogging<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  context?: string
): T {
  return (async (...args: Parameters<T>) => {
    const startTime = Date.now();
    try {
      const result = await fn(...args);
      const duration = Date.now() - startTime;

      if (duration > 3000) {
        // Log slow operations
        await warn(`Slow operation: ${context || fn.name}`, {
          duration,
          functionName: fn.name,
        });
      }

      return result;
    } catch (err) {
      const duration = Date.now() - startTime;
      await error(
        `Error in ${context || fn.name}`,
        err as Error,
        {
          duration,
          functionName: fn.name,
        }
      );
      throw err;
    } finally {
      await flush();
    }
  }) as T;
}

/**
 * Request logger middleware helper
 */
export function createRequestLogger() {
  const startTime = Date.now();

  return {
    log: async (
      request: Request,
      response: Response,
      userId?: string
    ): Promise<void> => {
      const duration = Date.now() - startTime;
      const url = new URL(request.url);

      await logApiRequest(
        request.method,
        url.pathname,
        response.status,
        duration,
        userId,
        {
          query: Object.fromEntries(url.searchParams),
          userAgent: request.headers.get('user-agent'),
          ipAddress: request.headers.get('x-forwarded-for'),
        }
      );

      await flush();
    },
  };
}

export default {
  debug,
  info,
  warn,
  error,
  fatal,
  logAuth,
  logPayment,
  logOfacScreening,
  logNotification,
  logApiRequest,
  logConfigChange,
  logSecurity,
  logRateLimit,
  logPerformance,
  flush,
  withLogging,
  createRequestLogger,
};
