import { Ratelimit } from '@upstash/ratelimit';
import { redis, isRedisAvailable } from '@/lib/redis';
import { NextResponse } from 'next/server';

/**
 * Rate Limiting System
 *
 * Protects API endpoints from abuse using sliding window algorithm
 *
 * Strategies:
 * - Sliding Window: Most accurate, prevents bursts
 * - Fixed Window: Simple, resets at fixed intervals
 * - Token Bucket: Allows controlled bursts
 */

export type RateLimitTier = 'strict' | 'moderate' | 'relaxed' | 'admin';

/**
 * Rate limit configurations for different tiers
 */
const RATE_LIMIT_CONFIGS = {
  // Critical endpoints: Payment, OFAC screening
  strict: {
    requests: 10,
    window: '1 m', // 10 requests per minute
  },
  // Standard API endpoints
  moderate: {
    requests: 30,
    window: '1 m', // 30 requests per minute
  },
  // Public endpoints: marketplace, products
  relaxed: {
    requests: 100,
    window: '1 m', // 100 requests per minute
  },
  // Admin endpoints
  admin: {
    requests: 200,
    window: '1 m', // 200 requests per minute
  },
} as const;

/**
 * Create rate limiter for a specific tier
 */
function createRateLimiter(tier: RateLimitTier) {
  if (!redis) {
    return null; // Rate limiting disabled if Redis not configured
  }

  const config = RATE_LIMIT_CONFIGS[tier];

  return new Ratelimit({
    redis,
    limiter: Ratelimit.slidingWindow(config.requests, config.window),
    analytics: true, // Enable analytics in Upstash console
    prefix: `ratelimit:${tier}`,
  });
}

// Create rate limiters for each tier
export const strictRateLimit = createRateLimiter('strict');
export const moderateRateLimit = createRateLimiter('moderate');
export const relaxedRateLimit = createRateLimiter('relaxed');
export const adminRateLimit = createRateLimiter('admin');

/**
 * Rate limit result
 */
export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: number; // Unix timestamp when limit resets
  retryAfter?: number; // Seconds to wait before retrying
}

/**
 * Apply rate limiting to a request
 *
 * @param identifier - Unique identifier (user ID, IP, etc.)
 * @param tier - Rate limit tier
 * @returns Rate limit result
 */
export async function rateLimit(
  identifier: string,
  tier: RateLimitTier = 'moderate'
): Promise<RateLimitResult> {
  // If Redis not available, allow request (graceful degradation)
  if (!isRedisAvailable()) {
    console.warn('Rate limiting skipped: Redis not available');
    return {
      success: true,
      limit: 9999,
      remaining: 9999,
      reset: Date.now() + 60000,
    };
  }

  // Get rate limiter for tier
  const limiter =
    tier === 'strict'
      ? strictRateLimit
      : tier === 'moderate'
      ? moderateRateLimit
      : tier === 'relaxed'
      ? relaxedRateLimit
      : adminRateLimit;

  if (!limiter) {
    // Should never happen, but handle gracefully
    return {
      success: true,
      limit: 9999,
      remaining: 9999,
      reset: Date.now() + 60000,
    };
  }

  try {
    const result = await limiter.limit(identifier);

    return {
      success: result.success,
      limit: result.limit,
      remaining: result.remaining,
      reset: result.reset,
      retryAfter: result.success ? undefined : Math.ceil((result.reset - Date.now()) / 1000),
    };
  } catch (error) {
    console.error('Rate limit error:', error);
    // On error, allow request (fail open)
    return {
      success: true,
      limit: 9999,
      remaining: 9999,
      reset: Date.now() + 60000,
    };
  }
}

/**
 * Get identifier from request
 *
 * Priority:
 * 1. User ID (if authenticated)
 * 2. IP address
 * 3. Fallback to 'anonymous'
 */
export function getIdentifier(
  request: Request,
  userId?: string | null
): string {
  if (userId) {
    return `user:${userId}`;
  }

  // Get IP from headers (works with Vercel and most proxies)
  const forwarded = request.headers.get('x-forwarded-for');
  const ip = forwarded ? forwarded.split(',')[0].trim() :
             request.headers.get('x-real-ip') ||
             'anonymous';

  return `ip:${ip}`;
}

/**
 * Create rate limit response with headers
 */
export function createRateLimitResponse(
  result: RateLimitResult,
  response?: NextResponse
): NextResponse {
  const headers = new Headers(response?.headers || {});

  // Add rate limit headers
  headers.set('X-RateLimit-Limit', result.limit.toString());
  headers.set('X-RateLimit-Remaining', result.remaining.toString());
  headers.set('X-RateLimit-Reset', result.reset.toString());

  if (!result.success && result.retryAfter) {
    headers.set('Retry-After', result.retryAfter.toString());

    return NextResponse.json(
      {
        error: 'Too Many Requests',
        message: `Rate limit exceeded. Please try again in ${result.retryAfter} seconds.`,
        retryAfter: result.retryAfter,
        limit: result.limit,
        reset: result.reset,
      },
      {
        status: 429,
        headers,
      }
    );
  }

  // If response provided, add headers to it
  if (response) {
    headers.forEach((value, key) => {
      response.headers.set(key, value);
    });
    return response;
  }

  // Create new success response with headers
  return NextResponse.json(
    { success: true },
    { headers }
  );
}

/**
 * Rate limit middleware helper
 *
 * Usage in API route:
 * ```typescript
 * export async function POST(request: Request) {
 *   const limitResult = await checkRateLimit(request, 'strict');
 *   if (!limitResult.success) {
 *     return createRateLimitResponse(limitResult);
 *   }
 *
 *   // Continue with request...
 *   const response = NextResponse.json({ data: '...' });
 *   return createRateLimitResponse(limitResult, response);
 * }
 * ```
 */
export async function checkRateLimit(
  request: Request,
  tier: RateLimitTier = 'moderate',
  userId?: string | null
): Promise<RateLimitResult> {
  const identifier = getIdentifier(request, userId);
  return await rateLimit(identifier, tier);
}

/**
 * Custom rate limit for specific use cases
 *
 * @param identifier - Unique identifier
 * @param maxRequests - Maximum requests allowed
 * @param windowMs - Time window in milliseconds
 */
export async function customRateLimit(
  identifier: string,
  maxRequests: number,
  windowMs: number
): Promise<RateLimitResult> {
  if (!redis) {
    return {
      success: true,
      limit: maxRequests,
      remaining: maxRequests,
      reset: Date.now() + windowMs,
    };
  }

  try {
    const limiter = new Ratelimit({
      redis,
      limiter: Ratelimit.slidingWindow(maxRequests, `${windowMs}ms`),
      prefix: 'ratelimit:custom',
    });

    const result = await limiter.limit(identifier);

    return {
      success: result.success,
      limit: result.limit,
      remaining: result.remaining,
      reset: result.reset,
      retryAfter: result.success ? undefined : Math.ceil((result.reset - Date.now()) / 1000),
    };
  } catch (error) {
    console.error('Custom rate limit error:', error);
    return {
      success: true,
      limit: maxRequests,
      remaining: maxRequests,
      reset: Date.now() + windowMs,
    };
  }
}

/**
 * Rate limit configuration info
 */
export function getRateLimitInfo(tier: RateLimitTier) {
  const config = RATE_LIMIT_CONFIGS[tier];
  return {
    tier,
    requests: config.requests,
    window: config.window,
    description: `${config.requests} requests per ${config.window}`,
  };
}

/**
 * Get all rate limit configurations
 */
export function getAllRateLimitInfo() {
  return Object.entries(RATE_LIMIT_CONFIGS).map(([tier, config]) => ({
    tier,
    requests: config.requests,
    window: config.window,
    description: `${config.requests} requests per ${config.window}`,
  }));
}
