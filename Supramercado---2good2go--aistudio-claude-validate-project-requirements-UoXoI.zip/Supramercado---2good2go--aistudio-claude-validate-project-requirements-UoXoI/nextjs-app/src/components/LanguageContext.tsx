'use client';

import React, { createContext, useContext, useState } from 'react';

type Language = 'ES' | 'EN';

interface LanguageContextType {
  lang: Language;
  setLang: (l: Language) => void;
  t: (key: string) => string;
}

const TRANSLATIONS = {
  ES: {
    welcome: "¡Hola Pedro!",
    explore: "Tiendas RD",
    impact: "Impacto",
    send_bag: "Envía una Suprabolsa hoy",
    ver_comercios: "Ver Comercios",
    beneficiary: "Cuidando de...",
    active_shipments: "Mis Envíos Activos",
    help_family: "Guía para mi familia",
    support_chat: "¿Necesitas ayuda con tu retiro?",
    expired_notice: "Este ticket expira en 24h",
  },
  EN: {
    welcome: "Hello Pedro!",
    explore: "DR Stores",
    impact: "Impact",
    send_bag: "Send a Suprabag today",
    ver_comercios: "Browse Stores",
    beneficiary: "Caring for...",
    active_shipments: "My Active Shipments",
    help_family: "Guide my family",
    support_chat: "Need help with your pickup?",
    expired_notice: "This ticket expires in 24h",
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLang] = useState<Language>('ES');
  const t = (key: string) => (TRANSLATIONS[lang] as any)[key] || key;

  return (
    <LanguageContext.Provider value={{ lang, setLang, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useTranslation must be used within LanguageProvider');
  return context;
};
