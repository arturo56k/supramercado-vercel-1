'use client';

import React, { useState } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { Volume2, Play, Loader2, MessageCircleHeart, Sparkles } from 'lucide-react';

interface VoiceGreetingProps {
  senderName: string;
  beneficiaryName: string;
  isMagicLink?: boolean;
}

export const VoiceGreeting: React.FC<VoiceGreetingProps> = ({ senderName, beneficiaryName, isMagicLink }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const playGreeting = async () => {
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `Genera un mensaje de voz cálido y dominicano. 
      De: ${senderName} para su familiar ${beneficiaryName}. 
      Dice: "${beneficiaryName}, te envié esta compra con mucho cariño para que no te falte nada. ¡Te quiero mucho!".
      Usa un tono alegre y protector.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        const binary = atob(base64Audio);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        
        const dataInt16 = new Int16Array(bytes.buffer);
        const buffer = audioCtx.createBuffer(1, dataInt16.length, 24000);
        const channelData = buffer.getChannelData(0);
        for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
        
        const source = audioCtx.createBufferSource();
        source.buffer = buffer;
        source.connect(audioCtx.destination);
        setIsPlaying(true);
        source.onended = () => setIsPlaying(false);
        source.start();
      }
    } catch (error) {
      console.error("Greeting error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`p-6 rounded-[2rem] border-2 transition-all ${isMagicLink ? 'bg-indigo-50 border-indigo-100' : 'bg-white border-slate-100 shadow-sm'}`}>
      <div className="flex items-center gap-4">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${isMagicLink ? 'bg-indigo-600 text-white' : 'bg-pink-100 text-pink-600'}`}>
          {isLoading ? <Loader2 className="w-6 h-6 animate-spin" /> : <MessageCircleHeart className="w-6 h-6" />}
        </div>
        <div className="flex-1">
          <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Mensaje Personalizado</p>
          <h4 className={`font-black ${isMagicLink ? 'text-indigo-900' : 'text-slate-900'}`}>
            De: {senderName}
          </h4>
        </div>
        <button 
          onClick={playGreeting}
          disabled={isLoading || isPlaying}
          className={`px-6 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 transition-all shadow-md ${isPlaying ? 'bg-slate-900 text-white' : 'bg-white text-slate-900 hover:scale-105'}`}
        >
          {isPlaying ? 'Escuchando...' : 'Escuchar Voz'}
          <Volume2 className="w-4 h-4" />
        </button>
      </div>
      {isMagicLink && (
        <div className="mt-4 flex items-center gap-2 text-[10px] font-black text-indigo-400 uppercase tracking-widest justify-center">
          <Sparkles className="w-3 h-3" /> Audio generado por Supramercado AI
        </div>
      )}
    </div>
  );
};
