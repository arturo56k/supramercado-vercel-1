'use client';

import React from 'react';
import { Printer, Download, X } from 'lucide-react';
import { Order, Merchant } from '../types';

interface ReceiptPrinterProps {
  order: Order;
  merchant: Merchant;
  onClose: () => void;
}

export const ReceiptPrinter: React.FC<ReceiptPrinterProps> = ({ order, merchant, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const ncf = `B02${Math.floor(10000000 + Math.random() * 90000000)}`;

  return (
    <div className="fixed inset-0 z-[500] flex items-center justify-center p-4 bg-slate-900/90 backdrop-blur-md print:bg-white print:p-0">
      <div className="bg-white w-full max-w-sm rounded-[2rem] overflow-hidden shadow-2xl print:shadow-none print:rounded-none animate-in zoom-in">
        <div className="p-4 bg-slate-100 flex justify-between items-center print:hidden">
          <h4 className="font-black text-xs uppercase tracking-widest text-slate-500">Vista de Impresión</h4>
          <button onClick={onClose} className="p-1 hover:bg-slate-200 rounded-full"><X className="w-5 h-5" /></button>
        </div>
        
        {/* Estilo Ticket Térmico */}
        <div id="thermal-receipt" className="p-8 bg-white text-black font-mono text-[12px] leading-tight">
          <div className="text-center space-y-1 mb-6">
            <h2 className="text-lg font-bold uppercase">{merchant.name}</h2>
            <p>RNC: {merchant.rnc || '131-XXXXX-X'}</p>
            <p>{merchant.address}</p>
            <p>{merchant.city}, RD</p>
            <p>TEL: 809-555-0123</p>
          </div>

          <div className="border-t border-dashed border-black py-4 space-y-1">
            <div className="flex justify-between"><span>FACTURA:</span> <span>#{order.id.split('-')[1]}</span></div>
            <div className="flex justify-between"><span>FECHA:</span> <span>{new Date().toLocaleDateString()}</span></div>
            <div className="flex justify-between font-bold"><span>NCF:</span> <span>{ncf}</span></div>
            <div className="flex justify-between"><span>CAJERO:</span> <span>Terminal 01</span></div>
          </div>

          <div className="border-t border-dashed border-black py-4">
            <p className="mb-2 font-bold uppercase">DESCRIPCIÓN DE VÍVERES</p>
            <div className="space-y-1">
              {order.items.split(',').map((item, i) => (
                <div key={i} className="flex justify-between">
                  <span className="truncate max-w-[150px]">{item.trim()}</span>
                  <span>--</span>
                </div>
              ))}
            </div>
          </div>

          <div className="border-t border-dashed border-black py-4 space-y-2">
            <div className="flex justify-between text-base font-bold">
              <span>TOTAL RD$:</span>
              <span>RD$ {(order.subtotalUSD * order.exchangeRateUsed).toLocaleString()}</span>
            </div>
            <div className="flex justify-between italic text-[10px]">
              <span>PAGADO EN USD:</span>
              <span>${order.totalUSD.toFixed(2)}</span>
            </div>
            <p className="text-[9px] mt-2 opacity-70">Tasa: 1 USD = RD$ {order.exchangeRateUsed.toFixed(2)}</p>
          </div>

          <div className="text-center mt-6 space-y-2 border-t border-dashed border-black pt-4">
            <p className="font-bold">¡GRACIAS POR USAR SUPRA!</p>
            <p>Remesas directas NY -> RD</p>
            <div className="flex justify-center py-2">
               <div className="w-24 h-24 border border-black flex items-center justify-center text-[8px]">QR SUPRA VALIDADO</div>
            </div>
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t flex gap-4 print:hidden">
          <button 
            onClick={handlePrint}
            className="flex-1 bg-slate-900 text-white py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2"
          >
            <Printer className="w-4 h-4" /> Imprimir Ticket
          </button>
          <button className="flex-1 bg-white border border-slate-200 text-slate-900 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2">
            <Download className="w-4 h-4" /> Guardar PDF
          </button>
        </div>
      </div>

      <style>{`
        @media print {
          body * { visibility: hidden; }
          #thermal-receipt, #thermal-receipt * { visibility: visible; }
          #thermal-receipt {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0;
            padding: 20px;
          }
        }
      `}</style>
    </div>
  );
};
