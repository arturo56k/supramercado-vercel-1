'use client';

import React, { useState, useEffect } from 'react';
import { Cloud, CloudOff, RefreshCw, CheckCircle2 } from 'lucide-react';

export const SyncMonitor: React.FC = () => {
  const [pendingCount, setPendingCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const updateQueue = () => {
      const queue = JSON.parse(localStorage.getItem('supra_offline_redemptions') || '[]');
      setPendingCount(queue.length);
    };

    const interval = setInterval(updateQueue, 2000);
    window.addEventListener('online', () => setIsSyncing(true));
    
    return () => clearInterval(interval);
  }, []);

  if (pendingCount === 0 && !isSyncing) return null;

  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[400] animate-in slide-in-from-bottom-4">
      <div className={`px-6 py-3 rounded-full border shadow-2xl flex items-center gap-3 backdrop-blur-xl transition-all ${pendingCount > 0 ? 'bg-orange-500 text-white border-orange-400' : 'bg-green-600 text-white border-green-500'}`}>
        {pendingCount > 0 ? (
          <RefreshCw className="w-4 h-4 animate-spin" />
        ) : (
          <CheckCircle2 className="w-4 h-4" />
        )}
        <span className="text-[10px] font-black uppercase tracking-widest">
          {pendingCount > 0 ? `${pendingCount} Sincronizaciones Pendientes` : 'Sincronizado con la Nube'}
        </span>
        {pendingCount > 0 ? <CloudOff className="w-4 h-4 opacity-50" /> : <Cloud className="w-4 h-4 opacity-50" />}
      </div>
    </div>
  );
};
