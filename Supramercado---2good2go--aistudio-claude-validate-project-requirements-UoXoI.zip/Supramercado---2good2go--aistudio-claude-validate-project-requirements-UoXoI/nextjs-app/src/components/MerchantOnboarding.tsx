'use client';

import React, { useState } from 'react';
import { 
  Building2, MapPin, Landmark, ArrowRight, CheckCircle2, 
  Camera, Upload, ShieldCheck, Store, Info, Phone
} from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';
import { Merchant } from '../types';

export const MerchantOnboarding: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const { registerMerchant } = useOrders();
  const { notify } = useNotify();
  const [formData, setFormData] = useState<Partial<Merchant>>({
    name: '',
    description: '',
    address: '',
    city: 'Santiago',
    categories: ['Groceries'],
    closingTime: '21:00',
    logo: 'https://images.unsplash.com/photo-1534723452862-4c874018d66d?auto=format&fit=crop&q=80&w=400',
    rating: 5.0,
    isOpen: true,
    status: 'PENDING_KYC',
    walletBalance: 0
  });

  const handleComplete = () => {
    const newMerchant: Merchant = {
      ...formData as Merchant,
      id: `m-${Date.now()}`,
      lat: 19.45,
      lng: -70.70,
    };
    registerMerchant(newMerchant);
    notify("Solicitud Enviada", "Nuestro equipo verificará tu RNC en las próximas 24h.", "SUCCESS");
    onComplete();
  };

  return (
    <div className="max-w-xl mx-auto space-y-8 animate-in fade-in zoom-in duration-500 pb-24">
      <div className="text-center space-y-4">
        <div className="w-20 h-20 bg-blue-700 rounded-3xl flex items-center justify-center text-white mx-auto shadow-2xl">
          <Store className="w-10 h-10" />
        </div>
        <h2 className="text-3xl font-black text-slate-900 tracking-tight">Vende a la Diáspora</h2>
        <p className="text-slate-500 font-medium">Únete a la red de Supramercado en 3 pasos.</p>
      </div>

      {/* Progress Bar */}
      <div className="flex justify-between px-4 relative">
        <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 -z-10"></div>
        {[1, 2, 3].map(s => (
          <div key={s} className={`w-10 h-10 rounded-full flex items-center justify-center font-black transition-all ${step >= s ? 'bg-blue-700 text-white shadow-lg scale-110' : 'bg-white text-slate-300 border-2 border-slate-100'}`}>
            {s}
          </div>
        ))}
      </div>

      <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-xl space-y-8">
        {step === 1 && (
          <div className="space-y-6 animate-in slide-in-from-right-4">
            <h3 className="text-xl font-black flex items-center gap-2"><Building2 className="w-6 h-6 text-blue-700" /> Datos del Negocio</h3>
            <div className="space-y-4">
              <Input label="Nombre Comercial" placeholder="Colmado La Fe" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
              <Input label="RNC (Opcional)" placeholder="101-00000-1" value={formData.rnc} onChange={v => setFormData({...formData, rnc: v})} />
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Categoría Principal</label>
                <select className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold appearance-none outline-none focus:border-blue-500" onChange={e => setFormData({...formData, category: e.target.value})}>
                  <option value="Groceries">Supermercado / Colmado</option>
                  <option value="Health">Farmacia</option>
                  <option value="Local">Tienda de Repuestos / Ferretería</option>
                </select>
              </div>
            </div>
            <button onClick={() => setStep(2)} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2">Siguiente <ArrowRight className="w-4 h-4" /></button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-in slide-in-from-right-4">
            <h3 className="text-xl font-black flex items-center gap-2"><MapPin className="w-6 h-6 text-orange-600" /> Ubicación en RD</h3>
            <div className="space-y-4">
               <Input label="Dirección Física" placeholder="Av. Juan Pablo Duarte #10, Santiago" value={formData.address} onChange={v => setFormData({...formData, address: v})} />
               <div className="bg-slate-50 h-48 rounded-[2rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-2">
                  <MapPin className="w-8 h-8 text-slate-300" />
                  <p className="text-xs font-black text-slate-400 uppercase">Mapa: Toca para marcar GPS</p>
               </div>
               <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 shrink-0" />
                  <p className="text-[10px] font-bold text-blue-800 leading-relaxed uppercase">La precisión GPS permite que el asistente de IA recomiende tu tienda a clientes cercanos en USA.</p>
               </div>
            </div>
            <div className="flex gap-4">
              <button onClick={() => setStep(1)} className="flex-1 bg-slate-100 text-slate-400 py-5 rounded-2xl font-black text-xs uppercase">Atrás</button>
              <button onClick={() => setStep(3)} className="flex-2 bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase flex items-center justify-center gap-2">Casi Listo <ArrowRight className="w-4 h-4" /></button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 text-center">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
               <ShieldCheck className="w-10 h-10" />
            </div>
            <h3 className="text-2xl font-black">Validación Stripe RD</h3>
            <p className="text-sm text-slate-500 font-medium">Para recibir pagos en USD convertidos a DOP, necesitamos verificar tu cuenta bancaria o Cédula Dominicana.</p>
            <div className="p-6 border-2 border-dashed border-slate-200 rounded-[2.5rem] flex flex-col items-center gap-4 group cursor-pointer hover:border-blue-500 transition-all">
               <Upload className="w-8 h-8 text-slate-300 group-hover:text-blue-500 transition-colors" />
               <p className="text-xs font-black text-slate-400 uppercase">Subir Foto de Cédula / RNC</p>
            </div>
            <button onClick={handleComplete} className="w-full bg-blue-700 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-2xl shadow-blue-700/30">COMPLETAR REGISTRO</button>
          </div>
        )}
      </div>
    </div>
  );
};

const Input = ({ label, placeholder, value, onChange }: any) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
    <input 
      type="text" 
      placeholder={placeholder}
      className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold outline-none focus:border-blue-500 transition-colors"
      value={value}
      onChange={e => onChange(e.target.value)}
    />
  </div>
);
