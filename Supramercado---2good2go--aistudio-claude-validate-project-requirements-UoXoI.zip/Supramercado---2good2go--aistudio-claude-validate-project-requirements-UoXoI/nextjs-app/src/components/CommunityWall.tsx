'use client';

import React, { useState, useEffect } from 'react';
import { Heart, MessageCircle, Share2, Sparkles, Quote } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

const MOCK_NOTES = [
  { id: '1', sender: 'Doña Altagracia', city: 'Santiago', text: 'Gracias a mi hija en NY por esta compra, ya tenemos la cena de hoy asegurada. ¡Bendiciones!', likes: 24 },
  { id: '2', sender: 'Juan Carlos', city: 'Bonao', text: 'El Magic Link funcionó de una vez. Gracias bro por no olvidarte de nosotros.', likes: 12 },
];

export const CommunityWall: React.FC = () => {
  const [aiQuote, setAiQuote] = useState<string | null>(null);

  useEffect(() => {
    const fetchInspiration = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: 'Genera un mensaje corto e inspirador sobre la solidaridad dominicana y la diáspora. Máximo 15 palabras.',
        });
        setAiQuote(response.text || null);
      } catch (e) {
        console.warn("AI Quote failed");
      }
    };
    fetchInspiration();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-2">
        <h4 className="font-black text-2xl text-slate-900 flex items-center gap-2">
          <MessageCircle className="w-6 h-6 text-orange-500" /> Muro de Gratitud
        </h4>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">En vivo desde RD</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {MOCK_NOTES.map(note => (
          <div key={note.id} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm hover:shadow-xl transition-all group">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-black">
                {note.sender.charAt(0)}
              </div>
              <div>
                <p className="text-sm font-black text-slate-900">{note.sender}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{note.city}, RD</p>
              </div>
            </div>
            <div className="relative">
              <Quote className="absolute -top-2 -left-2 w-8 h-8 text-slate-50 opacity-50" />
              <p className="text-sm text-slate-600 font-medium italic relative z-10 leading-relaxed">"{note.text}"</p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-50 flex items-center justify-between">
              <button className="flex items-center gap-2 text-pink-500 font-black text-[10px] uppercase">
                <Heart className="w-4 h-4 fill-pink-500" /> {note.likes} gracias
              </button>
              <button className="text-slate-300 hover:text-blue-700 transition-colors">
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {aiQuote && (
        <div className="bg-orange-500 p-6 rounded-[2rem] text-white flex items-center gap-4 shadow-xl shadow-orange-500/20">
          <Sparkles className="w-8 h-8 shrink-0 animate-pulse" />
          <p className="text-sm font-black italic">"{aiQuote}"</p>
        </div>
      )}
    </div>
  );
};
