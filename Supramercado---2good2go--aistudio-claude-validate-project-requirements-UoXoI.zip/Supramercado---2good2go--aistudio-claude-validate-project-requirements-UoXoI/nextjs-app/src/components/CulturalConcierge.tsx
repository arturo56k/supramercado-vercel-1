'use client';

import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Info, Sparkles, Loader2, X, UtensilsCrossed } from 'lucide-react';
import { Product } from '../types';

interface CulturalConciergeProps {
  product: Product;
  onClose: () => void;
}

export const CulturalConcierge: React.FC<CulturalConciergeProps> = ({ product, onClose }) => {
  const [explanation, setExplanation] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  React.useEffect(() => {
    const getExplanation = async () => {
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: `Explica la importancia cultural o el uso gastronómico típico en República Dominicana del producto: ${product.name}. Sé breve, cálido y menciona un plato típico relacionado.`,
        });
        setExplanation(response.text || "Un básico esencial de la cocina dominicana.");
      } catch (e) {
        setExplanation("Un producto de alta calidad seleccionado para tu familia.");
      } finally {
        setIsLoading(false);
      }
    };
    getExplanation();
  }, [product]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in duration-300 relative border border-slate-100">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 text-slate-300 hover:text-slate-900">
          <X className="w-6 h-6" />
        </button>
        
        <div className="flex items-center gap-4 mb-6">
          <div className="w-12 h-12 bg-orange-100 text-orange-600 rounded-2xl flex items-center justify-center">
            <UtensilsCrossed className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-black text-lg text-slate-900 leading-tight">Cultura en la Canasta</h4>
            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Glosario Dominicano AI</p>
          </div>
        </div>

        <div className="bg-slate-50 rounded-3xl p-6 border border-slate-100 min-h-[120px] flex items-center justify-center">
          {isLoading ? (
            <Loader2 className="w-8 h-8 text-blue-700 animate-spin" />
          ) : (
            <p className="text-slate-700 font-medium italic text-center leading-relaxed">
              "{explanation}"
            </p>
          )}
        </div>
        
        <div className="mt-8 flex items-center gap-2 text-blue-700 font-black text-[10px] uppercase tracking-widest justify-center">
          <Sparkles className="w-4 h-4" /> Generado con orgullo dominicano
        </div>
      </div>
    </div>
  );
};
