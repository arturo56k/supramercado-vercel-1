'use client';

import React, { useState } from 'react';
import { ShoppingBag, Package, RefreshCw, Plus, Search, AlertCircle } from 'lucide-react';
import { Product, Beneficiary } from '../types';
import { useOrders } from './OrderContext';
import { CulturalConcierge } from './CulturalConcierge';

interface MarketplaceProps {
  selectedBeneficiary: Beneficiary | null;
  onAddToCart: (product: Product) => void;
}

export const Marketplace: React.FC<MarketplaceProps> = ({ selectedBeneficiary, onAddToCart }) => {
  const { products } = useOrders();
  const [activeType, setActiveType] = useState<'INDIVIDUAL' | 'PACK' | 'SUBSCRIPTION'>('INDIVIDUAL');
  const [search, setSearch] = useState('');
  const [inspectedProduct, setInspectedProduct] = useState<Product | null>(null);

  const filteredProducts = products.filter(p => {
    const typeMatch = p.type === (activeType === 'PACK' ? 'PREDESIGNED_PACK' : activeType);
    const searchMatch = p.name.toLowerCase().includes(search.toLowerCase());
    // Filtro por ciudad si hay beneficiario (opcional para el MVP)
    return typeMatch && searchMatch;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      {!selectedBeneficiary && (
        <div className="bg-orange-50 border-2 border-orange-100 p-6 rounded-[2rem] flex items-center gap-4 text-orange-800 animate-bounce">
          <AlertCircle className="w-8 h-8 shrink-0" />
          <p className="font-black text-sm uppercase tracking-widest">Debes seleccionar a un familiar para ver productos disponibles en su zona.</p>
        </div>
      )}

      {/* Controles de Vista */}
      <div className="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-sm flex flex-col md:flex-row gap-6 items-center">
        <div className="relative flex-1 w-full">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input 
            type="text" 
            placeholder={`¿Qué falta en la despensa de ${selectedBeneficiary?.name || 'la familia'}?`}
            className="w-full pl-12 pr-4 py-4 bg-slate-50 border-none rounded-2xl outline-none font-bold text-sm text-slate-900"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <div className="flex bg-slate-100 p-1.5 rounded-2xl w-full md:w-auto overflow-x-auto scrollbar-hide">
          <TabButton active={activeType === 'INDIVIDUAL'} onClick={() => setActiveType('INDIVIDUAL')} icon={ShoppingBag} label="Unidades" />
          <TabButton active={activeType === 'PACK'} onClick={() => setActiveType('PACK')} icon={Package} label="Packs Ahorro" />
          <TabButton active={activeType === 'SUBSCRIPTION'} onClick={() => setActiveType('SUBSCRIPTION')} icon={RefreshCw} label="Suscripción" />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-8">
        {filteredProducts.map((product) => (
          <div key={product.id} className="group flex flex-col gap-4">
            <div className="relative aspect-square w-full rounded-[2.5rem] overflow-hidden bg-slate-100 shadow-sm transition-all group-hover:shadow-2xl">
              <img 
                src={product.image} 
                className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 ${product.stock === 0 ? 'grayscale opacity-50' : ''}`} 
                alt={product.name}
              />
              
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                 <button 
                  onClick={() => setInspectedProduct(product)}
                  className="bg-white/20 backdrop-blur-md text-white p-4 rounded-2xl hover:bg-white/40 transition-all"
                 >
                   <Search className="w-5 h-5" />
                 </button>
                 {product.stock > 0 && (
                   <button 
                    onClick={() => onAddToCart(product)}
                    className="bg-blue-600 text-white p-4 rounded-2xl shadow-xl hover:scale-110 transition-all"
                   >
                     <Plus className="w-5 h-5" />
                   </button>
                 )}
              </div>

              {product.stock <= 5 && product.stock > 0 && (
                <div className="absolute top-4 right-4 bg-orange-500 text-white px-3 py-1 rounded-xl text-[8px] font-black uppercase tracking-widest shadow-lg">
                  Últimas {product.stock}
                </div>
              )}
              {product.stock === 0 && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px]">
                   <span className="bg-white text-slate-900 px-6 py-2 rounded-full font-black text-xs uppercase tracking-widest">Agotado</span>
                </div>
              )}
            </div>
            
            <div className="px-1 space-y-1">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-black text-blue-600 uppercase tracking-[0.15em]">{product.category}</span>
                {product.type === 'SUBSCRIPTION' && <span className="text-[8px] font-black text-green-500 uppercase">Ahorra 10%</span>}
              </div>
              <h4 className="font-black text-slate-900 text-sm truncate">{product.name}</h4>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-lg font-black text-slate-900">${product.priceUSD.toFixed(2)}</span>
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">USD</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {inspectedProduct && (
        <CulturalConcierge product={inspectedProduct} onClose={() => setInspectedProduct(null)} />
      )}
    </div>
  );
};

const TabButton = ({ active, onClick, icon: Icon, label }: any) => (
  <button 
    onClick={onClick}
    className={`flex items-center gap-2 px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${active ? 'bg-slate-900 text-white shadow-sm scale-105' : 'text-slate-400 hover:text-slate-600'}`}
  >
    <Icon className={`w-4 h-4 ${active ? 'text-blue-500' : ''}`} /> {label}
  </button>
);
