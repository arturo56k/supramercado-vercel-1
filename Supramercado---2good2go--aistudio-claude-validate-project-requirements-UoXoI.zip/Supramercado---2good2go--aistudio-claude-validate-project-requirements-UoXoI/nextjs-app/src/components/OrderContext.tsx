'use client';

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { Order, Merchant, Product, SupportTicket, Subscription, FinancialConfig, Payout, OrderReview } from '../types';
import { MOCK_MERCHANTS, MOCK_PRODUCTS } from '../constants';

interface OrderContextType {
  orders: Order[];
  merchants: Merchant[];
  products: Product[];
  tickets: SupportTicket[];
  subscriptions: Subscription[];
  payouts: Payout[];
  reviews: OrderReview[];
  financialConfig: FinancialConfig;
  isSyncing: boolean;
  cloudSync: { latencyMs: number };
  totalImpactKg: number;
  addOrder: (order: Order) => void;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  cancelOrder: (id: string) => void;
  getOrderByCode: (code: string) => Order | undefined;
  calculateFinancials: (subtotalDOP: number) => { 
    totalUSD: number; 
    effectiveRate: number; 
    itbisDOP: number;
    platformFeeUSD: number;
    merchantPayoutDOP: number;
    stripeFeeUSD: number;
  };
  updateFinancialConfig: (config: FinancialConfig) => void;
  syncBpdRate: () => Promise<void>;
  addProduct: (product: Product) => void;
  removeProduct: (id: string) => void;
  registerMerchant: (merchant: Merchant) => void;
  updateMerchant: (id: string, updates: Partial<Merchant>) => void;
  addTicket: (ticket: SupportTicket) => void;
  updateTicket: (id: string, updates: Partial<SupportTicket>) => void;
  resolveDispute: (orderId: string, action: 'REFUND' | 'RELEASE') => void;
  addReview: (review: OrderReview) => void;
  reserveStock: (productId: string) => void;
  redeemOrder: (code: string, image?: string, coords?: { lat: number, lng: number }) => { success: boolean; reason?: string; isOffline?: boolean };
  addPayout: (payout: Payout) => void;
  updateSubscription: (id: string, updates: Partial<Subscription>) => void;
  capturePayment: (paymentIntentId: string, merchantId: string) => Promise<{ success: boolean; error?: string }>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [merchants, setMerchants] = useState<Merchant[]>(MOCK_MERCHANTS);
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [reviews, setReviews] = useState<OrderReview[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);
  const [financialConfig, setFinancialConfig] = useState<FinancialConfig>({
    supraCommissionPercent: 5,
    exchangeRateMarginPercent: 2,
    stripeFeePercent: 2.9,
    stripeFixedFeeUSD: 0.30,
    lastBpdRate: 59.50,
    itbisPercent: 18,
    isManualRate: false,
  });

  const cloudSync = useMemo(() => ({ latencyMs: Math.floor(Math.random() * 50) + 10 }), []);
  const totalImpactKg = useMemo(() => orders.reduce((acc, o) => acc + (o.impactKg || 0), 0), [orders]);

  const addOrder = (order: Order) => setOrders(prev => [order, ...prev]);
  const updateOrder = (id: string, updates: Partial<Order>) => setOrders(prev => prev.map(o => o.id === id ? { ...o, ...updates } : o));
  
  const capturePayment = async (paymentIntentId: string, merchantId: string) => {
    try {
      const order = orders.find(o => o.paymentIntentId === paymentIntentId);
      const merchant = merchants.find(m => m.id === merchantId);
      
      if (!order || !merchant) return { success: false, error: "Orden o comercio no encontrado." };

      const response = await fetch('/api/stripe/capture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          paymentIntentId,
          stripeConnectedId: merchant.stripeConnectedId,
          merchantPayoutDOP: order.merchantPayoutDOP,
          platformFeeUSD: order.platformFeeUSD,
          orderId: order.id
        })
      });
      const data = await response.json();
      
      if (data.success) {
        setOrders(prev => prev.map(o => o.paymentIntentId === paymentIntentId ? { ...o, paymentStatus: 'CAPTURED', status: 'REDEEMED' } : o));
        // Actualizar balance simulado del merchant
        setMerchants(prev => prev.map(m => m.id === merchantId ? { ...m, walletBalance: (m.walletBalance || 0) + (order.merchantPayoutDOP || 0) } : m));
        return { success: true };
      }
      return { success: false, error: data.error };
    } catch (e) {
      return { success: false, error: "Error de red al capturar pago." };
    }
  };

  const cancelOrder = (id: string) => setOrders(prev => prev.map(o => o.id === id ? { ...o, status: 'CANCELLED', paymentStatus: 'CANCELLED' } : o));
  const getOrderByCode = (code: string) => orders.find(o => o.magicLinkCode === code);

  const calculateFinancials = (subtotalDOP: number) => {
    const rate = financialConfig.isManualRate && financialConfig.manualRate ? financialConfig.manualRate : financialConfig.lastBpdRate;
    const effectiveRate = rate * (1 - financialConfig.exchangeRateMarginPercent / 100);
    const itbisDOP = subtotalDOP * (financialConfig.itbisPercent / 100);
    const totalDOP = subtotalDOP + itbisDOP;
    const subtotalUSD = totalDOP / effectiveRate;
    
    // Split: Supra Commission (Platform Fee)
    const platformFeeUSD = subtotalUSD * (financialConfig.supraCommissionPercent / 100);
    const preStripeTotalUSD = subtotalUSD + platformFeeUSD;
    
    // Stripe Fees
    const totalUSD = (preStripeTotalUSD + financialConfig.stripeFixedFeeUSD) / (1 - financialConfig.stripeFeePercent / 100);
    const stripeFeeUSD = totalUSD - preStripeTotalUSD;

    return { 
      totalUSD, 
      effectiveRate, 
      itbisDOP, 
      platformFeeUSD, 
      merchantPayoutDOP: subtotalDOP, 
      stripeFeeUSD 
    };
  };

  const updateFinancialConfig = (config: FinancialConfig) => setFinancialConfig(config);
  
  const syncBpdRate = async () => {
    setIsSyncing(true);
    await new Promise(r => setTimeout(r, 1000));
    setFinancialConfig(prev => ({ ...prev, lastBpdRate: 59.50 + (Math.random() - 0.5) }));
    setIsSyncing(false);
  };

  const addProduct = (product: Product) => setProducts(prev => [product, ...prev]);
  const removeProduct = (id: string) => setProducts(prev => prev.filter(p => p.id !== id));

  const registerMerchant = (merchant: Merchant) => setMerchants(prev => [merchant, ...prev]);
  const updateMerchant = (id: string, updates: Partial<Merchant>) => setMerchants(prev => prev.map(m => m.id === id ? { ...m, ...updates } : m));

  const addTicket = (ticket: SupportTicket) => setTickets(prev => [ticket, ...prev]);
  const updateTicket = (id: string, updates: Partial<SupportTicket>) => setTickets(prev => prev.map(t => t.id === id ? { ...t, ...updates } : t));

  const resolveDispute = (orderId: string, action: 'REFUND' | 'RELEASE') => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: action === 'REFUND' ? 'CANCELLED' : 'REDEEMED', paymentStatus: action === 'REFUND' ? 'CANCELLED' : 'CAPTURED' } : o));
  };

  const addReview = (review: OrderReview) => setReviews(prev => [review, ...prev]);
  const reserveStock = (productId: string) => setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: Math.max(0, p.stock - 1) } : p));

  const redeemOrder = (code: string, image?: string, coords?: { lat: number, lng: number }) => {
    const order = orders.find(o => o.magicLinkCode === code && o.status !== 'REDEEMED' && o.status !== 'CANCELLED');
    if (!order) return { success: false, reason: "Código no válido o ya redimido" };
    
    setOrders(prev => prev.map(o => o.magicLinkCode === code ? { ...o, status: 'REDEEMED', verificationImage: image, deliveryCoords: coords } : o));
    return { success: true };
  };

  const addPayout = (payout: Payout) => setPayouts(prev => [payout, ...prev]);
  const updateSubscription = (id: string, updates: Partial<Subscription>) => setSubscriptions(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));

  const value = {
    orders, merchants, products, tickets, subscriptions, payouts, reviews,
    financialConfig, isSyncing, cloudSync, totalImpactKg,
    addOrder, updateOrder, cancelOrder, getOrderByCode,
    calculateFinancials, updateFinancialConfig, syncBpdRate,
    addProduct, removeProduct, registerMerchant, updateMerchant,
    addTicket, updateTicket, resolveDispute, addReview, reserveStock, redeemOrder,
    addPayout, updateSubscription, capturePayment
  };

  return <OrderContext.Provider value={value}>{children}</OrderContext.Provider>;
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) throw new Error('useOrders must be used within OrderProvider');
  return context;
};
