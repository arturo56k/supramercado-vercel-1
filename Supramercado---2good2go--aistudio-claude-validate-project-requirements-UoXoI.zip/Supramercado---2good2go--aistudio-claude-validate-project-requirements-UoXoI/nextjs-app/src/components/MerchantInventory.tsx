'use client';

import React, { useState, useRef } from 'react';
import { 
  Plus, Search, Edit3, Trash2, Package, 
  Sparkles, Loader2, Camera, Zap, AlertCircle, ShoppingBag, X, FileUp
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { Product } from '../types';
import { useOrders } from './OrderContext';
import { MerchantBulkUpload } from './MerchantBulkUpload';

export const MerchantInventory: React.FC = () => {
  const { products, addProduct, removeProduct, calculateFinancials } = useOrders();
  const [search, setSearch] = useState('');
  const [isAnalyzingSurplus, setIsAnalyzingSurplus] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    description: '',
    basePriceDOP: 0,
    category: 'Groceries',
    stock: 0,
    merchantId: 'm1',
    image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400',
    type: 'INDIVIDUAL'
  });

  const filtered = products.filter(p => p.merchantId === 'm1' && p.name.toLowerCase().includes(search.toLowerCase()));

  const handleManualAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const { totalUSD } = calculateFinancials(newProduct.basePriceDOP || 0);
    const product: Product = {
      ...newProduct as Product,
      id: `prod-${Date.now()}`,
      priceUSD: totalUSD,
    };
    addProduct(product);
    setShowAddModal(false);
    setNewProduct({
      name: '',
      description: '',
      basePriceDOP: 0,
      category: 'Groceries',
      stock: 0,
      merchantId: 'm1',
      image: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=400',
      type: 'INDIVIDUAL'
    });
  };

  const createSuprabolsaFromPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsAnalyzingSurplus(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = (event.target?.result as string).split(',')[1];
      try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [
            { inlineData: { data: base64Data, mimeType: file.type } },
            { text: "Analiza estos productos excedentes de un colmado. Crea un 'Pack Sorpresa' atractivo. Devuelve un JSON con: name, description, price (en PESOS DOMINICANOS DOP), originalPrice (valor real en DOP)." },
          ],
        });

        const result = JSON.parse(response.text.replace(/```json|```/g, '').trim());
        const { totalUSD } = calculateFinancials(result.price);
        const supraProd: Product = {
          id: `surplus-${Date.now()}`,
          name: result.name,
          description: result.description,
          category: 'Suprabolsas ⚡',
          priceUSD: totalUSD,
          basePriceDOP: result.price,
          originalPriceDOP: result.originalPrice,
          stock: 5,
          merchantId: 'm1',
          isSuprabolsa: true,
          image: `data:${file.type};base64,${base64Data}`,
          type: 'PREDESIGNED_PACK',
        };
        addProduct(supraProd);
      } catch (err) {
        console.error("Analysis error:", err);
      } finally {
        setIsAnalyzingSurplus(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {showBulkModal && <MerchantBulkUpload onClose={() => setShowBulkModal(false)} />}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Gestión de Inventario</h2>
          <p className="text-slate-500 font-medium text-lg mt-1">Sube productos en DOP para el mercado global.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setShowBulkModal(true)}
            className="bg-white text-slate-900 px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-sm border border-slate-200 hover:bg-slate-50 transition-all"
          >
            <FileUp className="w-5 h-5 text-blue-600" /> Importar CSV
          </button>
          <button 
            onClick={() => setShowAddModal(true)}
            className="bg-blue-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-xl hover:bg-blue-800 transition-all"
          >
            <Plus className="w-5 h-5" /> Añadir Producto
          </button>
        </div>
      </div>

      <div className="bg-orange-600 text-white p-8 rounded-[2.5rem] shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center gap-8 border-b-8 border-orange-700">
        <div className="relative z-10 flex-1">
          <div className="flex items-center gap-3 mb-2">
             <Zap className="w-5 h-5 text-yellow-300 fill-yellow-300" />
             <p className="text-[10px] font-black uppercase tracking-widest text-orange-200">Excedentes de Hoy</p>
          </div>
          <h2 className="text-3xl font-black tracking-tight">Generar Suprabolsa ⚡</h2>
          <p className="text-orange-100 font-medium mt-2 max-w-md">Toma una foto de lo que te sobró hoy y la IA calculará el precio de remate automáticamente.</p>
        </div>
        <div className="relative z-10">
          <input type="file" hidden ref={fileInputRef} accept="image/*" onChange={createSuprabolsaFromPhoto} />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isAnalyzingSurplus}
            className="bg-white text-orange-600 px-8 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-3 shadow-xl hover:scale-105 transition-all"
          >
            {isAnalyzingSurplus ? <Loader2 className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
            FOTO DE EXCEDENTES
          </button>
        </div>
        <ShoppingBag className="absolute -bottom-10 -right-10 w-64 h-64 text-white opacity-10" />
      </div>

      <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <div className="relative w-full">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input 
              type="text" 
              placeholder="Filtrar catálogo..." 
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Producto</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Categoría</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-center">Stock</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Precio (DOP)</th>
                <th className="px-6 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Borrar</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(product => (
                <tr key={product.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-4">
                      <img src={product.image} className="w-12 h-12 rounded-xl object-cover" />
                      <p className="font-bold text-slate-900">{product.name}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-xs font-bold text-slate-500">{product.category}</span>
                  </td>
                  <td className="px-6 py-4 text-center">
                     <span className={`px-3 py-1 rounded-full text-[10px] font-black ${product.stock < 10 ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'}`}>
                       {product.stock} und
                     </span>
                  </td>
                  <td className="px-6 py-4 text-right font-black text-slate-900">RD$ {product.basePriceDOP.toLocaleString()}</td>
                  <td className="px-6 py-4 text-right">
                     <button onClick={() => removeProduct(product.id)} className="p-2 text-slate-300 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-md" onClick={() => setShowAddModal(false)}></div>
          <div className="relative bg-white w-full max-w-xl rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300">
             <div className="flex justify-between items-center mb-8">
                <h3 className="text-2xl font-black text-slate-900">Nuevo Producto Local</h3>
                <button onClick={() => setShowAddModal(false)}><X className="w-6 h-6 text-slate-400 hover:text-slate-900" /></button>
             </div>
             <form onSubmit={handleManualAdd} className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                   <div className="col-span-2 space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Nombre del Producto</label>
                      <input required type="text" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={newProduct.name} onChange={e => setNewProduct({...newProduct, name: e.target.value})} />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Precio en DOP</label>
                      <input required type="number" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={newProduct.basePriceDOP} onChange={e => setNewProduct({...newProduct, basePriceDOP: parseFloat(e.target.value)})} />
                   </div>
                   <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Stock Inicial</label>
                      <input required type="number" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={newProduct.stock} onChange={e => setNewProduct({...newProduct, stock: parseInt(e.target.value)})} />
                   </div>
                </div>
                <button className="w-full bg-blue-700 text-white font-black py-5 rounded-2xl shadow-xl uppercase tracking-widest text-xs">Añadir al Catálogo</button>
             </form>
          </div>
        </div>
      )}
    </div>
  );
};
