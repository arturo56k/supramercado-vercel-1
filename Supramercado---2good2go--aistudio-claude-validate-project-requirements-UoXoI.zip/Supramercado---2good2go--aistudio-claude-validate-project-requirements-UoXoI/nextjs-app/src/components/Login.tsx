'use client';

import React, { useState } from 'react';
import { Mail, Lock, ArrowRight, ShieldCheck, Smartphone, Globe } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
  onBack: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin, onBack }) => {
  const [step, setStep] = useState<'CHOICE' | 'EMAIL'>('CHOICE');

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-6 animate-in fade-in zoom-in duration-500">
      <div className="bg-white w-full max-w-md rounded-[3rem] p-10 shadow-2xl border border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-blue-700 to-orange-500"></div>
        
        <div className="text-center space-y-4 mb-10">
           <div className="w-16 h-16 bg-blue-700 rounded-2xl flex items-center justify-center text-white font-black text-3xl italic shadow-2xl shadow-blue-700/30 mx-auto mb-6">S</div>
           <h2 className="text-3xl font-black text-slate-900 tracking-tight">Bienvenido a Supra</h2>
           <p className="text-slate-500 font-medium">Inicia sesión para proteger tus compras con estándares globales de seguridad.</p>
        </div>

        {step === 'CHOICE' ? (
          <div className="space-y-4">
             <button 
              onClick={() => setStep('EMAIL')}
              className="w-full bg-slate-900 text-white p-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-4 hover:bg-slate-800 transition-all shadow-xl"
             >
               <Mail className="w-5 h-5" /> Continuar con Email
             </button>
             <button className="w-full bg-blue-600 text-white p-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-4 hover:bg-blue-700 transition-all shadow-xl">
               <Smartphone className="w-5 h-5" /> Continuar con WhatsApp
             </button>
             <div className="relative py-4">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                <div className="relative flex justify-center"><span className="bg-white px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">O</span></div>
             </div>
             <button onClick={onBack} className="w-full text-slate-400 font-black text-xs uppercase tracking-widest hover:text-slate-900 transition-colors">
               Volver como Invitado
             </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="space-y-4">
               <div className="relative">
                 <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                 <input 
                  type="email" 
                  placeholder="Email de acceso" 
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
                 />
               </div>
               <div className="relative">
                 <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                 <input 
                  type="password" 
                  placeholder="Tu contraseña" 
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
                 />
               </div>
            </div>
            
            <button 
              onClick={onLogin}
              className="w-full bg-blue-700 text-white p-5 rounded-2xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-blue-700/30 hover:bg-blue-800 transition-all"
            >
              Iniciar Sesión
            </button>
            <button onClick={() => setStep('CHOICE')} className="w-full text-slate-400 font-black text-xs uppercase tracking-widest hover:text-slate-900 transition-colors">
               Cambiar método
            </button>
          </div>
        )}

        <div className="mt-10 pt-8 border-t border-slate-50 text-center">
           <div className="flex items-center justify-center gap-2 text-slate-400 font-black text-[10px] uppercase tracking-widest mb-4">
              <ShieldCheck className="w-4 h-4 text-green-500" /> Verificado por Supra Security
           </div>
           <div className="flex justify-center gap-6">
              <Globe className="w-5 h-5 text-slate-200" />
              <div className="w-10 h-6 bg-slate-200 rounded-md opacity-30"></div>
              <div className="w-10 h-6 bg-slate-200 rounded-md opacity-30"></div>
           </div>
        </div>
      </div>
    </div>
  );
};
