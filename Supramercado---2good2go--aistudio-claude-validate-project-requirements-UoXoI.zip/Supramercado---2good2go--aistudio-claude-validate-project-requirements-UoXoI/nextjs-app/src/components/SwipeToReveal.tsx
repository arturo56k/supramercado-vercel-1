'use client';

import React, { useState } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { ChevronRight, CheckCircle2 } from 'lucide-react';

interface SwipeToRevealProps {
  onConfirm: () => void;
  text?: string;
}

export const SwipeToReveal: React.FC<SwipeToRevealProps> = ({ onConfirm, text = "Desliza para redimir" }) => {
  const [isConfirmed, setIsConfirmed] = useState(false);
  const x = useMotionValue(0);
  const opacity = useTransform(x, [0, 200], [1, 0]);
  const containerWidth = 280;
  const handleSize = 60;

  const handleDragEnd = () => {
    if (x.get() > containerWidth - handleSize - 20) {
      setIsConfirmed(true);
      onConfirm();
    } else {
      x.set(0);
    }
  };

  return (
    <div className="relative w-full max-w-[320px] h-20 bg-slate-200 rounded-full p-2 flex items-center overflow-hidden shadow-inner border border-slate-300">
      {!isConfirmed ? (
        <>
          <motion.div 
            style={{ opacity }}
            className="absolute inset-0 flex items-center justify-center pointer-events-none text-slate-500 font-semibold text-sm"
          >
            {text}
          </motion.div>
          <motion.div
            drag="x"
            dragConstraints={{ left: 0, right: containerWidth - handleSize }}
            style={{ x }}
            onDragEnd={handleDragEnd}
            className="z-10 w-[60px] h-[60px] bg-orange-500 rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing shadow-lg"
          >
            <ChevronRight className="text-white w-8 h-8" />
          </motion.div>
        </>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full h-full flex items-center justify-center bg-green-500 rounded-full text-white font-bold gap-2"
        >
          <CheckCircle2 className="w-6 h-6" />
          ORDEN VALIDADA
        </motion.div>
      )}
    </div>
  );
};
