'use client';

import React, { useState, useEffect } from 'react';
import { MapPin, Phone, ShieldCheck, QrCode, ArrowLeft, Navigation, Globe, Camera, Heart, MessageCircle, AlertTriangle, Clock, MessageSquare, Share2, ShieldAlert, X, Send, Star, CheckCircle2, RotateCcw, HelpCircle, Wifi, Loader2 } from 'lucide-react';
import { Order, Merchant } from '../types';
import { SwipeToReveal } from './SwipeToReveal';
import { useTranslation } from './LanguageContext';
import { useNotify } from './NotificationSystem';
import { useOrders } from './OrderContext';
import { GeoGuard } from './GeoGuard';

interface MagicLinkViewProps {
  order: Order;
  merchant: Merchant;
  onBack?: () => void;
  onConfirm: () => void;
}

export const MagicLinkView: React.FC<MagicLinkViewProps> = ({ order, merchant, onBack, onConfirm }) => {
  const [showGratitude, setShowGratitude] = useState(false);
  const [showDispute, setShowDispute] = useState(false);
  const [isGeoVerified, setIsGeoVerified] = useState(false);
  const [userCoords, setUserCoords] = useState<{lat: number, lng: number} | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [rating, setRating] = useState(0);
  const [disputeNote, setDisputeNote] = useState('');
  const { notify } = useNotify();
  const { addTicket, addReview, updateOrder, redeemOrder, capturePayment } = useOrders();

  useEffect(() => {
    localStorage.setItem(`supra_offline_${order.magicLinkCode}`, JSON.stringify({ order, merchant }));
  }, [order, merchant]);

  const handleSwipeConfirm = async () => {
    if (!isGeoVerified) {
      notify("Ubicación requerida", "Debes estar en el comercio para confirmar.", "WARNING");
      return;
    }

    setIsCapturing(true);
    notify("Finalizando Pago", "Capturando fondos y distribuyendo al comercio...", "INFO");

    // CRÍTICO: El swipe captura el dinero y ejecuta el split automático vía Stripe Connect
    const capture = await capturePayment(order.paymentIntentId || '', order.merchantId);
    
    if (!capture.success) {
      setIsCapturing(false);
      notify("Error de Cobro", "No se pudo procesar la liquidación. Contacte a soporte.", "WARNING");
      return;
    }

    redeemOrder(order.magicLinkCode, undefined, userCoords || undefined);
    setIsCapturing(false);
    onConfirm();
    setShowGratitude(true);
  };

  const handleReviewSubmit = () => {
    if (rating === 0) return;
    addReview({
      id: `rev-${Date.now()}`,
      orderId: order.id,
      rating,
      comment: "Retiro exitoso en tienda.",
      date: new Date().toISOString(),
      beneficiaryName: order.beneficiaryName
    });
    notify("¡Gracias!", "Tu calificación ayuda a otros familiares en RD.", "SUCCESS");
  };

  const handleReportIssue = () => {
    if (!disputeNote.trim()) return;
    updateOrder(order.id, { status: 'DISPUTED', disputeReason: disputeNote });
    addTicket({
      id: `tix-${Date.now()}`,
      orderId: order.id,
      subject: `Disputa en ${merchant.name}: ${disputeNote}`,
      status: 'OPEN',
      priority: 'HIGH',
      createdAt: new Date().toISOString()
    });
    notify("Pago Congelado", "Soporte Supra ha intervenido la transacción.", "WARNING");
    setShowDispute(false);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] p-4 md:p-10 flex flex-col items-center">
      {isCapturing && (
        <div className="fixed inset-0 z-[400] bg-slate-900/40 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-white p-8 rounded-[2rem] shadow-2xl flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 text-blue-700 animate-spin" />
            <p className="font-black text-sm uppercase tracking-widest text-slate-900">Liquidando Fondos...</p>
          </div>
        </div>
      )}

      <div className="w-full max-w-md space-y-6">
        <header className="flex justify-between items-center mb-8 px-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-slate-900 rounded-lg flex items-center justify-center text-white font-black italic">S</div>
            <span className="text-slate-900 font-black text-lg tracking-tighter">supramercado</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-green-50 text-green-700 rounded-full border border-green-100">
               <Wifi className="w-3 h-3" />
               <span className="text-[9px] font-black uppercase tracking-widest">Pago Garantizado</span>
            </div>
          </div>
        </header>

        {order.status === 'DISPUTED' ? (
          <div className="bg-white rounded-[3rem] shadow-2xl border-4 border-orange-100 p-10 text-center space-y-8 animate-in zoom-in">
             <div className="w-20 h-20 bg-orange-100 text-orange-600 rounded-full flex items-center justify-center mx-auto shadow-xl"><ShieldAlert className="w-10 h-10" /></div>
             <div className="space-y-4">
                <h2 className="text-3xl font-black text-slate-900">Fondos Congelados</h2>
                <p className="text-slate-500 font-medium leading-relaxed">El pago no será transferido al comercio hasta resolver la incidencia.</p>
             </div>
             <button onClick={onBack} className="w-full text-slate-400 font-black text-[10px] uppercase py-2">Volver</button>
          </div>
        ) : !showGratitude ? (
          <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden relative animate-in fade-in zoom-in">
            <div className={`h-3 w-full ${order.status === 'REDEEMED' ? 'bg-green-500' : 'bg-slate-900'}`}></div>
            <div className="p-8 text-center space-y-6">
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2">Ticket de Retiro para</p>
                <h2 className="text-3xl font-black text-slate-900">{order.beneficiaryName}</h2>
              </div>
              
              <div className="bg-slate-50 p-6 rounded-[2.5rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center gap-4">
                <div className="p-4 bg-white rounded-3xl shadow-sm border border-slate-100">
                  <img src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${order.pickupCode}`} className={`w-48 h-48 ${order.status === 'REDEEMED' ? 'opacity-20' : ''}`} alt="QR" />
                </div>
                <p className="text-4xl font-black tracking-[0.3em] text-slate-900">{order.pickupCode}</p>
              </div>

              {order.status !== 'REDEEMED' && (
                <GeoGuard 
                  merchantLat={merchant.lat} 
                  merchantLng={merchant.lng} 
                  onVerified={(coords) => {
                    setIsGeoVerified(true);
                    setUserCoords(coords);
                  }} 
                />
              )}

              <div className="pt-6 border-t border-slate-100 space-y-4 text-left">
                <div className="flex items-center gap-4">
                  <img src={merchant.logo} className="w-12 h-12 rounded-2xl object-cover" />
                  <div>
                    <h4 className="font-black text-slate-900">{merchant.name}</h4>
                    <p className="text-xs font-bold text-slate-500 flex items-center gap-1"><MapPin className="w-3 h-3" /> {merchant.address}</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-6 border-t-4 border-dashed border-slate-200">
              {order.status !== 'REDEEMED' ? (
                <>
                  <div className="flex justify-center opacity-80 hover:opacity-100 transition-opacity">
                    <SwipeToReveal onConfirm={handleSwipeConfirm} text={isGeoVerified ? "Desliza para redimir" : "Acércate al comercio"} />
                  </div>
                  <button onClick={() => setShowDispute(true)} className="mt-6 w-full flex items-center justify-center gap-2 text-[10px] font-black text-red-600 uppercase py-2">
                    <ShieldAlert className="w-4 h-4" /> Problemas en Tienda
                  </button>
                </>
              ) : (
                <div className="text-center py-2">
                  <p className="text-[10px] font-black text-green-600 uppercase">¡Orden Entregada!</p>
                  <button onClick={() => setShowGratitude(true)} className="mt-4 text-xs font-bold text-blue-700 underline">Calificar Experiencia</button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 p-10 text-center space-y-8 animate-in zoom-in">
            <div className="w-24 h-24 bg-pink-100 text-pink-600 rounded-full flex items-center justify-center mx-auto shadow-xl"><Heart className="w-12 h-12 fill-pink-500" /></div>
            <h2 className="text-3xl font-black text-slate-900">¡Retiro Completado!</h2>
            <div className="flex justify-center gap-3">
              {[1,2,3,4,5].map(s => (
                <button key={s} onClick={() => setRating(s)} className={`p-2 transition-all ${rating >= s ? 'scale-125' : 'grayscale opacity-30'}`}>
                  <Star className={`w-10 h-10 ${rating >= s ? 'fill-orange-400 text-orange-400' : 'text-slate-300'}`} />
                </button>
              ))}
            </div>
            <button onClick={handleReviewSubmit} disabled={rating === 0} className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs shadow-xl disabled:opacity-20 uppercase tracking-widest">Enviar Feedback</button>
            <button onClick={onBack} className="w-full text-slate-400 font-black text-[10px] uppercase py-2">Cerrar</button>
          </div>
        )}
      </div>
    </div>
  );
};
