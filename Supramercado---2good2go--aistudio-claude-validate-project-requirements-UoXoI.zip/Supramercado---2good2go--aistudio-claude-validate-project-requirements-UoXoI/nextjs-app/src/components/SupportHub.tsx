'use client';

import React, { useState } from 'react';
import { LifeBuoy, MessageSquare, ShieldAlert, CheckCircle, Search, Filter, Loader2 } from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';
import { SupportTicket } from '../types';

export const SupportHub: React.FC<{ isAdmin?: boolean }> = ({ isAdmin = false }) => {
  const { tickets, updateTicket, orders } = useOrders();
  const { notify } = useNotify();
  const [isProcessing, setIsProcessing] = useState<string | null>(null);

  const resolveTicket = (id: string) => {
    setIsProcessing(id);
    setTimeout(() => {
      updateTicket(id, { status: 'RESOLVED' });
      notify("Ticket Resuelto", "La incidencia ha sido cerrada satisfactoriamente.", "SUCCESS");
      setIsProcessing(null);
    }, 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Centro de Ayuda</h2>
          <p className="text-slate-500 font-medium">Resolución de incidencias y soporte USA-RD.</p>
        </div>
        {!isAdmin && (
           <button className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center gap-2">
             <MessageSquare className="w-5 h-5" /> Abrir Nuevo Ticket
           </button>
        )}
      </div>

      <div className="grid grid-cols-1 gap-4">
        {tickets.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-[3rem] border border-slate-200">
             <LifeBuoy className="w-16 h-16 text-slate-200 mx-auto mb-4" />
             <p className="font-black text-slate-400 uppercase tracking-widest">No hay tickets activos.</p>
          </div>
        ) : (
          tickets.map(ticket => {
            const order = orders.find(o => o.id === ticket.orderId);
            return (
              <div key={ticket.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
                <div className="flex flex-col md:flex-row justify-between gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                       <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${
                         ticket.status === 'OPEN' ? 'bg-red-50 text-red-600 border-red-100' : 
                         ticket.status === 'IN_PROGRESS' ? 'bg-blue-50 text-blue-600 border-blue-100' : 
                         'bg-green-50 text-green-600 border-green-100'
                       }`}>
                         {ticket.status}
                       </span>
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Prioridad: {ticket.priority}</span>
                    </div>
                    <h4 className="text-xl font-black text-slate-900">{ticket.subject}</h4>
                    <p className="text-sm text-slate-500 font-medium">Incidencia vinculada a la orden: <span className="font-bold text-slate-700">#{ticket.orderId}</span></p>
                  </div>

                  <div className="flex flex-col md:items-end justify-center gap-4">
                    <div className="text-left md:text-right">
                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Creado el</p>
                       <p className="text-sm font-bold text-slate-900">{new Date(ticket.createdAt).toLocaleDateString()}</p>
                    </div>
                    {isAdmin && ticket.status !== 'RESOLVED' && (
                      <button 
                        onClick={() => resolveTicket(ticket.id)}
                        disabled={isProcessing === ticket.id}
                        className="bg-green-600 text-white px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-lg hover:bg-green-700 transition-all flex items-center gap-2"
                      >
                        {isProcessing === ticket.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                        Marcar como Resuelto
                      </button>
                    )}
                  </div>
                </div>
              </div>
            )
          })
        )}
      </div>

      <div className="bg-slate-50 p-8 rounded-[3rem] border border-slate-200 space-y-4">
         <h4 className="font-black text-slate-900 flex items-center gap-2">
           <ShieldAlert className="w-5 h-5 text-orange-600" /> Garantía de Satisfacción Supra
         </h4>
         <p className="text-xs text-slate-500 leading-relaxed font-medium">
           Si el beneficiario en RD reporta una anomalía en la "frescura" o el "trato" del comercio, nuestro equipo retiene la liquidación de fondos al comercio hasta que se resuelva la disputa. Tu dinero en USA está protegido por nuestro contrato de Merchant of Record.
         </p>
      </div>
    </div>
  );
};
