'use client';

import React from 'react';
import { Heart, MessageCircle, MapPin, Sparkles, Camera } from 'lucide-react';
import { useOrders } from './OrderContext';

export const GratitudeGallery: React.FC = () => {
  const { orders } = useOrders();
  const redeemedOrders = orders.filter(o => o.status === 'REDEEMED' && o.verificationImage);

  if (redeemedOrders.length === 0) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between px-2">
        <h4 className="text-xl font-black text-slate-900 flex items-center gap-2">
          <Heart className="w-6 h-6 text-pink-500 fill-pink-500" /> Momentos Supra
        </h4>
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Evidencia de impacto</span>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide">
        {redeemedOrders.map(order => (
          <div key={order.id} className="min-w-[280px] bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all group">
            <div className="relative aspect-square rounded-[1.5rem] overflow-hidden mb-4">
              <img src={order.verificationImage} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
              <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-xl text-[9px] font-black text-slate-900 uppercase flex items-center gap-1.5">
                <Camera className="w-3 h-3" /> Foto de RD
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm font-black text-slate-900">{order.beneficiaryName}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> Santiago, RD
                  </p>
                </div>
                <div className="w-8 h-8 bg-pink-50 text-pink-500 rounded-full flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
              <p className="text-xs text-slate-500 font-medium italic">"Gracias hijo, ya tengo todo para el sancocho de mañana. ¡Dios te bendiga!"</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
