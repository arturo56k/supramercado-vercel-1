'use client';

import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Video, Sparkles, Loader2, Play, CheckCircle, Smartphone, AlertCircle } from 'lucide-react';

export const VideoTutorial: React.FC = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const generateTutorial = async () => {
    setIsGenerating(true);
    setVideoUrl(null);
    
    try {
      if (!await (window as any).aistudio.hasSelectedApiKey()) {
        await (window as any).aistudio.openSelectKey();
      }

      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      let operation = await ai.models.generateVideos({
        model: 'veo-3.1-fast-generate-preview',
        prompt: 'A friendly Dominican person showing how to use a smartphone to scan a QR code at a grocery store counter, bright lighting, helpful atmosphere.',
        config: {
          numberOfVideos: 1,
          resolution: '720p',
          aspectRatio: '9:16'
        }
      });

      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await (ai as any).operations.getVideosOperation({operation: operation});
      }

      const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
      const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
      const blob = await response.blob();
      setVideoUrl(URL.createObjectURL(blob));
    } catch (err) {
      console.error("Video error:", err);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setShowModal(true)}
        className="flex items-center gap-2 bg-blue-50 text-blue-700 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-100 transition-all border border-blue-100"
      >
        <Video className="w-4 h-4" /> Guía para mi familia
      </button>

      {showModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md">
          <div className="bg-white w-full max-w-lg rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300">
            <div className="flex justify-between items-start mb-8">
              <div>
                <h3 className="text-2xl font-black text-slate-900">Generador de Video Guía</h3>
                <p className="text-slate-500 font-medium">Crea un tutorial con IA para que tu familiar sepa cómo canjear su compra.</p>
              </div>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-900">
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="bg-slate-50 aspect-[9/16] max-h-[400px] rounded-[2rem] border-2 border-dashed border-slate-200 flex flex-col items-center justify-center relative overflow-hidden mb-8">
              {isGenerating ? (
                <div className="text-center p-8 space-y-4">
                  <div className="w-16 h-16 bg-blue-700 rounded-full flex items-center justify-center mx-auto shadow-2xl shadow-blue-700/30">
                    <Loader2 className="w-8 h-8 text-white animate-spin" />
                  </div>
                  <p className="text-sm font-black text-slate-900 uppercase">Generando video con Veo 3.1...</p>
                  <p className="text-xs text-slate-400">Esto puede tardar hasta un minuto. Estamos creando una guía visual paso a paso.</p>
                </div>
              ) : videoUrl ? (
                <video src={videoUrl} controls className="w-full h-full object-cover rounded-[2rem]" />
              ) : (
                <div className="text-center p-8 space-y-4">
                  <Video className="w-12 h-12 text-slate-200 mx-auto" />
                  <p className="text-sm font-bold text-slate-400">Presiona para generar tu video tutorial personalizado.</p>
                </div>
              )}
            </div>

            {!videoUrl && !isGenerating && (
              <button 
                onClick={generateTutorial}
                className="w-full bg-blue-700 text-white font-black py-5 rounded-2xl shadow-2xl shadow-blue-700/20 hover:bg-blue-800 transition-all flex items-center justify-center gap-3"
              >
                <Sparkles className="w-5 h-5" /> GENERAR VIDEO GUÍA
              </button>
            )}

            {videoUrl && (
              <div className="flex gap-4">
                <button className="flex-1 bg-green-500 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-green-500/20">
                  <Smartphone className="w-5 h-5" /> ENVIAR POR WHATSAPP
                </button>
                <button onClick={() => setVideoUrl(null)} className="p-4 bg-slate-100 text-slate-400 rounded-2xl hover:text-slate-900">
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            )}
            
            <p className="text-[10px] text-center text-slate-400 font-bold uppercase mt-6 flex items-center justify-center gap-2">
              <AlertCircle className="w-3 h-3" /> Requiere API Key con facturación activa
            </p>
          </div>
        </div>
      )}
    </>
  );
};

const XCircle = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const Trash2 = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
  </svg>
);
