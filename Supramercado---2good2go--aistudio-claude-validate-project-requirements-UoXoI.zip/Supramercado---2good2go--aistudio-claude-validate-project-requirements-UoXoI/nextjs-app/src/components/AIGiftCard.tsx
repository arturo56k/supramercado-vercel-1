'use client';

import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Sparkles, Image as ImageIcon, Download, Share2, Loader2, Heart, Send } from 'lucide-react';

export const AIGiftCard: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generateCard = async () => {
    if (!prompt) return;
    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [{ text: `A beautiful, high-quality artistic digital illustration for a gift card. Theme: ${prompt}. Style: warm colors, tropical Dominican vibes, heartwarming, high resolution, no text.` }]
        },
        config: {
          imageConfig: { aspectRatio: "16:9" }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          setGeneratedImage(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    } catch (error) {
      console.error("Error generating gift card:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-indigo-900 to-blue-900 rounded-[3rem] p-8 text-white shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-10">
        <Sparkles className="w-24 h-24" />
      </div>
      
      <div className="relative z-10 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-md">
            <Heart className="w-5 h-5 text-pink-400" />
          </div>
          <h4 className="text-xl font-black uppercase tracking-tight">Dedicatoria con IA</h4>
        </div>

        {generatedImage ? (
          <div className="space-y-4 animate-in zoom-in duration-500">
            <img src={generatedImage} className="w-full aspect-video object-cover rounded-3xl shadow-2xl border-4 border-white/10" alt="Gift Card" />
            <div className="flex gap-2">
              <button 
                onClick={() => setGeneratedImage(null)}
                className="flex-1 py-3 bg-white/10 hover:bg-white/20 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all"
              >
                Crear Otra
              </button>
              <button className="flex-1 py-3 bg-pink-500 hover:bg-pink-600 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center justify-center gap-2">
                <Share2 className="w-3 h-3" /> Adjuntar al Link
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-blue-100 font-medium">Describe un sentimiento para tu familia en RD y crearemos una postal única.</p>
            <div className="relative">
              <textarea 
                placeholder="Ej: 'Un abrazo fuerte para mi abuela en su cumpleaños con flores dominicanas'"
                className="w-full bg-white/10 border-2 border-white/10 rounded-2xl p-4 text-sm font-bold placeholder:text-blue-300/50 focus:border-white/30 outline-none transition-all resize-none h-24"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
              />
              <button 
                onClick={generateCard}
                disabled={isGenerating || !prompt}
                className="absolute bottom-4 right-4 p-3 bg-white text-blue-900 rounded-xl shadow-lg hover:scale-110 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100"
              >
                {isGenerating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
