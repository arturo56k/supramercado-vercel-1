'use client';

import React, { useState } from 'react';
import { Store, Camera, MapPin, ShieldCheck, Save, Globe, Landmark, AlertCircle } from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

export const MerchantSettings: React.FC = () => {
  const { merchants, updateMerchant } = useOrders();
  const { notify } = useNotify();
  const merchant = merchants.find(m => m.id === 'm1')!;
  
  const [formData, setFormData] = useState({
    name: merchant.name,
    description: merchant.description,
    rnc: merchant.rnc || '',
    locationName: merchant.locationName,
    category: merchant.category
  });

  const handleSave = () => {
    updateMerchant(merchant.id, formData);
    notify("Perfil Actualizado", "Los cambios en tu comercio ya son visibles en el marketplace.", "SUCCESS");
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-sm relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-r from-blue-700 to-blue-900 opacity-5"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
          <div className="relative group cursor-pointer">
            <img src={merchant.logo} className="w-40 h-40 rounded-[2.5rem] border-4 border-white shadow-2xl object-cover" />
            <div className="absolute inset-0 bg-black/40 rounded-[2.5rem] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <Camera className="text-white w-8 h-8" />
            </div>
          </div>
          <div className="flex-1 text-center md:text-left">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">{formData.name}</h2>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 mt-2">
               <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-200">
                 {formData.category}
               </span>
               <span className="flex items-center gap-1 text-green-600 font-bold text-xs uppercase tracking-widest">
                 <ShieldCheck className="w-4 h-4" /> Comercio Verificado
               </span>
            </div>
          </div>
          <button 
            onClick={handleSave}
            className="bg-blue-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-800 transition-all flex items-center gap-2"
          >
            <Save className="w-5 h-5" /> Guardar Cambios
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
           <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
             <Store className="w-6 h-6 text-blue-700" /> Identidad de Marca
           </h3>
           <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nombre Comercial</label>
                <input type="text" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Descripción del Negocio</label>
                <textarea rows={3} className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold resize-none" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
              </div>
           </div>
        </div>

        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
           <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
             <Landmark className="w-6 h-6 text-orange-600" /> Datos Fiscales & Operación
           </h3>
           <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">RNC (Registro Nacional de Contribuyente)</label>
                <input type="text" className="w-full p-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={formData.rnc} onChange={e => setFormData({...formData, rnc: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Ubicación / Provincia</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                  <input type="text" className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl font-bold" value={formData.locationName} onChange={e => setFormData({...formData, locationName: e.target.value})} />
                </div>
              </div>
           </div>
           <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-orange-600 shrink-0" />
              <p className="text-[10px] font-bold text-orange-900 uppercase leading-relaxed">
                Cambiar el RNC requiere una nueva validación KYC por parte del soporte de Supra.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};
