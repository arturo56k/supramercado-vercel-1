'use client';

import React, { useState } from 'react';
import { ShieldCheck, Loader2, CheckCircle2, CreditCard, Lock, ArrowRight, Smartphone, AlertCircle } from 'lucide-react';
import { LegalAgreements } from './LegalAgreements';

interface PaymentModalProps {
  isOpen: boolean;
  totalUSD: number;
  onSuccess: () => void;
  onCancel: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, totalUSD, onSuccess, onCancel }) => {
  const [step, setStep] = useState<'LEGAL' | 'CARD' | 'PROCESSING' | 'SUCCESS'>('LEGAL');

  if (!isOpen) return null;

  const handleAuthorizeHold = () => {
    setStep('PROCESSING');
    // Simulamos la creación de un PaymentIntent con capture_method: manual
    setTimeout(() => {
      setStep('SUCCESS');
    }, 2500);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-md">
      <div className="bg-white w-full max-w-md rounded-[3rem] p-10 shadow-2xl animate-in zoom-in duration-300">
        
        {step === 'LEGAL' && (
          <div className="space-y-8">
            <div className="text-center">
               <h3 className="text-2xl font-black text-slate-900">Garantía Escrow Supra</h3>
               <p className="text-slate-500 font-medium mt-1">Fondos protegidos hasta la entrega</p>
            </div>
            <LegalAgreements onAccept={() => {}} />
            <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100 flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-blue-700 shrink-0" />
              <p className="text-[10px] font-bold text-blue-900 uppercase">Su dinero no será transferido al comercio hasta que el beneficiario haga swipe en el colmado.</p>
            </div>
            <button 
              onClick={() => setStep('CARD')}
              className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl flex items-center justify-center gap-2"
            >
              Continuar <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={onCancel} className="w-full text-slate-400 font-black text-[10px] uppercase tracking-widest py-2">Cancelar</button>
          </div>
        )}

        {step === 'CARD' && (
          <div className="space-y-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 text-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-2xl font-black text-slate-900">Autorizar Retención</h3>
              <p className="text-slate-500 font-medium">Stripe Authorization (Diferido)</p>
            </div>

            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 space-y-4">
              <div className="flex justify-between items-center text-sm font-bold text-slate-400 uppercase tracking-widest">
                <span>Monto a retener</span>
                <span className="text-slate-900 text-xl font-black">${totalUSD.toFixed(2)} USD</span>
              </div>
              <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200">
                <CreditCard className="w-5 h-5 text-slate-400" />
                <span className="text-sm font-bold text-slate-700">VISA •••• 4242</span>
              </div>
            </div>

            <div className="space-y-3">
              <button 
                onClick={handleAuthorizeHold}
                className="w-full bg-blue-700 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-blue-800 transition-all flex items-center justify-center gap-2"
              >
                Autorizar Pago <ArrowRight className="w-4 h-4" />
              </button>
              <button onClick={() => setStep('LEGAL')} className="w-full text-slate-400 font-black text-[10px] uppercase tracking-widest py-2">Volver</button>
            </div>
          </div>
        )}

        {step === 'PROCESSING' && (
          <div className="text-center py-12 space-y-6">
            <div className="relative w-24 h-24 mx-auto">
              <Loader2 className="w-24 h-24 text-blue-700 animate-spin" />
              <ShieldCheck className="absolute inset-0 m-auto w-10 h-10 text-blue-700" />
            </div>
            <div>
              <h4 className="text-xl font-black text-slate-900">Creando Autorización</h4>
              <p className="text-sm text-slate-400 font-medium mt-1">Bloqueando fondos en origen...</p>
            </div>
          </div>
        )}

        {step === 'SUCCESS' && (
          <div className="text-center space-y-8 animate-in zoom-in duration-500">
            <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-12 h-12" />
            </div>
            <div>
              <h4 className="text-3xl font-black text-slate-900">¡Fondos Asegurados!</h4>
              <p className="text-slate-500 font-medium mt-2">Los fondos están en custodia de Supramercado.</p>
            </div>
            
            <div className="p-6 bg-blue-50 rounded-2xl border border-blue-100 flex items-center gap-4">
              <Smartphone className="w-10 h-10 text-blue-600" />
              <p className="text-[10px] font-black text-blue-700 uppercase leading-relaxed text-left">
                Comparta el Magic Link. El cobro final se realizará solo cuando retiren la compra.
              </p>
            </div>

            <button 
              onClick={onSuccess}
              className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2"
            >
              Generar Link de Retiro <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
