'use client';

import React from 'react';
import { ShieldCheck, Scale, FileText, CheckCircle2 } from 'lucide-react';

export const LegalAgreements: React.FC<{ onAccept: () => void }> = ({ onAccept }) => {
  return (
    <div className="bg-slate-50 p-6 rounded-3xl border border-slate-200 space-y-4">
      <div className="flex items-center gap-2 mb-2">
        <ShieldCheck className="w-4 h-4 text-blue-700" />
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Protección Legal Supra</span>
      </div>
      <div className="space-y-3">
        <div className="flex gap-3">
           <Scale className="w-4 h-4 text-slate-400 shrink-0" />
           <p className="text-[10px] text-slate-600 font-medium leading-relaxed">
             Al proceder, aceptas que Supramercado actúa como <strong>Merchant of Record</strong>. Somos responsables legales de tu transacción y de garantizar la entrega en el colmado seleccionado.
           </p>
        </div>
        <div className="flex gap-3">
           <FileText className="w-4 h-4 text-slate-400 shrink-0" />
           <p className="text-[10px] text-slate-600 font-medium leading-relaxed">
             Tu pago se procesa en USD bajo leyes de USA. El colmado recibe fondos equivalentes en DOP tras la validación física del beneficiario.
           </p>
        </div>
      </div>
      <div className="pt-4 flex items-center gap-3">
         <input 
           type="checkbox" 
           id="legal-check" 
           onChange={(e) => e.target.checked && onAccept()} 
           className="w-5 h-5 rounded-lg border-slate-300 text-blue-700 focus:ring-blue-500"
         />
         <label htmlFor="legal-check" className="text-[10px] font-black text-slate-900 uppercase tracking-widest cursor-pointer">Acepto los Términos y Garantía de Entrega</label>
      </div>
    </div>
  );
};
