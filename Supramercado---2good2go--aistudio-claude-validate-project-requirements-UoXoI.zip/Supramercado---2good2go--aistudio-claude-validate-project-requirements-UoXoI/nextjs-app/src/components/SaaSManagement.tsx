'use client';

import React, { useState } from 'react';
import { 
  Building2, Globe, Users, CreditCard, 
  ShieldCheck, ArrowRight, Plus, ExternalLink,
  Activity, Zap, Database, Landmark, RefreshCcw, DollarSign, Percent, Info,
  CheckCircle, XCircle, AlertTriangle, ToggleLeft as Toggle, ToggleRight,
  ShieldAlert, Scale, RotateCcw, Lock, History, Search
} from 'lucide-react';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

export const SaaSManagement: React.FC = () => {
  const { financialConfig, updateFinancialConfig, syncBpdRate, isSyncing, merchants, updateMerchant, tickets, resolveDispute, orders } = useOrders();
  const { notify } = useNotify();
  const [activeTab, setActiveTab] = useState<'CONFIG' | 'DISPUTES' | 'MERCHANTS'>('CONFIG');
  
  const handleConfigChange = (field: string, value: any) => {
    updateFinancialConfig({ ...financialConfig, [field]: value });
  };

  const openTickets = tickets.filter(t => t.status !== 'RESOLVED');
  const disputedOrders = orders.filter(o => o.status === 'DISPUTED');

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-24">
      <div className="bg-slate-900 p-10 rounded-[3rem] text-white relative overflow-hidden shadow-2xl">
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-6">
           <div>
              <h2 className="text-4xl font-black tracking-tight text-white">Centro de Comando</h2>
              <p className="text-blue-300 text-lg font-medium mt-2">Gestión de Escrow y Tasa Real-Time.</p>
           </div>
           <div className="flex bg-white/5 p-1.5 rounded-2xl border border-white/10 backdrop-blur-md">
              <button onClick={() => setActiveTab('CONFIG')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'CONFIG' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>Configuración</button>
              <button onClick={() => setActiveTab('DISPUTES')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all relative ${activeTab === 'DISPUTES' ? 'bg-red-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>
                Disputas {(openTickets.length > 0 || disputedOrders.length > 0) && <span className="absolute -top-1 -right-1 bg-white text-red-600 w-4 h-4 rounded-full flex items-center justify-center font-black animate-pulse">{openTickets.length + disputedOrders.length}</span>}
              </button>
              <button onClick={() => setActiveTab('MERCHANTS')} className={`px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'MERCHANTS' ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}>Merchants</button>
           </div>
        </div>
        <Database className="absolute -bottom-10 -right-10 w-64 h-64 text-white opacity-5" />
      </div>

      {activeTab === 'CONFIG' && (
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-2 space-y-8">
            <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
               <div className="flex items-center justify-between mb-8">
                 <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
                    <DollarSign className="w-7 h-7 text-green-600" /> Motor de Divisas
                 </h3>
                 <div className="flex items-center gap-4">
                   <button onClick={() => handleConfigChange('isManualRate', !financialConfig.isManualRate)} className="flex items-center gap-2 bg-slate-50 px-4 py-2 rounded-full border">
                      <span className="text-[10px] font-black uppercase text-slate-400">Manual</span>
                      {financialConfig.isManualRate ? <ToggleRight className="w-8 h-8 text-blue-700" /> : <Toggle className="w-8 h-8 text-slate-300" />}
                   </button>
                   {!financialConfig.isManualRate && <button onClick={syncBpdRate} className="text-[10px] font-black uppercase tracking-widest text-blue-700">{isSyncing ? <RefreshCcw className="w-4 h-4 animate-spin" /> : <Landmark className="w-4 h-4" />} Sync BPD</button>}
                 </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="p-6 bg-slate-50 rounded-[2rem] border space-y-4">
                     <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tasa Live BPD</p>
                     <div className="flex items-center gap-4">
                        <span className="text-3xl font-black text-slate-900">RD$ {financialConfig.lastBpdRate.toFixed(2)}</span>
                        <span className="text-[10px] font-bold px-2 py-1 rounded bg-green-100 text-green-500 uppercase">Verificado</span>
                     </div>
                  </div>
                  <div className="p-6 bg-blue-50/50 rounded-[2rem] border border-blue-100 space-y-4">
                     <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest">Margen de Tasa (%)</p>
                     <input type="number" value={financialConfig.exchangeRateMarginPercent} onChange={(e) => handleConfigChange('exchangeRateMarginPercent', parseFloat(e.target.value))} className="w-full p-4 bg-white border-2 border-blue-100 rounded-2xl font-black" />
                  </div>
               </div>
            </div>
          </div>

          <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white space-y-8 shadow-2xl">
             <h3 className="text-xl font-black flex items-center gap-3"><Activity className="w-6 h-6 text-orange-500" /> Red & Seguridad</h3>
             <div className="space-y-6">
                <StatusItem label="Stripe Connect" status="OK" />
                <StatusItem label="BPD Live API" status="OK" />
                <StatusItem label="Escrow Vault" status="LOCK" icon={Lock} />
             </div>
          </div>
        </div>
      )}

      {activeTab === 'DISPUTES' && (
        <div className="space-y-6">
           <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3"><ShieldAlert className="w-7 h-7 text-red-600" /> Tribunal de Mediación (Escrow)</h3>
           <div className="grid grid-cols-1 gap-4">
              {disputedOrders.length === 0 && openTickets.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed text-slate-300 font-bold italic">No hay disputas activas en la red.</div>
              ) : (
                <>
                  {disputedOrders.map(o => (
                    <div key={o.id} className="bg-white p-8 rounded-[2.5rem] border-2 border-red-100 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl animate-in slide-in-from-bottom-4">
                       <div className="flex items-center gap-5">
                          <div className="w-14 h-14 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center"><AlertTriangle className="w-7 h-7" /></div>
                          <div>
                             <h4 className="font-black text-slate-900 text-lg">Bloqueo de Fondos: {o.beneficiaryName}</h4>
                             <p className="text-sm font-medium text-slate-500 italic">Motivo: "{o.disputeReason}"</p>
                          </div>
                       </div>
                       <div className="flex gap-3">
                          <button onClick={() => resolveDispute(o.id, 'REFUND')} className="px-6 py-3 bg-slate-900 text-white rounded-xl font-black text-[10px] uppercase flex items-center gap-2 shadow-lg"><RotateCcw className="w-4 h-4" /> Reembolsar (NY)</button>
                          <button onClick={() => resolveDispute(o.id, 'RELEASE')} className="px-6 py-3 bg-green-600 text-white rounded-xl font-black text-[10px] uppercase flex items-center gap-2 shadow-lg"><CheckCircle className="w-4 h-4" /> Forzar Liquidación (RD)</button>
                       </div>
                    </div>
                  ))}
                </>
              )}
           </div>
        </div>
      )}

      {activeTab === 'MERCHANTS' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3"><Building2 className="w-7 h-7 text-purple-600" /> Directorio de Socios</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" placeholder="Buscar RNC o Nombre..." className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-full text-xs font-bold outline-none" />
            </div>
          </div>
          <div className="bg-white rounded-[3rem] border border-slate-200 shadow-sm overflow-hidden">
             <table className="w-full text-left">
               <thead className="bg-slate-50 border-b">
                 <tr>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Comercio</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Provincia</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Balance Pendiente</th>
                   <th className="px-8 py-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Estado KYC</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-100">
                 {merchants.map(m => (
                   <tr key={m.id} className="hover:bg-slate-50/50 cursor-pointer">
                     <td className="px-8 py-6">
                        <div className="flex items-center gap-4">
                           <img src={m.logo} className="w-10 h-10 rounded-xl object-cover" />
                           <p className="font-black text-slate-900">{m.name}</p>
                        </div>
                     </td>
                     <td className="px-8 py-6 text-sm font-bold text-slate-500">{m.locationName}</td>
                     <td className="px-8 py-6">
                        <p className="font-black text-slate-900">RD$ {(m.walletBalance || 0).toLocaleString()}</p>
                     </td>
                     <td className="px-8 py-6">
                        <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase border ${m.isVerified ? 'bg-green-50 text-green-600 border-green-100' : 'bg-orange-50 text-orange-600 border-orange-100'}`}>
                          {m.isVerified ? 'VERIFICADO' : 'PENDIENTE'}
                        </span>
                     </td>
                   </tr>
                 ))}
               </tbody>
             </table>
          </div>
        </div>
      )}
    </div>
  );
};

const StatusItem = ({ label, status, icon: Icon = Zap }: { label: string, status: string, icon?: any }) => (
  <div className="flex items-center justify-between">
    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{label}</span>
    <span className="flex items-center gap-1.5 text-[10px] font-black text-green-500 uppercase tracking-widest bg-green-500/10 px-3 py-1 rounded-full">
      <Icon className="w-3 h-3 fill-green-500" /> {status}
    </span>
  </div>
);
