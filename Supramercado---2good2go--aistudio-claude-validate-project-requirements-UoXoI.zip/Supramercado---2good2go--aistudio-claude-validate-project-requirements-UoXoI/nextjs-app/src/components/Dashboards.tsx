'use client';

import React, { useMemo, useState } from 'react';
import { 
  TrendingUp, Users, ShoppingBag, CreditCard, 
  Store, ShieldAlert, LifeBuoy, MapPin, Package, Clock,
  Smartphone, CheckCircle2, AlertCircle, BarChart3,
  Headphones, Globe, Database, Loader2, ClipboardCheck, ArrowRight,
  Leaf, Star, Power, PowerOff, DollarSign, ArrowUpRight, Navigation, ShieldCheck
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, LineChart, Line,
  AreaChart, Area, PieChart, Pie, Cell
} from 'recharts';
import { UserRole, Order } from '../types';
import { useOrders } from './OrderContext';
import { useNotify } from './NotificationSystem';

const StatCard = ({ title, value, sub, icon: Icon, color }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex items-start justify-between hover:shadow-md transition-shadow">
    <div>
      <p className="text-slate-500 text-sm font-medium">{title}</p>
      <h3 className="text-2xl font-bold mt-1 text-slate-900">{value}</h3>
      <p className="text-xs text-slate-400 mt-1">{sub}</p>
    </div>
    <div className={`p-3 rounded-xl ${color}`}>
      <Icon className="text-white w-5 h-5" />
    </div>
  </div>
);

export const SaaSAdminDashboard = () => {
  const { orders, calculateFinancials, tickets } = useOrders();
  
  const stats = useMemo(() => {
    let totalVolume = 0;
    let totalCommissions = 0;
    let totalStripeFees = 0;
    orders.forEach(o => {
      totalVolume += o.totalUSD;
      // Fix: Destructure platformFeeUSD instead of non-existent supraNetUSD
      const { platformFeeUSD, stripeFeeUSD } = calculateFinancials(o.subtotalUSD * o.exchangeRateUsed);
      totalCommissions += platformFeeUSD;
      totalStripeFees += stripeFeeUSD;
    });
    return { totalVolume, totalCommissions, totalStripeFees };
  }, [orders, calculateFinancials]);

  const activeTickets = tickets.filter(t => t.status !== 'RESOLVED');

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Volumen Global" value={`$${stats.totalVolume.toLocaleString()}`} sub="Total Procesado" icon={TrendingUp} color="bg-blue-600" />
        <StatCard title="Alertas Riesgo" value={activeTickets.length} sub="Tickets Críticos RD" icon={ShieldAlert} color={activeTickets.length > 0 ? "bg-red-500 animate-pulse" : "bg-slate-900"} />
        <StatCard title="Órdenes Totales" value={orders.length} sub="USA -> RD Pipeline" icon={Package} color="bg-purple-600" />
        <StatCard title="Salud de Red" value="Estable" sub="Latencia 12ms" icon={ShieldCheck} color="bg-emerald-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
           <div className="flex justify-between items-center mb-6">
              <h4 className="font-black text-xl text-slate-900">Cola de Incidencias en RD</h4>
              <button className="text-[10px] font-black uppercase text-blue-700">Ver todo</button>
           </div>
           <div className="space-y-4">
              {activeTickets.length === 0 ? (
                <div className="text-center py-12 text-slate-300 italic font-bold">No hay incidencias activas en el corredor.</div>
              ) : (
                activeTickets.map(t => (
                  <div key={t.id} className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-red-500 rounded-xl flex items-center justify-center text-white"><ShieldAlert className="w-5 h-5" /></div>
                      <div>
                        <p className="text-sm font-black text-red-900">{t.subject}</p>
                        <p className="text-[10px] text-red-400 font-bold uppercase">Orden #{t.orderId}</p>
                      </div>
                    </div>
                    <button className="bg-white text-red-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-red-100">Intervenir</button>
                  </div>
                ))
              )}
           </div>
        </div>
        
        <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white">
          <h4 className="text-lg font-black mb-6">Métrica de Fraude</h4>
          <div className="h-48 flex items-end justify-between gap-2">
             {[4,7,2,9,5,3,8].map((v, i) => (
               <div key={i} className="flex-1 bg-blue-500/20 rounded-t-lg relative group">
                  <div className="absolute bottom-0 w-full bg-blue-500 rounded-t-lg transition-all duration-1000" style={{ height: `${v * 10}%` }}></div>
               </div>
             ))}
          </div>
          <p className="text-xs text-slate-400 mt-6 leading-relaxed">Monitoreo de redenciones fuera de zona horaria y GPS de colmado.</p>
        </div>
      </div>
    </div>
  );
};

export const MerchantAdminDashboard = () => {
  const { orders, reviews, merchants, updateMerchant } = useOrders();
  const { notify } = useNotify();
  const merchantId = 'm1';
  const merchant = merchants.find(m => m.id === merchantId)!;
  const mOrders = useMemo(() => orders.filter(o => o.merchantId === merchantId), [orders]);
  const redeemedOrders = mOrders.filter(o => o.status === 'REDEEMED');
  const totalSalesDOP = redeemedOrders.reduce((acc, curr) => acc + (curr.subtotalUSD * curr.exchangeRateUsed), 0);
  const pendingPayoutDOP = mOrders.filter(o => o.status !== 'REDEEMED' && o.status !== 'CANCELLED').reduce((acc, curr) => acc + (curr.subtotalUSD * curr.exchangeRateUsed), 0);

  const toggleStatus = () => {
    const nextState = !merchant.isOpen;
    updateMerchant(merchantId, { isOpen: nextState });
    notify(nextState ? "Abierto" : "Cerrado", nextState ? "Visible en NY." : "Ventas pausadas.", "INFO");
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-6 bg-slate-900 p-10 rounded-[3rem] text-white">
        <div>
           <h2 className="text-4xl font-black text-white">{merchant.name}</h2>
           <p className="text-slate-400 font-medium mt-2">Sucursal RD Operativa</p>
        </div>
        <div className="flex items-center gap-4 bg-white/5 p-2 rounded-2xl border border-white/10">
           <span className={`text-[10px] font-black uppercase px-4 py-2 rounded-xl ${merchant.isOpen ? 'text-green-400' : 'text-red-400'}`}>{merchant.isOpen ? 'ONLINE' : 'OFFLINE'}</span>
           <button onClick={toggleStatus} className={`p-4 rounded-xl ${merchant.isOpen ? 'bg-red-500' : 'bg-green-500'}`}>{merchant.isOpen ? <PowerOff className="w-5 h-5" /> : <Power className="w-5 h-5" />}</button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Ventas Hoy" value={`RD$ ${totalSalesDOP.toLocaleString()}`} sub="Liquidación Lista" icon={CreditCard} color="bg-green-600" />
        <StatCard title="Pendiente" value={`RD$ ${pendingPayoutDOP.toLocaleString()}`} sub="En cola de retiro" icon={Clock} color="bg-orange-500" />
        <StatCard title="Calidad" value="4.9" sub="Basado en reviews" icon={Star} color="bg-blue-600" />
      </div>
    </div>
  );
};

const LandmarkIcon = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011-1v5m-4 0h4" /></svg>
);
