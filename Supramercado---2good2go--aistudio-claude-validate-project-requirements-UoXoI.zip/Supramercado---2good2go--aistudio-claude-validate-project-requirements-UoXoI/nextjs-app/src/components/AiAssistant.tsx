'use client';

import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Send, Sparkles, X, Loader2, Map as MapIcon, Link as LinkIcon, Navigation, User } from 'lucide-react';
import { ChatMessage, Beneficiary } from '../types';

interface AiAssistantProps {
  selectedBeneficiary: Beneficiary | null;
}

export const AiAssistant: React.FC<AiAssistantProps> = ({ selectedBeneficiary }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: '¡Hola! Soy tu asistente Supra. ¿Qué necesita tu familia hoy?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [groundingChunks, setGroundingChunks] = useState<any[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      // Fix: Always initialize GoogleGenAI with the API key from process.env.API_KEY in a named parameter object.
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const context = selectedBeneficiary 
        ? `El usuario está comprando para ${selectedBeneficiary.name} en ${selectedBeneficiary.address}, ${selectedBeneficiary.city}. ` 
        : "";

      const response = await ai.models.generateContent({
        // Fix: Use 'gemini-flash-lite-latest' for the lite model task.
        model: 'gemini-flash-lite-latest',
        contents: `${context}Usuario dice: ${userMessage}. Ayuda a encontrar productos o comercios cercanos.`,
        config: {
          tools: [{ googleSearch: {} }, { googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: {
                latitude: selectedBeneficiary?.lat || 18.4861,
                longitude: selectedBeneficiary?.lng || -69.9312
              }
            }
          }
        }
      });

      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setGroundingChunks(chunks);
      // Fix: Access response.text as a property, not a function.
      setMessages(prev => [...prev, { role: 'model', text: response.text || 'He encontrado algunas opciones.' }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: 'Error al conectar con los comercios locales.' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-slate-900 text-white rounded-2xl shadow-2xl flex items-center justify-center hover:scale-110 transition-all z-50 group"
      >
        <Sparkles className="w-6 h-6 group-hover:rotate-12 transition-transform" />
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-full max-w-[400px] h-[600px] bg-white rounded-[2.5rem] shadow-2xl border border-slate-200 flex flex-col overflow-hidden z-50 animate-in slide-in-from-bottom-8">
          <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                <Navigation className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-black text-sm uppercase">Asistente Supra</h4>
                <p className="text-[10px] text-blue-300 font-bold">
                  {selectedBeneficiary ? `Cerca de ${selectedBeneficiary.name}` : 'Buscador Global'}
                </p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/10 rounded-lg"><X className="w-5 h-5" /></button>
          </div>

          <div ref={scrollRef} className="flex-1 p-6 overflow-y-auto space-y-4 bg-slate-50">
            {messages.map((msg, i) => (
              <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-3xl text-sm font-medium ${
                  msg.role === 'user' ? 'bg-blue-700 text-white rounded-tr-none' : 'bg-white text-slate-900 rounded-tl-none border border-slate-200'
                }`}>
                  {msg.text}
                </div>
              </div>
            ))}
            
            {groundingChunks.length > 0 && (
              <div className="space-y-2 mt-4">
                {groundingChunks.map((chunk, idx) => (
                  <div key={idx} className="bg-white p-3 rounded-2xl border border-slate-100 shadow-sm">
                    {chunk.maps && (
                      <a href={chunk.maps.uri} target="_blank" className="flex items-center gap-3 text-blue-600 font-bold text-xs" rel="noreferrer">
                        <MapIcon className="w-4 h-4" /> {chunk.maps.title}
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}
            
            {isLoading && (
              <div className="flex justify-start gap-2 text-slate-400 text-xs font-bold p-4 animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin" /> Escaneando inventario local...
              </div>
            )}
          </div>

          <div className="p-4 bg-white border-t border-slate-100 flex gap-2">
            <input 
              type="text" 
              placeholder="¿Qué falta en casa?"
              className="flex-1 bg-slate-100 border-none rounded-2xl px-5 py-4 text-sm font-bold outline-none"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button onClick={handleSend} className="p-4 bg-blue-700 text-white rounded-2xl shadow-lg hover:bg-blue-800 disabled:opacity-50" disabled={isLoading}>
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </>
  );
};
