'use client';

import React, { useState, useEffect } from 'react';
import { Activity, Globe, ShoppingBag, CheckCircle, Zap } from 'lucide-react';

interface ActivityItem {
  id: string;
  type: 'ORDER' | 'REDEEM' | 'NEW_MERCHANT';
  message: string;
  time: string;
}

export const ActivityFeed: React.FC = () => {
  const [activities, setActivities] = useState<ActivityItem[]>([
    { id: '1', type: 'ORDER', message: 'Nueva compra desde Queens, NY para Santiago', time: 'Hace 2m' },
    { id: '2', type: 'REDEEM', message: 'Orden redimida con éxito en Supermercado Nacional', time: 'Hace 5m' },
    { id: '3', type: 'NEW_MERCHANT', message: 'Colmado "El Primo" ha completado su KYC', time: 'Hace 12m' },
  ]);

  return (
    <div className="bg-slate-900 rounded-[2.5rem] p-8 border border-white/5 shadow-2xl space-y-6">
      <div className="flex items-center justify-between">
        <h4 className="text-xl font-black text-white flex items-center gap-3">
          <Activity className="w-6 h-6 text-blue-500" /> Actividad Global
        </h4>
        <span className="bg-blue-500/20 text-blue-400 px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest animate-pulse">
          Live Hub
        </span>
      </div>

      <div className="space-y-4">
        {activities.map(act => (
          <div key={act.id} className="flex gap-4 p-4 bg-white/5 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors group cursor-default">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              act.type === 'ORDER' ? 'bg-blue-500/20 text-blue-400' : 
              act.type === 'REDEEM' ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'
            }`}>
              {act.type === 'ORDER' && <ShoppingBag className="w-5 h-5" />}
              {act.type === 'REDEEM' && <CheckCircle className="w-5 h-5" />}
              {act.type === 'NEW_MERCHANT' && <Zap className="w-5 h-5" />}
            </div>
            <div className="flex-1">
              <p className="text-xs font-bold text-white group-hover:text-blue-300 transition-colors">{act.message}</p>
              <p className="text-[10px] font-black text-slate-500 uppercase mt-1">{act.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
