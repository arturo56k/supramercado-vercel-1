'use client';

import React, { useState, useRef } from 'react';
import { 
  Search, Filter, ShoppingBag, Clock, CheckCircle2, 
  User, Phone, MapPin, MoreVertical, Eye,
  ArrowUpRight, Volume2, Loader2, Camera, ShieldCheck, X,
  ChefHat, PackageCheck, Truck, FileText, Download, Sparkles, History, Ban, Printer
} from 'lucide-react';
import { GoogleGenAI, Modality } from "@google/genai";
import { useOrders } from './OrderContext';
import { ReceiptPrinter } from './ReceiptPrinter';
import { UserRole } from '../types';
import { hasPermission } from '@/utils/permissions';

interface OrderManagementProps {
  userRole?: UserRole;
}

export const OrderManagement: React.FC<OrderManagementProps> = ({ userRole = UserRole.MERCHANT_ADMIN }) => {
  const { orders, updateOrder, merchants } = useOrders();
  const [filter, setFilter] = useState('ALL');
  const [showAudit, setShowAudit] = useState<string | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState<{note: string, img: string} | null>(null);
  const [generatingInvoice, setGeneratingInvoice] = useState<string | null>(null);
  const [invoiceText, setInvoiceText] = useState<string | null>(null);
  const [printingOrder, setPrintingOrder] = useState<any | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredOrders = orders.filter(o => {
    if (filter === 'ALL') return true;
    return o.status === filter;
  });

  const generateLegalInvoice = async (order: any) => {
    if (!hasPermission(userRole, 'generate_invoice')) return;
    setGeneratingInvoice(order.id);
    setInvoiceText(null);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Genera el texto de una factura pro-forma legal dominicana para el comercio "Supermercado Nacional". 
        RNC: 101-00000-1. 
        Cliente Beneficiario: ${order.beneficiaryName}. 
        Items: ${order.items}. 
        Total en DOP: RD$ ${(order.subtotalUSD * order.exchangeRateUsed).toLocaleString()}. 
        Incluye número de comprobante fiscal (NCF) simulado de consumo (B02). 
        El formato debe ser limpio y profesional en texto plano.`,
      });
      setInvoiceText(response.text || "No se pudo generar el documento.");
    } catch (err) {
      setInvoiceText("Error al conectar con el motor de facturación.");
    } finally {
      setGeneratingInvoice(null);
    }
  };

  const confirmDelivery = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    updateOrder(orderId, { status: 'REDEEMED', verificationImage: auditResult?.img });
    setShowAudit(null);
    setAuditResult(null);
    if (order && hasPermission(userRole, 'generate_invoice')) setPrintingOrder(order);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 pb-20">
      {printingOrder && (
        <ReceiptPrinter 
          order={printingOrder} 
          merchant={merchants.find(m => m.id === printingOrder.merchantId) || merchants[0]} 
          onClose={() => setPrintingOrder(null)} 
        />
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Monitor de Operaciones</h2>
          <p className="text-slate-500 font-medium text-lg mt-1">Control de flujo USA -> RD en tiempo real.</p>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide w-full md:w-auto">
          {['ALL', 'PENDING', 'PREPARING', 'READY_FOR_PICKUP', 'REDEEMED'].map(f => (
            <button 
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filter === f ? 'bg-slate-900 text-white shadow-xl' : 'bg-slate-50 text-slate-400 border border-slate-100'}`}
            >
              {f === 'ALL' ? 'Todas' : f}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredOrders.length === 0 ? (
          <div className="text-center py-20 bg-slate-50 rounded-[2.5rem] border-2 border-dashed border-slate-200">
             <ShoppingBag className="w-16 h-16 text-slate-200 mx-auto mb-4" />
             <p className="font-black text-slate-400 uppercase tracking-widest text-xs">No hay órdenes en esta categoría.</p>
          </div>
        ) : (
          filteredOrders.map(order => (
            <div key={order.id} className="bg-white p-6 rounded-[2rem] border border-slate-200 shadow-sm hover:border-blue-300 transition-all group relative">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center border ${order.status === 'REDEEMED' ? 'bg-green-100 text-green-600' : 'bg-slate-100'}`}>
                    {order.status === 'PENDING' && <Clock className="w-5 h-5" />}
                    {order.status === 'REDEEMED' && <ShieldCheck className="w-5 h-5" />}
                  </div>
                  <div>
                    <h4 className="font-black text-slate-900">Orden #{order.id.split('-')[1]}</h4>
                    <p className="text-xs font-bold text-slate-400 uppercase">{order.beneficiaryName}</p>
                  </div>
                </div>

                <div className="flex-1 lg:max-w-md p-4 bg-slate-50 rounded-2xl border border-slate-100">
                   <p className="text-sm font-bold text-slate-700">{order.items}</p>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Liquidación Neto</p>
                    <p className="text-lg font-black text-slate-900">RD$ {(order.subtotalUSD * order.exchangeRateUsed).toLocaleString()}</p>
                  </div>
                  
                  <div className="flex gap-2">
                     {order.status === 'REDEEMED' && hasPermission(userRole, 'generate_invoice') && (
                        <button onClick={() => setPrintingOrder(order)} className="p-3 bg-blue-50 text-blue-700 rounded-xl hover:bg-blue-100"><Printer className="w-5 h-5" /></button>
                     )}
                     
                     {hasPermission(userRole, 'generate_invoice') && (
                       <button 
                         onClick={() => generateLegalInvoice(order)}
                         disabled={generatingInvoice === order.id}
                         className="p-3 bg-slate-100 text-slate-400 rounded-xl hover:text-blue-700 hover:bg-blue-50 transition-all"
                       >
                         {generatingInvoice === order.id ? <Loader2 className="w-5 h-5 animate-spin" /> : <FileText className="w-5 h-5" />}
                       </button>
                     )}

                     {(order.status === 'READY_FOR_PICKUP' || order.status === 'PENDING') && hasPermission(userRole, 'redeem_order') && (
                       <button 
                        onClick={() => setShowAudit(order.id)}
                        className="p-3 bg-slate-900 text-white rounded-xl hover:scale-110 transition-all"
                       >
                         <Camera className="w-5 h-5" />
                       </button>
                     )}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {hasPermission(userRole, 'generate_invoice') && (
        <div className="mt-12 bg-white rounded-[3rem] border border-slate-200 shadow-sm overflow-hidden">
           <div className="p-8 border-b border-slate-100 flex items-center justify-between">
              <h3 className="text-xl font-black text-slate-900 flex items-center gap-3"><History className="w-6 h-6 text-slate-400" /> Historial NCF</h3>
              <span className="text-[10px] font-black text-orange-500 uppercase tracking-widest bg-orange-50 px-4 py-1.5 rounded-full border border-orange-100">B02 Consumo</span>
           </div>
           <div className="p-10 text-center opacity-30 italic font-bold text-sm">
              Persistencia fiscal local activada (DGII Compatible).
           </div>
        </div>
      )}
    </div>
  );
};
