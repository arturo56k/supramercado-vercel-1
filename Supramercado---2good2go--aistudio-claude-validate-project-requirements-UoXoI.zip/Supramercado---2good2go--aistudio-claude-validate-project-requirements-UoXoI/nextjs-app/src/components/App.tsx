'use client';
import React, { useState, useEffect } from 'react';
import { 
  Home, ShoppingBag, User, Smartphone, ShoppingCart, 
  Search, Activity, ShieldCheck, LifeBuoy, Camera, TabletSmartphone, Loader2
} from 'lucide-react';
import { UserRole, Beneficiary, Product, Merchant, Order } from '@/types';
import { AiAssistant } from '@/components/AiAssistant';
import { PaymentModal } from '@/components/PaymentModal';
import { ScannerView } from '@/components/ScannerView';
import { ActivityFeed } from '@/components/ActivityFeed';
import { Marketplace } from '@/components/Marketplace';
import { Landing } from '@/components/Landing';
import { Profile } from '@/components/Profile';
import { CartDrawer } from '@/components/CartDrawer';
import { MagicLinkView } from '@/components/MagicLinkView';
import { SaaSManagement } from '@/components/SaaSManagement';
import { MerchantHub } from '@/components/MerchantHub';
import { SupportHub } from '@/components/SupportHub';
import { useOrders } from '@/components/OrderContext';
// Fixed casing: notificationSystem -> NotificationSystem
import { useNotify } from '@/components/NotificationSystem'; 
import { MerchantPage } from '@/components/MerchantPage';
import { BeneficiarySelector } from '@/components/BeneficiarySelector';
import { NetworkHUD } from '@/components/NetworkHUD';
import { validateOFAC } from '@/components/OFACValidator';

const MOCK_BENEFICIARIES: Beneficiary[] = [
  { id: 'b1', name: 'Doña Altagracia', relationship: 'Madre', phone: '+18295550101', address: 'Villa Olga', city: 'Santiago', lat: 19.4517, lng: -70.6970, avatar: 'https://picsum.photos/seed/altagracia/100/100' },
  { id: 'b2', name: 'Tío Juan', relationship: 'Tío', phone: '+18095550202', address: 'Ensanche Espaillat', city: 'Santiago', lat: 19.4617, lng: -70.7070, avatar: 'https://picsum.photos/seed/juan/100/100' },
];

const App: React.FC = () => {
  const [role, setRole] = useState<UserRole>(UserRole.CLIENT);
  const [view, setView] = useState<'HOME' | 'MERCHANT_DETAIL' | 'MARKET' | 'PROFILE' | 'MAGIC_LINK' | 'ADMIN_SAAS' | 'MERCHANT_HUB' | 'SUPPORT'>('HOME');
  const [selectedMerchant, setSelectedMerchant] = useState<Merchant | null>(null);
  const [selectedBeneficiaryId, setSelectedBeneficiaryId] = useState<string | null>(MOCK_BENEFICIARIES[0].id);
  const [cart, setCart] = useState<{ product: Product; qty: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [activeOrderCode, setActiveOrderCode] = useState<string | null>(null);
  const [isValidatingCompliance, setIsValidatingCompliance] = useState(false);

  const { orders, merchants, addOrder, calculateFinancials, getOrderByCode, cloudSync } = useOrders();
  const { notify, requestNativePermissions } = useNotify();

  useEffect(() => {
    requestNativePermissions();
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    if (code) {
      setActiveOrderCode(code);
      setView('MAGIC_LINK');
    }
  }, []);

  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) return prev.map(item => item.product.id === product.id ? { ...item, qty: item.qty + 1 } : item);
      return [...prev, { product, qty: 1 }];
    });
    notify("Añadido", `${product.name} listo para enviar.`, "SUCCESS");
  };

  const finalizeCheckout = async () => {
    const beneficiary = MOCK_BENEFICIARIES.find(b => b.id === selectedBeneficiaryId);
    if (!beneficiary) return;

    setIsValidatingCompliance(true);
    notify("Compliance", "Validando beneficiario con listas OFAC...", "INFO");

    const ofacCheck = await validateOFAC(beneficiary.name, beneficiary.phone, beneficiary.address);

    if (ofacCheck.status === 'REJECTED') {
      setIsValidatingCompliance(false);
      setIsPaymentOpen(false);
      notify("Transacción Rechazada", ofacCheck.reason || "No podemos procesar este envío por restricciones regulatorias.", "WARNING");
      return;
    }

    const subtotalDOP = cart.reduce((acc, item) => acc + (item.product.basePriceDOP * item.qty), 0);
    const financials = calculateFinancials(subtotalDOP);

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      status: 'PENDING',
      buyerId: 'user1',
      beneficiaryId: beneficiary.id,
      beneficiaryName: beneficiary.name,
      items: cart.map(i => `${i.qty}x ${i.product.name}`).join(', '),
      totalUSD: financials.totalUSD,
      subtotalUSD: subtotalDOP / financials.effectiveRate,
      exchangeRateUsed: financials.effectiveRate,
      merchantId: cart[0].product.merchantId,
      pickupCode: Math.floor(1000 + Math.random() * 9000).toString(),
      magicLinkCode: Math.random().toString(36).substring(7),
      createdAt: new Date().toISOString(),
      isSubscriptionInstance: false,
      ofacStatus: 'APPROVED',
      paymentStatus: 'AUTHORIZED'
    };

    addOrder(newOrder);

    // TRIGGER N8N ORCHESTRATION
    try {
      fetch('/api/webhooks/n8n-trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          order: newOrder, 
          beneficiary,
          eventType: 'ORDER_CREATED'
        })
      });
    } catch (e) { console.warn("n8n Dispatch failed (offline mode)"); }

    setIsValidatingCompliance(false);
    setActiveOrderCode(newOrder.magicLinkCode);
    setIsPaymentOpen(false);
    setCart([]);
    setView('MAGIC_LINK');
    notify("Pago Procesado", "El link ha sido enviado por WhatsApp.", "SUCCESS");
  };

  const renderContent = () => {
    if (view === 'MAGIC_LINK') {
      const order = getOrderByCode(activeOrderCode || '');
      const merchant = merchants.find(m => m.id === order?.merchantId) || merchants[0];
      if (!order) return <div className="text-center py-20 font-black text-slate-300 italic">Ticket no disponible</div>;
      return <MagicLinkView order={order} merchant={merchant} onBack={() => setView('HOME')} onConfirm={() => notify("Entregado", "Disfrute su compra", "SUCCESS")} />;
    }

    switch (view) {
      case 'HOME':
        return (
          <div className="space-y-12">
            <BeneficiarySelector beneficiaries={MOCK_BENEFICIARIES} selectedId={selectedBeneficiaryId} onSelect={setSelectedBeneficiaryId} onAdd={() => notify("Próximamente", "Registro de nuevos familiares.", "INFO")} />
            <Landing 
              onSelectMerchant={(m) => { setSelectedMerchant(m); setView('MERCHANT_DETAIL'); }} 
              onBrowseAll={() => setView('MARKET')} 
            />
          </div>
        );
      case 'MERCHANT_DETAIL':
        return selectedMerchant ? <MerchantPage merchant={selectedMerchant} onBack={() => setView('HOME')} onAddToCart={handleAddToCart} /> : null;
      case 'MARKET':
        return <Marketplace selectedBeneficiary={MOCK_BENEFICIARIES.find(b => b.id === selectedBeneficiaryId) || null} onAddToCart={handleAddToCart} />;
      case 'PROFILE':
        return <Profile role={role} />;
      case 'ADMIN_SAAS':
        return <SaaSManagement />;
      case 'MERCHANT_HUB':
        return <MerchantHub />;
      case 'SUPPORT':
        return <SupportHub isAdmin={role === UserRole.SAAS_ADMIN} />;
      default:
        return <Landing onSelectMerchant={(m) => { setSelectedMerchant(m); setView('MERCHANT_DETAIL'); }} onBrowseAll={() => setView('MARKET')} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#F8FAFC] font-sans text-slate-900">
      <NetworkHUD />
      {view !== 'MAGIC_LINK' && <AiAssistant selectedBeneficiary={MOCK_BENEFICIARIES.find(b => b.id === selectedBeneficiaryId) || null} />}
      
      {isValidatingCompliance && (
        <div className="fixed inset-0 z-[300] bg-slate-900/40 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-white p-8 rounded-[2rem] shadow-2xl flex flex-col items-center gap-4">
            <Loader2 className="w-12 h-12 text-blue-700 animate-spin" />
            <p className="font-black text-sm uppercase tracking-widest text-slate-900">Verificando Compliance...</p>
          </div>
        </div>
      )}

      <PaymentModal 
        isOpen={isPaymentOpen} 
        totalUSD={cart.reduce((acc, item) => acc + (item.product.priceUSD * item.qty), 0)} 
        onSuccess={finalizeCheckout} 
        onCancel={() => setIsPaymentOpen(false)} 
      />

      <CartDrawer 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        cartItems={cart} 
        onRemove={(id) => setCart(prev => prev.filter(i => i.product.id !== id))}
        onCheckout={() => { setIsCartOpen(false); setIsPaymentOpen(true); }}
        selectedBeneficiary={MOCK_BENEFICIARIES.find(b => b.id === selectedBeneficiaryId) || null}
      />

      {showScanner && <ScannerView onClose={() => setShowScanner(false)} />}

      {view !== 'MAGIC_LINK' && (
        <aside className="hidden lg:flex flex-col w-20 xl:w-72 bg-white border-r border-slate-100 p-6 shadow-sm z-40">
          <div className="flex items-center gap-4 mb-14 px-2" onClick={() => setView('HOME')}>
            <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black italic shadow-xl cursor-pointer">S</div>
            <h1 className="text-xl font-black tracking-tighter hidden xl:block cursor-pointer">Supra</h1>
          </div>
          
          <nav className="space-y-2">
            <NavItem active={view === 'HOME'} onClick={() => setView('HOME')} icon={Home} label="Marketplace" />
            <NavItem active={view === 'MARKET'} onClick={() => setView('MARKET')} icon={ShoppingBag} label="Directo RD" />
            <NavItem active={view === 'PROFILE'} onClick={() => setView('PROFILE')} icon={User} label="Perfil" />
            
            <div className="pt-8 mt-8 border-t border-slate-50 space-y-1">
               <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest px-4 mb-2 hidden xl:block">Consolas</p>
               <NavItem active={view === 'ADMIN_SAAS'} onClick={() => { setRole(UserRole.SAAS_ADMIN); setView('ADMIN_SAAS'); }} icon={ShieldCheck} label="SaaS Admin" color="text-red-500" />
               <NavItem active={view === 'MERCHANT_HUB'} onClick={() => { setRole(UserRole.MERCHANT_ADMIN); setView('MERCHANT_HUB'); }} icon={TabletSmartphone} label="Terminal POS" color="text-blue-500" />
               <NavItem active={view === 'SUPPORT'} onClick={() => setView('SUPPORT')} icon={LifeBuoy} label="Ayuda" color="text-orange-500" />
            </div>
          </nav>

          <div className="mt-auto">
            <button 
              onClick={() => setShowScanner(true)}
              className="w-full bg-slate-900 text-white p-4 rounded-2xl shadow-xl flex items-center justify-center gap-3 hover:scale-105 transition-all mb-4"
            >
              <Camera className="w-6 h-6" />
              <span className="font-bold text-sm hidden xl:block">Rápido Escaneo</span>
            </button>
            <ActivityFeed />
          </div>
        </aside>
      )}

      <main className={`flex-1 overflow-y-auto ${view === 'MAGIC_LINK' ? '' : 'p-6 lg:p-12'}`}>
        {view !== 'MAGIC_LINK' && (
          <header className="flex flex-col md:flex-row justify-between items-center mb-10 gap-6">
            <div className="flex items-center justify-between w-full md:w-auto">
              <div className="flex items-center gap-4 lg:hidden" onClick={() => setView('HOME')}>
                 <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black italic">S</div>
              </div>
              <div className="flex items-center gap-2 bg-slate-900 px-4 py-2 rounded-full border border-white/10 shadow-lg">
                <Activity className="w-3 h-3 text-green-500" />
                <span className="text-[9px] font-black text-white uppercase tracking-[0.2em]">Corredor NY-RD: {cloudSync.latencyMs}ms</span>
              </div>
            </div>
            
            <div className="flex-1 max-w-xl hidden md:block">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input type="text" placeholder="¿Qué necesita tu familia hoy?" className="w-full pl-12 pr-4 py-4 bg-white border border-slate-100 rounded-2xl shadow-sm outline-none focus:border-blue-500 font-bold text-sm" />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <button onClick={() => setIsCartOpen(true)} className="relative p-4 bg-white rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-all">
                <ShoppingCart className="w-6 h-6 text-blue-700" />
                {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">{cart.length}</span>}
              </button>
              <div className="w-12 h-12 bg-slate-200 rounded-2xl overflow-hidden shadow-sm hidden sm:block border-2 border-white">
                <img src="https://picsum.photos/seed/pedro/100/100" className="w-full h-full object-cover" />
              </div>
            </div>
          </header>
        )}
        
        <div className="max-w-[1600px] mx-auto">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

const NavItem = ({ active, onClick, icon: Icon, label, color = "text-slate-400" }: any) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl transition-all ${
      active ? 'bg-slate-900 text-white shadow-xl' : `hover:bg-slate-50 ${color}`
    }`}
  >
    <Icon className={`w-6 h-6 ${active ? 'text-white' : ''}`} />
    <span className="font-bold text-sm hidden xl:block">{label}</span>
  </button>
);

export default App;