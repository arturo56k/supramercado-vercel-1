'use client';

import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Search, Sparkles, MapPin, Loader2, ArrowRight } from 'lucide-react';

export const AiStoreFinder: React.FC<{ onSelectMerchant: (name: string) => void }> = ({ onSelectMerchant }) => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<any[]>([]);

  const handleSearch = async () => {
    if (!query) return;
    setIsLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `El usuario en USA busca comercios de comida cerca de: "${query}" en República Dominicana. Recomienda 3 zonas o comercios hipotéticos que suelen estar en esa área. Responde en formato JSON lista de objetos {name, area, reason}.`,
        config: { tools: [{ googleSearch: {} }] }
      });
      
      const cleanJson = response.text.replace(/```json|```/g, '').trim();
      setSuggestions(JSON.parse(cleanJson));
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-blue-100 text-blue-700 rounded-xl flex items-center justify-center">
          <Sparkles className="w-5 h-5" />
        </div>
        <h3 className="font-black text-xl text-slate-900">Encuentra por ubicación</h3>
      </div>
      
      <div className="relative">
        <input 
          type="text" 
          placeholder="Ej: Cerca de la UASD en Santiago..."
          className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl focus:border-blue-500 outline-none font-bold text-sm"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
        />
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
        <button 
          onClick={handleSearch}
          disabled={isLoading}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-2 bg-blue-700 text-white rounded-xl"
        >
          {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4" />}
        </button>
      </div>

      <div className="space-y-3">
        {suggestions.map((s, i) => (
          <button 
            key={i}
            onClick={() => onSelectMerchant(s.name)}
            className="w-full p-4 bg-slate-50 border border-slate-100 rounded-2xl text-left hover:border-blue-300 transition-all group"
          >
            <p className="text-sm font-black text-slate-900 group-hover:text-blue-700">{s.name}</p>
            <p className="text-[10px] font-bold text-slate-400 uppercase">{s.area} • {s.reason}</p>
          </button>
        ))}
      </div>
    </div>
  );
};
