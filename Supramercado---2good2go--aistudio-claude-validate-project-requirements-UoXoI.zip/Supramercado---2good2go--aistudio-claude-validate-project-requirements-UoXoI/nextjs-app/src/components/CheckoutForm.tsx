'use client';

import { useState } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { useRouter } from 'next/navigation';

interface CheckoutFormProps {
  orderId: string;
  orderNumber: string;
  totalUSD: number;
}

export default function CheckoutForm({ orderId, orderNumber, totalUSD }: CheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const { error: submitError } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/order/success?orderId=${orderId}`,
        },
      });

      if (submitError) {
        setError(submitError.message || 'Error procesando el pago');
        setLoading(false);
      }
    } catch (err: any) {
      setError(err.message || 'Error inesperado');
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-4 mb-6">
        <div className="flex justify-between items-center mb-2">
          <span className="text-gray-700 font-medium">Orden:</span>
          <span className="text-gray-900 font-mono text-sm">{orderNumber}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-700 font-medium">Total:</span>
          <span className="text-2xl font-bold text-emerald-600">
            ${totalUSD.toFixed(2)} USD
          </span>
        </div>
      </div>

      <PaymentElement />

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full bg-emerald-600 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:bg-emerald-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? '⏳ Procesando...' : `💳 Pagar $${totalUSD.toFixed(2)} USD`}
      </button>

      <p className="text-xs text-gray-500 text-center">
        🔒 Pago seguro procesado por Stripe. Tu información está protegida.
      </p>
    </form>
  );
}
