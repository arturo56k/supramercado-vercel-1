'use client';

import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Activity, Globe, Zap, AlertCircle, ShieldCheck } from 'lucide-react';
import { useOrders } from './OrderContext';

export const NetworkHUD: React.FC = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [latency, setLatency] = useState<number | null>(null);
  const [apiStatus, setApiStatus] = useState<'OK' | 'SLOW' | 'ERROR'>('OK');
  const { cloudSync } = useOrders();

  useEffect(() => {
    const handleStatus = () => setIsOnline(navigator.onLine);
    window.addEventListener('online', handleStatus);
    window.addEventListener('offline', handleStatus);

    const checkLatency = async () => {
      const start = Date.now();
      try {
        await fetch('https://www.google.com/favicon.ico', { mode: 'no-cors' });
        const ms = Date.now() - start;
        setLatency(ms);
        setApiStatus(ms > 300 ? 'SLOW' : 'OK');
      } catch (e) {
        setApiStatus('ERROR');
      }
    };

    const interval = setInterval(checkLatency, 10000);
    checkLatency();

    return () => {
      window.removeEventListener('online', handleStatus);
      window.removeEventListener('offline', handleStatus);
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[300] pointer-events-none">
      <div className="bg-slate-900/80 backdrop-blur-xl border border-white/10 rounded-full px-4 py-2 flex items-center gap-4 shadow-2xl pointer-events-auto transition-all">
        <div className="flex items-center gap-2 border-r border-white/10 pr-4">
          {isOnline ? (
            <div className="flex items-center gap-1.5">
              <div className="flex gap-0.5 items-end h-3">
                <div className={`w-0.5 rounded-full bg-green-500 ${latency && latency < 100 ? 'h-3' : 'h-1.5'}`}></div>
                <div className={`w-0.5 rounded-full bg-green-500 ${latency && latency < 200 ? 'h-3' : 'h-2'}`}></div>
                <div className={`w-0.5 rounded-full bg-green-500 ${latency && latency < 300 ? 'h-3' : 'h-2.5'}`}></div>
              </div>
              <span className="text-[9px] font-black text-white uppercase tracking-widest">{latency ? `${latency}ms` : 'LTE'}</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-red-400">
              <WifiOff className="w-3 h-3" />
              <span className="text-[9px] font-black uppercase">Offline</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className={`w-3 h-3 ${apiStatus === 'OK' ? 'text-blue-400' : 'text-orange-400'}`} />
            <span className="text-[9px] font-black text-white/60 uppercase tracking-tighter">NY-RD Corridor</span>
          </div>
          <div className="flex items-center gap-1.5">
             <Activity className="w-3 h-3 text-green-500" />
             <span className="text-[9px] font-black text-white/60 uppercase tracking-tighter">Sync: {cloudSync.latencyMs}ms</span>
          </div>
        </div>
      </div>
    </div>
  );
};
