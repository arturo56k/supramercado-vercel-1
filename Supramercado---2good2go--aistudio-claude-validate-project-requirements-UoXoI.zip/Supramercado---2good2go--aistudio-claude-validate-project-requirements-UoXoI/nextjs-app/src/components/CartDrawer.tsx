'use client';

import React, { useState, useEffect } from 'react';
import { ShoppingCart, X, Trash2, ArrowRight, Info, AlertCircle, Clock } from 'lucide-react';
import { Product, Beneficiary } from '../types';
import { useOrders } from './OrderContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: { product: Product; qty: number }[];
  onRemove: (id: string) => void;
  onCheckout: () => void;
  selectedBeneficiary: Beneficiary | null;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, cartItems, onRemove, onCheckout, selectedBeneficiary }) => {
  const { calculateFinancials, reserveStock } = useOrders();
  const [timeLeft, setTimeLeft] = useState(600); // 10 mins

  useEffect(() => {
    if (isOpen && cartItems.length > 0) {
      cartItems.forEach(item => reserveStock(item.product.id));
      const timer = setInterval(() => setTimeLeft(prev => prev > 0 ? prev - 1 : 0), 1000);
      return () => clearInterval(timer);
    }
  }, [isOpen, cartItems.length]);

  const subtotalDOP = cartItems.reduce((acc, item) => acc + (item.product.basePriceDOP * item.qty), 0);
  const financials = calculateFinancials(subtotalDOP);

  if (!isOpen) return null;

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-[150] flex justify-end">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
        
        <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50">
          <div className="flex items-center gap-3">
            <ShoppingCart className="w-6 h-6 text-blue-700" />
            <h3 className="text-xl font-black text-slate-900">Carrito Supra</h3>
          </div>
          <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-xl border border-blue-100 text-blue-700 shadow-sm animate-pulse">
            <Clock className="w-4 h-4" />
            <span className="text-xs font-black">{formatTime(timeLeft)}</span>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 space-y-6">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
              <ShoppingCart className="w-16 h-16 mb-4" />
              <p className="font-black uppercase tracking-widest text-xs">El carrito está vacío</p>
            </div>
          ) : (
            <>
              <div className="p-4 bg-orange-50 border border-orange-100 rounded-2xl flex items-center gap-3">
                 <AlertCircle className="w-5 h-5 text-orange-600 shrink-0" />
                 <p className="text-[10px] font-bold text-orange-800 uppercase leading-relaxed">Inventario reservado. Completa el pago antes de que expire el tiempo.</p>
              </div>
              {cartItems.map((item) => (
                <div key={item.product.id} className="flex gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 group">
                  <img src={item.product.image} className="w-16 h-16 rounded-xl object-cover shadow-sm" />
                  <div className="flex-1">
                    <h4 className="font-bold text-sm text-slate-900">{item.product.name}</h4>
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cant: {item.qty}</p>
                    <p className="text-sm font-black text-blue-700 mt-1">RD$ {item.product.basePriceDOP.toLocaleString()}</p>
                  </div>
                  <button onClick={() => onRemove(item.product.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </>
          )}
        </div>

        {cartItems.length > 0 && (
          <div className="p-8 bg-white border-t border-slate-100 space-y-6">
            <div className="space-y-3">
              <div className="flex justify-between text-xs font-bold text-slate-500">
                <span>Subtotal Mercancía (DOP)</span>
                <span>RD$ {subtotalDOP.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs font-bold text-slate-500">
                <span>ITBIS (18%)</span>
                <span>RD$ {financials.itbisDOP.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs font-black text-blue-700 pt-3 border-t border-slate-200">
                <span className="uppercase tracking-widest">Total a Pagar (USD)</span>
                <span className="text-xl font-black">${financials.totalUSD.toFixed(2)}</span>
              </div>
            </div>
            <button 
              onClick={onCheckout}
              className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 shadow-xl hover:bg-blue-700 transition-all active:scale-95"
            >
              Confirmar y Pagar <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
