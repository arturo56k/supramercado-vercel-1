
export enum UserRole {
  CLIENT = 'CLIENT',
  BENEFICIARY = 'BENEFICIARY',
  MERCHANT_ADMIN = 'MERCHANT_ADMIN',
  MERCHANT_BRANCH_ADMIN = 'MERCHANT_BRANCH_ADMIN',
  MERCHANT_EMPLOYEE = 'MERCHANT_EMPLOYEE',
  SAAS_SUPPORT = 'SAAS_SUPPORT',
  SAAS_ADMIN = 'SAAS_ADMIN'
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  merchantId?: string;
  branchId?: string;
  joinedAt: string;
}

export type OrderStatus = 'PENDING' | 'CONFIRMED' | 'PREPARING' | 'READY_FOR_PICKUP' | 'PICKED_UP' | 'CANCELLED' | 'REDEEMED' | 'DISPUTED' | 'EXPIRED';

export interface Payout {
  id: string;
  amountDOP: number;
  status: 'PENDING' | 'SUCCESS' | 'FAILED';
  date: string;
  bankName: string;
  accountLast4: string;
  orderIds?: string[];
}

export interface Beneficiary {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  address: string;
  city: string;
  lat: number;
  lng: number;
  avatar: string;
}

export interface Merchant {
  id: string;
  name: string;
  logo: string;
  address: string;
  city: string;
  isOpen: boolean;
  closingTime: string;
  rating: number;
  categories: string[];
  category?: string;
  lat: number;
  lng: number;
  description: string;
  isVerified?: boolean;
  walletBalance?: number;
  stripeConnectedId?: string;
  hasIssuingCard?: boolean;
  status?: string;
  rnc?: string;
  locationName?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  priceUSD: number;
  basePriceDOP: number;
  image: string;
  merchantId: string;
  category: string;
  stock: number;
  type: 'INDIVIDUAL' | 'PACK' | 'SUBSCRIPTION' | 'PREDESIGNED_PACK';
  subscriptionFrequency?: 'WEEKLY' | 'MONTHLY';
  subscriptionDiscount?: number;
  originalPriceDOP?: number;
  isSuprabolsa?: boolean;
}

export interface Order {
  id: string;
  status: OrderStatus;
  buyerId: string;
  beneficiaryId: string;
  beneficiaryName?: string;
  items: string;
  totalUSD: number;
  subtotalUSD: number;
  exchangeRateUsed: number;
  merchantId: string;
  pickupCode: string;
  magicLinkCode: string;
  createdAt: string;
  expiresAt?: string;
  isSubscriptionInstance: boolean;
  hasReview?: boolean;
  verificationImage?: string;
  itemDetails?: { productId: string; qty: number }[];
  deliveryCoords?: { lat: number; lng: number };
  impactKg?: number;
  disputeReason?: string;
  payoutId?: string;
  ofacStatus?: 'PENDING' | 'APPROVED' | 'REJECTED';
  paymentIntentId?: string;
  paymentStatus: 'AUTHORIZED' | 'CAPTURED' | 'CANCELLED';
  platformFeeUSD?: number;
  merchantPayoutDOP?: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface FinancialConfig {
  supraCommissionPercent: number;
  exchangeRateMarginPercent: number;
  stripeFeePercent: number;
  stripeFixedFeeUSD: number;
  lastBpdRate: number;
  itbisPercent: number;
  isManualRate: boolean;
  manualRate?: number;
}

export interface OrderReview {
  id: string;
  orderId: string;
  rating: number;
  comment: string;
  date: string;
  beneficiaryName?: string;
}

export interface Subscription {
  id: string;
  merchantId: string;
  items: string;
  amountUSD: number;
  frequency: 'WEEKLY' | 'MONTHLY';
  nextBillingDate: string;
  status: 'ACTIVE' | 'PAUSED';
}

export interface SupportTicket {
  id: string;
  orderId: string;
  subject: string;
  status: 'OPEN' | 'IN_PROGRESS' | 'RESOLVED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  createdAt: string;
}

export interface WishlistItem {
  id: string;
  productName: string;
  urgency: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'PENDING' | 'ADDED';
}
